# ZenWood – Complete Launch Guide & Play Store Checklist

---

## STEP 1 — Firebase Setup (From Scratch)

### 1.1 Create Firebase Project
1. Go to https://console.firebase.google.com
2. Click "Add project" → Name it "ZenWood"
3. Enable Google Analytics → Select "Default Account for Firebase"
4. Click "Create project"

### 1.2 Add Android App
1. In Firebase Console → Project Overview → Add app → Android icon
2. Package name: `com.yourname.zenwood` (MUST match your app)
3. App nickname: ZenWood
4. Download `google-services.json`
5. Place it at: `android/app/google-services.json`

### 1.3 Add iOS App (if needed)
1. Add app → iOS icon
2. Bundle ID: `com.yourname.zenwood`
3. Download `GoogleService-Info.plist`
4. Place it at: `ios/Runner/GoogleService-Info.plist`

### 1.4 FlutterFire CLI Setup
```bash
dart pub global activate flutterfire_cli
flutterfire configure --project=your-firebase-project-id
```
This generates `lib/firebase_options.dart` automatically.

### 1.5 Enable Firebase Services
In Firebase Console, enable:
- ✅ Authentication → Email/Password + Google Sign-In
- ✅ Firestore Database → Start in Production Mode
- ✅ Cloud Functions → Upgrade to Blaze plan (required for functions)
- ✅ Analytics → Already enabled
- ✅ Remote Config → Create default parameters
- ✅ Cloud Messaging → For push notifications

### 1.6 Deploy Firestore Rules & Functions
```bash
firebase login
firebase init  # Select Firestore, Functions, Hosting
firebase deploy --only firestore:rules
cd functions && npm install && cd ..
firebase deploy --only functions
```

### 1.7 Remote Config Keys to Create
| Key | Default Value | Description |
|-----|--------------|-------------|
| `ads_enabled` | `true` | Master ad toggle |
| `interstitial_frequency` | `3` | Games between interstitials |
| `daily_reward_multiplier` | `1` | Multiply all daily rewards |
| `show_rewarded_ads` | `true` | Enable/disable rewarded ads |

---

## STEP 2 — AdMob Setup (From Scratch)

### 2.1 Create AdMob Account
1. Go to https://admob.google.com
2. Sign in with your Google account
3. Complete account setup → Provide payment info

### 2.2 Add Your App
1. Apps → Add App
2. Platform: Android → Is the app on Google Play? → No (first time)
3. App name: ZenWood
4. Copy your **AdMob App ID** (looks like `ca-app-pub-XXXXXXXX~YYYYYYYY`)

### 2.3 Create Ad Units
Create these 3 ad units in AdMob:

| Ad Unit | Type | Name |
|---------|------|------|
| Home screen | Banner | zenwood_home_banner |
| Game over | Interstitial | zenwood_gameover_inter |
| Revive/Coins | Rewarded | zenwood_rewarded |

Copy each **Ad Unit ID** for the next step.

### 2.4 Replace Test IDs with Real IDs
In `lib/core/constants/app_constants.dart`, replace:
```dart
// BEFORE (test IDs):
static const String admobAppIdAndroid = 'ca-app-pub-3940256099942544~3347511713';
static const String bannerAdUnitAndroid = 'ca-app-pub-3940256099942544/6300978111';
// etc.

// AFTER (your real IDs):
static const String admobAppIdAndroid = 'ca-app-pub-YOUR_ID~YOUR_APP_ID';
static const String bannerAdUnitAndroid = 'ca-app-pub-YOUR_ID/YOUR_BANNER_ID';
```

Also update in `android/app/src/main/AndroidManifest.xml`:
```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="YOUR_REAL_ADMOB_APP_ID"/>
```

### 2.5 AdMob + Google Play Policies
- ✅ Never click your own ads
- ✅ Never incentivize ad clicks
- ✅ Add privacy policy URL in AdMob dashboard
- ✅ Enable User Messaging Platform (UMP) for GDPR/consent

---

## STEP 3 — Google Play Setup

### 3.1 Developer Account
1. Go to https://play.google.com/console
2. Pay one-time $25 fee
3. Complete identity verification

### 3.2 Create App
1. All apps → Create app
2. App name: ZenWood: Classic Block Blast
3. Default language: English (United States)
4. App or game: Game
5. Free or paid: Free

### 3.3 App Content & Data Safety

**Data Safety Form (REQUIRED):**
| Data Type | Collected? | Shared? |
|-----------|-----------|---------|
| Name | Yes | No |
| Email | Yes | No |
| User IDs | Yes | No |
| App interactions | Yes | Yes (Firebase Analytics) |
| Crash logs | Yes | Yes (Crashlytics) |
| Financial info | Yes (purchases) | No |

**Content Rating:**
- Run the questionnaire → Game category
- No violence/nudity/etc → Will get "Everyone" rating

**Privacy Policy:**
- Create a page on GitHub Pages or your website
- Include: data collected, Firebase usage, AdMob, how to delete account
- URL example: `https://yourname.github.io/zenwood-privacy`

### 3.4 Store Listing
```
Short description (80 chars):
Place wooden blocks, clear lines & blast your way to the top score!

Full description (4000 chars):
ZenWood is the ultimate classic block blast puzzle game with a beautiful
wooden theme. Relax your mind while strategically placing blocks to clear
lines and earn massive scores.

🌿 FEATURES:
• Classic 8x8 grid gameplay
• Beautiful wooden theme with smooth animations
• Global leaderboard – compete with players worldwide
• Daily rewards & streak bonuses
• Power-ups: Undo, Shuffle, Bomb, Extra Slot, Revive
• Cloud save – your progress syncs everywhere
• Play offline anytime

🏆 HOW TO PLAY:
• Drag and drop blocks onto the board
• Fill complete rows or columns to blast them away
• Chain multiple clears for combo bonuses
• Game ends when no blocks can be placed

🎮 PREMIUM FEATURES:
• Remove all ads for uninterrupted play
• Monthly subscription with exclusive themes
• Bonus coin rewards for subscribers
```

### 3.5 Graphics Required
| Asset | Size | Notes |
|-------|------|-------|
| App icon | 512×512 PNG | No alpha |
| Feature graphic | 1024×500 PNG | Shown on Play Store |
| Phone screenshots | Min 2, max 8 | 1080×1920 or 1080×2340 |
| Tablet screenshots | Optional | 1200×1920 |

---

## STEP 4 — Build & Sign Release APK/AAB

### 4.1 Generate Signing Key
```bash
keytool -genkey -v -keystore ~/zenwood-release.keystore \
  -alias zenwood -keyalg RSA -keysize 2048 -validity 10000
```
**⚠️ KEEP THIS FILE SAFE – you cannot update your app without it!**

### 4.2 Configure Signing in Flutter
Create `android/key.properties`:
```properties
storePassword=YOUR_KEYSTORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=zenwood
storeFile=/path/to/zenwood-release.keystore
```

Add to `android/app/build.gradle`:
```groovy
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    ...
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

### 4.3 Build App Bundle (Required for Play Store)
```bash
flutter clean
flutter pub get
flutter build appbundle --release
```
Output: `build/app/outputs/bundle/release/app-release.aab`

### 4.4 ProGuard Rules
Add to `android/app/proguard-rules.pro`:
```
# Flutter
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }

# Firebase
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# AdMob
-keep public class com.google.android.gms.ads.** { public *; }

# In-App Purchases
-keep class com.android.vending.billing.** { *; }
```

---

## STEP 5 — Security Checklist

- [ ] No API keys or secrets in source code
- [ ] `google-services.json` in `.gitignore`
- [ ] `key.properties` in `.gitignore`
- [ ] `firebase_options.dart` – restrict API key in Google Cloud Console
- [ ] Firebase App Check enabled
- [ ] Firestore security rules deployed and tested
- [ ] Server-side score validation via Cloud Functions
- [ ] Purchase verification server-side only
- [ ] ProGuard/R8 enabled for release builds
- [ ] Certificate pinning for sensitive API calls

---

## STEP 6 — Play Store Submission Checklist

### Pre-submission
- [ ] App tested on min SDK (Android 5.0+) and latest Android
- [ ] All screens tested (splash, home, game, game over, leaderboard, settings, shop)
- [ ] Ads showing correctly (test vs real IDs confirmed)
- [ ] Purchases working in test mode
- [ ] Daily rewards working
- [ ] Offline mode working
- [ ] Cloud save working
- [ ] Sound/haptic working
- [ ] All animations smooth (60fps)
- [ ] No crashes in release build

### Play Console
- [ ] App signed with release keystore
- [ ] AAB uploaded to Internal Testing first
- [ ] Tested by 3+ testers via Internal Testing
- [ ] Content rating questionnaire complete
- [ ] Data safety form complete
- [ ] Privacy policy URL added
- [ ] Target SDK = latest (API 34+)
- [ ] Permissions explained in store listing
- [ ] All screenshots uploaded
- [ ] Feature graphic uploaded
- [ ] App icon uploaded (512×512)
- [ ] Short + full description written
- [ ] Category: Games > Puzzle

### After Approval
- [ ] Monitor crashes in Firebase Crashlytics
- [ ] Monitor ANRs in Play Console
- [ ] Set up Firebase Remote Config A/B tests
- [ ] Respond to user reviews
- [ ] Update keywords based on Play Store analytics

---

## MONETIZATION FLOW

```
User Opens App
     │
     ├── Banner Ad (Home Screen) ─────────────────────► Revenue
     │
     ▼
User Plays Game
     │
     ├── Game Over
     │      ├── Interstitial Ad (every 3 games) ──────► Revenue
     │      ├── Rewarded Ad (revive/coins) ─────────────► Revenue
     │      └── Prompt: Remove Ads / Premium ─────────► IAP Revenue
     │
     ├── Shop Screen
     │      ├── Remove Ads (₹199 one-time) ───────────► IAP Revenue
     │      ├── Coin Packs (₹49 / ₹179 / ₹349) ───────► IAP Revenue
     │      ├── Power Bundle (₹249) ─────────────────► IAP Revenue
     │      └── Premium Subscription (₹99/month) ────► Subscription Revenue
     │
     └── Daily Reward (retention) ──────────────────► User Retention
```

---

## ESTIMATED TIMELINE

| Phase | Duration |
|-------|----------|
| Firebase + AdMob setup | 1-2 days |
| Complete all screens | 3-5 days |
| Game logic polish | 2-3 days |
| Asset creation (icons, textures) | 2-3 days |
| Testing + bug fixes | 3-5 days |
| Play Store submission | 1-2 days |
| Review time (Google) | 3-7 days |
| **Total** | **~3-4 weeks** |
