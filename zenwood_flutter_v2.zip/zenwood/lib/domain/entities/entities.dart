import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

// ─── Block Entity ─────────────────────────────────────────────────────────────
class BlockEntity {
  final String id;
  final String shapeKey;
  final List<List<bool>> shape;
  final Color color;
  final Color shadowColor;
  final int rows;
  final int cols;

  const BlockEntity({
    required this.id,
    required this.shapeKey,
    required this.shape,
    required this.color,
    required this.shadowColor,
    required this.rows,
    required this.cols,
  });

  int get cellCount => shape.fold(0, (sum, row) => sum + row.where((c) => c).length);
}

// ─── Board Cell ───────────────────────────────────────────────────────────────
class BoardCell {
  final bool occupied;
  final Color? color;
  final String? blockId;
  final bool isClearing;

  const BoardCell({
    this.occupied = false,
    this.color,
    this.blockId,
    this.isClearing = false,
  });

  BoardCell copyWith({bool? occupied, Color? color, String? blockId, bool? isClearing}) {
    return BoardCell(
      occupied: occupied ?? this.occupied,
      color: color ?? this.color,
      blockId: blockId ?? this.blockId,
      isClearing: isClearing ?? this.isClearing,
    );
  }

  static const empty = BoardCell();
}

// ─── Game State ───────────────────────────────────────────────────────────────
enum GameStatus { idle, playing, paused, gameOver, won }

class GameState {
  final List<List<BoardCell>> board;
  final List<BlockEntity?> availableBlocks; // 3 slots
  final int score;
  final int bestScore;
  final int combo;
  final GameStatus status;
  final int coins;
  final int undosLeft;
  final int bombsLeft;
  final int shufflesLeft;
  final List<List<BoardCell>>? lastBoard; // for undo
  final List<BlockEntity?> lastBlocks;
  final int lastScore;

  const GameState({
    required this.board,
    required this.availableBlocks,
    this.score = 0,
    this.bestScore = 0,
    this.combo = 0,
    this.status = GameStatus.idle,
    this.coins = 0,
    this.undosLeft = 0,
    this.bombsLeft = 0,
    this.shufflesLeft = 0,
    this.lastBoard,
    this.lastBlocks = const [],
    this.lastScore = 0,
  });

  GameState copyWith({
    List<List<BoardCell>>? board,
    List<BlockEntity?>? availableBlocks,
    int? score,
    int? bestScore,
    int? combo,
    GameStatus? status,
    int? coins,
    int? undosLeft,
    int? bombsLeft,
    int? shufflesLeft,
    List<List<BoardCell>>? lastBoard,
    List<BlockEntity?>? lastBlocks,
    int? lastScore,
  }) {
    return GameState(
      board: board ?? this.board,
      availableBlocks: availableBlocks ?? this.availableBlocks,
      score: score ?? this.score,
      bestScore: bestScore ?? this.bestScore,
      combo: combo ?? this.combo,
      status: status ?? this.status,
      coins: coins ?? this.coins,
      undosLeft: undosLeft ?? this.undosLeft,
      bombsLeft: bombsLeft ?? this.bombsLeft,
      shufflesLeft: shufflesLeft ?? this.shufflesLeft,
      lastBoard: lastBoard ?? this.lastBoard,
      lastBlocks: lastBlocks ?? this.lastBlocks,
      lastScore: lastScore ?? this.lastScore,
    );
  }

  static GameState initial(int bestScore, int coins) {
    return GameState(
      board: List.generate(8, (_) => List.generate(8, (_) => const BoardCell())),
      availableBlocks: [null, null, null],
      bestScore: bestScore,
      coins: coins,
      status: GameStatus.idle,
    );
  }
}

// ─── User Entity ──────────────────────────────────────────────────────────────
class UserEntity {
  final String uid;
  final String displayName;
  final String? photoUrl;
  final int bestScore;
  final int totalCoins;
  final int gamesPlayed;
  final bool isPremium;
  final bool removeAds;
  final DateTime? premiumExpiry;
  final int rewardStreak;
  final DateTime? lastRewardDate;

  const UserEntity({
    required this.uid,
    required this.displayName,
    this.photoUrl,
    this.bestScore = 0,
    this.totalCoins = 0,
    this.gamesPlayed = 0,
    this.isPremium = false,
    this.removeAds = false,
    this.premiumExpiry,
    this.rewardStreak = 0,
    this.lastRewardDate,
  });

  Map<String, dynamic> toFirestore() => {
        'uid': uid,
        'displayName': displayName,
        'photoUrl': photoUrl,
        'bestScore': bestScore,
        'totalCoins': totalCoins,
        'gamesPlayed': gamesPlayed,
        'isPremium': isPremium,
        'removeAds': removeAds,
        'premiumExpiry': premiumExpiry?.toIso8601String(),
        'rewardStreak': rewardStreak,
        'lastRewardDate': lastRewardDate?.toIso8601String(),
      };

  factory UserEntity.fromFirestore(Map<String, dynamic> data) => UserEntity(
        uid: data['uid'] ?? '',
        displayName: data['displayName'] ?? 'Player',
        photoUrl: data['photoUrl'],
        bestScore: data['bestScore'] ?? 0,
        totalCoins: data['totalCoins'] ?? 0,
        gamesPlayed: data['gamesPlayed'] ?? 0,
        isPremium: data['isPremium'] ?? false,
        removeAds: data['removeAds'] ?? false,
        premiumExpiry: data['premiumExpiry'] != null
            ? DateTime.parse(data['premiumExpiry'])
            : null,
        rewardStreak: data['rewardStreak'] ?? 0,
        lastRewardDate: data['lastRewardDate'] != null
            ? DateTime.parse(data['lastRewardDate'])
            : null,
      );
}

// ─── Leaderboard Entry ────────────────────────────────────────────────────────
class LeaderboardEntry {
  final String uid;
  final String displayName;
  final String? photoUrl;
  final String country;
  final int score;
  final int rank;
  final bool isCurrentUser;

  const LeaderboardEntry({
    required this.uid,
    required this.displayName,
    this.photoUrl,
    required this.country,
    required this.score,
    required this.rank,
    this.isCurrentUser = false,
  });

  factory LeaderboardEntry.fromFirestore(Map<String, dynamic> data, String currentUid) =>
      LeaderboardEntry(
        uid: data['uid'] ?? '',
        displayName: data['displayName'] ?? 'Player',
        photoUrl: data['photoUrl'],
        country: data['country'] ?? 'IN',
        score: data['score'] ?? 0,
        rank: data['rank'] ?? 0,
        isCurrentUser: data['uid'] == currentUid,
      );
}

// ─── Settings Entity ──────────────────────────────────────────────────────────
class SettingsEntity {
  final bool soundEnabled;
  final bool musicEnabled;
  final bool vibrationEnabled;
  final bool hapticEnabled;
  final bool showOutline;
  final String theme; // 'dark' | 'light'
  final String dragSensitivity; // 'low' | 'medium' | 'high'

  const SettingsEntity({
    this.soundEnabled = true,
    this.musicEnabled = true,
    this.vibrationEnabled = true,
    this.hapticEnabled = true,
    this.showOutline = true,
    this.theme = 'dark',
    this.dragSensitivity = 'medium',
  });

  SettingsEntity copyWith({
    bool? soundEnabled,
    bool? musicEnabled,
    bool? vibrationEnabled,
    bool? hapticEnabled,
    bool? showOutline,
    String? theme,
    String? dragSensitivity,
  }) =>
      SettingsEntity(
        soundEnabled: soundEnabled ?? this.soundEnabled,
        musicEnabled: musicEnabled ?? this.musicEnabled,
        vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
        hapticEnabled: hapticEnabled ?? this.hapticEnabled,
        showOutline: showOutline ?? this.showOutline,
        theme: theme ?? this.theme,
        dragSensitivity: dragSensitivity ?? this.dragSensitivity,
      );
}

// ─── Shop Item ────────────────────────────────────────────────────────────────
class ShopItem {
  final String id;
  final String title;
  final String description;
  final String price;
  final String iconPath;
  final ShopItemType type;
  final int? coins;

  const ShopItem({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.iconPath,
    required this.type,
    this.coins,
  });
}

enum ShopItemType { removeAds, coinPack, powerBundle, subscription }
