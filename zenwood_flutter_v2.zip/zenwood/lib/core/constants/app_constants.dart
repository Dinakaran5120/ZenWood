class AppConstants {
  // Game Board
  static const int boardSize = 8;
  static const int blockSlots = 3;
  static const double cellSize = 40.0;
  static const double cellPadding = 2.0;

  // Score
  static const int scorePerCell = 10;
  static const int scorePerLine = 100;
  static const int comboMultiplier = 2;

  // Coins
  static const int coinsPerGame = 5;
  static const int coinsPerLineBlast = 10;
  static const int startingCoins = 100;

  // Power-up costs (coins)
  static const int undoCost = 20;
  static const int shuffleCost = 30;
  static const int bombCost = 50;
  static const int extraSlotCost = 40;
  static const int reviveCost = 100;

  // Daily Rewards (coins per day streak)
  static const List<int> dailyRewards = [10, 15, 20, 30, 40, 50, 100];

  // Ad frequency
  static const int interstitialFrequency = 3; // every N game overs
  static const int rewardAdCoins = 50;

  // Firestore collections
  static const String usersCollection = 'users';
  static const String leaderboardCollection = 'leaderboard';
  static const String weeklyLeaderboard = 'leaderboard_weekly';
  static const String dailyRewardsCollection = 'daily_rewards';

  // Hive boxes
  static const String settingsBox = 'settings';
  static const String gameStateBox = 'game_state';
  static const String scoresBox = 'scores';

  // SharedPrefs keys
  static const String prefSoundEnabled = 'sound_enabled';
  static const String prefMusicEnabled = 'music_enabled';
  static const String prefVibration = 'vibration_enabled';
  static const String prefTheme = 'theme';
  static const String prefDragSensitivity = 'drag_sensitivity';
  static const String prefShowOutline = 'show_outline';
  static const String prefHaptic = 'haptic_enabled';
  static const String prefRemoveAds = 'remove_ads';
  static const String prefCoins = 'coins';
  static const String prefBestScore = 'best_score';
  static const String prefLastRewardDate = 'last_reward_date';
  static const String prefRewardStreak = 'reward_streak';
  static const String prefGamesPlayed = 'games_played';

  // IAP product IDs
  static const String iapRemoveAds = 'zenwood_remove_ads';
  static const String iapCoins100 = 'zenwood_coins_100';
  static const String iapCoins500 = 'zenwood_coins_500';
  static const String iapCoins1200 = 'zenwood_coins_1200';
  static const String iapPowerBundle = 'zenwood_power_bundle';
  static const String subMonthly = 'zenwood_premium_monthly';

  // AdMob IDs (test IDs — replace with real ones before launch)
  static const String admobAppIdAndroid = 'ca-app-pub-3940256099942544~3347511713';
  static const String admobAppIdIos = 'ca-app-pub-3940256099942544~1458002511';
  static const String bannerAdUnitAndroid = 'ca-app-pub-3940256099942544/6300978111';
  static const String interstitialAdUnitAndroid = 'ca-app-pub-3940256099942544/1033173712';
  static const String rewardedAdUnitAndroid = 'ca-app-pub-3940256099942544/5224354917';
  static const String bannerAdUnitIos = 'ca-app-pub-3940256099942544/2934735716';
  static const String interstitialAdUnitIos = 'ca-app-pub-3940256099942544/4411468910';
  static const String rewardedAdUnitIos = 'ca-app-pub-3940256099942544/1712485313';

  // Animation durations
  static const Duration splashDuration = Duration(seconds: 3);
  static const Duration blockDropDuration = Duration(milliseconds: 200);
  static const Duration lineClearDuration = Duration(milliseconds: 500);
  static const Duration gameOverDuration = Duration(milliseconds: 800);
  static const Duration screenTransition = Duration(milliseconds: 300);
}

class BlockShapes {
  // All possible block shapes as List<List<bool>>
  static const Map<String, List<List<bool>>> shapes = {
    'single': [[true]],
    'domino_h': [[true, true]],
    'domino_v': [[true], [true]],
    'trio_h': [[true, true, true]],
    'trio_v': [[true], [true], [true]],
    'quad_h': [[true, true, true, true]],
    'quad_v': [[true], [true], [true], [true]],
    'penta_h': [[true, true, true, true, true]],
    'L_shape': [[true, false], [true, false], [true, true]],
    'L_mirror': [[false, true], [false, true], [true, true]],
    'J_shape': [[true, true], [true, false], [true, false]],
    'S_shape': [[false, true, true], [true, true, false]],
    'Z_shape': [[true, true, false], [false, true, true]],
    'T_shape': [[true, true, true], [false, true, false]],
    'square_2x2': [[true, true], [true, true]],
    'square_3x3': [[true, true, true], [true, true, true], [true, true, true]],
    'corner_br': [[true, false], [true, true]],
    'corner_bl': [[false, true], [true, true]],
    'corner_tr': [[true, true], [true, false]],
    'corner_tl': [[true, true], [false, true]],
    'plus': [[false, true, false], [true, true, true], [false, true, false]],
    'diag_1': [[true, false, false], [false, true, false], [false, false, true]],
  };
}
