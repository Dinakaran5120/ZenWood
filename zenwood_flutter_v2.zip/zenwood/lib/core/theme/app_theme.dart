import 'package:flutter/material.dart';

class AppColors {
  // Primary Wood Palette
  static const Color woodDark = Color(0xFF2D1A06);
  static const Color woodMid = Color(0xFF4A2C0A);
  static const Color woodLight = Color(0xFF7B4A1E);
  static const Color woodGrain = Color(0xFF603815);
  static const Color woodHighlight = Color(0xFF9B6434);

  // UI Colors
  static const Color goldPrimary = Color(0xFFD4A017);
  static const Color goldLight = Color(0xFFF5C842);
  static const Color goldDark = Color(0xFF9B7200);
  static const Color goldText = Color(0xFFFFE066);

  static const Color buttonBrown = Color(0xFF8B5E1A);
  static const Color buttonBrownDark = Color(0xFF5C3A0E);
  static const Color buttonBrownLight = Color(0xFFAA7B35);
  static const Color buttonGreen = Color(0xFF4CAF50);
  static const Color buttonGreenDark = Color(0xFF2E7D32);
  static const Color buttonRed = Color(0xFFC0392B);

  static const Color panelBg = Color(0xFF3D2009);
  static const Color panelBorder = Color(0xFF6B3F15);
  static const Color panelInner = Color(0xFF2A1505);

  // Block Colors
  static const Color blockOrange = Color(0xFFE8722A);
  static const Color blockBlue = Color(0xFF3B82F6);
  static const Color blockGreen = Color(0xFF22C55E);
  static const Color blockPurple = Color(0xFF8B5CF6);
  static const Color blockYellow = Color(0xFFF59E0B);
  static const Color blockRed = Color(0xFFEF4444);
  static const Color blockCyan = Color(0xFF06B6D4);
  static const Color blockPink = Color(0xFFEC4899);

  // Score Colors
  static const Color scoreGold = Color(0xFFFFD700);
  static const Color scoreSilver = Color(0xFFC0C0C0);
  static const Color scoreBronze = Color(0xFFCD7F32);

  // Text
  static const Color textPrimary = Color(0xFFFFF8E7);
  static const Color textSecondary = Color(0xFFD4A96A);
  static const Color textMuted = Color(0xFF8B6B3D);

  // Rank backgrounds
  static const Color rankGold = Color(0xFFFFD700);
  static const Color rankSilver = Color(0xFFC0C0C0);
  static const Color rankBronze = Color(0xFFCD7F32);
  static const Color rankHighlight = Color(0xFF4A7C28);
}

class AppTheme {
  static ThemeData get theme => ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'BodyFont',
        scaffoldBackgroundColor: AppColors.woodDark,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.goldPrimary,
          secondary: AppColors.buttonBrown,
          surface: AppColors.panelBg,
          background: AppColors.woodDark,
        ),
        textTheme: const TextTheme(
          displayLarge: TextStyle(
            fontFamily: 'GameFont',
            color: AppColors.goldText,
            fontSize: 48,
            letterSpacing: 2,
          ),
          displayMedium: TextStyle(
            fontFamily: 'GameFont',
            color: AppColors.goldText,
            fontSize: 32,
            letterSpacing: 1.5,
          ),
          headlineLarge: TextStyle(
            fontFamily: 'GameFont',
            color: AppColors.textPrimary,
            fontSize: 28,
            letterSpacing: 1,
          ),
          headlineMedium: TextStyle(
            fontFamily: 'GameFont',
            color: AppColors.textPrimary,
            fontSize: 22,
          ),
          titleLarge: TextStyle(
            fontFamily: 'BodyFont',
            color: AppColors.textPrimary,
            fontSize: 18,
            fontWeight: FontWeight.w700,
          ),
          bodyLarge: TextStyle(
            color: AppColors.textSecondary,
            fontSize: 16,
          ),
          bodyMedium: TextStyle(
            color: AppColors.textSecondary,
            fontSize: 14,
          ),
        ),
      );
}

class AppTextStyles {
  static const gameTitleHuge = TextStyle(
    fontFamily: 'GameFont',
    fontSize: 52,
    color: AppColors.goldText,
    letterSpacing: 3,
    shadows: [
      Shadow(color: Color(0xFF8B5E1A), offset: Offset(3, 3), blurRadius: 0),
      Shadow(color: Color(0xFF2D1A06), offset: Offset(5, 5), blurRadius: 4),
    ],
  );

  static const gameTitle = TextStyle(
    fontFamily: 'GameFont',
    fontSize: 36,
    color: AppColors.goldText,
    letterSpacing: 2,
    shadows: [
      Shadow(color: Color(0xFF8B5E1A), offset: Offset(2, 2), blurRadius: 0),
      Shadow(color: Color(0xFF2D1A06), offset: Offset(4, 4), blurRadius: 3),
    ],
  );

  static const scoreDisplay = TextStyle(
    fontFamily: 'GameFont',
    fontSize: 48,
    color: Colors.white,
    shadows: [
      Shadow(color: Color(0xFF8B5E1A), offset: Offset(2, 2), blurRadius: 0),
    ],
  );

  static const buttonLabel = TextStyle(
    fontFamily: 'GameFont',
    fontSize: 20,
    color: AppColors.goldText,
    letterSpacing: 1,
    shadows: [
      Shadow(color: Color(0xFF2D1A06), offset: Offset(1, 2), blurRadius: 2),
    ],
  );

  static const leaderboardName = TextStyle(
    fontFamily: 'BodyFont',
    fontSize: 16,
    color: AppColors.textPrimary,
    fontWeight: FontWeight.w700,
  );

  static const leaderboardScore = TextStyle(
    fontFamily: 'BodyFont',
    fontSize: 16,
    color: AppColors.textPrimary,
    fontWeight: FontWeight.w700,
  );

  static const settingsLabel = TextStyle(
    fontFamily: 'BodyFont',
    fontSize: 16,
    color: AppColors.textPrimary,
    fontWeight: FontWeight.w500,
  );

  static const sectionHeader = TextStyle(
    fontFamily: 'GameFont',
    fontSize: 14,
    color: AppColors.textSecondary,
    letterSpacing: 2,
  );
}
