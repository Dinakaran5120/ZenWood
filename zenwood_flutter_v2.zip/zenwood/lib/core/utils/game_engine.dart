import 'dart:math';
import 'package:flutter/material.dart';
import '../../domain/entities/entities.dart';
import '../../core/constants/app_constants.dart';
import '../theme/app_theme.dart';

class GameEngine {
  static final Random _random = Random();

  // ─── Block Generation ────────────────────────────────────────────────────
  static BlockEntity generateBlock() {
    final shapeKeys = BlockShapes.shapes.keys.toList();
    final key = shapeKeys[_random.nextInt(shapeKeys.length)];
    final shape = BlockShapes.shapes[key]!;
    final color = _randomBlockColor();
    return BlockEntity(
      id: DateTime.now().microsecondsSinceEpoch.toString() + _random.nextInt(9999).toString(),
      shapeKey: key,
      shape: shape,
      color: color,
      shadowColor: _shadowFor(color),
      rows: shape.length,
      cols: shape[0].length,
    );
  }

  static List<BlockEntity?> generateThreeBlocks() {
    return [generateBlock(), generateBlock(), generateBlock()];
  }

  static Color _randomBlockColor() {
    const colors = [
      AppColors.blockOrange,
      AppColors.blockBlue,
      AppColors.blockGreen,
      AppColors.blockPurple,
      AppColors.blockYellow,
      AppColors.blockRed,
      AppColors.blockCyan,
      AppColors.blockPink,
    ];
    return colors[_random.nextInt(colors.length)];
  }

  static Color _shadowFor(Color c) {
    return Color.fromARGB(255, (c.red * 0.6).toInt(), (c.green * 0.6).toInt(), (c.blue * 0.6).toInt());
  }

  // ─── Placement Validation ────────────────────────────────────────────────
  static bool canPlace(
    List<List<BoardCell>> board,
    BlockEntity block,
    int row,
    int col,
  ) {
    for (int r = 0; r < block.rows; r++) {
      for (int c = 0; c < block.cols; c++) {
        if (!block.shape[r][c]) continue;
        final boardRow = row + r;
        final boardCol = col + c;
        if (boardRow < 0 || boardRow >= AppConstants.boardSize) return false;
        if (boardCol < 0 || boardCol >= AppConstants.boardSize) return false;
        if (board[boardRow][boardCol].occupied) return false;
      }
    }
    return true;
  }

  // ─── Place Block ─────────────────────────────────────────────────────────
  static List<List<BoardCell>> placeBlock(
    List<List<BoardCell>> board,
    BlockEntity block,
    int row,
    int col,
  ) {
    final newBoard = board.map((r) => List<BoardCell>.from(r)).toList();
    for (int r = 0; r < block.rows; r++) {
      for (int c = 0; c < block.cols; c++) {
        if (!block.shape[r][c]) continue;
        newBoard[row + r][col + c] = BoardCell(
          occupied: true,
          color: block.color,
          blockId: block.id,
        );
      }
    }
    return newBoard;
  }

  // ─── Line Clearing ───────────────────────────────────────────────────────
  static LineClearResult checkAndClearLines(List<List<BoardCell>> board) {
    final newBoard = board.map((r) => List<BoardCell>.from(r)).toList();
    final clearedRows = <int>[];
    final clearedCols = <int>[];

    // Check rows
    for (int r = 0; r < AppConstants.boardSize; r++) {
      if (newBoard[r].every((cell) => cell.occupied)) {
        clearedRows.add(r);
      }
    }

    // Check columns
    for (int c = 0; c < AppConstants.boardSize; c++) {
      if (newBoard.every((row) => row[c].occupied)) {
        clearedCols.add(c);
      }
    }

    // Clear
    for (final r in clearedRows) {
      for (int c = 0; c < AppConstants.boardSize; c++) {
        newBoard[r][c] = const BoardCell();
      }
    }
    for (final c in clearedCols) {
      for (int r = 0; r < AppConstants.boardSize; r++) {
        newBoard[r][c] = const BoardCell();
      }
    }

    final linesCleared = clearedRows.length + clearedCols.length;
    final score = _calculateScore(linesCleared, clearedRows, clearedCols);

    return LineClearResult(
      board: newBoard,
      clearedRows: clearedRows,
      clearedCols: clearedCols,
      linesCleared: linesCleared,
      scoreGained: score,
    );
  }

  static int _calculateScore(int lines, List<int> rows, List<int> cols) {
    if (lines == 0) return 0;
    int base = lines * AppConstants.scorePerLine;
    // Combo bonus
    if (lines >= 2) base += (lines - 1) * 50;
    if (lines >= 4) base += 200; // Bonus for 4+ lines
    return base;
  }

  // ─── Game Over Check ─────────────────────────────────────────────────────
  static bool hasValidMove(List<List<BoardCell>> board, List<BlockEntity?> blocks) {
    for (final block in blocks) {
      if (block == null) continue;
      for (int r = 0; r < AppConstants.boardSize; r++) {
        for (int c = 0; c < AppConstants.boardSize; c++) {
          if (canPlace(board, block, r, c)) return true;
        }
      }
    }
    return false;
  }

  // ─── Board Density ───────────────────────────────────────────────────────
  static double boardDensity(List<List<BoardCell>> board) {
    int count = 0;
    for (final row in board) {
      for (final cell in row) {
        if (cell.occupied) count++;
      }
    }
    return count / (AppConstants.boardSize * AppConstants.boardSize);
  }

  // ─── Find Best Placement (hint) ──────────────────────────────────────────
  static PlacementHint? findBestPlacement(
    List<List<BoardCell>> board,
    BlockEntity block,
  ) {
    int bestScore = -1;
    int bestRow = -1;
    int bestCol = -1;

    for (int r = 0; r < AppConstants.boardSize; r++) {
      for (int c = 0; c < AppConstants.boardSize; c++) {
        if (!canPlace(board, block, r, c)) continue;
        final tempBoard = placeBlock(board, block, r, c);
        final result = checkAndClearLines(tempBoard);
        if (result.scoreGained > bestScore) {
          bestScore = result.scoreGained;
          bestRow = r;
          bestCol = c;
        }
      }
    }

    if (bestRow == -1) return null;
    return PlacementHint(row: bestRow, col: bestCol);
  }

  // ─── Bomb Power-up ───────────────────────────────────────────────────────
  static List<List<BoardCell>> applyBomb(
    List<List<BoardCell>> board,
    int centerRow,
    int centerCol,
    int radius,
  ) {
    final newBoard = board.map((r) => List<BoardCell>.from(r)).toList();
    for (int r = centerRow - radius; r <= centerRow + radius; r++) {
      for (int c = centerCol - radius; c <= centerCol + radius; c++) {
        if (r >= 0 && r < AppConstants.boardSize && c >= 0 && c < AppConstants.boardSize) {
          newBoard[r][c] = const BoardCell();
        }
      }
    }
    return newBoard;
  }
}

class LineClearResult {
  final List<List<BoardCell>> board;
  final List<int> clearedRows;
  final List<int> clearedCols;
  final int linesCleared;
  final int scoreGained;

  const LineClearResult({
    required this.board,
    required this.clearedRows,
    required this.clearedCols,
    required this.linesCleared,
    required this.scoreGained,
  });
}

class PlacementHint {
  final int row;
  final int col;
  const PlacementHint({required this.row, required this.col});
}
