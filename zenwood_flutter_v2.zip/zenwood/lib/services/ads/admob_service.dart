// ════════════════════════════════════════════════════════
//  services/ads/admob_service.dart
// ════════════════════════════════════════════════════════
import 'dart:io';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../../core/constants/app_constants.dart';

class AdMobService {
  static AdMobService? _instance;
  static AdMobService get instance => _instance ??= AdMobService._();
  AdMobService._();

  BannerAd? _bannerAd;
  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;

  bool _isInterstitialLoaded = false;
  bool _isRewardedLoaded = false;

  // ─── Ad Unit IDs ─────────────────────────────────────────────────────────
  String get bannerAdUnitId => Platform.isAndroid
      ? AppConstants.bannerAdUnitAndroid
      : AppConstants.bannerAdUnitIos;

  String get interstitialAdUnitId => Platform.isAndroid
      ? AppConstants.interstitialAdUnitAndroid
      : AppConstants.interstitialAdUnitIos;

  String get rewardedAdUnitId => Platform.isAndroid
      ? AppConstants.rewardedAdUnitAndroid
      : AppConstants.rewardedAdUnitIos;

  // ─── Initialize ────────────────────────────────────────────────────────────
  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    loadInterstitial();
    loadRewarded();
  }

  // ─── Banner ────────────────────────────────────────────────────────────────
  BannerAd createBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) => print('Banner loaded'),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Banner failed: $error');
        },
      ),
    )..load();
    return _bannerAd!;
  }

  void disposeBanner() {
    _bannerAd?.dispose();
    _bannerAd = null;
  }

  // ─── Interstitial ──────────────────────────────────────────────────────────
  void loadInterstitial() {
    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialLoaded = true;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              _isInterstitialLoaded = false;
              loadInterstitial(); // Preload next
            },
            onAdFailedToShowFullScreenContent: (ad, error) {
              ad.dispose();
              _isInterstitialLoaded = false;
            },
          );
        },
        onAdFailedToLoad: (error) {
          print('Interstitial failed: $error');
          _isInterstitialLoaded = false;
        },
      ),
    );
  }

  void showInterstitial() {
    if (_isInterstitialLoaded && _interstitialAd != null) {
      _interstitialAd!.show();
    }
  }

  // ─── Rewarded ──────────────────────────────────────────────────────────────
  void loadRewarded() {
    RewardedAd.load(
      adUnitId: rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _isRewardedLoaded = true;
        },
        onAdFailedToLoad: (error) {
          print('Rewarded failed: $error');
          _isRewardedLoaded = false;
        },
      ),
    );
  }

  void showRewarded({required Function(int coins) onRewarded}) {
    if (!_isRewardedLoaded || _rewardedAd == null) return;
    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _isRewardedLoaded = false;
        loadRewarded();
      },
    );
    _rewardedAd!.show(onUserEarnedReward: (_, reward) {
      onRewarded(AppConstants.rewardAdCoins);
    });
  }

  bool get isRewardedReady => _isRewardedLoaded;
}
