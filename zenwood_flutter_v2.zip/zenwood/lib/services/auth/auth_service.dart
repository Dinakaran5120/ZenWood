import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/entities.dart';
import '../../core/constants/app_constants.dart';

class AuthService {
  static AuthService? _instance;
  static AuthService get instance => _instance ??= AuthService._();
  AuthService._();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;
  bool get isLoggedIn => currentUser != null && !currentUser!.isAnonymous;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ─── Google Sign In ───────────────────────────────────────────────────────
  Future<UserEntity?> signInWithGoogle() async {
    try {
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null;

      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCred = await _auth.signInWithCredential(credential);
      return await _upsertUser(userCred.user!);
    } catch (e) {
      print('Google sign in error: $e');
      return null;
    }
  }

  // ─── Email/Password ───────────────────────────────────────────────────────
  Future<UserEntity?> signInWithEmail(String email, String password) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      return await _getUser(cred.user!.uid);
    } on FirebaseAuthException catch (e) {
      throw _mapAuthError(e);
    }
  }

  Future<UserEntity?> registerWithEmail(
      String email, String password, String displayName) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      await cred.user!.updateDisplayName(displayName);
      return await _upsertUser(cred.user!);
    } on FirebaseAuthException catch (e) {
      throw _mapAuthError(e);
    }
  }

  // ─── Anonymous (play without account) ────────────────────────────────────
  Future<UserEntity?> signInAnonymously() async {
    try {
      final cred = await _auth.signInAnonymously();
      return UserEntity(
        uid: cred.user!.uid,
        displayName: 'Guest',
      );
    } catch (e) {
      return null;
    }
  }

  // ─── Sign Out ─────────────────────────────────────────────────────────────
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }

  // ─── Firestore user ops ───────────────────────────────────────────────────
  Future<UserEntity?> _upsertUser(User firebaseUser) async {
    final ref = _db
        .collection(AppConstants.usersCollection)
        .doc(firebaseUser.uid);

    final doc = await ref.get();
    if (!doc.exists) {
      final newUser = UserEntity(
        uid: firebaseUser.uid,
        displayName: firebaseUser.displayName ?? 'Player',
        photoUrl: firebaseUser.photoURL,
      );
      await ref.set(newUser.toFirestore());
      return newUser;
    }
    return UserEntity.fromFirestore(doc.data()!);
  }

  Future<UserEntity?> _getUser(String uid) async {
    final doc = await _db
        .collection(AppConstants.usersCollection)
        .doc(uid)
        .get();
    if (!doc.exists) return null;
    return UserEntity.fromFirestore(doc.data()!);
  }

  Future<void> updateUserScore(String uid, int score) async {
    await _db.collection(AppConstants.usersCollection).doc(uid).update({
      'bestScore': score,
    });
  }

  // ─── Cloud Save / Restore ─────────────────────────────────────────────────
  Future<void> saveProgress({
    required String uid,
    required int bestScore,
    required int coins,
  }) async {
    await _db.collection(AppConstants.usersCollection).doc(uid).update({
      'bestScore': bestScore,
      'totalCoins': coins,
      'lastSyncAt': FieldValue.serverTimestamp(),
    });
  }

  Future<Map<String, dynamic>?> restoreProgress(String uid) async {
    final doc = await _db
        .collection(AppConstants.usersCollection)
        .doc(uid)
        .get();
    if (!doc.exists) return null;
    return {
      'bestScore': doc.data()!['bestScore'] ?? 0,
      'coins': doc.data()!['totalCoins'] ?? 0,
    };
  }

  String _mapAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'email-already-in-use':
        return 'Email already registered.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'invalid-email':
        return 'Invalid email address.';
      default:
        return 'Authentication failed. Please try again.';
    }
  }
}
