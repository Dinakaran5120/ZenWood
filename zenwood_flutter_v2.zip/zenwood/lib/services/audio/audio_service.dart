import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../presentation/providers/providers.dart';

class AudioService {
  static AudioService? _instance;
  static AudioService get instance => _instance ??= AudioService._();
  AudioService._();

  final AudioPlayer _sfxPlayer = AudioPlayer();
  final AudioPlayer _musicPlayer = AudioPlayer();

  bool _soundEnabled = true;
  bool _musicEnabled = true;

  void configure({required bool sound, required bool music}) {
    _soundEnabled = sound;
    _musicEnabled = music;
  }

  // ─── Sound Effects ────────────────────────────────────────────────────────
  Future<void> playClick() async {
    if (!_soundEnabled) return;
    await _sfxPlayer.play(AssetSource('sounds/click.mp3'), volume: 0.7);
  }

  Future<void> playBlockDrop() async {
    if (!_soundEnabled) return;
    await _sfxPlayer.play(AssetSource('sounds/block_drop.mp3'), volume: 0.8);
  }

  Future<void> playBlast() async {
    if (!_soundEnabled) return;
    await _sfxPlayer.play(AssetSource('sounds/blast.mp3'), volume: 1.0);
  }

  Future<void> playCombo() async {
    if (!_soundEnabled) return;
    await _sfxPlayer.play(AssetSource('sounds/combo.mp3'), volume: 0.9);
  }

  Future<void> playGameOver() async {
    if (!_soundEnabled) return;
    await _sfxPlayer.play(AssetSource('sounds/game_over.mp3'), volume: 0.9);
  }

  Future<void> playWin() async {
    if (!_soundEnabled) return;
    await _sfxPlayer.play(AssetSource('sounds/win.mp3'), volume: 1.0);
  }

  Future<void> playNewBest() async {
    if (!_soundEnabled) return;
    await _sfxPlayer.play(AssetSource('sounds/new_best.mp3'), volume: 1.0);
  }

  Future<void> playReward() async {
    if (!_soundEnabled) return;
    await _sfxPlayer.play(AssetSource('sounds/reward.mp3'), volume: 0.8);
  }

  // ─── Background Music ─────────────────────────────────────────────────────
  Future<void> startMusic() async {
    if (!_musicEnabled) return;
    await _musicPlayer.setReleaseMode(ReleaseMode.loop);
    await _musicPlayer.play(AssetSource('sounds/bg_music.mp3'), volume: 0.3);
  }

  Future<void> stopMusic() async {
    await _musicPlayer.stop();
  }

  Future<void> pauseMusic() async {
    await _musicPlayer.pause();
  }

  Future<void> resumeMusic() async {
    if (!_musicEnabled) return;
    await _musicPlayer.resume();
  }

  void setSoundEnabled(bool v) {
    _soundEnabled = v;
    if (!v) _sfxPlayer.stop();
  }

  void setMusicEnabled(bool v) {
    _musicEnabled = v;
    if (v) {
      startMusic();
    } else {
      stopMusic();
    }
  }

  void dispose() {
    _sfxPlayer.dispose();
    _musicPlayer.dispose();
  }
}

// ─── Audio Provider ────────────────────────────────────────────────────────
final audioServiceProvider = Provider<AudioService>((ref) {
  final settings = ref.watch(settingsProvider);
  final audio = AudioService.instance;
  audio.configure(
    sound: settings.soundEnabled,
    music: settings.musicEnabled,
  );
  return audio;
});
