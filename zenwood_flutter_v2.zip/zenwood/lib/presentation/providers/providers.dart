import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../domain/entities/entities.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/game_engine.dart';

// ─── SharedPreferences Provider ──────────────────────────────────────────────
final sharedPrefsProvider = Provider<SharedPreferences>((ref) {
  throw UnimplementedError('Initialize in main.dart');
});

// ─── Settings Provider ────────────────────────────────────────────────────────
class SettingsNotifier extends StateNotifier<SettingsEntity> {
  final SharedPreferences _prefs;

  SettingsNotifier(this._prefs) : super(const SettingsEntity()) {
    _load();
  }

  void _load() {
    state = SettingsEntity(
      soundEnabled: _prefs.getBool(AppConstants.prefSoundEnabled) ?? true,
      musicEnabled: _prefs.getBool(AppConstants.prefMusicEnabled) ?? true,
      vibrationEnabled: _prefs.getBool(AppConstants.prefVibration) ?? true,
      hapticEnabled: _prefs.getBool(AppConstants.prefHaptic) ?? true,
      showOutline: _prefs.getBool(AppConstants.prefShowOutline) ?? true,
      theme: _prefs.getString(AppConstants.prefTheme) ?? 'dark',
      dragSensitivity: _prefs.getString(AppConstants.prefDragSensitivity) ?? 'medium',
    );
  }

  Future<void> toggleSound() async {
    final v = !state.soundEnabled;
    state = state.copyWith(soundEnabled: v);
    await _prefs.setBool(AppConstants.prefSoundEnabled, v);
  }

  Future<void> toggleMusic() async {
    final v = !state.musicEnabled;
    state = state.copyWith(musicEnabled: v);
    await _prefs.setBool(AppConstants.prefMusicEnabled, v);
  }

  Future<void> toggleVibration() async {
    final v = !state.vibrationEnabled;
    state = state.copyWith(vibrationEnabled: v);
    await _prefs.setBool(AppConstants.prefVibration, v);
  }

  Future<void> toggleHaptic() async {
    final v = !state.hapticEnabled;
    state = state.copyWith(hapticEnabled: v);
    await _prefs.setBool(AppConstants.prefHaptic, v);
  }

  Future<void> toggleOutline() async {
    final v = !state.showOutline;
    state = state.copyWith(showOutline: v);
    await _prefs.setBool(AppConstants.prefShowOutline, v);
  }

  Future<void> setTheme(String t) async {
    state = state.copyWith(theme: t);
    await _prefs.setString(AppConstants.prefTheme, t);
  }

  Future<void> setDragSensitivity(String s) async {
    state = state.copyWith(dragSensitivity: s);
    await _prefs.setString(AppConstants.prefDragSensitivity, s);
  }
}

final settingsProvider = StateNotifierProvider<SettingsNotifier, SettingsEntity>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  return SettingsNotifier(prefs);
});

// ─── Game Provider ────────────────────────────────────────────────────────────
class GameNotifier extends StateNotifier<GameState> {
  final SharedPreferences _prefs;
  Timer? _syncTimer;

  GameNotifier(this._prefs)
      : super(GameState.initial(
          0,
          AppConstants.startingCoins,
        )) {
    _loadSavedData();
  }

  void _loadSavedData() {
    final bestScore = _prefs.getInt(AppConstants.prefBestScore) ?? 0;
    final coins = _prefs.getInt(AppConstants.prefCoins) ?? AppConstants.startingCoins;
    state = GameState.initial(bestScore, coins);
  }

  // Start new game
  void startGame() {
    final blocks = GameEngine.generateThreeBlocks();
    state = state.copyWith(
      board: List.generate(8, (_) => List.generate(8, (_) => const BoardCell())),
      availableBlocks: blocks,
      score: 0,
      combo: 0,
      status: GameStatus.playing,
      undosLeft: 1,
      bombsLeft: state.coins >= AppConstants.bombCost ? 1 : 0,
    );
  }

  // Try placing a block
  bool tryPlaceBlock(int blockIndex, int row, int col) {
    final block = state.availableBlocks[blockIndex];
    if (block == null) return false;
    if (state.status != GameStatus.playing) return false;

    if (!GameEngine.canPlace(state.board, block, row, col)) return false;

    // Save state for undo
    final prevBoard = state.board.map((r) => List<BoardCell>.from(r)).toList();
    final prevBlocks = List<BlockEntity?>.from(state.availableBlocks);
    final prevScore = state.score;

    // Place block
    var newBoard = GameEngine.placeBlock(state.board, block, row, col);
    var scoreGained = block.cellCount * AppConstants.scorePerCell;

    // Check line clears
    final clearResult = GameEngine.checkAndClearLines(newBoard);
    newBoard = clearResult.board;
    scoreGained += clearResult.scoreGained;

    // Update available blocks
    final newBlocks = List<BlockEntity?>.from(state.availableBlocks);
    newBlocks[blockIndex] = null;

    // Regenerate if all used
    final allUsed = newBlocks.every((b) => b == null);
    if (allUsed) {
      final fresh = GameEngine.generateThreeBlocks();
      newBlocks[0] = fresh[0];
      newBlocks[1] = fresh[1];
      newBlocks[2] = fresh[2];
    }

    final newScore = state.score + scoreGained;
    final newBest = newScore > state.bestScore ? newScore : state.bestScore;
    final newCombo = clearResult.linesCleared > 0 ? state.combo + 1 : 0;

    // Check game over
    final gameOver = !GameEngine.hasValidMove(newBoard, newBlocks);

    state = state.copyWith(
      board: newBoard,
      availableBlocks: newBlocks,
      score: newScore,
      bestScore: newBest,
      combo: newCombo,
      status: gameOver ? GameStatus.gameOver : GameStatus.playing,
      lastBoard: prevBoard,
      lastBlocks: prevBlocks,
      lastScore: prevScore,
    );

    // Save best score
    if (newBest > (_prefs.getInt(AppConstants.prefBestScore) ?? 0)) {
      _prefs.setInt(AppConstants.prefBestScore, newBest);
    }

    return true;
  }

  // Undo move
  bool undoMove() {
    if (state.undosLeft <= 0 || state.lastBoard == null) return false;
    state = state.copyWith(
      board: state.lastBoard,
      availableBlocks: state.lastBlocks,
      score: state.lastScore,
      undosLeft: state.undosLeft - 1,
      status: GameStatus.playing,
    );
    return true;
  }

  // Bomb power-up
  void applyBomb(int row, int col) {
    if (state.bombsLeft <= 0) return;
    final newBoard = GameEngine.applyBomb(state.board, row, col, 1);
    state = state.copyWith(
      board: newBoard,
      bombsLeft: state.bombsLeft - 1,
    );
  }

  // Shuffle blocks
  void shuffleBlocks() {
    if (state.coins < AppConstants.shuffleCost) return;
    final newBlocks = GameEngine.generateThreeBlocks();
    state = state.copyWith(
      availableBlocks: newBlocks,
      coins: state.coins - AppConstants.shuffleCost,
    );
    _prefs.setInt(AppConstants.prefCoins, state.coins);
  }

  // Add coins
  void addCoins(int amount) {
    final newCoins = state.coins + amount;
    state = state.copyWith(coins: newCoins);
    _prefs.setInt(AppConstants.prefCoins, newCoins);
  }

  // Spend coins
  bool spendCoins(int amount) {
    if (state.coins < amount) return false;
    final newCoins = state.coins - amount;
    state = state.copyWith(coins: newCoins);
    _prefs.setInt(AppConstants.prefCoins, newCoins);
    return true;
  }

  // Pause/resume
  void togglePause() {
    if (state.status == GameStatus.playing) {
      state = state.copyWith(status: GameStatus.paused);
    } else if (state.status == GameStatus.paused) {
      state = state.copyWith(status: GameStatus.playing);
    }
  }

  // Revive (after game over)
  bool revive() {
    if (!spendCoins(AppConstants.reviveCost)) return false;
    // Remove some cells to give player space
    final board = state.board.map((r) => List<BoardCell>.from(r)).toList();
    // Clear bottom 2 rows
    for (int r = 6; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        board[r][c] = const BoardCell();
      }
    }
    final newBlocks = GameEngine.generateThreeBlocks();
    state = state.copyWith(
      board: board,
      availableBlocks: newBlocks,
      status: GameStatus.playing,
    );
    return true;
  }

  @override
  void dispose() {
    _syncTimer?.cancel();
    super.dispose();
  }
}

final gameProvider = StateNotifierProvider<GameNotifier, GameState>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  return GameNotifier(prefs);
});

// ─── Coins Provider ───────────────────────────────────────────────────────────
final coinsProvider = Provider<int>((ref) {
  return ref.watch(gameProvider).coins;
});

// ─── Best Score Provider ──────────────────────────────────────────────────────
final bestScoreProvider = Provider<int>((ref) {
  return ref.watch(gameProvider).bestScore;
});

// ─── Games Played Provider (for ad frequency) ─────────────────────────────────
final gamesPlayedProvider = StateProvider<int>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  return prefs.getInt(AppConstants.prefGamesPlayed) ?? 0;
});

// ─── Remove Ads Provider ──────────────────────────────────────────────────────
final removeAdsProvider = StateProvider<bool>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  return prefs.getBool(AppConstants.prefRemoveAds) ?? false;
});

// ─── Daily Reward Provider ────────────────────────────────────────────────────
class DailyRewardNotifier extends StateNotifier<DailyRewardState> {
  final SharedPreferences _prefs;

  DailyRewardNotifier(this._prefs) : super(DailyRewardState.initial()) {
    _check();
  }

  void _check() {
    final lastDateStr = _prefs.getString(AppConstants.prefLastRewardDate);
    final streak = _prefs.getInt(AppConstants.prefRewardStreak) ?? 0;
    final now = DateTime.now();

    if (lastDateStr == null) {
      state = DailyRewardState(canClaim: true, streak: 0, nextRewardAt: now);
      return;
    }

    final lastDate = DateTime.parse(lastDateStr);
    final diff = now.difference(lastDate).inHours;

    if (diff >= 24) {
      // New streak or broken streak
      final newStreak = diff < 48 ? streak + 1 : 0;
      state = DailyRewardState(canClaim: true, streak: newStreak, nextRewardAt: now);
    } else {
      // Not yet
      state = DailyRewardState(
        canClaim: false,
        streak: streak,
        nextRewardAt: lastDate.add(const Duration(hours: 24)),
      );
    }
  }

  Future<int> claimReward() async {
    if (!state.canClaim) return 0;
    final rewardIdx = state.streak % AppConstants.dailyRewards.length;
    final reward = AppConstants.dailyRewards[rewardIdx];
    final now = DateTime.now();
    await _prefs.setString(AppConstants.prefLastRewardDate, now.toIso8601String());
    await _prefs.setInt(AppConstants.prefRewardStreak, state.streak + 1);
    state = DailyRewardState(
      canClaim: false,
      streak: state.streak + 1,
      nextRewardAt: now.add(const Duration(hours: 24)),
    );
    return reward;
  }
}

class DailyRewardState {
  final bool canClaim;
  final int streak;
  final DateTime nextRewardAt;

  const DailyRewardState({
    required this.canClaim,
    required this.streak,
    required this.nextRewardAt,
  });

  static DailyRewardState initial() => DailyRewardState(
        canClaim: false,
        streak: 0,
        nextRewardAt: DateTime.now(),
      );
}

final dailyRewardProvider =
    StateNotifierProvider<DailyRewardNotifier, DailyRewardState>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  return DailyRewardNotifier(prefs);
});
