import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../widgets/common/common_widgets.dart';
import '../home/home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  double _progress = 0.0;
  late AnimationController _progressController;
  late AnimationController _logoController;

  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _progressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..addListener(() {
        setState(() => _progress = _progressController.value);
      });

    _startLoading();
  }

  Future<void> _startLoading() async {
    await Future.delayed(const Duration(milliseconds: 400));
    _progressController.forward();
    await Future.delayed(const Duration(milliseconds: 3200));
    if (mounted) {
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, animation, __) => const HomeScreen(),
          transitionsBuilder: (_, animation, __, child) =>
              FadeTransition(opacity: animation, child: child),
          transitionDuration: const Duration(milliseconds: 500),
        ),
      );
    }
  }

  @override
  void dispose() {
    _progressController.dispose();
    _logoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: WoodBackground(
        baseColor: AppColors.woodMid,
        child: SafeArea(
          child: Stack(
            children: [
              // Leaf decorations - top left
              Positioned(
                top: -10,
                left: -10,
                child: Image.asset(
                  'assets/images/leaf_cluster.png',
                  width: 120,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => _buildLeafFallback(true),
                ),
              ),
              // Leaf decorations - top right
              Positioned(
                top: -10,
                right: -10,
                child: Transform.flip(
                  flipX: true,
                  child: Image.asset(
                    'assets/images/leaf_cluster.png',
                    width: 120,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => _buildLeafFallback(false),
                  ),
                ),
              ),
              // Main content
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Logo blocks
                    _LogoBlocks()
                        .animate()
                        .slideY(begin: -0.3, duration: 600.ms, curve: Curves.elasticOut)
                        .fadeIn(duration: 400.ms),

                    const SizedBox(height: 8),

                    // ZENWOOD title
                    Text(
                      'ZENWOOD',
                      style: AppTextStyles.gameTitleHuge,
                    )
                        .animate()
                        .fadeIn(delay: 200.ms, duration: 600.ms)
                        .scale(begin: const Offset(0.8, 0.8)),

                    const SizedBox(height: 6),

                    // Subtitle banner
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.buttonBrownDark,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.goldDark, width: 1.5),
                      ),
                      child: const Text(
                        'CLASSIC BLOCK BLAST',
                        style: TextStyle(
                          fontFamily: 'GameFont',
                          fontSize: 14,
                          color: AppColors.textSecondary,
                          letterSpacing: 2,
                        ),
                      ),
                    ).animate().fadeIn(delay: 400.ms, duration: 400.ms),

                    const SizedBox(height: 60),

                    // Ornamental divider
                    _OrnamentDivider()
                        .animate()
                        .fadeIn(delay: 600.ms, duration: 400.ms),

                    const SizedBox(height: 12),

                    // Tagline
                    const Text(
                      'Relax. Strategize. Blast!',
                      style: TextStyle(
                        fontFamily: 'BodyFont',
                        fontSize: 18,
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w400,
                      ),
                    ).animate().fadeIn(delay: 700.ms, duration: 400.ms),

                    const SizedBox(height: 6),

                    _OrnamentDivider()
                        .animate()
                        .fadeIn(delay: 600.ms, duration: 400.ms),

                    const SizedBox(height: 60),

                    // Loading
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 60),
                      child: Column(
                        children: [
                          const Text(
                            'Loading...',
                            style: TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 16,
                              fontFamily: 'BodyFont',
                            ),
                          ),
                          const SizedBox(height: 10),
                          WoodLoadingBar(progress: _progress),
                          const SizedBox(height: 8),
                          Text(
                            '${(_progress * 100).toInt()}%',
                            style: const TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 14,
                              fontFamily: 'BodyFont',
                            ),
                          ),
                        ],
                      ),
                    ).animate().fadeIn(delay: 800.ms, duration: 400.ms),
                  ],
                ),
              ),
              // Sparkle bottom right
              const Positioned(
                bottom: 20,
                right: 20,
                child: Icon(Icons.star_four_points_rounded,
                    color: AppColors.textMuted, size: 20),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLeafFallback(bool isLeft) {
    return const SizedBox(width: 80, height: 100);
  }
}

class _LogoBlocks extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      child: Image.asset(
        'assets/images/logo_blocks.png',
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => _buildFallbackBlocks(),
      ),
    );
  }

  Widget _buildFallbackBlocks() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _block(60, AppColors.blockOrange),
        const SizedBox(width: 4),
        Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            _block(30, AppColors.blockOrange),
            const SizedBox(height: 4),
            _block(30, AppColors.blockOrange),
          ],
        ),
      ],
    );
  }

  Widget _block(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.5), width: 2),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.4),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
        image: const DecorationImage(
          image: AssetImage('assets/images/wood_block.png'),
          fit: BoxFit.cover,
          opacity: 0.5,
        ),
      ),
    );
  }
}

class _OrnamentDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(width: 40, height: 1, color: AppColors.woodGrain),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          width: 8,
          height: 8,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.woodGrain,
          ),
        ),
        const Icon(Icons.star, color: AppColors.textMuted, size: 14),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          width: 8,
          height: 8,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.woodGrain,
          ),
        ),
        Container(width: 40, height: 1, color: AppColors.woodGrain),
      ],
    );
  }
}
