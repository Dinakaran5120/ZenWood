// ─── SHOP SCREEN ─────────────────────────────────────────────────────────────
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_theme.dart';
import '../../widgets/common/common_widgets.dart';
import '../../providers/providers.dart';

class ShopScreen extends ConsumerWidget {
  const ShopScreen({super.key});

  static const _coinPacks = [
    {'label': '100 Coins', 'price': '₹49', 'coins': 100, 'icon': '🪙', 'id': 'zenwood_coins_100'},
    {'label': '500 Coins', 'price': '₹179', 'coins': 500, 'icon': '💰', 'id': 'zenwood_coins_500', 'badge': 'POPULAR'},
    {'label': '1200 Coins', 'price': '₹349', 'coins': 1200, 'icon': '💎', 'id': 'zenwood_coins_1200', 'badge': 'BEST VALUE'},
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final coins = ref.watch(coinsProvider);

    return Scaffold(
      body: WoodBackground(
        child: SafeArea(
          child: Column(
            children: [
              // ─── Header ──────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(
                  children: [
                    const WoodBackButton(),
                    const Spacer(),
                    const Text('SHOP',
                        style: TextStyle(
                          fontFamily: 'GameFont',
                          fontSize: 24,
                          color: AppColors.goldText,
                          letterSpacing: 2,
                        )),
                    const Spacer(),
                    CoinDisplay(coins: coins),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      // ─── Remove Ads Card ─────────────────────────
                      _RemoveAdsCard()
                          .animate().fadeIn(duration: 300.ms),

                      const SizedBox(height: 12),

                      // ─── Premium Subscription ─────────────────────
                      _PremiumCard()
                          .animate().fadeIn(delay: 100.ms),

                      const SizedBox(height: 12),

                      // ─── Coin Packs ───────────────────────────────
                      WoodPanel(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const WoodSectionHeader(title: 'COIN PACKS'),
                            ..._coinPacks.asMap().entries.map((e) =>
                              _CoinPackRow(pack: e.value)
                                  .animate().fadeIn(delay: ((e.key + 2) * 80).ms)),
                          ],
                        ),
                      ),

                      const SizedBox(height: 12),

                      // ─── Power Bundle ─────────────────────────────
                      _PowerBundleCard()
                          .animate().fadeIn(delay: 400.ms),

                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RemoveAdsCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return WoodPanel(
      child: Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              color: const Color(0xFF8B1A1A),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.block_rounded, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Remove Ads', style: TextStyle(
                    color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.w700)),
                Text('Play without interruptions forever',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
          ),
          WoodButton(
            label: '₹199',
            onTap: () {},
            width: 80,
            height: 40,
            color: AppColors.buttonBrown,
            textStyle: const TextStyle(
                fontFamily: 'GameFont', fontSize: 14, color: AppColors.goldText),
          ),
        ],
      ),
    );
  }
}

class _PremiumCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF8B5E1A), Color(0xFF5C3A0E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.goldPrimary, width: 2),
        boxShadow: const [
          BoxShadow(color: Colors.black38, blurRadius: 12, offset: Offset(0, 4)),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Row(
              children: [
                Icon(Icons.workspace_premium_rounded, color: AppColors.goldLight, size: 28),
                SizedBox(width: 10),
                Text('PREMIUM MONTHLY',
                    style: TextStyle(
                      fontFamily: 'GameFont',
                      fontSize: 18,
                      color: AppColors.goldText,
                      letterSpacing: 1,
                    )),
                Spacer(),
                Text('₹99/mo',
                    style: TextStyle(
                      fontFamily: 'GameFont',
                      fontSize: 20,
                      color: AppColors.goldLight,
                    )),
              ],
            ),
            const SizedBox(height: 12),
            const Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                _PremiumBadge('✨ No Ads'),
                _PremiumBadge('🎨 Exclusive Themes'),
                _PremiumBadge('🎁 Bonus Rewards'),
                _PremiumBadge('☁️ Cloud Save Priority'),
              ],
            ),
            const SizedBox(height: 14),
            WoodButton(
              label: 'SUBSCRIBE NOW',
              onTap: () {},
              color: AppColors.goldDark,
              shadowColor: AppColors.goldDark.withOpacity(0.5),
              height: 48,
            ),
          ],
        ),
      ),
    );
  }
}

class _PremiumBadge extends StatelessWidget {
  final String label;
  const _PremiumBadge(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black26,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.goldDark.withOpacity(0.5)),
      ),
      child: Text(label,
          style: const TextStyle(color: AppColors.textPrimary, fontSize: 12)),
    );
  }
}

class _CoinPackRow extends StatelessWidget {
  final Map<String, dynamic> pack;
  const _CoinPackRow({required this.pack});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.panelInner.withOpacity(0.5),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.woodGrain.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          Text(pack['icon'] as String, style: const TextStyle(fontSize: 28)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(pack['label'] as String,
                        style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w700,
                            fontSize: 15)),
                    const SizedBox(width: 8),
                    if (pack.containsKey('badge'))
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.goldDark,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(pack['badge'] as String,
                            style: const TextStyle(
                                color: AppColors.goldText,
                                fontSize: 9,
                                fontWeight: FontWeight.w700)),
                      ),
                  ],
                ),
              ],
            ),
          ),
          WoodButton(
            label: pack['price'] as String,
            onTap: () {},
            width: 80,
            height: 36,
            color: AppColors.buttonBrown,
            textStyle: const TextStyle(
                fontFamily: 'GameFont', fontSize: 14, color: AppColors.goldText),
          ),
        ],
      ),
    );
  }
}

class _PowerBundleCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return WoodPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const WoodSectionHeader(title: 'POWER BUNDLE'),
          const Text('Get all 5 power-ups in one bundle!',
              style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
          const SizedBox(height: 12),
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _PowerupBadge('↩️', 'Undo'),
              _PowerupBadge('🔀', 'Shuffle'),
              _PowerupBadge('💣', 'Bomb'),
              _PowerupBadge('➕', 'Extra Slot'),
              _PowerupBadge('💖', 'Revive'),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Power Bundle',
                        style: TextStyle(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w700,
                            fontSize: 16)),
                    Text('5 of each power-up',
                        style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  ],
                ),
              ),
              WoodButton(
                label: '₹249',
                onTap: () {},
                width: 90,
                height: 42,
                color: AppColors.buttonBrown,
                textStyle: const TextStyle(
                    fontFamily: 'GameFont', fontSize: 15, color: AppColors.goldText),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PowerupBadge extends StatelessWidget {
  final String emoji;
  final String label;
  const _PowerupBadge(this.emoji, this.label);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 24)),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(color: AppColors.textMuted, fontSize: 10)),
      ],
    );
  }
}
