import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/utils/game_engine.dart';
import '../../../domain/entities/entities.dart';
import '../../widgets/common/common_widgets.dart';
import '../../providers/providers.dart';
import '../gameover/gameover_screen.dart';
import '../home/home_screen.dart';

class GameScreen extends ConsumerStatefulWidget {
  const GameScreen({super.key});

  @override
  ConsumerState<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends ConsumerState<GameScreen>
    with TickerProviderStateMixin {

  // Drag state
  int? _draggingBlockIndex;
  BlockEntity? _draggingBlock;
  Offset? _dragPosition;
  int? _hoverRow;
  int? _hoverCol;
  bool _canPlace = false;

  // Board key for coordinate conversion
  final GlobalKey _boardKey = GlobalKey();

  // Line clear animation
  late AnimationController _clearAnim;
  late AnimationController _scorePopAnim;

  @override
  void initState() {
    super.initState();
    _clearAnim = AnimationController(
      vsync: this,
      duration: AppConstants.lineClearDuration,
    );
    _scorePopAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(gameProvider.notifier).startGame();
    });
  }

  @override
  void dispose() {
    _clearAnim.dispose();
    _scorePopAnim.dispose();
    super.dispose();
  }

  // ─── Drag coordinate math ─────────────────────────────────────────────────
  RenderBox? get _boardBox =>
      _boardKey.currentContext?.findRenderObject() as RenderBox?;

  void _updateHover(Offset globalPos, BlockEntity block) {
    final rb = _boardBox;
    if (rb == null) return;

    final local = rb.globalToLocal(globalPos);
    final boardPadding = 10.0; // matches Container padding in _buildBoard
    final cellTotal = AppConstants.cellSize + AppConstants.cellPadding * 2;

    // Lift block above finger
    final liftOffset = Offset(
      block.cols * cellTotal / 2,
      block.rows * cellTotal + 50,
    );
    final adjusted = local - liftOffset + Offset(boardPadding, boardPadding);

    final col = (adjusted.dx / cellTotal).floor();
    final row = (adjusted.dy / cellTotal).floor();

    final gameState = ref.read(gameProvider);
    final valid = row >= 0 && col >= 0
        ? GameEngine.canPlace(gameState.board, block, row, col)
        : false;

    setState(() {
      _dragPosition = globalPos;
      _hoverRow = row;
      _hoverCol = col;
      _canPlace = valid;
    });
  }

  void _startDrag(int index, BlockEntity block) {
    HapticFeedback.selectionClick();
    setState(() {
      _draggingBlockIndex = index;
      _draggingBlock = block;
    });
  }

  void _dropBlock() {
    final index = _draggingBlockIndex;
    final block = _draggingBlock;

    setState(() {
      _draggingBlockIndex = null;
      _draggingBlock = null;
      _dragPosition = null;
      _hoverRow = null;
      _hoverCol = null;
      _canPlace = false;
    });

    if (index == null || block == null) return;
    if (_hoverRow == null || _hoverCol == null) return;

    final placed = ref.read(gameProvider.notifier)
        .tryPlaceBlock(index, _hoverRow!, _hoverCol!);

    if (placed) {
      HapticFeedback.mediumImpact();
      _scorePopAnim.forward(from: 0);
    } else {
      HapticFeedback.heavyImpact();
    }

    // Check game over after state update
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final gs = ref.read(gameProvider);
      if (gs.status == GameStatus.gameOver && mounted) {
        // Increment games played for ad frequency
        ref.read(gamesPlayedProvider.notifier).state++;
        Future.delayed(const Duration(milliseconds: 400), () {
          if (!mounted) return;
          Navigator.pushReplacement(
            context,
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => const GameOverScreen(),
              transitionsBuilder: (_, anim, __, child) =>
                  FadeTransition(opacity: anim, child: child),
              transitionDuration: const Duration(milliseconds: 400),
            ),
          );
        });
      }
    });
  }

  bool _isInBlockRange(int row, int col, GameState gs) {
    final block = _draggingBlock;
    if (block == null || _hoverRow == null || _hoverCol == null) return false;
    final dr = row - _hoverRow!;
    final dc = col - _hoverCol!;
    if (dr < 0 || dr >= block.rows || dc < 0 || dc >= block.cols) return false;
    return block.shape[dr][dc];
  }

  // ─── Pause dialog ─────────────────────────────────────────────────────────
  void _showPauseDialog() {
    ref.read(gameProvider.notifier).togglePause();
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => WillPopScope(
        onWillPop: () async => false,
        child: Center(
          child: WoodPanel(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('PAUSED',
                    style: TextStyle(
                      fontFamily: 'GameFont',
                      fontSize: 28,
                      color: AppColors.goldText,
                      letterSpacing: 2,
                    )),
                const SizedBox(height: 24),
                WoodButton(
                  label: 'RESUME',
                  icon: Icons.play_arrow_rounded,
                  onTap: () {
                    Navigator.pop(context);
                    ref.read(gameProvider.notifier).togglePause();
                  },
                  height: 50,
                ),
                const SizedBox(height: 12),
                WoodButton(
                  label: 'RESTART',
                  icon: Icons.refresh_rounded,
                  color: AppColors.buttonBrown,
                  onTap: () {
                    Navigator.pop(context);
                    ref.read(gameProvider.notifier).startGame();
                  },
                  height: 50,
                ),
                const SizedBox(height: 12),
                WoodButton(
                  label: 'HOME',
                  icon: Icons.home_rounded,
                  color: AppColors.buttonGreen,
                  shadowColor: AppColors.buttonGreenDark,
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (_) => const HomeScreen()),
                      (r) => false,
                    );
                  },
                  height: 50,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final gameState = ref.watch(gameProvider);

    return Scaffold(
      body: WoodBackground(
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  // ─── Top Bar ─────────────────────────────────────
                  _TopBar(
                    score: gameState.score,
                    bestScore: gameState.bestScore,
                    bombsLeft: gameState.bombsLeft,
                    onPause: _showPauseDialog,
                  ),
                  const SizedBox(height: 10),

                  // ─── Game Board ───────────────────────────────────
                  Expanded(
                    child: Center(
                      child: _buildBoard(gameState),
                    ),
                  ),

                  const SizedBox(height: 10),

                  // ─── Block Tray ───────────────────────────────────
                  _BlockTray(
                    blocks: gameState.availableBlocks,
                    draggingIndex: _draggingBlockIndex,
                    onDragStart: _startDrag,
                    onDragUpdate: _updateHover,
                    onDragEnd: (_b, _i) => _dropBlock(),
                    onDragCancel: _dropBlock,
                  ),
                  const SizedBox(height: 10),

                  // ─── Power-ups ────────────────────────────────────
                  _PowerupBar(
                    undosLeft: gameState.undosLeft,
                    coins: gameState.coins,
                    onUndo: () => ref.read(gameProvider.notifier).undoMove(),
                    onShuffle: () =>
                        ref.read(gameProvider.notifier).shuffleBlocks(),
                  ),
                  const SizedBox(height: 16),
                ],
              ),

              // ─── Floating dragged block ghost ─────────────────────
              if (_draggingBlock != null && _dragPosition != null)
                Positioned(
                  left: _dragPosition!.dx -
                      (_draggingBlock!.cols *
                          (AppConstants.cellSize +
                              AppConstants.cellPadding * 2) /
                          2),
                  top: _dragPosition!.dy -
                      (_draggingBlock!.rows *
                              (AppConstants.cellSize +
                                  AppConstants.cellPadding * 2) +
                          50),
                  child: IgnorePointer(
                    child: Opacity(
                      opacity: 0.85,
                      child: Transform.scale(
                        scale: 1.15,
                        child: _BlockPreview(block: _draggingBlock!),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBoard(GameState gs) {
    final cellTotal = AppConstants.cellSize + AppConstants.cellPadding * 2;

    return Container(
      key: _boardKey,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.panelInner,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.panelBorder, width: 2),
        boxShadow: const [
          BoxShadow(
              color: Colors.black54, blurRadius: 16, offset: Offset(0, 6)),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(AppConstants.boardSize, (row) {
          return Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(AppConstants.boardSize, (col) {
              final cell = gs.board[row][col];
              final hovered = _draggingBlock != null &&
                  _isInBlockRange(row, col, gs);

              return _BoardCell(
                cell: cell,
                isHovered: hovered,
                canPlace: _canPlace,
                size: AppConstants.cellSize,
                padding: AppConstants.cellPadding,
              );
            }),
          );
        }),
      ),
    );
  }
}

// ─── Board Cell ───────────────────────────────────────────────────────────────
class _BoardCell extends StatelessWidget {
  final BoardCell cell;
  final bool isHovered;
  final bool canPlace;
  final double size;
  final double padding;

  const _BoardCell({
    required this.cell,
    required this.isHovered,
    required this.canPlace,
    required this.size,
    required this.padding,
  });

  @override
  Widget build(BuildContext context) {
    Color bg;
    if (cell.occupied) {
      bg = cell.color!;
    } else if (isHovered) {
      bg = canPlace
          ? Colors.greenAccent.withOpacity(0.45)
          : Colors.redAccent.withOpacity(0.35);
    } else {
      bg = const Color(0xFF1A0D03);
    }

    return Container(
      margin: EdgeInsets.all(padding),
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(
          color: cell.occupied
              ? Colors.white.withOpacity(0.15)
              : const Color(0xFF2A1505),
          width: 0.5,
        ),
        boxShadow: cell.occupied
            ? [
                BoxShadow(
                  color: cell.color!.withOpacity(0.5),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                )
              ]
            : null,
      ),
    );
  }
}

// ─── Top Bar ──────────────────────────────────────────────────────────────────
class _TopBar extends StatelessWidget {
  final int score;
  final int bestScore;
  final int bombsLeft;
  final VoidCallback onPause;

  const _TopBar({
    required this.score,
    required this.bestScore,
    required this.bombsLeft,
    required this.onPause,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          _iconBtn(Icons.pause_rounded, onPause),
          const Spacer(),
          ScoreBox(label: 'SCORE', value: score.toString()),
          const SizedBox(width: 12),
          ScoreBox(label: 'BEST', value: bestScore.toString()),
          const Spacer(),
          Stack(children: [
            _iconBtn(Icons.hardware_rounded, () {}),
            Positioned(
              right: 0,
              bottom: 0,
              child: Container(
                width: 18,
                height: 18,
                decoration: const BoxDecoration(
                  color: AppColors.buttonBrownDark,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(bombsLeft.toString(),
                      style: const TextStyle(
                          color: AppColors.goldText,
                          fontSize: 11,
                          fontWeight: FontWeight.w700)),
                ),
              ),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _iconBtn(IconData icon, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: AppColors.buttonBrown,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.woodHighlight, width: 1.5),
            boxShadow: const [
              BoxShadow(
                  color: Color(0xFF3D1E08),
                  offset: Offset(0, 3),
                  blurRadius: 0),
            ],
          ),
          child: Icon(icon, color: AppColors.goldText, size: 22),
        ),
      );
}

// ─── Block Tray ───────────────────────────────────────────────────────────────
class _BlockTray extends StatelessWidget {
  final List<BlockEntity?> blocks;
  final int? draggingIndex;
  final Function(int, BlockEntity) onDragStart;
  final Function(Offset, BlockEntity) onDragUpdate;
  final Function(BlockEntity, int) onDragEnd;
  final VoidCallback onDragCancel;

  const _BlockTray({
    required this.blocks,
    required this.draggingIndex,
    required this.onDragStart,
    required this.onDragUpdate,
    required this.onDragEnd,
    required this.onDragCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.panelBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.panelBorder, width: 1.5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(3, (i) {
          final block = blocks[i];
          if (block == null) {
            return const SizedBox(width: 80, height: 60);
          }
          final isDragging = draggingIndex == i;
          return Opacity(
            opacity: isDragging ? 0.3 : 1.0,
            child: GestureDetector(
              onPanStart: (d) => onDragStart(i, block),
              onPanUpdate: (d) => onDragUpdate(d.globalPosition, block),
              onPanEnd: (_) => onDragEnd(block, i),
              onPanCancel: onDragCancel,
              child: _BlockPreview(block: block),
            ),
          );
        }),
      ),
    );
  }
}

// ─── Block Preview ────────────────────────────────────────────────────────────
class _BlockPreview extends StatelessWidget {
  final BlockEntity block;
  const _BlockPreview({required this.block});

  @override
  Widget build(BuildContext context) {
    const cellSz = 16.0;
    const pad = 1.5;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: block.shape.map((row) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: row.map((filled) {
            return Container(
              margin: const EdgeInsets.all(pad),
              width: cellSz,
              height: cellSz,
              decoration: filled
                  ? BoxDecoration(
                      color: block.color,
                      borderRadius: BorderRadius.circular(3),
                      border: Border.all(color: Colors.white24, width: 0.5),
                      boxShadow: [
                        BoxShadow(
                            color: block.color.withOpacity(0.5),
                            blurRadius: 3,
                            offset: const Offset(0, 1)),
                      ],
                    )
                  : null,
            );
          }).toList(),
        );
      }).toList(),
    );
  }
}

// ─── Power-up Bar ─────────────────────────────────────────────────────────────
class _PowerupBar extends StatelessWidget {
  final int undosLeft;
  final int coins;
  final VoidCallback onUndo;
  final VoidCallback onShuffle;

  const _PowerupBar({
    required this.undosLeft,
    required this.coins,
    required this.onUndo,
    required this.onShuffle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _PowerBtn(
            icon: Icons.undo_rounded,
            label: 'Undo',
            onTap: onUndo,
            enabled: undosLeft > 0,
          ),
          CoinDisplay(coins: coins),
          _PowerBtn(
            icon: Icons.shuffle_rounded,
            label: 'Shuffle',
            cost: AppConstants.shuffleCost,
            onTap: onShuffle,
            enabled: coins >= AppConstants.shuffleCost,
          ),
        ],
      ),
    );
  }
}

class _PowerBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool enabled;
  final int? cost;

  const _PowerBtn({
    required this.icon,
    required this.label,
    required this.onTap,
    this.enabled = true,
    this.cost,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: Opacity(
        opacity: enabled ? 1.0 : 0.5,
        child: Column(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: AppColors.buttonBrown,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.woodHighlight, width: 1.5),
                boxShadow: const [
                  BoxShadow(
                      color: Color(0xFF3D1E08),
                      offset: Offset(0, 3),
                      blurRadius: 0),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: AppColors.goldText, size: 20),
                  if (cost != null)
                    Text('${cost}🪙',
                        style: const TextStyle(
                            fontSize: 8,
                            color: AppColors.textSecondary)),
                ],
              ),
            ),
            const SizedBox(height: 4),
            Text(label,
                style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 10,
                    fontFamily: 'BodyFont')),
          ],
        ),
      ),
    );
  }
}
