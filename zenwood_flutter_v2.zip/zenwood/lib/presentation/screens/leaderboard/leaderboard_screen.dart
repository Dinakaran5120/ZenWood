import 'dart:math' show min;
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_theme.dart';
import '../../widgets/common/common_widgets.dart';
import '../../../domain/entities/entities.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  bool _isAllTime = true;

  // Mock data matching the screenshots
  final List<LeaderboardEntry> _entries = [
    LeaderboardEntry(uid: '1', displayName: 'Arjun', country: '🇮🇳', score: 12580, rank: 1),
    LeaderboardEntry(uid: '2', displayName: 'Priya', country: '🇮🇳', score: 11230, rank: 2),
    LeaderboardEntry(uid: '3', displayName: 'Rahul', country: '🇮🇳', score: 9850, rank: 3),
    LeaderboardEntry(uid: '4', displayName: 'Sneha', country: '🇮🇳', score: 7640, rank: 4),
    LeaderboardEntry(uid: '5', displayName: 'Vikram', country: '🇮🇳', score: 6420, rank: 5),
    LeaderboardEntry(uid: '6', displayName: 'Karthik (You)', country: '🇮🇳', score: 3420, rank: 6, isCurrentUser: true),
    LeaderboardEntry(uid: '7', displayName: 'Ananya', country: '🇮🇳', score: 2980, rank: 7),
    LeaderboardEntry(uid: '8', displayName: 'Siddharth', country: '🇮🇳', score: 2760, rank: 8),
    LeaderboardEntry(uid: '9', displayName: 'Meera', country: '🇮🇳', score: 2540, rank: 9),
    LeaderboardEntry(uid: '10', displayName: 'Kiran', country: '🇮🇳', score: 2100, rank: 10),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: WoodBackground(
        child: SafeArea(
          child: Column(
            children: [
              // ─── Header ────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(
                  children: [
                    const WoodBackButton(),
                    const Spacer(),
                    const Text(
                      'GLOBAL LEADERBOARD',
                      style: TextStyle(
                        fontFamily: 'GameFont',
                        fontSize: 20,
                        color: AppColors.goldText,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const Spacer(),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // ─── Tab Selector ──────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.panelInner,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.panelBorder, width: 1.5),
                  ),
                  child: Row(
                    children: [
                      _TabButton(
                        label: 'ALL TIME',
                        icon: Icons.emoji_events_rounded,
                        selected: _isAllTime,
                        onTap: () => setState(() => _isAllTime = true),
                      ),
                      _TabButton(
                        label: 'WEEKLY',
                        icon: Icons.calendar_today_rounded,
                        selected: !_isAllTime,
                        onTap: () => setState(() => _isAllTime = false),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // ─── Column Headers ────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    const SizedBox(width: 48),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Row(
                        children: [
                          const SizedBox(width: 52),
                          Text(
                            'PLAYER',
                            style: TextStyle(
                              color: AppColors.textMuted,
                              fontSize: 12,
                              fontFamily: 'GameFont',
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Text(
                      'SCORE',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 12,
                        fontFamily: 'GameFont',
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(width: 4),
                  ],
                ),
              ),

              const SizedBox(height: 8),

              // ─── Leaderboard List ──────────────────────────────────
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: _entries.length,
                  itemBuilder: (context, i) {
                    final entry = _entries[i];
                    return _LeaderboardRow(entry: entry)
                        .animate()
                        .fadeIn(delay: (i * 50).ms, duration: 300.ms)
                        .slideX(begin: 0.05);
                  },
                ),
              ),

              // ─── Footer ───────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Leaderboard updates in real-time',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 12,
                        fontFamily: 'BodyFont',
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                    const Icon(Icons.star_four_points_rounded,
                        color: AppColors.textMuted, size: 16),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TabButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _TabButton({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? AppColors.goldDark : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            border: selected ? Border.all(color: AppColors.goldPrimary, width: 1.5) : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  color: selected ? AppColors.goldText : AppColors.textMuted,
                  size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  fontFamily: 'GameFont',
                  fontSize: 14,
                  color: selected ? AppColors.goldText : AppColors.textMuted,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LeaderboardRow extends StatelessWidget {
  final LeaderboardEntry entry;

  const _LeaderboardRow({required this.entry});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 3),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: entry.isCurrentUser
            ? AppColors.rankHighlight.withOpacity(0.3)
            : AppColors.panelBg.withOpacity(0.5),
        borderRadius: BorderRadius.circular(10),
        border: entry.isCurrentUser
            ? Border.all(color: AppColors.rankHighlight, width: 1.5)
            : Border.all(color: Colors.transparent),
      ),
      child: Row(
        children: [
          // Rank medal
          SizedBox(width: 40, child: RankMedal(rank: entry.rank)),

          const SizedBox(width: 10),

          // Avatar
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.buttonBrown,
              border: Border.all(
                color: entry.isCurrentUser ? AppColors.rankHighlight : AppColors.woodGrain,
                width: 2,
              ),
            ),
            child: ClipOval(
              child: entry.photoUrl != null
                  ? Image.network(entry.photoUrl!, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _initials(entry.displayName))
                  : _initials(entry.displayName),
            ),
          ),

          const SizedBox(width: 10),

          // Name
          Expanded(
            child: Text(
              entry.displayName,
              style: AppTextStyles.leaderboardName.copyWith(
                color: entry.isCurrentUser ? Colors.white : AppColors.textPrimary,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),

          // Country flag
          Text(entry.country, style: const TextStyle(fontSize: 18)),

          const SizedBox(width: 8),

          // Score
          Text(
            entry.score.toString(),
            style: AppTextStyles.leaderboardScore.copyWith(
              color: entry.rank <= 3
                  ? [AppColors.rankGold, AppColors.rankSilver, AppColors.rankBronze][entry.rank - 1]
                  : AppColors.textPrimary,
            ),
          ),

          const SizedBox(width: 6),

          // Trophy icon
          Icon(
            Icons.emoji_events_rounded,
            color: entry.rank <= 3
                ? [AppColors.rankGold, AppColors.rankSilver, AppColors.rankBronze][entry.rank - 1]
                : AppColors.textMuted,
            size: 16,
          ),
        ],
      ),
    );
  }

  Widget _initials(String name) {
    final parts = name.split(' ');
    final initials = parts.length >= 2
        ? '${parts[0][0]}${parts[1][0]}'.toUpperCase()
        : name.substring(0, min(2, name.length)).toUpperCase();
    return Container(
      color: AppColors.buttonBrown,
      child: Center(
        child: Text(initials,
            style: const TextStyle(
                color: AppColors.goldText,
                fontSize: 14,
                fontWeight: FontWeight.w700)),
      ),
    );
  }


}
