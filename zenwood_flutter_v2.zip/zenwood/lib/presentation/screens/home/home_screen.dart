import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_theme.dart';
import '../../widgets/common/common_widgets.dart';
import '../../providers/providers.dart';
import '../game/game_screen.dart';
import '../leaderboard/leaderboard_screen.dart';
import '../settings/settings_screen.dart';
import '../shop/shop_screen.dart';
import '../daily_reward/daily_reward_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Auto-show daily reward if available
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final rewardState = ref.read(dailyRewardProvider);
      if (rewardState.canClaim) {
        Future.delayed(const Duration(milliseconds: 800), () {
          if (mounted) {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => const DailyRewardScreen()),
            );
          }
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final bestScore = ref.watch(bestScoreProvider);
    final coins = ref.watch(coinsProvider);

    return Scaffold(
      body: WoodBackground(
        child: SafeArea(
          child: Stack(
            children: [
              // Leaf top left
              Positioned(
                top: -5,
                left: -5,
                child: Image.asset(
                  'assets/images/leaf_cluster.png',
                  width: 100,
                  errorBuilder: (_, __, ___) => const SizedBox(width: 80, height: 80),
                ),
              ),
              // Leaf top right
              Positioned(
                top: -5,
                right: -5,
                child: Transform.flip(
                  flipX: true,
                  child: Image.asset(
                    'assets/images/leaf_cluster.png',
                    width: 100,
                    errorBuilder: (_, __, ___) => const SizedBox(width: 80, height: 80),
                  ),
                ),
              ),

              Column(
                children: [
                  // ─── Top Profile Bar ──────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                    child: _ProfileBar().animate().fadeIn(duration: 400.ms),
                  ),

                  const Spacer(),

                  // ─── Logo ─────────────────────────────────────────────
                  _LogoSection()
                      .animate()
                      .fadeIn(delay: 200.ms, duration: 500.ms)
                      .slideY(begin: -0.1),

                  const SizedBox(height: 40),

                  // ─── Menu Buttons ─────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      children: [
                        // PLAY button (lighter wood, bigger)
                        _MenuButton(
                          label: 'PLAY',
                          icon: Icons.play_arrow_rounded,
                          color: const Color(0xFF9B6B2A),
                          shadowColor: const Color(0xFF5C3A0E),
                          height: 64,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const GameScreen()),
                          ),
                        ).animate().fadeIn(delay: 300.ms).slideX(begin: -0.1),

                        const SizedBox(height: 12),

                        // HIGH SCORE
                        _MenuButton(
                          label: 'HIGH SCORE',
                          icon: Icons.emoji_events_rounded,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
                          ),
                        ).animate().fadeIn(delay: 400.ms).slideX(begin: -0.1),

                        const SizedBox(height: 12),

                        // SETTINGS
                        _MenuButton(
                          label: 'SETTINGS',
                          icon: Icons.settings_rounded,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const SettingsScreen()),
                          ),
                        ).animate().fadeIn(delay: 500.ms).slideX(begin: -0.1),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ─── Best Score Banner ────────────────────────────────
                  _BestScoreBanner(score: bestScore)
                      .animate()
                      .fadeIn(delay: 600.ms),

                  const Spacer(),

                  // ─── Bottom Nav Bar ───────────────────────────────────
                  _BottomNav(
                    onProfile: () {},
                    onShop: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ShopScreen()),
                    ),
                    onShare: () {},
                  ).animate().fadeIn(delay: 700.ms),

                  const SizedBox(height: 16),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfileBar extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.panelInner.withOpacity(0.85),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Avatar
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.goldDark, width: 2),
              image: const DecorationImage(
                image: AssetImage('assets/images/default_avatar.png'),
                fit: BoxFit.cover,
              ),
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/default_avatar.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => CircleAvatar(
                  backgroundColor: AppColors.buttonBrown,
                  child: const Icon(Icons.person, color: AppColors.goldText, size: 24),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Karthik',
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  )),
              Row(
                children: [
                  const Icon(Icons.emoji_events_rounded,
                      color: AppColors.goldPrimary, size: 14),
                  const SizedBox(width: 4),
                  Consumer(builder: (_, ref, __) {
                    final best = ref.watch(bestScoreProvider);
                    return Text('$best',
                        style: const TextStyle(
                            color: AppColors.textSecondary, fontSize: 13));
                  }),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _LogoSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Wooden blocks logo
        SizedBox(
          height: 110,
          child: Image.asset(
            'assets/images/logo_blocks.png',
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => _fallbackBlocks(),
          ),
        ),
        const SizedBox(height: 8),
        Text('ZENWOOD', style: AppTextStyles.gameTitleHuge),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
          decoration: BoxDecoration(
            color: AppColors.buttonBrownDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.goldDark, width: 1),
          ),
          child: const Text(
            'CLASSIC BLOCK BLAST',
            style: TextStyle(
              fontFamily: 'GameFont',
              fontSize: 13,
              color: AppColors.textSecondary,
              letterSpacing: 2,
            ),
          ),
        ),
      ],
    );
  }

  Widget _fallbackBlocks() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _block(55, AppColors.blockOrange),
        const SizedBox(width: 4),
        Column(mainAxisAlignment: MainAxisAlignment.end, children: [
          _block(28, AppColors.blockOrange),
          const SizedBox(height: 3),
          _block(28, AppColors.blockOrange),
        ]),
      ],
    );
  }

  Widget _block(double sz, Color c) => Container(
        width: sz,
        height: sz,
        decoration: BoxDecoration(
          color: c,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: Colors.black26, width: 1.5),
          boxShadow: [BoxShadow(color: c.withOpacity(0.4), blurRadius: 6, offset: const Offset(0, 3))],
        ),
      );
}

class _MenuButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final Color shadowColor;
  final double height;

  const _MenuButton({
    required this.label,
    required this.icon,
    required this.onTap,
    this.color = AppColors.buttonBrown,
    this.shadowColor = const Color(0xFF3D1E08),
    this.height = 56,
  });

  @override
  State<_MenuButton> createState() => _MenuButtonState();
}

class _MenuButtonState extends State<_MenuButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 100));
    _scale = Tween(begin: 1.0, end: 0.96).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          height: widget.height,
          decoration: BoxDecoration(
            color: widget.color,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.woodHighlight.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(color: widget.shadowColor, offset: const Offset(0, 6), blurRadius: 0),
              BoxShadow(color: Colors.black.withOpacity(0.25), offset: const Offset(0, 9), blurRadius: 6),
            ],
            image: const DecorationImage(
              image: AssetImage('assets/images/wood_btn.png'),
              fit: BoxFit.cover,
              opacity: 0.3,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(widget.icon, color: AppColors.goldText, size: 26),
              const SizedBox(width: 10),
              Text(widget.label, style: AppTextStyles.buttonLabel.copyWith(fontSize: 22)),
            ],
          ),
        ),
      ),
    );
  }
}

class _BestScoreBanner extends StatelessWidget {
  final int score;
  const _BestScoreBanner({required this.score});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.panelInner,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.panelBorder, width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'BEST SCORE',
              style: TextStyle(
                fontFamily: 'GameFont',
                fontSize: 16,
                color: AppColors.textSecondary,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(width: 12),
            const Icon(Icons.emoji_events_rounded, color: AppColors.goldPrimary, size: 22),
            const SizedBox(width: 6),
            Text(
              score.toString(),
              style: const TextStyle(
                fontFamily: 'GameFont',
                fontSize: 24,
                color: AppColors.goldText,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  final VoidCallback onProfile;
  final VoidCallback onShop;
  final VoidCallback onShare;

  const _BottomNav({
    required this.onProfile,
    required this.onShop,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _navItem(Icons.person_rounded, 'Profile', onProfile),
        _navItem(Icons.shopping_cart_rounded, 'Shop', onShop),
        _navItem(Icons.share_rounded, 'Share', onShare),
      ],
    );
  }

  Widget _navItem(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: AppColors.buttonBrown,
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.woodHighlight.withOpacity(0.5), width: 2),
              boxShadow: const [
                BoxShadow(color: Color(0xFF3D1E08), offset: Offset(0, 4), blurRadius: 0),
              ],
            ),
            child: Icon(icon, color: AppColors.goldText, size: 24),
          ),
          const SizedBox(height: 6),
          Text(label,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 12,
                fontFamily: 'BodyFont',
              )),
        ],
      ),
    );
  }
}
