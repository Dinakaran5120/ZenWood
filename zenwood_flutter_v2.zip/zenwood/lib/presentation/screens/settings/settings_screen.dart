import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_theme.dart';
import '../../widgets/common/common_widgets.dart';
import '../../providers/providers.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);
    final bestScore = ref.watch(bestScoreProvider);

    return Scaffold(
      body: WoodBackground(
        child: SafeArea(
          child: Stack(
            children: [
              // Leaf top corners
              Positioned(top: -5, left: -5,
                child: Image.asset('assets/images/leaf_cluster.png', width: 80,
                    errorBuilder: (_, __, ___) => const SizedBox())),
              Positioned(top: -5, right: -5,
                child: Transform.flip(flipX: true,
                  child: Image.asset('assets/images/leaf_cluster.png', width: 80,
                      errorBuilder: (_, __, ___) => const SizedBox()))),

              Column(
                children: [
                  // ─── Header ────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                    child: Row(
                      children: [
                        const WoodBackButton(),
                        const Spacer(),
                        const Text(
                          'SETTINGS',
                          style: TextStyle(
                            fontFamily: 'GameFont',
                            fontSize: 24,
                            color: AppColors.goldText,
                            letterSpacing: 2,
                          ),
                        ),
                        const Spacer(),
                        const SizedBox(width: 48),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        children: [
                          // ─── Profile Card ─────────────────────────
                          _ProfileCard(bestScore: bestScore)
                              .animate().fadeIn(duration: 300.ms),

                          const SizedBox(height: 12),

                          // ─── Game Section ──────────────────────────
                          WoodPanel(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const WoodSectionHeader(title: 'GAME'),
                                SettingsRow(
                                  icon: Icons.volume_up_rounded,
                                  label: 'Sound Effects',
                                  trailing: WoodToggle(
                                    value: settings.soundEnabled,
                                    onChanged: (_) => notifier.toggleSound(),
                                  ),
                                ),
                                SettingsRow(
                                  icon: Icons.music_note_rounded,
                                  label: 'Music',
                                  trailing: WoodToggle(
                                    value: settings.musicEnabled,
                                    onChanged: (_) => notifier.toggleMusic(),
                                  ),
                                ),
                                SettingsRow(
                                  icon: Icons.vibration_rounded,
                                  label: 'Vibration',
                                  trailing: WoodToggle(
                                    value: settings.vibrationEnabled,
                                    onChanged: (_) => notifier.toggleVibration(),
                                  ),
                                ),
                                SettingsRow(
                                  icon: Icons.palette_rounded,
                                  label: 'Theme',
                                  trailing: SegmentSelector(
                                    options: const ['Light', 'Dark'],
                                    selected: settings.theme == 'dark' ? 'Dark' : 'Light',
                                    onChanged: (v) => notifier.setTheme(v.toLowerCase()),
                                  ),
                                ),
                              ],
                            ),
                          ).animate().fadeIn(delay: 100.ms),

                          const SizedBox(height: 12),

                          // ─── Gameplay Section ──────────────────────
                          WoodPanel(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const WoodSectionHeader(title: 'GAMEPLAY'),
                                SettingsRow(
                                  icon: Icons.grid_view_rounded,
                                  label: 'Show Next Block Outline',
                                  trailing: WoodToggle(
                                    value: settings.showOutline,
                                    onChanged: (_) => notifier.toggleOutline(),
                                  ),
                                ),
                                SettingsRow(
                                  icon: Icons.touch_app_rounded,
                                  label: 'Drag Sensitivity',
                                  trailing: SegmentSelector(
                                    options: const ['Low', 'Medium', 'High'],
                                    selected: _capitalize(settings.dragSensitivity),
                                    onChanged: (v) => notifier.setDragSensitivity(v.toLowerCase()),
                                  ),
                                ),
                                SettingsRow(
                                  icon: Icons.auto_awesome_rounded,
                                  label: 'Haptic Feedback',
                                  trailing: WoodToggle(
                                    value: settings.hapticEnabled,
                                    onChanged: (_) => notifier.toggleHaptic(),
                                  ),
                                ),
                              ],
                            ),
                          ).animate().fadeIn(delay: 200.ms),

                          const SizedBox(height: 12),

                          // ─── More Section ──────────────────────────
                          WoodPanel(
                            child: Column(
                              children: [
                                const WoodSectionHeader(title: 'MORE'),
                                _LinkRow(icon: Icons.help_outline_rounded, label: 'How to Play', onTap: () {}),
                                _LinkRow(icon: Icons.security_rounded, label: 'Privacy Policy', onTap: () {}),
                                _LinkRow(icon: Icons.description_outlined, label: 'Terms of Service', onTap: () {}),
                              ],
                            ),
                          ).animate().fadeIn(delay: 300.ms),

                          const SizedBox(height: 12),

                          // ─── About Section ─────────────────────────
                          WoodPanel(
                            child: Column(
                              children: [
                                const WoodSectionHeader(title: 'ABOUT'),
                                Row(
                                  children: [
                                    Container(
                                      width: 44, height: 44,
                                      decoration: BoxDecoration(
                                        color: AppColors.buttonBrown,
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: AppColors.goldDark, width: 1),
                                      ),
                                      child: const Icon(Icons.grid_view_rounded,
                                          color: AppColors.goldText, size: 22),
                                    ),
                                    const SizedBox(width: 12),
                                    const Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text('ZenWood: Classic Block Blast',
                                              style: TextStyle(
                                                color: AppColors.textPrimary,
                                                fontWeight: FontWeight.w700,
                                                fontSize: 14,
                                              )),
                                          Text('Version 1.0.0',
                                              style: TextStyle(
                                                color: AppColors.textMuted,
                                                fontSize: 12,
                                              )),
                                        ],
                                      ),
                                    ),
                                    WoodButton(
                                      label: 'RATE US',
                                      icon: Icons.star_rounded,
                                      onTap: () {},
                                      width: 110,
                                      height: 40,
                                      color: AppColors.buttonBrown,
                                      textStyle: const TextStyle(
                                        fontFamily: 'GameFont',
                                        fontSize: 13,
                                        color: AppColors.goldText,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                              ],
                            ),
                          ).animate().fadeIn(delay: 400.ms),

                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _capitalize(String s) =>
      s.isNotEmpty ? '${s[0].toUpperCase()}${s.substring(1)}' : s;
}

class _ProfileCard extends StatelessWidget {
  final int bestScore;

  const _ProfileCard({required this.bestScore});

  @override
  Widget build(BuildContext context) {
    return WoodPanel(
      child: Row(
        children: [
          // Avatar
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.goldDark, width: 2.5),
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/default_avatar.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: AppColors.buttonBrown,
                  child: const Icon(Icons.person, color: AppColors.goldText, size: 32),
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Karthik',
                    style: TextStyle(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w700,
                        fontSize: 18)),
                Row(
                  children: [
                    const Icon(Icons.emoji_events_rounded,
                        color: AppColors.goldPrimary, size: 16),
                    const SizedBox(width: 4),
                    Text(
                      'Best Score: $bestScore',
                      style: const TextStyle(
                          color: AppColors.goldText,
                          fontSize: 14,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ],
            ),
          ),
          WoodButton(
            label: 'PROFILE',
            icon: Icons.person_rounded,
            onTap: () {},
            width: 110,
            height: 40,
            textStyle: const TextStyle(
                fontFamily: 'GameFont', fontSize: 13, color: AppColors.goldText),
          ),
        ],
      ),
    );
  }
}

class _LinkRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _LinkRow({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: AppColors.buttonBrown,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.goldDark, width: 1),
              ),
              child: Icon(icon, color: AppColors.goldText, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: AppTextStyles.settingsLabel)),
            const Icon(Icons.chevron_right_rounded,
                color: AppColors.textMuted, size: 20),
          ],
        ),
      ),
    );
  }
}
