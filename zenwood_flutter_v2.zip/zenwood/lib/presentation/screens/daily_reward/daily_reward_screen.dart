import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_theme.dart';
import '../../widgets/common/common_widgets.dart';
import '../../providers/providers.dart';

class DailyRewardScreen extends ConsumerStatefulWidget {
  const DailyRewardScreen({super.key});

  @override
  ConsumerState<DailyRewardScreen> createState() => _DailyRewardScreenState();
}

class _DailyRewardScreenState extends ConsumerState<DailyRewardScreen>
    with SingleTickerProviderStateMixin {
  bool _claimed = false;
  int _claimedAmount = 0;
  late AnimationController _celebController;

  @override
  void initState() {
    super.initState();
    _celebController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
  }

  @override
  void dispose() {
    _celebController.dispose();
    super.dispose();
  }

  Future<void> _claim() async {
    final reward =
        await ref.read(dailyRewardProvider.notifier).claimReward();
    if (reward > 0) {
      ref.read(gameProvider.notifier).addCoins(reward);
      setState(() {
        _claimed = true;
        _claimedAmount = reward;
      });
      _celebController.forward();
    }
  }

  @override
  Widget build(BuildContext context) {
    final rewardState = ref.watch(dailyRewardProvider);
    final streak = rewardState.streak;
    final canClaim = rewardState.canClaim;

    return Scaffold(
      body: WoodBackground(
        child: SafeArea(
          child: Column(
            children: [
              // ─── Header ────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(
                  children: [
                    const WoodBackButton(),
                    const Spacer(),
                    const Text(
                      'DAILY REWARD',
                      style: TextStyle(
                        fontFamily: 'GameFont',
                        fontSize: 22,
                        color: AppColors.goldText,
                        letterSpacing: 2,
                      ),
                    ),
                    const Spacer(),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // ─── Streak Display ────────────────────────────────────
              WoodPanel(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('🔥 ',
                            style: TextStyle(fontSize: 24)),
                        Text(
                          '$streak Day Streak',
                          style: const TextStyle(
                            fontFamily: 'GameFont',
                            fontSize: 22,
                            color: AppColors.goldText,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    // ─── 7-day reward grid ─────────────────────────
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: List.generate(7, (i) {
                        final rewards = AppConstants.dailyRewards;
                        final isToday = i == streak % 7;
                        final isPast = i < streak % 7;
                        return _DayRewardBox(
                          day: i + 1,
                          coins: rewards[i],
                          isToday: isToday,
                          isPast: isPast,
                        );
                      }),
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 300.ms),

              const SizedBox(height: 24),

              // ─── Claim area ────────────────────────────────────────
              if (_claimed) ...[
                _ClaimedBanner(amount: _claimedAmount)
                    .animate()
                    .scale(
                        begin: const Offset(0.5, 0.5),
                        duration: 500.ms,
                        curve: Curves.elasticOut)
                    .fadeIn(duration: 300.ms),
              ] else if (canClaim) ...[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: Column(
                    children: [
                      const Text(
                        'Your reward is ready!',
                        style: TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 18,
                          fontFamily: 'BodyFont',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 16),
                      WoodButton(
                        label: 'CLAIM REWARD',
                        icon: Icons.card_giftcard_rounded,
                        onTap: _claim,
                        color: AppColors.goldDark,
                        shadowColor: const Color(0xFF5A3A00),
                        height: 60,
                        textStyle: const TextStyle(
                          fontFamily: 'GameFont',
                          fontSize: 20,
                          color: AppColors.goldText,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ).animate().fadeIn(delay: 200.ms),
              ] else ...[
                _NextRewardTimer(nextAt: rewardState.nextRewardAt)
                    .animate()
                    .fadeIn(delay: 200.ms),
              ],

              const Spacer(),

              // ─── Close button ─────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(32, 0, 32, 24),
                child: WoodButton(
                  label: 'CLOSE',
                  icon: Icons.close_rounded,
                  onTap: () => Navigator.pop(context),
                  height: 50,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DayRewardBox extends StatelessWidget {
  final int day;
  final int coins;
  final bool isToday;
  final bool isPast;

  const _DayRewardBox({
    required this.day,
    required this.coins,
    required this.isToday,
    required this.isPast,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: 38,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        color: isToday
            ? AppColors.goldDark
            : isPast
                ? AppColors.buttonBrownDark
                : AppColors.panelInner,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isToday
              ? AppColors.goldLight
              : isPast
                  ? AppColors.woodGrain
                  : AppColors.panelBorder,
          width: isToday ? 2 : 1,
        ),
      ),
      child: Column(
        children: [
          Text(
            'Day',
            style: TextStyle(
              fontSize: 8,
              color: isToday
                  ? AppColors.goldText
                  : isPast
                      ? AppColors.textMuted
                      : AppColors.textMuted,
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            day.toString(),
            style: TextStyle(
              fontFamily: 'GameFont',
              fontSize: 14,
              color: isToday
                  ? AppColors.goldText
                  : isPast
                      ? AppColors.textSecondary
                      : AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 4),
          isPast
              ? const Icon(Icons.check_circle_rounded,
                  color: AppColors.buttonGreen, size: 14)
              : const Text('🪙', style: TextStyle(fontSize: 12)),
          Text(
            coins.toString(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: isToday ? AppColors.goldText : AppColors.textMuted,
            ),
          ),
        ],
      ),
    );
  }
}

class _ClaimedBanner extends StatelessWidget {
  final int amount;
  const _ClaimedBanner({required this.amount});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text('🎉', style: TextStyle(fontSize: 48)),
        const SizedBox(height: 8),
        const Text(
          'Reward Claimed!',
          style: TextStyle(
            fontFamily: 'GameFont',
            fontSize: 24,
            color: AppColors.goldText,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🪙', style: TextStyle(fontSize: 28)),
            const SizedBox(width: 8),
            Text(
              '+$amount coins',
              style: const TextStyle(
                fontFamily: 'GameFont',
                fontSize: 28,
                color: AppColors.goldText,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _NextRewardTimer extends StatefulWidget {
  final DateTime nextAt;
  const _NextRewardTimer({required this.nextAt});

  @override
  State<_NextRewardTimer> createState() => _NextRewardTimerState();
}

class _NextRewardTimerState extends State<_NextRewardTimer> {
  late Duration _remaining;

  @override
  void initState() {
    super.initState();
    _update();
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(_update);
      return mounted;
    });
  }

  void _update() {
    final now = DateTime.now();
    _remaining = widget.nextAt.isAfter(now)
        ? widget.nextAt.difference(now)
        : Duration.zero;
  }

  @override
  Widget build(BuildContext context) {
    final h = _remaining.inHours.toString().padLeft(2, '0');
    final m = (_remaining.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_remaining.inSeconds % 60).toString().padLeft(2, '0');

    return Column(
      children: [
        const Text(
          'Come back in',
          style: TextStyle(
            color: AppColors.textSecondary,
            fontSize: 16,
            fontFamily: 'BodyFont',
          ),
        ),
        const SizedBox(height: 10),
        Text(
          '$h:$m:$s',
          style: const TextStyle(
            fontFamily: 'GameFont',
            fontSize: 36,
            color: AppColors.goldText,
            letterSpacing: 4,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'for your next reward',
          style: TextStyle(
            color: AppColors.textMuted,
            fontSize: 13,
            fontFamily: 'BodyFont',
          ),
        ),
      ],
    );
  }
}
