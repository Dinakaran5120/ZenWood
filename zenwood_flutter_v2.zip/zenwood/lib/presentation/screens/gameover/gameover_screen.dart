import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_theme.dart';
import '../../widgets/common/common_widgets.dart';
import '../../providers/providers.dart';
import '../game/game_screen.dart';
import '../home/home_screen.dart';

class GameOverScreen extends ConsumerWidget {
  const GameOverScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final gameState = ref.watch(gameProvider);
    final removeAds = ref.watch(removeAdsProvider);
    final score = gameState.score;
    final bestScore = gameState.bestScore;
    final isNewBest = score >= bestScore && score > 0;

    return Scaffold(
      body: WoodBackground(
        child: SafeArea(
          child: Column(
            children: [
              // ─── Top Bar (same as game screen) ──────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(
                        color: AppColors.buttonBrown,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.woodHighlight, width: 1.5),
                      ),
                      child: const Icon(Icons.pause_rounded, color: AppColors.goldText),
                    ),
                    const Spacer(),
                    ScoreBox(label: 'SCORE', value: score.toString()),
                    const SizedBox(width: 12),
                    ScoreBox(label: 'BEST', value: bestScore.toString()),
                    const Spacer(),
                    Stack(children: [
                      Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: AppColors.buttonBrown,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.woodHighlight, width: 1.5),
                        ),
                        child: const Icon(Icons.hardware_rounded, color: AppColors.goldText),
                      ),
                      Positioned(right: 0, bottom: 0,
                        child: Container(width: 18, height: 18,
                          decoration: const BoxDecoration(color: AppColors.buttonBrownDark, shape: BoxShape.circle),
                          child: const Center(child: Text('3', style: TextStyle(color: AppColors.goldText, fontSize: 11, fontWeight: FontWeight.w700))),
                        ),
                      ),
                    ]),
                  ],
                ),
              ),

              const Spacer(),

              // ─── Game Over Card ────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: _GameOverCard(
                  score: score,
                  bestScore: bestScore,
                  isNewBest: isNewBest,
                  onRestart: () {
                    ref.read(gameProvider.notifier).startGame();
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => const GameScreen()),
                    );
                  },
                  onHome: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (_) => const HomeScreen()),
                      (route) => false,
                    );
                  },
                ).animate().scale(begin: const Offset(0.8, 0.8), duration: 400.ms, curve: Curves.elasticOut)
                  .fadeIn(duration: 300.ms),
              ),

              const SizedBox(height: 12),

              // ─── Next reward text ─────────────────────────────────
              const Text(
                'Next reward in 1 game',
                style: TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 14,
                  fontFamily: 'BodyFont',
                ),
              ),

              const SizedBox(height: 12),

              // ─── AdMob Interstitial Banner (if not removed) ────────
              if (!removeAds) ...[
                _AdBanner().animate().fadeIn(delay: 500.ms),
                const SizedBox(height: 8),
                _RemoveAdsBanner(onTap: () {}),
              ],

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

class _GameOverCard extends StatelessWidget {
  final int score;
  final int bestScore;
  final bool isNewBest;
  final VoidCallback onRestart;
  final VoidCallback onHome;

  const _GameOverCard({
    required this.score,
    required this.bestScore,
    required this.isNewBest,
    required this.onRestart,
    required this.onHome,
  });

  @override
  Widget build(BuildContext context) {
    return WoodPanel(
      padding: const EdgeInsets.all(0),
      child: Column(
        children: [
          // ─── GAME OVER Banner ────────────────────────────────
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: const BoxDecoration(
              color: Color(0xFF8B1A1A),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(14),
                topRight: Radius.circular(14),
              ),
              gradient: LinearGradient(
                colors: [Color(0xFFA52020), Color(0xFF6B1010)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: const Text(
              'GAME OVER',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'GameFont',
                fontSize: 34,
                color: Color(0xFFFFE566),
                letterSpacing: 3,
                shadows: [
                  Shadow(color: Colors.black54, offset: Offset(2, 3), blurRadius: 4),
                ],
              ),
            ),
          ),

          // ─── Score Section ───────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
            child: Column(
              children: [
                const Text(
                  'SCORE',
                  style: TextStyle(
                    fontFamily: 'GameFont',
                    fontSize: 16,
                    color: AppColors.textSecondary,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  score.toString(),
                  style: AppTextStyles.scoreDisplay,
                ).animate().scale(begin: const Offset(0.5, 0.5), duration: 600.ms, curve: Curves.elasticOut),

                if (isNewBest) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColors.goldDark,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.goldLight, width: 1.5),
                      boxShadow: const [
                        BoxShadow(color: AppColors.goldDark, blurRadius: 12, spreadRadius: 2),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('👑 ', style: TextStyle(fontSize: 16)),
                        Text(
                          'NEW BEST!',
                          style: TextStyle(
                            fontFamily: 'GameFont',
                            fontSize: 16,
                            color: AppColors.goldText,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ).animate().shimmer(duration: 1200.ms, color: AppColors.goldLight),
                ],

                const SizedBox(height: 16),

                // Best score
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'BEST SCORE',
                      style: TextStyle(
                        fontFamily: 'GameFont',
                        fontSize: 14,
                        color: AppColors.textSecondary,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Icon(Icons.emoji_events_rounded,
                        color: AppColors.goldPrimary, size: 20),
                    const SizedBox(width: 4),
                    Text(
                      bestScore.toString(),
                      style: const TextStyle(
                        fontFamily: 'GameFont',
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // Restart + Home buttons
                Row(
                  children: [
                    Expanded(
                      child: WoodButton(
                        label: 'RESTART',
                        icon: Icons.refresh_rounded,
                        onTap: onRestart,
                        color: AppColors.buttonBrown,
                        shadowColor: AppColors.buttonBrownDark,
                        height: 52,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: WoodButton(
                        label: 'HOME',
                        icon: Icons.home_rounded,
                        onTap: onHome,
                        color: AppColors.buttonGreen,
                        shadowColor: AppColors.buttonGreenDark,
                        height: 52,
                        textStyle: AppTextStyles.buttonLabel.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AdBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        height: 80,
        decoration: BoxDecoration(
          color: const Color(0xFFF5F0E8),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.woodGrain, width: 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // AdMob logo placeholder
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: Colors.white,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  'assets/images/admob_logo.png',
                  errorBuilder: (_, __, ___) => const Center(
                    child: Text('📱', style: TextStyle(fontSize: 24)),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              'AdMob Interstitial Ad',
              style: TextStyle(
                color: Color(0xFF5C3A0E),
                fontSize: 16,
                fontFamily: 'BodyFont',
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RemoveAdsBanner extends StatelessWidget {
  final VoidCallback onTap;

  const _RemoveAdsBanner({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.buttonBrownDark.withOpacity(0.9),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.woodGrain, width: 1),
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.block_rounded, color: Colors.redAccent, size: 20),
              SizedBox(width: 8),
              Text(
                'Remove Ads',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 15,
                  fontFamily: 'BodyFont',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
