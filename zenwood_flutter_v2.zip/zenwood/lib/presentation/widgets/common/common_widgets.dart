import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme/app_theme.dart';

// ─── Wood Background ──────────────────────────────────────────────────────────
class WoodBackground extends StatelessWidget {
  final Widget child;
  final Color baseColor;

  const WoodBackground({
    super.key,
    required this.child,
    this.baseColor = AppColors.woodMid,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: baseColor,
        image: const DecorationImage(
          image: AssetImage('assets/images/wood_bg.png'),
          fit: BoxFit.cover,
          opacity: 0.85,
        ),
      ),
      child: child,
    );
  }
}

// ─── Wood Panel ───────────────────────────────────────────────────────────────
class WoodPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double borderRadius;
  final Color? color;
  final bool hasBorder;

  const WoodPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = 16,
    this.color,
    this.hasBorder = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? AppColors.panelBg,
        borderRadius: BorderRadius.circular(borderRadius),
        border: hasBorder
            ? Border.all(color: AppColors.panelBorder, width: 2)
            : null,
        boxShadow: const [
          BoxShadow(
            color: Color(0x80000000),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
        image: const DecorationImage(
          image: AssetImage('assets/images/wood_panel.png'),
          fit: BoxFit.cover,
          opacity: 0.6,
        ),
      ),
      child: child,
    );
  }
}

// ─── Wood Button ─────────────────────────────────────────────────────────────
class WoodButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final Color color;
  final Color shadowColor;
  final double width;
  final double height;
  final IconData? icon;
  final String? iconAsset;
  final TextStyle? textStyle;

  const WoodButton({
    super.key,
    required this.label,
    required this.onTap,
    this.color = AppColors.buttonBrown,
    this.shadowColor = AppColors.buttonBrownDark,
    this.width = double.infinity,
    this.height = 56,
    this.icon,
    this.iconAsset,
    this.textStyle,
  });

  @override
  State<WoodButton> createState() => _WoodButtonState();
}

class _WoodButtonState extends State<WoodButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scale = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        _controller.forward();
        HapticFeedback.lightImpact();
      },
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            color: widget.color,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: widget.color.withOpacity(0.8),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.shadowColor,
                offset: const Offset(0, 5),
                blurRadius: 0,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                offset: const Offset(0, 8),
                blurRadius: 6,
              ),
            ],
            image: const DecorationImage(
              image: AssetImage('assets/images/wood_btn.png'),
              fit: BoxFit.cover,
              opacity: 0.4,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.icon != null) ...[
                Icon(widget.icon, color: AppColors.goldText, size: 22),
                const SizedBox(width: 8),
              ],
              if (widget.iconAsset != null) ...[
                Image.asset(widget.iconAsset!, width: 22, height: 22),
                const SizedBox(width: 8),
              ],
              Text(
                widget.label,
                style: widget.textStyle ?? AppTextStyles.buttonLabel,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Gold Badge / Score Box ───────────────────────────────────────────────────
class ScoreBox extends StatelessWidget {
  final String label;
  final String value;

  const ScoreBox({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.panelInner,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.panelBorder, width: 1.5),
      ),
      child: Column(
        children: [
          Text(label,
              style: const TextStyle(
                color: AppColors.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              )),
          const SizedBox(height: 2),
          Text(value,
              style: const TextStyle(
                fontFamily: 'GameFont',
                fontSize: 26,
                color: Colors.white,
                height: 1,
              )),
        ],
      ),
    );
  }
}

// ─── Wood Toggle ─────────────────────────────────────────────────────────────
class WoodToggle extends StatelessWidget {
  final bool value;
  final ValueChanged<bool> onChanged;

  const WoodToggle({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onChanged(!value);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 52,
        height: 28,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: value ? AppColors.buttonGreen : AppColors.woodLight,
          border: Border.all(
            color: value ? AppColors.buttonGreenDark : AppColors.woodGrain,
            width: 1.5,
          ),
        ),
        child: AnimatedAlign(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeInOut,
          alignment: value ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            width: 22,
            height: 22,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.textPrimary,
              boxShadow: const [
                BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Segment Selector ─────────────────────────────────────────────────────────
class SegmentSelector extends StatelessWidget {
  final List<String> options;
  final String selected;
  final ValueChanged<String> onChanged;

  const SegmentSelector({
    super.key,
    required this.options,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.panelInner,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.panelBorder),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: options.map((o) {
          final isSelected = o == selected;
          return GestureDetector(
            onTap: () => onChanged(o),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: isSelected ? AppColors.buttonBrown : Colors.transparent,
                borderRadius: BorderRadius.circular(7),
                border: isSelected
                    ? Border.all(color: AppColors.goldDark, width: 1)
                    : null,
              ),
              child: Text(
                o,
                style: TextStyle(
                  fontFamily: 'BodyFont',
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: isSelected ? AppColors.goldText : AppColors.textMuted,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ─── Coin Display ─────────────────────────────────────────────────────────────
class CoinDisplay extends StatelessWidget {
  final int coins;

  const CoinDisplay({super.key, required this.coins});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.panelInner,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.goldDark, width: 1.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset('assets/images/coin.png', width: 20, height: 20,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.monetization_on, color: AppColors.goldPrimary, size: 20)),
          const SizedBox(width: 6),
          Text(
            coins.toString(),
            style: const TextStyle(
              fontFamily: 'GameFont',
              fontSize: 16,
              color: AppColors.goldText,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Section Divider with label ────────────────────────────────────────────────
class WoodSectionHeader extends StatelessWidget {
  final String title;

  const WoodSectionHeader({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          const Expanded(child: Divider(color: AppColors.woodGrain, thickness: 1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                const Text('❧ ', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                Text(title, style: AppTextStyles.sectionHeader),
                const Text(' ❧', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
          const Expanded(child: Divider(color: AppColors.woodGrain, thickness: 1)),
        ],
      ),
    );
  }
}

// ─── Back Button ─────────────────────────────────────────────────────────────
class WoodBackButton extends StatelessWidget {
  final VoidCallback? onTap;

  const WoodBackButton({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap ?? () => Navigator.pop(context),
      child: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: AppColors.buttonBrown,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.goldDark, width: 1.5),
          boxShadow: const [
            BoxShadow(color: AppColors.buttonBrownDark, offset: Offset(0, 4), blurRadius: 0),
          ],
        ),
        child: const Icon(Icons.arrow_back_ios_new_rounded,
            color: AppColors.goldText, size: 20),
      ),
    );
  }
}

// ─── Rank Medal ──────────────────────────────────────────────────────────────
class RankMedal extends StatelessWidget {
  final int rank;

  const RankMedal({super.key, required this.rank});

  @override
  Widget build(BuildContext context) {
    if (rank > 3) {
      return SizedBox(
        width: 36,
        child: Text(
          rank.toString(),
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontFamily: 'GameFont',
            fontSize: 18,
            color: AppColors.textSecondary,
          ),
        ),
      );
    }

    final colors = [AppColors.rankGold, AppColors.rankSilver, AppColors.rankBronze];
    final color = colors[rank - 1];

    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        border: Border.all(color: Colors.white24, width: 1),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.5), blurRadius: 8, spreadRadius: 2),
        ],
      ),
      child: Center(
        child: Text(
          rank.toString(),
          style: const TextStyle(
            fontFamily: 'GameFont',
            fontSize: 16,
            color: Colors.white,
            shadows: [Shadow(color: Colors.black54, offset: Offset(0, 1))],
          ),
        ),
      ),
    );
  }
}

// ─── Loading Bar ─────────────────────────────────────────────────────────────
class WoodLoadingBar extends StatelessWidget {
  final double progress; // 0.0 to 1.0

  const WoodLoadingBar({super.key, required this.progress});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 20,
      decoration: BoxDecoration(
        color: const Color(0xFF2A1505),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.woodGrain, width: 2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: FractionallySizedBox(
          widthFactor: progress,
          alignment: Alignment.centerLeft,
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.goldDark, AppColors.goldLight, AppColors.goldPrimary],
              ),
              borderRadius: BorderRadius.all(Radius.circular(8)),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Settings Row ─────────────────────────────────────────────────────────────
class SettingsRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget trailing;

  const SettingsRow({
    super.key,
    required this.icon,
    required this.label,
    required this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppColors.buttonBrown,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.goldDark, width: 1),
            ),
            child: Icon(icon, color: AppColors.goldText, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(label, style: AppTextStyles.settingsLabel),
          ),
          trailing,
        ],
      ),
    );
  }
}
