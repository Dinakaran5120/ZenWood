const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { GoogleAuth } = require('google-auth-library');

admin.initializeApp();
const db = admin.firestore();

// ─── Score Submission & Anti-cheat ────────────────────────────────────────────
exports.submitScore = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Login required');

  const { score, gameHash } = data;
  const uid = context.auth.uid;

  // Validate score range
  if (typeof score !== 'number' || score < 0 || score > 999999) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid score');
  }

  // Get user's previous best
  const userRef = db.collection('users').doc(uid);
  const userDoc = await userRef.get();
  const currentBest = userDoc.exists ? (userDoc.data().bestScore || 0) : 0;

  // Anti-cheat: detect abnormal score jumps
  if (score > currentBest + 50000) {
    console.warn(`Suspicious score jump for user ${uid}: ${currentBest} -> ${score}`);
    // Flag for review but don't block (gives benefit of doubt)
    await db.collection('suspicious_scores').add({ uid, score, currentBest, timestamp: admin.firestore.FieldValue.serverTimestamp() });
  }

  // Update user best score
  if (score > currentBest) {
    await userRef.update({
      bestScore: score,
      gamesPlayed: admin.firestore.FieldValue.increment(1),
    });

    // Update leaderboard
    await updateLeaderboard(uid, score, userDoc.data());
  } else {
    await userRef.update({ gamesPlayed: admin.firestore.FieldValue.increment(1) });
  }

  return { success: true, newBest: Math.max(score, currentBest) };
});

async function updateLeaderboard(uid, score, userData) {
  const batch = db.batch();

  // All-time
  const allTimeRef = db.collection('leaderboard').doc(uid);
  batch.set(allTimeRef, {
    uid,
    displayName: userData?.displayName || 'Player',
    photoUrl: userData?.photoUrl || null,
    country: userData?.country || 'IN',
    score,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  }, { merge: true });

  // Weekly (reset every Monday)
  const weeklyRef = db.collection('leaderboard_weekly').doc(uid);
  const weeklyDoc = await weeklyRef.get();
  if (!weeklyDoc.exists || weeklyDoc.data().score < score) {
    batch.set(weeklyRef, {
      uid,
      displayName: userData?.displayName || 'Player',
      photoUrl: userData?.photoUrl || null,
      country: userData?.country || 'IN',
      score,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  await batch.commit();
}

// ─── Daily Reward Claim (server-validated) ────────────────────────────────────
exports.claimDailyReward = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Login required');

  const uid = context.auth.uid;
  const rewardRef = db.collection('daily_rewards').doc(uid);
  const rewardDoc = await rewardRef.get();

  const now = new Date();
  const DAILY_REWARDS = [10, 15, 20, 30, 40, 50, 100];

  if (rewardDoc.exists) {
    const { lastClaimedAt, streak } = rewardDoc.data();
    const lastClaimed = lastClaimedAt.toDate();
    const diffHours = (now - lastClaimed) / (1000 * 60 * 60);

    if (diffHours < 24) {
      throw new functions.https.HttpsError('failed-precondition', 'Already claimed today');
    }

    const newStreak = diffHours < 48 ? (streak + 1) % DAILY_REWARDS.length : 0;
    const reward = DAILY_REWARDS[newStreak];

    await rewardRef.update({ lastClaimedAt: now, streak: newStreak });
    await db.collection('users').doc(uid).update({
      totalCoins: admin.firestore.FieldValue.increment(reward),
    });

    return { reward, streak: newStreak };
  } else {
    const reward = DAILY_REWARDS[0];
    await rewardRef.set({ lastClaimedAt: now, streak: 0 });
    await db.collection('users').doc(uid).update({
      totalCoins: admin.firestore.FieldValue.increment(reward),
    });
    return { reward, streak: 0 };
  }
});

// ─── Purchase Verification (Google Play) ──────────────────────────────────────
exports.verifyPurchase = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Login required');

  const { purchaseToken, productId, packageName } = data;
  const uid = context.auth.uid;

  // Verify with Google Play Developer API
  const auth = new GoogleAuth({
    scopes: ['https://www.googleapis.com/auth/androidpublisher'],
  });
  const client = await auth.getClient();

  try {
    const response = await client.request({
      url: `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${packageName}/purchases/products/${productId}/tokens/${purchaseToken}`,
    });

    if (response.data.purchaseState === 0) { // 0 = purchased
      // Grant the purchase
      await grantPurchase(uid, productId);
      return { success: true };
    } else {
      throw new functions.https.HttpsError('failed-precondition', 'Purchase not valid');
    }
  } catch (e) {
    console.error('Purchase verification failed:', e);
    throw new functions.https.HttpsError('internal', 'Verification failed');
  }
});

async function grantPurchase(uid, productId) {
  const userRef = db.collection('users').doc(uid);
  const coinMap = {
    'zenwood_coins_100': 100,
    'zenwood_coins_500': 500,
    'zenwood_coins_1200': 1200,
    'zenwood_power_bundle': 0, // handled separately
  };

  if (productId === 'zenwood_remove_ads') {
    await userRef.update({ removeAds: true });
  } else if (coinMap[productId]) {
    await userRef.update({
      totalCoins: admin.firestore.FieldValue.increment(coinMap[productId]),
    });
  } else if (productId === 'zenwood_power_bundle') {
    await userRef.update({
      powerUps: {
        undo: admin.firestore.FieldValue.increment(5),
        shuffle: admin.firestore.FieldValue.increment(5),
        bomb: admin.firestore.FieldValue.increment(5),
        extraSlot: admin.firestore.FieldValue.increment(5),
        revive: admin.firestore.FieldValue.increment(5),
      },
    });
  }
}

// ─── Weekly leaderboard reset (every Monday 00:00 UTC) ────────────────────────
exports.resetWeeklyLeaderboard = functions.pubsub
  .schedule('0 0 * * 1') // Every Monday at midnight
  .timeZone('UTC')
  .onRun(async (context) => {
    const batch = db.batch();
    const docs = await db.collection('leaderboard_weekly').listDocuments();
    docs.forEach(doc => batch.delete(doc));
    await batch.commit();
    console.log(`Deleted ${docs.length} weekly leaderboard entries`);
    return null;
  });
