import 'package:flutter/material.dart';

// ─────────────────────────────────────────────
//  Theme system — Sunset Beach · Inferno Realm · Celestial Heaven
// ─────────────────────────────────────────────

enum GameThemeType { beach, devil, angel }

class GameThemeColors {
  final Color background1;
  final Color background2;
  final Color background3;
  final Color gridBg;
  final Color gridLine;
  final Color cellEmpty;
  final Color panelBg;
  final Color panelBorder;
  final Color textPrimary;
  final Color textAccent;
  final Color particleColor1;
  final Color particleColor2;
  final Color particleColor3;
  final Color glowColor;
  final List<Color> blockColors;
  final Color buttonPrimary;
  final Color buttonSecondary;

  const GameThemeColors({
    required this.background1,
    required this.background2,
    required this.background3,
    required this.gridBg,
    required this.gridLine,
    required this.cellEmpty,
    required this.panelBg,
    required this.panelBorder,
    required this.textPrimary,
    required this.textAccent,
    required this.particleColor1,
    required this.particleColor2,
    required this.particleColor3,
    required this.glowColor,
    required this.blockColors,
    required this.buttonPrimary,
    required this.buttonSecondary,
  });
}

class GameThemeData {
  final GameThemeType type;
  final String name;
  final GameThemeColors colors;
  final String ambientSound;
  final String blastSound;

  const GameThemeData({
    required this.type,
    required this.name,
    required this.colors,
    required this.ambientSound,
    required this.blastSound,
  });
}

// ─── Beach Theme ──────────────────────────────
const beachTheme = GameThemeData(
  type: GameThemeType.beach,
  name: 'Sunset Beach',
  ambientSound: 'beach_waves.mp3',
  blastSound: 'beach_splash.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF040F1E),
    background2: Color(0xFF0A2240),
    background3: Color(0xFF071830),
    gridBg: Color(0xFF030C18),
    gridLine: Color(0xFF061828),
    cellEmpty: Color(0xFF061526),
    panelBg: Color(0xCC040F1E),
    panelBorder: Color(0xFF005F7A),
    textPrimary: Color(0xFFFFF9E6),
    textAccent: Color(0xFFFFCC44),
    particleColor1: Color(0xFFFFCC44),
    particleColor2: Color(0xFF00A8CC),
    particleColor3: Color(0xFFCC4818),
    glowColor: Color(0xFF007799),
    blockColors: [
      Color(0xFF004D99), // deep sapphire
      Color(0xFF007A8A), // deep teal
      Color(0xFFB03A10), // burnt sienna
      Color(0xFF991030), // deep rose
      Color(0xFF00756A), // deep jade
      Color(0xFF1040B0), // deep royal blue
      Color(0xFF880040), // deep fuchsia
    ],
    buttonPrimary: Color(0xFF005F9A),
    buttonSecondary: Color(0xFF003070),
  ),
);

// ─── Devil Theme ──────────────────────────────
const devilTheme = GameThemeData(
  type: GameThemeType.devil,
  name: 'Inferno Realm',
  ambientSound: 'devil_ambient.mp3',
  blastSound: 'devil_blast.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF120000),
    background2: Color(0xFF200000),
    background3: Color(0xFF150500),
    gridBg: Color(0xFF0A0000),
    gridLine: Color(0xFF350000),
    cellEmpty: Color(0xFF100000),
    panelBg: Color(0xCC120000),
    panelBorder: Color(0xFF880010),
    textPrimary: Color(0xFFFFE0D0),
    textAccent: Color(0xFFCC5530),
    particleColor1: Color(0xFFAA0020),
    particleColor2: Color(0xFFAA6600),
    particleColor3: Color(0xFFAA4400),
    glowColor: Color(0xFF880015),
    blockColors: [
      Color(0xFF990012), // deep crimson
      Color(0xFF7A0030), // deep berry
      Color(0xFF883500), // deep ember
      Color(0xFF3D2820), // dark volcanic ash
      Color(0xFF5A0099), // deep violet
      Color(0xFF330080), // deep indigo
      Color(0xFF881400), // deep lava
    ],
    buttonPrimary: Color(0xFF880000),
    buttonSecondary: Color(0xFF500000),
  ),
);

// ─── Angel Theme ──────────────────────────────
const angelTheme = GameThemeData(
  type: GameThemeType.angel,
  name: 'Celestial Heaven',
  ambientSound: 'angel_ambient.mp3',
  blastSound: 'angel_chime.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF0D0A1E),
    background2: Color(0xFF120E2E),
    background3: Color(0xFF0A1040),
    gridBg: Color(0xFF080616),
    gridLine: Color(0xFF1A0E38),
    cellEmpty: Color(0xFF0C0A20),
    panelBg: Color(0xCC0D0A1E),
    panelBorder: Color(0xFF501060),
    textPrimary: Color(0xFFF0F4FF),
    textAccent: Color(0xFFCCD5FF),
    particleColor1: Color(0xFFBBBBCC),
    particleColor2: Color(0xFF701880),
    particleColor3: Color(0xFFAA8800),
    glowColor: Color(0xFF5020AA),
    blockColors: [
      Color(0xFF1040BB), // deep cobalt
      Color(0xFF330DAA), // deep indigo
      Color(0xFF550099), // deep amethyst
      Color(0xFF660099), // deep orchid
      Color(0xFF005C52), // deep aqua
      Color(0xFF006834), // deep emerald
      Color(0xFF886600), // deep gold
    ],
    buttonPrimary: Color(0xFF400EA0),
    buttonSecondary: Color(0xFF200060),
  ),
);

class ThemeRegistry {
  static const Map<GameThemeType, GameThemeData> themes = {
    GameThemeType.beach: beachTheme,
    GameThemeType.devil: devilTheme,
    GameThemeType.angel: angelTheme,
  };

  static GameThemeData get(GameThemeType type) => themes[type]!;

  // Converts stored string (including legacy 'forest') → theme data
  static GameThemeData fromString(String id) => switch (id) {
        'devil' => devilTheme,
        'angel' => angelTheme,
        _ => beachTheme, // default + handles legacy 'forest'
      };
}
