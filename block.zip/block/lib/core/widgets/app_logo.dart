import 'package:flutter/material.dart';

/// App logo from [assets/images/splash_logo.png].
class AppLogo extends StatelessWidget {
  final double size;
  final BoxFit fit;

  const AppLogo({
    super.key,
    this.size = 100,
    this.fit = BoxFit.contain,
  });

  static const _assetPath = 'assets/images/splash_logo.png';

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      _assetPath,
      width: size,
      height: size,
      fit: fit,
      errorBuilder: (_, __, ___) => Icon(
        Icons.grid_view_rounded,
        size: size * 0.5,
        color: const Color(0xFF7FD96B),
      ),
    );
  }
}
