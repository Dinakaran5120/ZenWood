import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/auth/domain/auth_notifier.dart';

// ─────────────────────────────────────────────
//  Global Real-Time Coin Provider
//
//  Streams the user's coin balance directly from
//  Firestore so all screens (Levels, Store, Profile,
//  Game) always show the same up-to-date value.
//
//  Usage:
//    final coins = ref.watch(coinProvider).valueOrNull ?? 0;
// ─────────────────────────────────────────────

final coinProvider = StreamProvider.autoDispose<int>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  if (uid == null) return Stream.value(0);

  return FirebaseFirestore.instance
      .collection('users')
      .doc(uid)
      .snapshots()
      .map((snap) => (snap.data()?['coins'] as num?)?.toInt() ?? 0);
});
