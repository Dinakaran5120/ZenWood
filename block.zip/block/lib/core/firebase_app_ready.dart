import 'package:firebase_core/firebase_core.dart';

/// True after [Firebase.initializeApp] has been called in main.dart.
bool get isFirebaseInitialized => Firebase.apps.isNotEmpty;
