// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'store_models.dart';
// import 'store_repository.dart';
// import '../auth/domain/auth_notifier.dart';
// import '../admob/admob_service.dart';
// import '../../core/theme/game_theme.dart';
// import '../../core/providers/coin_provider.dart';

// // ─────────────────────────────────────────────
// //  StoreScreen — Premium Powerup Marketplace
// // ─────────────────────────────────────────────

// class StoreScreen extends ConsumerStatefulWidget {
//   final GameThemeData theme;
//   const StoreScreen({super.key, required this.theme});

//   @override
//   ConsumerState<StoreScreen> createState() => _StoreScreenState();
// }

// class _StoreScreenState extends ConsumerState<StoreScreen>
//     with TickerProviderStateMixin {
//   late AnimationController _entryCtrl;
//   late AnimationController _coinPulseCtrl;
//   late AnimationController _featuredCtrl;
//   late PageController _featuredPageCtrl;
//   int _featuredPage = 0;

//   @override
//   void initState() {
//     super.initState();
//     _entryCtrl = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 600),
//     )..forward();

//     _coinPulseCtrl = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 1500),
//     )..repeat(reverse: true);

//     _featuredCtrl = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 400),
//     )..forward();

//     _featuredPageCtrl = PageController();

//     // Auto-advance featured banner
//     Future.delayed(const Duration(seconds: 3), _autoAdvanceFeatured);
//   }

//   void _autoAdvanceFeatured() {
//     if (!mounted) return;
//     final next = (_featuredPage + 1) % _featuredItems.length;
//     _featuredPageCtrl.animateToPage(
//       next,
//       duration: const Duration(milliseconds: 500),
//       curve: Curves.easeInOut,
//     );
//     Future.delayed(const Duration(seconds: 3), _autoAdvanceFeatured);
//   }

//   @override
//   void dispose() {
//     _entryCtrl.dispose();
//     _coinPulseCtrl.dispose();
//     _featuredCtrl.dispose();
//     _featuredPageCtrl.dispose();
//     super.dispose();
//   }

//   // Featured banner items
//   static const _featuredItems = [
//     _FeaturedBannerData(
//       title: 'LUCKY CHEST',
//       subtitle: 'Open for surprise rewards!',
//       emoji: '📦',
//       gradient: [Color(0xFFFF6B35), Color(0xFFFF1744)],
//       itemId: 'chest_lucky',
//     ),
//     _FeaturedBannerData(
//       title: 'RAINBOW BLOCK',
//       subtitle: 'Matches any block — legendary!',
//       emoji: '🌈',
//       gradient: [Color(0xFF7C4DFF), Color(0xFF2979FF)],
//       itemId: 'powerup_rainbow',
//     ),
//     _FeaturedBannerData(
//       title: 'CELESTIAL HEAVEN',
//       subtitle: 'Unlock the divine theme',
//       emoji: '😇',
//       gradient: [Color(0xFF651FFF), Color(0xFFD500F9)],
//       itemId: 'theme_angel',
//     ),
//   ];

//   @override
//   Widget build(BuildContext context) {
//     final store = ref.watch(storeProvider);
//     final auth = ref.watch(authNotifierProvider);
//     final colors = widget.theme.colors;
//     // Real-time coin balance
//     final coins = ref.watch(coinProvider).valueOrNull ?? auth.user?.coins ?? 0;

//     // Show purchase feedback
//     ref.listen<StoreState>(storeProvider, (_, next) {
//       if (next.message != null) {
//         _showSuccessSnack(context, colors, next.message!);
//         ref.read(storeProvider.notifier).clearMessage();
//       }
//     });

//     return Scaffold(
//       backgroundColor: Colors.transparent,
//       body: SafeArea(
//         child: FadeTransition(
//           opacity: CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut),
//           child: Column(
//             children: [
//               // ── Header ────────────────────────
//               _StoreHeader(
//                 colors: colors,
//                 coins: coins,
//                 coinPulse: _coinPulseCtrl,
//               ),

//               // ── Content ───────────────────────
//               Expanded(
//                 child: CustomScrollView(
//                   physics: const BouncingScrollPhysics(),
//                   slivers: [
//                     // Featured banner
//                     SliverToBoxAdapter(
//                       child: _FeaturedBanner(
//                         items: _featuredItems,
//                         colors: colors,
//                         pageCtrl: _featuredPageCtrl,
//                         currentPage: _featuredPage,
//                         onPageChanged: (p) => setState(() => _featuredPage = p),
//                         onTap: (id) => _handleFeaturedTap(id, coins),
//                       ),
//                     ),

//                     // Daily retention strip
//                     SliverToBoxAdapter(
//                       child: _DailyStrip(colors: colors, onSpin: _goToSpin),
//                     ),

//                     // Section title
//                     SliverToBoxAdapter(
//                       child: _SectionTitle(
//                         category: store.selectedCategory,
//                         colors: colors,
//                       ),
//                     ),

//                     // Items grid
//                     store.isLoading
//                         ? SliverFillRemaining(
//                             child: Center(
//                               child: CircularProgressIndicator(
//                                   color: colors.glowColor),
//                             ),
//                           )
//                         : _ItemsSliver(
//                             items: store.filteredItems,
//                             inventory: store.inventory,
//                             coins: coins,
//                             colors: colors,
//                             onBuy: (item) => _handleBuy(item, coins),
//                           ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   void _handleFeaturedTap(String itemId, int coins) {
//     final item = storeCatalog.firstWhere(
//       (i) => i.id == itemId,
//       orElse: () => storeCatalog.first,
//     );
//     _handleBuy(item, coins);
//   }

//   Future<void> _handleBuy(StoreItem item, int coins) async {
//     if (item.isPremium) {
//       _showPremiumDialog(item);
//       return;
//     }

//     if (coins < item.coinPrice) {
//       _showInsufficientCoins(item.coinPrice - coins);
//       return;
//     }

//     // Show rewarded ad popup before purchase
//     await _showRewardedAdPurchaseFlow(item, coins);
//   }

//   Future<void> _showRewardedAdPurchaseFlow(StoreItem item, int coins) async {
//     final colors = widget.theme.colors;
//     final confirmed = await showDialog<bool>(
//       context: context,
//       barrierDismissible: false,
//       builder: (_) => _RewardedAdDialog(
//         item: item,
//         colors: colors,
//         onWatchAd: () async {
//           Navigator.pop(context, false);
//           await _watchAdThenPurchase(item, coins);
//         },
//         onBuyDirectly: () => Navigator.pop(context, true),
//       ),
//     );

//     if (confirmed == true) {
//       await _executePurchase(item, coins);
//     }
//   }

//   Future<void> _watchAdThenPurchase(StoreItem item, int coins) async {
//     final adService = ref.read(adMobServiceProvider);
//     final colors = widget.theme.colors;

//     // Show loading
//     _showAdLoadingSnack(colors);

//     final result = await adService.showRewardedAd(coinsOnSuccess: 0);

//     if (!mounted) return;

//     if (result.earned) {
//       await _executePurchase(item, coins);
//       _showPurchaseSuccess(item, colors);
//     } else {
//       _showSuccessSnack(context, colors, 'Ad skipped — purchase cancelled');
//     }
//   }

//   Future<void> _executePurchase(StoreItem item, int coins) async {
//     final result = await ref.read(storeProvider.notifier).purchase(item, coins);

//     if (!mounted) return;
//     if (!result.isSuccess && result.status == PurchaseStatus.insufficientCoins) {
//       _showInsufficientCoins(result.coinsNeeded ?? 0);
//     } else if (result.isSuccess) {
//       _showPurchaseSuccess(item, widget.theme.colors);
//     }
//   }

//   void _showPurchaseSuccess(StoreItem item, GameThemeColors colors) {
//     if (!mounted) return;
//     showDialog(
//       context: context,
//       builder: (_) => _PurchaseSuccessDialog(item: item, colors: colors),
//     );
//   }

//   void _showInsufficientCoins(int needed) {
//     showDialog(
//       context: context,
//       builder: (_) => _InsufficientCoinsDialog(
//         colors: widget.theme.colors,
//         coinsNeeded: needed,
//         onWatchAd: () async {
//           Navigator.pop(context);
//           final adService = ref.read(adMobServiceProvider);
//           final result = await adService.showRewardedAd(coinsOnSuccess: 150);
//           if (!mounted) return;
//           if (result.earned) {
//             final uid = ref.read(authNotifierProvider).user?.uid;
//             if (uid != null) {
//               await ref.read(storeRepositoryProvider).addCoins(uid, result.coinsEarned);
//             }
//             if (!mounted) return;
//             _showSuccessSnack(context, widget.theme.colors,
//                 '🪙 +${result.coinsEarned} coins earned!');
//           }
//         },
//       ),
//     );
//   }

//   void _showPremiumDialog(StoreItem item) {
//     showDialog(
//       context: context,
//       builder: (_) => _PremiumDialog(item: item, colors: widget.theme.colors),
//     );
//   }

//   void _showAdLoadingSnack(GameThemeColors colors) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: const Text('Loading ad...'),
//         backgroundColor: colors.buttonPrimary,
//         behavior: SnackBarBehavior.floating,
//         duration: const Duration(seconds: 2),
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//       ),
//     );
//   }

//   void _goToSpin() => Navigator.of(context).pop();

//   void _showSuccessSnack(BuildContext ctx, GameThemeColors colors, String msg) {
//     ScaffoldMessenger.of(ctx).showSnackBar(
//       SnackBar(
//         content: Text(msg),
//         backgroundColor: colors.buttonPrimary,
//         behavior: SnackBarBehavior.floating,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//         duration: const Duration(seconds: 2),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────
// //  Featured Banner Data
// // ─────────────────────────────────────────────

// class _FeaturedBannerData {
//   final String title;
//   final String subtitle;
//   final String emoji;
//   final List<Color> gradient;
//   final String itemId;

//   const _FeaturedBannerData({
//     required this.title,
//     required this.subtitle,
//     required this.emoji,
//     required this.gradient,
//     required this.itemId,
//   });
// }

// // ─────────────────────────────────────────────
// //  Store Header
// // ─────────────────────────────────────────────

// class _StoreHeader extends StatelessWidget {
//   final GameThemeColors colors;
//   final int coins;
//   final AnimationController coinPulse;

//   const _StoreHeader({
//     required this.colors,
//     required this.coins,
//     required this.coinPulse,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topCenter,
//           end: Alignment.bottomCenter,
//           colors: [
//             colors.background1,
//             colors.background1.withValues(alpha: 0.0),
//           ],
//         ),
//       ),
//       child: Row(
//         children: [
//           GestureDetector(
//             onTap: () => Navigator.of(context).pop(),
//             child: Container(
//               width: 40,
//               height: 40,
//               decoration: BoxDecoration(
//                 color: colors.panelBg,
//                 borderRadius: BorderRadius.circular(12),
//                 border: Border.all(color: colors.panelBorder.withValues(alpha: 0.5)),
//               ),
//               child: Icon(Icons.arrow_back_ios_new,
//                   color: colors.textPrimary, size: 18),
//             ),
//           ),
//           const SizedBox(width: 14),
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 'STORE',
//                 style: TextStyle(
//                   color: colors.textPrimary,
//                   fontSize: 26,
//                   fontWeight: FontWeight.w900,
//                   letterSpacing: 5,
//                   shadows: [
//                     Shadow(
//                         color: colors.glowColor.withValues(alpha: 0.6),
//                         blurRadius: 16),
//                   ],
//                 ),
//               ),
//               Text(
//                 'Power up your game',
//                 style: TextStyle(
//                   color: colors.textPrimary.withValues(alpha: 0.45),
//                   fontSize: 11,
//                   letterSpacing: 1,
//                 ),
//               ),
//             ],
//           ),
//           const Spacer(),
//           // Animated coin balance
//           AnimatedBuilder(
//             animation: coinPulse,
//             builder: (_, __) => Transform.scale(
//               scale: 1.0 + coinPulse.value * 0.04,
//               child: Container(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [
//                       const Color(0xFFFFB300).withValues(alpha: 0.2),
//                       const Color(0xFFFF8F00).withValues(alpha: 0.15),
//                     ],
//                   ),
//                   borderRadius: BorderRadius.circular(24),
//                   border: Border.all(
//                     color: const Color(0xFFFFB300).withValues(alpha: 0.6),
//                     width: 1.5,
//                   ),
//                   boxShadow: [
//                     BoxShadow(
//                       color: const Color(0xFFFFB300)
//                           .withValues(alpha: 0.2 + coinPulse.value * 0.15),
//                       blurRadius: 12 + coinPulse.value * 6,
//                       spreadRadius: 1,
//                     ),
//                   ],
//                 ),
//                 child: Row(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     const Text('🪙', style: TextStyle(fontSize: 18)),
//                     const SizedBox(width: 8),
//                     Text(
//                       _fmt(coins),
//                       style: const TextStyle(
//                         color: Color(0xFFFFD54F),
//                         fontWeight: FontWeight.w800,
//                         fontSize: 17,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   String _fmt(int n) {
//     if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
//     return n.toString();
//   }
// }

// // ─────────────────────────────────────────────
// //  Featured Banner Carousel
// // ─────────────────────────────────────────────

// class _FeaturedBanner extends StatelessWidget {
//   final List<_FeaturedBannerData> items;
//   final GameThemeColors colors;
//   final PageController pageCtrl;
//   final int currentPage;
//   final ValueChanged<int> onPageChanged;
//   final ValueChanged<String> onTap;

//   const _FeaturedBanner({
//     required this.items,
//     required this.colors,
//     required this.pageCtrl,
//     required this.currentPage,
//     required this.onPageChanged,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final screenWidth = MediaQuery.of(context).size.width;
//     final bannerHeight = (screenWidth * 0.22).clamp(110.0, 180.0);
//     final isSmallScreen = screenWidth < 360;
//     final isVerySmallScreen = screenWidth < 320;
    
//     return Column(
//       children: [
//         SizedBox(
//           height: bannerHeight,
//           child: PageView.builder(
//             controller: pageCtrl,
//             onPageChanged: onPageChanged,
//             itemCount: items.length,
//             itemBuilder: (_, i) {
//               final item = items[i];
//               return GestureDetector(
//                 onTap: () => onTap(item.itemId),
//                 child: Container(
//                   margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
//                   decoration: BoxDecoration(
//                     gradient: LinearGradient(
//                       begin: Alignment.topLeft,
//                       end: Alignment.bottomRight,
//                       colors: item.gradient,
//                     ),
//                     borderRadius: BorderRadius.circular(20),
//                     boxShadow: [
//                       BoxShadow(
//                         color: item.gradient[0].withValues(alpha: 0.5),
//                         blurRadius: 20,
//                         spreadRadius: 1,
//                         offset: const Offset(0, 6),
//                       ),
//                     ],
//                   ),
//                   child: Stack(
//                     children: [
//                       // Background decoration
//                       Positioned(
//                         right: -20,
//                         top: -20,
//                         child: Container(
//                           width: 130,
//                           height: 130,
//                           decoration: BoxDecoration(
//                             shape: BoxShape.circle,
//                             color: Colors.white.withValues(alpha: 0.08),
//                           ),
//                         ),
//                       ),
//                       Positioned(
//                         right: 10,
//                         bottom: -15,
//                         child: Container(
//                           width: 80,
//                               height: 80,
//                               decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: Colors.white.withValues(alpha: 0.05),
//                               ),
//                             ),
//                           ),
//                           // Content
//                           Padding(
//                             padding: EdgeInsets.symmetric(
//                                 horizontal: isVerySmallScreen ? 12 : (isSmallScreen ? 16 : 24), 
//                                 vertical: isVerySmallScreen ? 8 : (isSmallScreen ? 12 : 16)),
//                             child: Row(
//                               children: [
//                                 Expanded(
//                                   child: Column(
//                                     crossAxisAlignment: CrossAxisAlignment.start,
//                                     mainAxisAlignment: MainAxisAlignment.center,
//                                     mainAxisSize: MainAxisSize.min,
//                                     children: [
//                                       Container(
//                                         padding: EdgeInsets.symmetric(
//                                             horizontal: isVerySmallScreen ? 4 : (isSmallScreen ? 6 : 8), 
//                                             vertical: isVerySmallScreen ? 1 : (isSmallScreen ? 2 : 3)),
//                                         decoration: BoxDecoration(
//                                           color: Colors.white.withValues(alpha: 0.2),
//                                           borderRadius: BorderRadius.circular(6),
//                                         ),
//                                         child: Text(
//                                           'FEATURED',
//                                           style: TextStyle(
//                                             color: Colors.white,
//                                             fontSize: isVerySmallScreen ? 7 : (isSmallScreen ? 8 : 9),
//                                             fontWeight: FontWeight.w800,
//                                             letterSpacing: 1.5,
//                                           ),
//                                         ),
//                                       ),
//                                       SizedBox(height: isVerySmallScreen ? 4 : (isSmallScreen ? 6 : 8)),
//                                       Text(
//                                         item.title,
//                                         style: TextStyle(
//                                           color: Colors.white,
//                                           fontSize: isVerySmallScreen ? 16 : (isSmallScreen ? 18 : 22),
//                                           fontWeight: FontWeight.w900,
//                                           letterSpacing: 1,
//                                         ),
//                                       ),
//                                       SizedBox(height: isVerySmallScreen ? 2 : (isSmallScreen ? 3 : 4)),
//                                       Text(
//                                         item.subtitle,
//                                         style: TextStyle(
//                                           color: Colors.white.withValues(alpha: 0.75),
//                                           fontSize: isVerySmallScreen ? 9 : (isSmallScreen ? 10 : 12),
//                                         ),
//                                       ),
//                                       SizedBox(height: isVerySmallScreen ? 6 : (isSmallScreen ? 8 : 12)),
//                                       Container(
//                                         padding: EdgeInsets.symmetric(
//                                             horizontal: isVerySmallScreen ? 8 : (isSmallScreen ? 10 : 14), 
//                                             vertical: isVerySmallScreen ? 4 : (isSmallScreen ? 5 : 7)),
//                                         decoration: BoxDecoration(
//                                           color: Colors.white,
//                                           borderRadius: BorderRadius.circular(10),
//                                         ),
//                                         child: Text(
//                                           'GET NOW →',
//                                           style: TextStyle(
//                                             color: item.gradient[0],
//                                             fontSize: isVerySmallScreen ? 8 : (isSmallScreen ? 9 : 11),
//                                             fontWeight: FontWeight.w800,
//                                             letterSpacing: 1,
//                                           ),
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                                 Text(item.emoji,
//                                     style: TextStyle(fontSize: isVerySmallScreen ? 40 : (isSmallScreen ? 50 : 60))),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   );
//                 },
//               ),
//           ),
//           // Page dots
//           Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: List.generate(
//               items.length,
//               (i) => AnimatedContainer(
//                 duration: const Duration(milliseconds: 200),
//                 margin: const EdgeInsets.symmetric(horizontal: 3),
//                 width: i == currentPage ? 20 : 6,
//                 height: 6,
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(3),
//                   color: i == currentPage
//                       ? colors.glowColor
//                       : colors.panelBorder.withValues(alpha: 0.3),
//                 ),
//               ),
//             ),
//           ),
//           const SizedBox(height: 12),
//         ],
//       );
//     }
//   }

// // ─────────────────────────────────────────────
// //  Daily Retention Strip
// // ─────────────────────────────────────────────

// class _DailyStrip extends StatelessWidget {
//   final GameThemeColors colors;
//   final VoidCallback onSpin;

//   const _DailyStrip({required this.colors, required this.onSpin});

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
//       child: Row(
//         children: [
//           Expanded(
//             child: _StripCard(
//               emoji: '🎁',
//               label: 'Daily Reward',
//               sublabel: 'Claim now',
//               gradient: const [Color(0xFF43A047), Color(0xFF1B5E20)],
//               onTap: () => Navigator.of(context).pop(),
//             ),
//           ),
//           const SizedBox(width: 10),
//           Expanded(
//             child: _StripCard(
//               emoji: '🎰',
//               label: 'Lucky Spin',
//               sublabel: 'Free daily',
//               gradient: const [Color(0xFFE91E63), Color(0xFF880E4F)],
//               onTap: onSpin,
//             ),
//           ),
//           const SizedBox(width: 10),
//           Expanded(
//             child: _StripCard(
//               emoji: '📺',
//               label: 'Free Coins',
//               sublabel: 'Watch ad',
//               gradient: const [Color(0xFF1565C0), Color(0xFF0D47A1)],
//               onTap: () => _watchAdForCoins(context),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   void _watchAdForCoins(BuildContext context) {
//     // Hook into AdMob service — shown via parent StoreScreen
//     Navigator.of(context).pop();
//   }
// }

// class _StripCard extends StatelessWidget {
//   final String emoji;
//   final String label;
//   final String sublabel;
//   final List<Color> gradient;
//   final VoidCallback onTap;

//   const _StripCard({
//     required this.emoji,
//     required this.label,
//     required this.sublabel,
//     required this.gradient,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//             colors: gradient,
//           ),
//           borderRadius: BorderRadius.circular(14),
//           boxShadow: [
//             BoxShadow(
//               color: gradient[0].withValues(alpha: 0.4),
//               blurRadius: 10,
//               spreadRadius: 0,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Column(
//           children: [
//             Text(emoji, style: const TextStyle(fontSize: 22)),
//             const SizedBox(height: 4),
//             Text(
//               label,
//               textAlign: TextAlign.center,
//               style: const TextStyle(
//                 color: Colors.white,
//                 fontSize: 11,
//                 fontWeight: FontWeight.w700,
//               ),
//             ),
//             Text(
//               sublabel,
//               style: TextStyle(
//                 color: Colors.white.withValues(alpha: 0.65),
//                 fontSize: 9,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────
// //  Category Tabs (Pinned)
// // ─────────────────────────────────────────────

// class _CategoryTabsDelegate extends SliverPersistentHeaderDelegate {
//   final ItemCategory selected;
//   final GameThemeColors colors;
//   final ValueChanged<ItemCategory> onSelect;

//   _CategoryTabsDelegate({
//     required this.selected,
//     required this.colors,
//     required this.onSelect,
//   });

//   static const _cats = [
//     (ItemCategory.powerup, '⚡', 'Power-Ups'),
//     (ItemCategory.chest, '📦', 'Chests'),
//     (ItemCategory.theme, '🎨', 'Themes'),
//     (ItemCategory.coins, '🪙', 'Coins'),
//   ];

//   @override
//   Widget build(
//       BuildContext context, double shrinkOffset, bool overlapsContent) {
//     final screenHeight = MediaQuery.of(context).size.height;
//     final tabHeight = screenHeight * 0.07;
//     return Container(
//       color: colors.background1.withValues(alpha: 0.95),
//       child: SizedBox(
//         height: tabHeight.clamp(48.0, 64.0),
//         child: ListView.separated(
//           scrollDirection: Axis.horizontal,
//           padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
//           itemCount: _cats.length,
//           separatorBuilder: (_, __) => const SizedBox(width: 8),
//           itemBuilder: (_, i) {
//             final (cat, emoji, label) = _cats[i];
//             final isActive = cat == selected;
//             return GestureDetector(
//               onTap: () => onSelect(cat),
//               child: AnimatedContainer(
//                 duration: const Duration(milliseconds: 200),
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//                 decoration: BoxDecoration(
//                   gradient: isActive
//                       ? LinearGradient(
//                           colors: [colors.buttonPrimary, colors.buttonSecondary],
//                         )
//                       : null,
//                   color: isActive ? null : colors.panelBg,
//                   borderRadius: BorderRadius.circular(24),
//                   border: Border.all(
//                     color: isActive
//                         ? colors.glowColor.withValues(alpha: 0.6)
//                         : colors.panelBorder.withValues(alpha: 0.3),
//                     width: isActive ? 1.5 : 1,
//                   ),
//                   boxShadow: isActive
//                       ? [
//                           BoxShadow(
//                             color: colors.glowColor.withValues(alpha: 0.35),
//                             blurRadius: 12,
//                             spreadRadius: 1,
//                           ),
//                         ]
//                       : null,
//                 ),
//                 child: Row(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     Text(emoji, style: const TextStyle(fontSize: 14)),
//                     const SizedBox(width: 6),
//                     Text(
//                       label,
//                       style: TextStyle(
//                         color: isActive
//                             ? colors.textPrimary
//                             : colors.textPrimary.withValues(alpha: 0.5),
//                         fontSize: 12,
//                         fontWeight: isActive ? FontWeight.w700 : FontWeight.normal,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }

//   @override
//   double get maxExtent => 64.0;
//   @override
//   double get minExtent => 48.0;
//   @override
//   bool shouldRebuild(_CategoryTabsDelegate old) =>
//       old.selected != selected || old.colors != colors;
// }

// // ─────────────────────────────────────────────
// //  Section Title
// // ─────────────────────────────────────────────

// class _SectionTitle extends StatelessWidget {
//   final ItemCategory category;
//   final GameThemeColors colors;

//   const _SectionTitle({required this.category, required this.colors});

//   String get _title => switch (category) {
//         ItemCategory.powerup => '⚡ Power-Ups',
//         ItemCategory.chest => '📦 Chests',
//         ItemCategory.theme => '🎨 Themes',
//         ItemCategory.coins => '🪙 Coin Packs',
//       };

//   String get _subtitle => switch (category) {
//         ItemCategory.powerup => 'Boost your gameplay instantly',
//         ItemCategory.chest => 'Open for mystery rewards',
//         ItemCategory.theme => 'Unlock premium visual experiences',
//         ItemCategory.coins => 'Get more coins to power up',
//       };

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Text(
//             _title,
//             style: TextStyle(
//               color: colors.textPrimary,
//               fontSize: 18,
//               fontWeight: FontWeight.w800,
//               letterSpacing: 0.5,
//             ),
//           ),
//           const SizedBox(height: 2),
//           Text(
//             _subtitle,
//             style: TextStyle(
//               color: colors.textPrimary.withValues(alpha: 0.4),
//               fontSize: 12,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────
// //  Items Grid (Sliver)
// // ─────────────────────────────────────────────

// class _ItemsSliver extends StatelessWidget {
//   final List<StoreItem> items;
//   final Inventory inventory;
//   final int coins;
//   final GameThemeColors colors;
//   final void Function(StoreItem) onBuy;

//   const _ItemsSliver({
//     required this.items,
//     required this.inventory,
//     required this.coins,
//     required this.colors,
//     required this.onBuy,
//   });

//   @override
//   Widget build(BuildContext context) {
//     if (items.isEmpty) {
//       return SliverFillRemaining(
//         child: Center(
//           child: Text(
//             'No items available',
//             style: TextStyle(
//               color: colors.textPrimary.withValues(alpha: 0.5),
//               fontSize: 16,
//             ),
//           ),
//         ),
//       );
//     }

//     return SliverPadding(
//       padding: const EdgeInsets.symmetric(horizontal: 16),
//       sliver: SliverGrid(
//         gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//           crossAxisCount: 2,
//           childAspectRatio: 0.82,
//           crossAxisSpacing: 12,
//           mainAxisSpacing: 12,
//         ),
//         delegate: SliverChildBuilderDelegate(
//           (_, i) {
//             final item = items[i];
//             final canAfford = coins >= item.coinPrice;
//             final owned = _isOwned(item);

//             return _PowerupCard(
//               item: item,
//               owned: owned,
//               canAfford: canAfford,
//               inventory: inventory,
//               colors: colors,
//               onTap: () => onBuy(item),
//             );
//           },
//           childCount: items.length,
//         ),
//       ),
//     );
//   }

//   bool _isOwned(StoreItem item) {
//     if (item.category == ItemCategory.theme) {
//       final themeId = item.metadata['themeId'] as String?;
//       return themeId != null && inventory.unlockedThemes.contains(themeId);
//     }
//     return false;
//   }
// }

// // ─────────────────────────────────────────────
// //  Powerup Card
// // ─────────────────────────────────────────────

// class _PowerupCard extends StatefulWidget {
//   final StoreItem item;
//   final bool owned;
//   final bool canAfford;
//   final Inventory inventory;
//   final GameThemeColors colors;
//   final VoidCallback onTap;

//   const _PowerupCard({
//     required this.item,
//     required this.owned,
//     required this.canAfford,
//     required this.inventory,
//     required this.colors,
//     required this.onTap,
//   });

//   @override
//   State<_PowerupCard> createState() => _PowerupCardState();
// }

// class _PowerupCardState extends State<_PowerupCard>
//     with SingleTickerProviderStateMixin {
//   late AnimationController _pressCtrl;

//   @override
//   void initState() {
//     super.initState();
//     _pressCtrl = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 100),
//     );
//   }

//   @override
//   void dispose() {
//     _pressCtrl.dispose();
//     super.dispose();
//   }

//   int get _ownedCount {
//     if (widget.item.powerupType == null) return 0;
//     return widget.inventory.countForPowerup(widget.item.powerupType!);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final c = widget.colors;
//     final rarity = widget.item.rarity;
//     final rarityColor1 = Color(rarity.colors[0]);
//     final rarityColor2 = Color(rarity.colors[1]);
//     final count = _ownedCount;

//     return GestureDetector(
//       onTapDown: (_) => _pressCtrl.forward(),
//       onTapUp: (_) {
//         _pressCtrl.reverse();
//         widget.onTap();
//       },
//       onTapCancel: () => _pressCtrl.reverse(),
//       child: AnimatedBuilder(
//         animation: _pressCtrl,
//         builder: (_, __) => Transform.scale(
//           scale: 1.0 - _pressCtrl.value * 0.04,
//           child: Container(
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   c.panelBg,
//                   c.panelBg.withValues(alpha: 0.8),
//                 ],
//               ),
//               borderRadius: BorderRadius.circular(20),
//               border: Border.all(
//                 color: widget.owned
//                     ? const Color(0xFF4CAF50).withValues(alpha: 0.8)
//                     : rarityColor1.withValues(alpha: 0.45),
//                 width: widget.owned ? 2 : 1.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: (widget.owned
//                           ? const Color(0xFF4CAF50)
//                           : rarityColor1)
//                       .withValues(alpha: 0.2),
//                   blurRadius: 16,
//                   spreadRadius: 1,
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withValues(alpha: 0.35),
//                   blurRadius: 10,
//                   offset: const Offset(0, 4),
//                   spreadRadius: -2,
//                 ),
//               ],
//             ),
//             child: Column(
//               children: [
//                 // Rarity bar
//                 Container(
//                   height: 3,
//                   decoration: BoxDecoration(
//                     borderRadius: const BorderRadius.vertical(
//                         top: Radius.circular(18)),
//                     gradient:
//                         LinearGradient(colors: [rarityColor1, rarityColor2]),
//                   ),
//                 ),

//                 Expanded(
//                   child: Padding(
//                     padding: const EdgeInsets.all(14),
//                     child: Column(
//                       children: [
//                         // Top: emoji + owned count badge
//                         Row(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Expanded(
//                               child: Center(
//                                 child: Text(widget.item.emoji,
//                                     style: const TextStyle(fontSize: 38)),
//                               ),
//                             ),
//                             if (count > 0)
//                               Container(
//                                 padding: const EdgeInsets.symmetric(
//                                     horizontal: 7, vertical: 3),
//                                 decoration: BoxDecoration(
//                                   gradient: LinearGradient(
//                                     colors: [rarityColor1, rarityColor2],
//                                   ),
//                                   borderRadius: BorderRadius.circular(10),
//                                 ),
//                                 child: Text(
//                                   '×$count',
//                                   style: const TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 11,
//                                     fontWeight: FontWeight.w800,
//                                   ),
//                                 ),
//                               ),
//                           ],
//                         ),

//                         const SizedBox(height: 8),

//                         // Name
//                         Text(
//                           widget.item.name,
//                           textAlign: TextAlign.center,
//                           style: TextStyle(
//                             color: c.textPrimary,
//                             fontSize: 13,
//                             fontWeight: FontWeight.w700,
//                           ),
//                         ),
//                         const SizedBox(height: 3),

//                         // Description
//                         Text(
//                           widget.item.description,
//                           textAlign: TextAlign.center,
//                           maxLines: 2,
//                           overflow: TextOverflow.ellipsis,
//                           style: TextStyle(
//                             color: c.textPrimary.withValues(alpha: 0.45),
//                             fontSize: 10,
//                             height: 1.3,
//                           ),
//                         ),

//                         const Spacer(),

//                         // Rarity badge
//                         Container(
//                           padding: const EdgeInsets.symmetric(
//                               horizontal: 8, vertical: 2),
//                           decoration: BoxDecoration(
//                             gradient: LinearGradient(
//                                 colors: [rarityColor1, rarityColor2]),
//                             borderRadius: BorderRadius.circular(6),
//                           ),
//                           child: Text(
//                             rarity.label.toUpperCase(),
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontSize: 8,
//                               fontWeight: FontWeight.w800,
//                               letterSpacing: 0.8,
//                             ),
//                           ),
//                         ),

//                         const SizedBox(height: 8),

//                         // Buy button
//                         _BuyButton(
//                           item: widget.item,
//                           owned: widget.owned,
//                           canAfford: widget.canAfford,
//                           colors: c,
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────
// //  Buy Button
// // ─────────────────────────────────────────────

// class _BuyButton extends StatelessWidget {
//   final StoreItem item;
//   final bool owned;
//   final bool canAfford;
//   final GameThemeColors colors;

//   const _BuyButton({
//     required this.item,
//     required this.owned,
//     required this.canAfford,
//     required this.colors,
//   });

//   @override
//   Widget build(BuildContext context) {
//     if (owned && item.category == ItemCategory.theme) {
//       return Container(
//         width: double.infinity,
//         padding: const EdgeInsets.symmetric(vertical: 8),
//         decoration: BoxDecoration(
//           color: const Color(0xFF4CAF50).withValues(alpha: 0.2),
//           borderRadius: BorderRadius.circular(10),
//           border: Border.all(color: const Color(0xFF4CAF50), width: 1.5),
//         ),
//         child: const Text(
//           '✓ OWNED',
//           textAlign: TextAlign.center,
//           style: TextStyle(
//             color: Color(0xFF4CAF50),
//             fontSize: 11,
//             fontWeight: FontWeight.w800,
//             letterSpacing: 0.5,
//           ),
//         ),
//       );
//     }

//     if (item.isPremium) {
//       return Container(
//         width: double.infinity,
//         padding: const EdgeInsets.symmetric(vertical: 8),
//         decoration: BoxDecoration(
//           gradient: const LinearGradient(
//             colors: [Color(0xFFFFB300), Color(0xFFFF8F00)],
//           ),
//           borderRadius: BorderRadius.circular(10),
//           boxShadow: [
//             BoxShadow(
//               color: const Color(0xFFFFB300).withValues(alpha: 0.35),
//               blurRadius: 8,
//               spreadRadius: 1,
//             ),
//           ],
//         ),
//         child: const Text(
//           '💎 PREMIUM',
//           textAlign: TextAlign.center,
//           style: TextStyle(
//             color: Colors.white,
//             fontSize: 11,
//             fontWeight: FontWeight.w800,
//             letterSpacing: 0.5,
//           ),
//         ),
//       );
//     }

//     return Container(
//       width: double.infinity,
//       padding: const EdgeInsets.symmetric(vertical: 8),
//       decoration: BoxDecoration(
//         gradient: canAfford
//             ? LinearGradient(
//                 colors: [colors.buttonPrimary, colors.buttonSecondary],
//               )
//             : null,
//         color: canAfford
//             ? null
//             : colors.panelBorder.withValues(alpha: 0.12),
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(
//           color: canAfford
//               ? colors.glowColor.withValues(alpha: 0.5)
//               : colors.panelBorder.withValues(alpha: 0.2),
//           width: 1,
//         ),
//         boxShadow: canAfford
//             ? [
//                 BoxShadow(
//                   color: colors.glowColor.withValues(alpha: 0.3),
//                   blurRadius: 8,
//                   spreadRadius: 0,
//                 ),
//               ]
//             : null,
//       ),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Text(
//             canAfford ? '🪙' : '🔒',
//             style: const TextStyle(fontSize: 12),
//           ),
//           const SizedBox(width: 4),
//           Text(
//             _fmt(item.coinPrice),
//             style: TextStyle(
//               color: canAfford
//                   ? colors.textPrimary
//                   : colors.textPrimary.withValues(alpha: 0.3),
//               fontSize: 12,
//               fontWeight: FontWeight.w800,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   String _fmt(int n) =>
//       n >= 1000 ? '${(n / 1000).toStringAsFixed(1)}K' : n.toString();
// }

// // ─────────────────────────────────────────────
// //  Rewarded Ad Purchase Dialog
// // ─────────────────────────────────────────────

// class _RewardedAdDialog extends StatelessWidget {
//   final StoreItem item;
//   final GameThemeColors colors;
//   final VoidCallback onWatchAd;
//   final VoidCallback onBuyDirectly;

//   const _RewardedAdDialog({
//     required this.item,
//     required this.colors,
//     required this.onWatchAd,
//     required this.onBuyDirectly,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final rarityColor = Color(item.rarity.colors[0]);

//     return Dialog(
//       backgroundColor: Colors.transparent,
//       child: Container(
//         constraints: BoxConstraints(
//           maxHeight: MediaQuery.of(context).size.height * 0.85,
//         ),
//         child: SingleChildScrollView(
//           child: Container(
//             padding: EdgeInsets.all((MediaQuery.of(context).size.width * 0.06).clamp(16.0, 28.0)),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [colors.panelBg, colors.panelBg.withValues(alpha: 0.9)],
//               ),
//               borderRadius: BorderRadius.circular(28),
//               border: Border.all(
//                   color: rarityColor.withValues(alpha: 0.6), width: 1.5),
//               boxShadow: [
//                 BoxShadow(
//                   color: rarityColor.withValues(alpha: 0.3),
//                   blurRadius: 40,
//                   spreadRadius: 4,
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withValues(alpha: 0.5),
//                   blurRadius: 25,
//                   offset: const Offset(0, 8),
//                 ),
//               ],
//             ),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//             Text(item.emoji, style: const TextStyle(fontSize: 52)),
//             const SizedBox(height: 12),
//             Text(
//               item.name,
//               style: TextStyle(
//                 color: colors.textPrimary,
//                 fontSize: 20,
//                 fontWeight: FontWeight.w800,
//               ),
//             ),
//             const SizedBox(height: 6),
//             Text(
//               item.description,
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                 color: colors.textPrimary.withValues(alpha: 0.5),
//                 fontSize: 13,
//               ),
//             ),
//             const SizedBox(height: 24),

//             // Watch ad option
//             GestureDetector(
//               onTap: onWatchAd,
//               child: Container(
//                 width: double.infinity,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 decoration: BoxDecoration(
//                   gradient: const LinearGradient(
//                     colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
//                   ),
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: const Color(0xFF1565C0).withValues(alpha: 0.4),
//                       blurRadius: 15,
//                       spreadRadius: 1,
//                     ),
//                   ],
//                 ),
//                 child: Column(
//                   children: [
//                     const Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text('📺', style: TextStyle(fontSize: 20)),
//                         SizedBox(width: 8),
//                         Text(
//                           'WATCH AD & GET FREE',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 14,
//                             fontWeight: FontWeight.w800,
//                             letterSpacing: 0.5,
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(height: 4),
//                     Text(
//                       'Watch a short ad — get it free!',
//                       style: TextStyle(
//                         color: Colors.white.withValues(alpha: 0.7),
//                         fontSize: 11,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),

//             const SizedBox(height: 10),

//             // Pay coins option
//             GestureDetector(
//               onTap: onBuyDirectly,
//               child: Container(
//                 width: double.infinity,
//                 padding: const EdgeInsets.symmetric(vertical: 14),
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [colors.buttonPrimary, colors.buttonSecondary],
//                   ),
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: colors.glowColor.withValues(alpha: 0.35),
//                       blurRadius: 12,
//                       spreadRadius: 1,
//                     ),
//                   ],
//                 ),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     const Text('🪙', style: TextStyle(fontSize: 18)),
//                     const SizedBox(width: 8),
//                     Text(
//                       'BUY FOR ${item.coinPrice} COINS',
//                       style: TextStyle(
//                         color: colors.textPrimary,
//                         fontSize: 13,
//                         fontWeight: FontWeight.w800,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),

//             const SizedBox(height: 12),
//             TextButton(
//               onPressed: () => Navigator.pop(context),
//               child: Text(
//                 'Maybe later',
//                 style:
//                     TextStyle(color: colors.textPrimary.withValues(alpha: 0.35)),
//               ),
//             ),
//           ],
//         ),
//       ),
//         ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────
// //  Purchase Success Dialog
// // ─────────────────────────────────────────────

// class _PurchaseSuccessDialog extends StatefulWidget {
//   final StoreItem item;
//   final GameThemeColors colors;

//   const _PurchaseSuccessDialog({required this.item, required this.colors});

//   @override
//   State<_PurchaseSuccessDialog> createState() => _PurchaseSuccessDialogState();
// }

// class _PurchaseSuccessDialogState extends State<_PurchaseSuccessDialog>
//     with SingleTickerProviderStateMixin {
//   late AnimationController _ctrl;
//   late Animation<double> _scale;

//   @override
//   void initState() {
//     super.initState();
//     _ctrl = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 700),
//     )..forward();
//     _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);

//     // Auto-dismiss
//     Future.delayed(const Duration(seconds: 2), () {
//       if (mounted) Navigator.pop(context);
//     });
//   }

//   @override
//   void dispose() {
//     _ctrl.dispose();
//     super.dispose();
//   }

//   String get _successMessage => switch (widget.item.category) {
//         ItemCategory.powerup => '${widget.item.name} Added!',
//         ItemCategory.chest => 'Chest Opened!',
//         ItemCategory.theme => 'Theme Unlocked!',
//         ItemCategory.coins => 'Coins Added!',
//       };

//   @override
//   Widget build(BuildContext context) {
//     final c = widget.colors;
//     return Dialog(
//       backgroundColor: Colors.transparent,
//       child: ScaleTransition(
//         scale: _scale,
//         child: Container(
//           padding: const EdgeInsets.all(32),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [c.panelBg, c.panelBg.withValues(alpha: 0.9)],
//             ),
//             borderRadius: BorderRadius.circular(28),
//             border: Border.all(
//                 color: const Color(0xFF4CAF50).withValues(alpha: 0.7), width: 2),
//             boxShadow: [
//               BoxShadow(
//                 color: const Color(0xFF4CAF50).withValues(alpha: 0.4),
//                 blurRadius: 40,
//                 spreadRadius: 4,
//               ),
//               BoxShadow(
//                 color: Colors.black.withValues(alpha: 0.5),
//                 blurRadius: 25,
//                 offset: const Offset(0, 8),
//               ),
//             ],
//           ),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               const Text('🎉', style: TextStyle(fontSize: 52)),
//               const SizedBox(height: 12),
//               Text(
//                 _successMessage,
//                 textAlign: TextAlign.center,
//                 style: TextStyle(
//                   color: c.textPrimary,
//                   fontSize: 22,
//                   fontWeight: FontWeight.w900,
//                   shadows: [
//                     Shadow(
//                         color: const Color(0xFF4CAF50).withValues(alpha: 0.5),
//                         blurRadius: 12),
//                   ],
//                 ),
//               ),
//               const SizedBox(height: 8),
//               Text(
//                 widget.item.emoji,
//                 style: const TextStyle(fontSize: 40),
//               ),
//               const SizedBox(height: 8),
//               Text(
//                 'Ready to use in your next game!',
//                 style: TextStyle(
//                   color: c.textPrimary.withValues(alpha: 0.45),
//                   fontSize: 12,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────
// //  Insufficient Coins Dialog
// // ─────────────────────────────────────────────

// class _InsufficientCoinsDialog extends StatelessWidget {
//   final GameThemeColors colors;
//   final int coinsNeeded;
//   final VoidCallback onWatchAd;

//   const _InsufficientCoinsDialog({
//     required this.colors,
//     required this.coinsNeeded,
//     required this.onWatchAd,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Dialog(
//       backgroundColor: Colors.transparent,
//       child: Container(
//         padding: const EdgeInsets.all(28),
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//             colors: [colors.panelBg, colors.panelBg.withValues(alpha: 0.9)],
//           ),
//           borderRadius: BorderRadius.circular(28),
//           border: Border.all(
//               color: const Color(0xFFFFB300).withValues(alpha: 0.6), width: 1.5),
//           boxShadow: [
//             BoxShadow(
//               color: const Color(0xFFFFB300).withValues(alpha: 0.25),
//               blurRadius: 35,
//               spreadRadius: 3,
//             ),
//             BoxShadow(
//               color: Colors.black.withValues(alpha: 0.5),
//               blurRadius: 20,
//               offset: const Offset(0, 8),
//             ),
//           ],
//         ),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             const Text('🪙', style: TextStyle(fontSize: 48)),
//             const SizedBox(height: 12),
//             Text(
//               'Not Enough Coins',
//               style: TextStyle(
//                 color: colors.textPrimary,
//                 fontSize: 20,
//                 fontWeight: FontWeight.w800,
//               ),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               'You need $coinsNeeded more coins.\nWatch an ad to earn free coins!',
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                 color: colors.textPrimary.withValues(alpha: 0.5),
//                 fontSize: 13,
//                 height: 1.5,
//               ),
//             ),
//             const SizedBox(height: 24),
//             GestureDetector(
//               onTap: onWatchAd,
//               child: Container(
//                 width: double.infinity,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 decoration: BoxDecoration(
//                   gradient: const LinearGradient(
//                     colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
//                   ),
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: const Color(0xFF1565C0).withValues(alpha: 0.4),
//                       blurRadius: 12,
//                       spreadRadius: 1,
//                     ),
//                   ],
//                 ),
//                 child: const Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text('📺', style: TextStyle(fontSize: 20)),
//                     SizedBox(width: 8),
//                     Text(
//                       'WATCH AD FOR +150 COINS',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 13,
//                         fontWeight: FontWeight.w800,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//             const SizedBox(height: 10),
//             TextButton(
//               onPressed: () => Navigator.pop(context),
//               child: Text(
//                 'Later',
//                 style: TextStyle(
//                     color: colors.textPrimary.withValues(alpha: 0.35)),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────
// //  Premium Dialog (IAP items)
// // ─────────────────────────────────────────────

// class _PremiumDialog extends StatelessWidget {
//   final StoreItem item;
//   final GameThemeColors colors;

//   const _PremiumDialog({required this.item, required this.colors});

//   @override
//   Widget build(BuildContext context) {
//     return Dialog(
//       backgroundColor: Colors.transparent,
//       child: Container(
//         padding: const EdgeInsets.all(28),
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//             colors: [colors.panelBg, colors.panelBg.withValues(alpha: 0.9)],
//           ),
//           borderRadius: BorderRadius.circular(28),
//           border: Border.all(
//               color: const Color(0xFFFFB300).withValues(alpha: 0.7), width: 2),
//           boxShadow: [
//             BoxShadow(
//               color: const Color(0xFFFFB300).withValues(alpha: 0.3),
//               blurRadius: 40,
//               spreadRadius: 4,
//             ),
//           ],
//         ),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Text(item.emoji, style: const TextStyle(fontSize: 52)),
//             const SizedBox(height: 12),
//             Text(
//               item.name,
//               style: TextStyle(
//                 color: colors.textPrimary,
//                 fontSize: 22,
//                 fontWeight: FontWeight.w800,
//               ),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               item.description,
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                 color: colors.textPrimary.withValues(alpha: 0.5),
//                 fontSize: 13,
//               ),
//             ),
//             const SizedBox(height: 24),
//             Container(
//               width: double.infinity,
//               padding: const EdgeInsets.symmetric(vertical: 16),
//               decoration: BoxDecoration(
//                 gradient: const LinearGradient(
//                   colors: [Color(0xFFFFB300), Color(0xFFFF8F00)],
//                 ),
//                 borderRadius: BorderRadius.circular(16),
//                 boxShadow: [
//                   BoxShadow(
//                     color: const Color(0xFFFFB300).withValues(alpha: 0.4),
//                     blurRadius: 12,
//                     spreadRadius: 1,
//                   ),
//                 ],
//               ),
//               child: const Text(
//                 '💎 PURCHASE',
//                 textAlign: TextAlign.center,
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 15,
//                   fontWeight: FontWeight.w800,
//                   letterSpacing: 1,
//                 ),
//               ),
//             ),
//             const SizedBox(height: 10),
//             TextButton(
//               onPressed: () => Navigator.pop(context),
//               child: Text('Cancel',
//                   style: TextStyle(
//                       color: colors.textPrimary.withValues(alpha: 0.35))),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────
// //  Game Over / Revive Dialog
// //  Call this from game_screen.dart when player loses
// // ─────────────────────────────────────────────

// class GameOverReviveDialog extends ConsumerStatefulWidget {
//   final GameThemeData theme;
//   final int score;
//   final VoidCallback onReviveAd;
//   final VoidCallback onReviveHammer;
//   final VoidCallback onReviveBomb;
//   final VoidCallback onRestart;

//   const GameOverReviveDialog({
//     super.key,
//     required this.theme,
//     required this.score,
//     required this.onReviveAd,
//     required this.onReviveHammer,
//     required this.onReviveBomb,
//     required this.onRestart,
//   });

//   @override
//   ConsumerState<GameOverReviveDialog> createState() =>
//       _GameOverReviveDialogState();
// }

// class _GameOverReviveDialogState extends ConsumerState<GameOverReviveDialog>
//     with SingleTickerProviderStateMixin {
//   late AnimationController _ctrl;
//   late Animation<double> _scale;
//   late Animation<double> _fade;
//   int _countdown = 5;

//   @override
//   void initState() {
//     super.initState();
//     _ctrl = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 700),
//     )..forward();
//     _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
//     _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
//     _startCountdown();
//   }

//   void _startCountdown() {
//     Future.delayed(const Duration(seconds: 1), () {
//       if (!mounted) return;
//       setState(() => _countdown--);
//       if (_countdown > 0) _startCountdown();
//     });
//   }

//   @override
//   void dispose() {
//     _ctrl.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final c = widget.theme.colors;
//     final inventory = ref.watch(storeProvider).inventory;

//     return AnimatedBuilder(
//       animation: _ctrl,
//       builder: (_, __) => Container(
//         color: Colors.black.withValues(alpha: 0.85 * _fade.value),
//         child: Center(
//           child: ScaleTransition(
//             scale: _scale,
//             child: Container(
//               margin: const EdgeInsets.all(32),
//               padding: const EdgeInsets.all(28),
//               decoration: BoxDecoration(
//                 gradient: LinearGradient(
//                   begin: Alignment.topLeft,
//                   end: Alignment.bottomRight,
//                   colors: [c.panelBg, c.panelBg.withValues(alpha: 0.95)],
//                 ),
//                 borderRadius: BorderRadius.circular(32),
//                 border: Border.all(
//                     color: const Color(0xFFFF1744).withValues(alpha: 0.7), width: 2),
//                 boxShadow: [
//                   BoxShadow(
//                     color: const Color(0xFFFF1744).withValues(alpha: 0.3),
//                     blurRadius: 50,
//                     spreadRadius: 5,
//                   ),
//                   BoxShadow(
//                     color: Colors.black.withValues(alpha: 0.5),
//                     blurRadius: 30,
//                     offset: const Offset(0, 10),
//                   ),
//                 ],
//               ),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   const Text('💀', style: TextStyle(fontSize: 52)),
//                   const SizedBox(height: 8),
//                   Text(
//                     'GAME OVER',
//                     style: TextStyle(
//                       color: const Color(0xFFFF1744),
//                       fontSize: 26,
//                       fontWeight: FontWeight.w900,
//                       letterSpacing: 3,
//                       shadows: [
//                         Shadow(
//                           color: const Color(0xFFFF1744).withValues(alpha: 0.6),
//                           blurRadius: 16,
//                         ),
//                       ],
//                     ),
//                   ),
//                   const SizedBox(height: 4),
//                   Text(
//                     'Score: ${widget.score}',
//                     style: TextStyle(
//                       color: c.textPrimary.withValues(alpha: 0.5),
//                       fontSize: 14,
//                     ),
//                   ),
//                   const SizedBox(height: 6),
//                   // Countdown
//                   AnimatedContainer(
//                     duration: const Duration(milliseconds: 300),
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 12, vertical: 4),
//                     decoration: BoxDecoration(
//                       color: const Color(0xFFFF1744).withValues(alpha: 0.15),
//                       borderRadius: BorderRadius.circular(10),
//                       border: Border.all(
//                           color: const Color(0xFFFF1744).withValues(alpha: 0.4)),
//                     ),
//                     child: Text(
//                       'Continue? $_countdown',
//                       style: const TextStyle(
//                         color: Color(0xFFFF1744),
//                         fontSize: 13,
//                         fontWeight: FontWeight.w700,
//                       ),
//                     ),
//                   ),
//                   const SizedBox(height: 20),

//                   // Watch Ad to Continue
//                   _ReviveOption(
//                     emoji: '📺',
//                     label: 'Continue Watching Ad',
//                     sublabel: 'Keep your current board',
//                     gradient: const [
//                       Color(0xFF1565C0),
//                       Color(0xFF0D47A1)
//                     ],
//                     onTap: widget.onReviveAd,
//                   ),
//                   const SizedBox(height: 10),

//                   // Use Hammer
//                   if (inventory.hammers > 0) ...[
//                     _ReviveOption(
//                       emoji: '🔨',
//                       label: 'Use Hammer (×${inventory.hammers})',
//                       sublabel: 'Break a block and continue',
//                       gradient: const [
//                         Color(0xFF795548),
//                         Color(0xFF4E342E)
//                       ],
//                       onTap: widget.onReviveHammer,
//                     ),
//                     const SizedBox(height: 10),
//                   ],

//                   // Use Bomb
//                   if (inventory.bombs > 0) ...[
//                     _ReviveOption(
//                       emoji: '💣',
//                       label: 'Use Bomb (×${inventory.bombs})',
//                       sublabel: 'Blast an area and continue',
//                       gradient: const [
//                         Color(0xFF424242),
//                         Color(0xFF212121)
//                       ],
//                       onTap: widget.onReviveBomb,
//                     ),
//                     const SizedBox(height: 10),
//                   ],

//                   // Restart
//                   GestureDetector(
//                     onTap: widget.onRestart,
//                     child: Container(
//                       width: double.infinity,
//                       padding: const EdgeInsets.symmetric(vertical: 14),
//                       decoration: BoxDecoration(
//                         color: c.panelBorder.withValues(alpha: 0.1),
//                         borderRadius: BorderRadius.circular(14),
//                         border: Border.all(
//                             color: c.panelBorder.withValues(alpha: 0.3)),
//                       ),
//                       child: Text(
//                         '↺  Start Over',
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                           color: c.textPrimary.withValues(alpha: 0.5),
//                           fontSize: 14,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

// class _ReviveOption extends StatelessWidget {
//   final String emoji;
//   final String label;
//   final String sublabel;
//   final List<Color> gradient;
//   final VoidCallback onTap;

//   const _ReviveOption({
//     required this.emoji,
//     required this.label,
//     required this.sublabel,
//     required this.gradient,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         width: double.infinity,
//         padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             colors: gradient,
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//           ),
//           borderRadius: BorderRadius.circular(14),
//           boxShadow: [
//             BoxShadow(
//               color: gradient[0].withValues(alpha: 0.4),
//               blurRadius: 12,
//               spreadRadius: 1,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Row(
//           children: [
//             Text(emoji, style: const TextStyle(fontSize: 22)),
//             const SizedBox(width: 12),
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   label,
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 13,
//                     fontWeight: FontWeight.w700,
//                   ),
//                 ),
//                 Text(
//                   sublabel,
//                   style: TextStyle(
//                     color: Colors.white.withValues(alpha: 0.6),
//                     fontSize: 10,
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'store_models.dart';
import 'store_repository.dart';
import '../auth/domain/auth_notifier.dart';
import '../admob/admob_service.dart';
import '../../core/theme/game_theme.dart';
import '../../core/providers/coin_provider.dart';

// ─────────────────────────────────────────────
//  StoreScreen — Premium Powerup Marketplace
// ─────────────────────────────────────────────

class StoreScreen extends ConsumerStatefulWidget {
  final GameThemeData theme;
  const StoreScreen({super.key, required this.theme});

  @override
  ConsumerState<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends ConsumerState<StoreScreen>
    with TickerProviderStateMixin {
  late AnimationController _entryCtrl;
  late AnimationController _coinPulseCtrl;
  late AnimationController _featuredCtrl;
  late PageController _featuredPageCtrl;
  int _featuredPage = 0;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();

    _coinPulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _featuredCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    )..forward();

    _featuredPageCtrl = PageController();

    // Auto-advance featured banner
    Future.delayed(const Duration(seconds: 3), _autoAdvanceFeatured);
  }

  void _autoAdvanceFeatured() {
    if (!mounted) return;
    final next = (_featuredPage + 1) % _featuredItems.length;
    _featuredPageCtrl.animateToPage(
      next,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
    Future.delayed(const Duration(seconds: 3), _autoAdvanceFeatured);
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _coinPulseCtrl.dispose();
    _featuredCtrl.dispose();
    _featuredPageCtrl.dispose();
    super.dispose();
  }

  // Featured banner items
  static const _featuredItems = [
    _FeaturedBannerData(
      title: 'LUCKY CHEST',
      subtitle: 'Open for surprise rewards!',
      emoji: '📦',
      gradient: [Color(0xFFFF6B35), Color(0xFFFF1744)],
      itemId: 'chest_lucky',
    ),
    _FeaturedBannerData(
      title: 'RAINBOW BLOCK',
      subtitle: 'Matches any block — legendary!',
      emoji: '🌈',
      gradient: [Color(0xFF7C4DFF), Color(0xFF2979FF)],
      itemId: 'powerup_rainbow',
    ),
    _FeaturedBannerData(
      title: 'CELESTIAL HEAVEN',
      subtitle: 'Unlock the divine theme',
      emoji: '😇',
      gradient: [Color(0xFF651FFF), Color(0xFFD500F9)],
      itemId: 'theme_angel',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final store = ref.watch(storeProvider);
    final auth = ref.watch(authNotifierProvider);
    final colors = widget.theme.colors;
    // Real-time coin balance
    final coins = ref.watch(coinProvider).valueOrNull ?? auth.user?.coins ?? 0;

    // Show purchase feedback
    ref.listen<StoreState>(storeProvider, (_, next) {
      if (next.message != null) {
        _showSuccessSnack(context, colors, next.message!);
        ref.read(storeProvider.notifier).clearMessage();
      }
    });

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: FadeTransition(
          opacity: CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut),
          child: Column(
            children: [
              // ── Header ────────────────────────
              _StoreHeader(
                colors: colors,
                coins: coins,
                coinPulse: _coinPulseCtrl,
              ),

              // ── Content ───────────────────────
              Expanded(
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    // Featured banner
                    SliverToBoxAdapter(
                      child: _FeaturedBanner(
                        items: _featuredItems,
                        colors: colors,
                        pageCtrl: _featuredPageCtrl,
                        currentPage: _featuredPage,
                        onPageChanged: (p) => setState(() => _featuredPage = p),
                        onTap: (id) => _handleFeaturedTap(id, coins),
                      ),
                    ),

                    // Daily retention strip
                    SliverToBoxAdapter(
                      child: _DailyStrip(colors: colors, onSpin: _goToSpin),
                    ),

                    // Section title
                    SliverToBoxAdapter(
                      child: _SectionTitle(
                        category: store.selectedCategory,
                        colors: colors,
                      ),
                    ),

                    // Items grid
                    store.isLoading
                        ? SliverFillRemaining(
                            child: Center(
                              child: CircularProgressIndicator(
                                  color: colors.glowColor),
                            ),
                          )
                        : _ItemsSliver(
                            items: store.filteredItems,
                            inventory: store.inventory,
                            coins: coins,
                            colors: colors,
                            onBuy: (item) => _handleBuy(item, coins),
                          ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleFeaturedTap(String itemId, int coins) {
    final item = storeCatalog.firstWhere(
      (i) => i.id == itemId,
      orElse: () => storeCatalog.first,
    );
    _handleBuy(item, coins);
  }

  Future<void> _handleBuy(StoreItem item, int coins) async {
    if (item.isPremium) {
      _showPremiumDialog(item);
      return;
    }

    if (coins < item.coinPrice) {
      _showInsufficientCoins(item.coinPrice - coins);
      return;
    }

    // Show rewarded ad popup before purchase
    await _showRewardedAdPurchaseFlow(item, coins);
  }

  Future<void> _showRewardedAdPurchaseFlow(StoreItem item, int coins) async {
    final colors = widget.theme.colors;
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _RewardedAdDialog(
        item: item,
        colors: colors,
        onWatchAd: () async {
          Navigator.pop(context, false);
          await _watchAdThenPurchase(item, coins);
        },
        onBuyDirectly: () => Navigator.pop(context, true),
      ),
    );

    if (confirmed == true) {
      await _executePurchase(item, coins);
    }
  }

  Future<void> _watchAdThenPurchase(StoreItem item, int coins) async {
    final adService = ref.read(adMobServiceProvider);
    final colors = widget.theme.colors;

    // Show loading
    _showAdLoadingSnack(colors);

    final result = await adService.showRewardedAd(coinsOnSuccess: 0);

    if (!mounted) return;

    if (result.earned) {
      await _executePurchase(item, coins);
      _showPurchaseSuccess(item, colors);
    } else {
      _showSuccessSnack(context, colors, 'Ad skipped — purchase cancelled');
    }
  }

  Future<void> _executePurchase(StoreItem item, int coins) async {
    final result = await ref.read(storeProvider.notifier).purchase(item, coins);

    if (!mounted) return;
    if (!result.isSuccess && result.status == PurchaseStatus.insufficientCoins) {
      _showInsufficientCoins(result.coinsNeeded ?? 0);
    } else if (result.isSuccess) {
      _showPurchaseSuccess(item, widget.theme.colors);
    }
  }

  void _showPurchaseSuccess(StoreItem item, GameThemeColors colors) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => _PurchaseSuccessDialog(item: item, colors: colors),
    );
  }

  void _showInsufficientCoins(int needed) {
    showDialog(
      context: context,
      builder: (_) => _InsufficientCoinsDialog(
        colors: widget.theme.colors,
        coinsNeeded: needed,
        onWatchAd: () async {
          Navigator.pop(context);
          final adService = ref.read(adMobServiceProvider);
          final result = await adService.showRewardedAd(coinsOnSuccess: 150);
          if (!mounted) return;
          if (result.earned) {
            final uid = ref.read(authNotifierProvider).user?.uid;
            if (uid != null) {
              await ref.read(storeRepositoryProvider).addCoins(uid, result.coinsEarned);
            }
            if (!mounted) return;
            _showSuccessSnack(context, widget.theme.colors,
                '🪙 +${result.coinsEarned} coins earned!');
          }
        },
      ),
    );
  }

  void _showPremiumDialog(StoreItem item) {
    showDialog(
      context: context,
      builder: (_) => _PremiumDialog(item: item, colors: widget.theme.colors),
    );
  }

  void _showAdLoadingSnack(GameThemeColors colors) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Loading ad...'),
        backgroundColor: colors.buttonPrimary,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _goToSpin() => Navigator.of(context).pop();

  void _showSuccessSnack(BuildContext ctx, GameThemeColors colors, String msg) {
    ScaffoldMessenger.of(ctx).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: colors.buttonPrimary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Featured Banner Data
// ─────────────────────────────────────────────

class _FeaturedBannerData {
  final String title;
  final String subtitle;
  final String emoji;
  final List<Color> gradient;
  final String itemId;

  const _FeaturedBannerData({
    required this.title,
    required this.subtitle,
    required this.emoji,
    required this.gradient,
    required this.itemId,
  });
}

// ─────────────────────────────────────────────
//  Store Header
// ─────────────────────────────────────────────

class _StoreHeader extends StatelessWidget {
  final GameThemeColors colors;
  final int coins;
  final AnimationController coinPulse;

  const _StoreHeader({
    required this.colors,
    required this.coins,
    required this.coinPulse,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            colors.background1,
            colors.background1.withValues(alpha: 0.0),
          ],
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: colors.panelBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: colors.panelBorder.withValues(alpha: 0.5)),
              ),
              child: Icon(Icons.arrow_back_ios_new,
                  color: colors.textPrimary, size: 18),
            ),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'STORE',
                style: TextStyle(
                  color: colors.textPrimary,
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 5,
                  shadows: [
                    Shadow(
                        color: colors.glowColor.withValues(alpha: 0.6),
                        blurRadius: 16),
                  ],
                ),
              ),
              Text(
                'Power up your game',
                style: TextStyle(
                  color: colors.textPrimary.withValues(alpha: 0.45),
                  fontSize: 11,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const Spacer(),
          // Animated coin balance
          AnimatedBuilder(
            animation: coinPulse,
            builder: (_, __) => Transform.scale(
              scale: 1.0 + coinPulse.value * 0.04,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFFFFB300).withValues(alpha: 0.2),
                      const Color(0xFFFF8F00).withValues(alpha: 0.15),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: const Color(0xFFFFB300).withValues(alpha: 0.6),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFFB300)
                          .withValues(alpha: 0.2 + coinPulse.value * 0.15),
                      blurRadius: 12 + coinPulse.value * 6,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('🪙', style: TextStyle(fontSize: 18)),
                    const SizedBox(width: 8),
                    Text(
                      _fmt(coins),
                      style: const TextStyle(
                        color: Color(0xFFFFD54F),
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _fmt(int n) {
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}

// ─────────────────────────────────────────────
//  Featured Banner Carousel — FIXED overflow
// ─────────────────────────────────────────────

class _FeaturedBanner extends StatelessWidget {
  final List<_FeaturedBannerData> items;
  final GameThemeColors colors;
  final PageController pageCtrl;
  final int currentPage;
  final ValueChanged<int> onPageChanged;
  final ValueChanged<String> onTap;

  const _FeaturedBanner({
    required this.items,
    required this.colors,
    required this.pageCtrl,
    required this.currentPage,
    required this.onPageChanged,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    // FIX 1: Increased multiplier from 0.22 to 0.32 and raised clamp min
    final bannerHeight = (screenWidth * 0.32).clamp(150.0, 200.0);
    final isSmallScreen = screenWidth < 360;
    final isVerySmallScreen = screenWidth < 320;

    return Column(
      children: [
        SizedBox(
          height: bannerHeight,
          child: PageView.builder(
            controller: pageCtrl,
            onPageChanged: onPageChanged,
            itemCount: items.length,
            itemBuilder: (_, i) {
              final item = items[i];
              return GestureDetector(
                onTap: () => onTap(item.itemId),
                child: Container(
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                  // FIX 2: Added clipBehavior to prevent decorative
                  // circles from pushing content outside bounds
                  clipBehavior: Clip.hardEdge,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: item.gradient,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: item.gradient[0].withValues(alpha: 0.5),
                        blurRadius: 20,
                        spreadRadius: 1,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      // Background decoration circles
                      Positioned(
                        right: -20,
                        top: -20,
                        child: Container(
                          width: 130,
                          height: 130,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withValues(alpha: 0.08),
                          ),
                        ),
                      ),
                      Positioned(
                        right: 10,
                        bottom: -15,
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withValues(alpha: 0.05),
                          ),
                        ),
                      ),
                      // FIX 3: Reduced vertical padding to prevent overflow
                      Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: isVerySmallScreen
                              ? 10
                              : (isSmallScreen ? 14 : 20),
                          vertical: isVerySmallScreen
                              ? 6
                              : (isSmallScreen ? 8 : 12),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: isVerySmallScreen
                                          ? 4
                                          : (isSmallScreen ? 6 : 8),
                                      vertical: isVerySmallScreen
                                          ? 1
                                          : (isSmallScreen ? 2 : 3),
                                    ),
                                    decoration: BoxDecoration(
                                      color:
                                          Colors.white.withValues(alpha: 0.2),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      'FEATURED',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: isVerySmallScreen
                                            ? 7
                                            : (isSmallScreen ? 8 : 9),
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 1.5,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                      height: isVerySmallScreen
                                          ? 4
                                          : (isSmallScreen ? 5 : 6)),
                                  Text(
                                    item.title,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: isVerySmallScreen
                                          ? 16
                                          : (isSmallScreen ? 18 : 22),
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1,
                                    ),
                                  ),
                                  SizedBox(
                                      height: isVerySmallScreen
                                          ? 2
                                          : (isSmallScreen ? 3 : 4)),
                                  Text(
                                    item.subtitle,
                                    style: TextStyle(
                                      color: Colors.white
                                          .withValues(alpha: 0.75),
                                      fontSize: isVerySmallScreen
                                          ? 9
                                          : (isSmallScreen ? 10 : 12),
                                    ),
                                  ),
                                  SizedBox(
                                      height: isVerySmallScreen
                                          ? 6
                                          : (isSmallScreen ? 7 : 10)),
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: isVerySmallScreen
                                          ? 8
                                          : (isSmallScreen ? 10 : 14),
                                      vertical: isVerySmallScreen
                                          ? 4
                                          : (isSmallScreen ? 5 : 7),
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text(
                                      'GET NOW →',
                                      style: TextStyle(
                                        color: item.gradient[0],
                                        fontSize: isVerySmallScreen
                                            ? 8
                                            : (isSmallScreen ? 9 : 11),
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              item.emoji,
                              style: TextStyle(
                                fontSize: isVerySmallScreen
                                    ? 40
                                    : (isSmallScreen ? 50 : 60),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        // Page dots
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            items.length,
            (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: i == currentPage ? 20 : 6,
              height: 6,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                color: i == currentPage
                    ? colors.glowColor
                    : colors.panelBorder.withValues(alpha: 0.3),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }
}

// ─────────────────────────────────────────────
//  Daily Retention Strip
// ─────────────────────────────────────────────

class _DailyStrip extends StatelessWidget {
  final GameThemeColors colors;
  final VoidCallback onSpin;

  const _DailyStrip({required this.colors, required this.onSpin});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
      child: Row(
        children: [
          Expanded(
            child: _StripCard(
              emoji: '🎁',
              label: 'Daily Reward',
              sublabel: 'Claim now',
              gradient: const [Color(0xFF43A047), Color(0xFF1B5E20)],
              onTap: () => Navigator.of(context).pop(),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StripCard(
              emoji: '🎰',
              label: 'Lucky Spin',
              sublabel: 'Free daily',
              gradient: const [Color(0xFFE91E63), Color(0xFF880E4F)],
              onTap: onSpin,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StripCard(
              emoji: '📺',
              label: 'Free Coins',
              sublabel: 'Watch ad',
              gradient: const [Color(0xFF1565C0), Color(0xFF0D47A1)],
              onTap: () => _watchAdForCoins(context),
            ),
          ),
        ],
      ),
    );
  }

  void _watchAdForCoins(BuildContext context) {
    Navigator.of(context).pop();
  }
}

class _StripCard extends StatelessWidget {
  final String emoji;
  final String label;
  final String sublabel;
  final List<Color> gradient;
  final VoidCallback onTap;

  const _StripCard({
    required this.emoji,
    required this.label,
    required this.sublabel,
    required this.gradient,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: gradient,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: gradient[0].withValues(alpha: 0.4),
              blurRadius: 10,
              spreadRadius: 0,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 4),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              sublabel,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.65),
                fontSize: 9,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Category Tabs (Pinned)
// ─────────────────────────────────────────────

class _CategoryTabsDelegate extends SliverPersistentHeaderDelegate {
  final ItemCategory selected;
  final GameThemeColors colors;
  final ValueChanged<ItemCategory> onSelect;

  _CategoryTabsDelegate({
    required this.selected,
    required this.colors,
    required this.onSelect,
  });

  static const _cats = [
    (ItemCategory.powerup, '⚡', 'Power-Ups'),
    (ItemCategory.chest, '📦', 'Chests'),
    (ItemCategory.theme, '🎨', 'Themes'),
    (ItemCategory.coins, '🪙', 'Coins'),
  ];

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    final screenHeight = MediaQuery.of(context).size.height;
    final tabHeight = screenHeight * 0.07;
    return Container(
      color: colors.background1.withValues(alpha: 0.95),
      child: SizedBox(
        height: tabHeight.clamp(48.0, 64.0),
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          itemCount: _cats.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            final (cat, emoji, label) = _cats[i];
            final isActive = cat == selected;
            return GestureDetector(
              onTap: () => onSelect(cat),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: isActive
                      ? LinearGradient(
                          colors: [
                            colors.buttonPrimary,
                            colors.buttonSecondary
                          ],
                        )
                      : null,
                  color: isActive ? null : colors.panelBg,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: isActive
                        ? colors.glowColor.withValues(alpha: 0.6)
                        : colors.panelBorder.withValues(alpha: 0.3),
                    width: isActive ? 1.5 : 1,
                  ),
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                            color: colors.glowColor.withValues(alpha: 0.35),
                            blurRadius: 12,
                            spreadRadius: 1,
                          ),
                        ]
                      : null,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(emoji, style: const TextStyle(fontSize: 14)),
                    const SizedBox(width: 6),
                    Text(
                      label,
                      style: TextStyle(
                        color: isActive
                            ? colors.textPrimary
                            : colors.textPrimary.withValues(alpha: 0.5),
                        fontSize: 12,
                        fontWeight: isActive
                            ? FontWeight.w700
                            : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  double get maxExtent => 64.0;
  @override
  double get minExtent => 48.0;
  @override
  bool shouldRebuild(_CategoryTabsDelegate old) =>
      old.selected != selected || old.colors != colors;
}

// ─────────────────────────────────────────────
//  Section Title
// ─────────────────────────────────────────────

class _SectionTitle extends StatelessWidget {
  final ItemCategory category;
  final GameThemeColors colors;

  const _SectionTitle({required this.category, required this.colors});

  String get _title => switch (category) {
        ItemCategory.powerup => '⚡ Power-Ups',
        ItemCategory.chest => '📦 Chests',
        ItemCategory.theme => '🎨 Themes',
        ItemCategory.coins => '🪙 Coin Packs',
      };

  String get _subtitle => switch (category) {
        ItemCategory.powerup => 'Boost your gameplay instantly',
        ItemCategory.chest => 'Open for mystery rewards',
        ItemCategory.theme => 'Unlock premium visual experiences',
        ItemCategory.coins => 'Get more coins to power up',
      };

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _title,
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 18,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            _subtitle,
            style: TextStyle(
              color: colors.textPrimary.withValues(alpha: 0.4),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Items Grid (Sliver)
// ─────────────────────────────────────────────

class _ItemsSliver extends StatelessWidget {
  final List<StoreItem> items;
  final Inventory inventory;
  final int coins;
  final GameThemeColors colors;
  final void Function(StoreItem) onBuy;

  const _ItemsSliver({
    required this.items,
    required this.inventory,
    required this.coins,
    required this.colors,
    required this.onBuy,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return SliverFillRemaining(
        child: Center(
          child: Text(
            'No items available',
            style: TextStyle(
              color: colors.textPrimary.withValues(alpha: 0.5),
              fontSize: 16,
            ),
          ),
        ),
      );
    }

    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.82,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        delegate: SliverChildBuilderDelegate(
          (_, i) {
            final item = items[i];
            final canAfford = coins >= item.coinPrice;
            final owned = _isOwned(item);

            return _PowerupCard(
              item: item,
              owned: owned,
              canAfford: canAfford,
              inventory: inventory,
              colors: colors,
              onTap: () => onBuy(item),
            );
          },
          childCount: items.length,
        ),
      ),
    );
  }

  bool _isOwned(StoreItem item) {
    if (item.category == ItemCategory.theme) {
      final themeId = item.metadata['themeId'] as String?;
      return themeId != null && inventory.unlockedThemes.contains(themeId);
    }
    return false;
  }
}

// ─────────────────────────────────────────────
//  Powerup Card
// ─────────────────────────────────────────────

class _PowerupCard extends StatefulWidget {
  final StoreItem item;
  final bool owned;
  final bool canAfford;
  final Inventory inventory;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _PowerupCard({
    required this.item,
    required this.owned,
    required this.canAfford,
    required this.inventory,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_PowerupCard> createState() => _PowerupCardState();
}

class _PowerupCardState extends State<_PowerupCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressCtrl;

  @override
  void initState() {
    super.initState();
    _pressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
  }

  @override
  void dispose() {
    _pressCtrl.dispose();
    super.dispose();
  }

  int get _ownedCount {
    if (widget.item.powerupType == null) return 0;
    return widget.inventory.countForPowerup(widget.item.powerupType!);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    final rarity = widget.item.rarity;
    final rarityColor1 = Color(rarity.colors[0]);
    final rarityColor2 = Color(rarity.colors[1]);
    final count = _ownedCount;

    return GestureDetector(
      onTapDown: (_) => _pressCtrl.forward(),
      onTapUp: (_) {
        _pressCtrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _pressCtrl.reverse(),
      child: AnimatedBuilder(
        animation: _pressCtrl,
        builder: (_, __) => Transform.scale(
          scale: 1.0 - _pressCtrl.value * 0.04,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  c.panelBg,
                  c.panelBg.withValues(alpha: 0.8),
                ],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: widget.owned
                    ? const Color(0xFF4CAF50).withValues(alpha: 0.8)
                    : rarityColor1.withValues(alpha: 0.45),
                width: widget.owned ? 2 : 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: (widget.owned
                          ? const Color(0xFF4CAF50)
                          : rarityColor1)
                      .withValues(alpha: 0.2),
                  blurRadius: 16,
                  spreadRadius: 1,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.35),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                  spreadRadius: -2,
                ),
              ],
            ),
            child: Column(
              children: [
                // Rarity bar
                Container(
                  height: 3,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(18)),
                    gradient: LinearGradient(
                        colors: [rarityColor1, rarityColor2]),
                  ),
                ),

                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      children: [
                        // Top: emoji + owned count badge
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Center(
                                child: Text(widget.item.emoji,
                                    style:
                                        const TextStyle(fontSize: 38)),
                              ),
                            ),
                            if (count > 0)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 7, vertical: 3),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [rarityColor1, rarityColor2],
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  '×$count',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                          ],
                        ),

                        const SizedBox(height: 8),

                        // Name
                        Text(
                          widget.item.name,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: c.textPrimary,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 3),

                        // Description
                        Text(
                          widget.item.description,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: c.textPrimary.withValues(alpha: 0.45),
                            fontSize: 10,
                            height: 1.3,
                          ),
                        ),

                        const Spacer(),

                        // Rarity badge
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [rarityColor1, rarityColor2]),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            rarity.label.toUpperCase(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 8,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),

                        const SizedBox(height: 8),

                        // Buy button
                        _BuyButton(
                          item: widget.item,
                          owned: widget.owned,
                          canAfford: widget.canAfford,
                          colors: c,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Buy Button
// ─────────────────────────────────────────────

class _BuyButton extends StatelessWidget {
  final StoreItem item;
  final bool owned;
  final bool canAfford;
  final GameThemeColors colors;

  const _BuyButton({
    required this.item,
    required this.owned,
    required this.canAfford,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    if (owned && item.category == ItemCategory.theme) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF4CAF50).withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
              color: const Color(0xFF4CAF50), width: 1.5),
        ),
        child: const Text(
          '✓ OWNED',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFF4CAF50),
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.5,
          ),
        ),
      );
    }

    if (item.isPremium) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFFB300), Color(0xFFFF8F00)],
          ),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFFB300).withValues(alpha: 0.35),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: const Text(
          '💎 PREMIUM',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.5,
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        gradient: canAfford
            ? LinearGradient(
                colors: [colors.buttonPrimary, colors.buttonSecondary],
              )
            : null,
        color: canAfford
            ? null
            : colors.panelBorder.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: canAfford
              ? colors.glowColor.withValues(alpha: 0.5)
              : colors.panelBorder.withValues(alpha: 0.2),
          width: 1,
        ),
        boxShadow: canAfford
            ? [
                BoxShadow(
                  color: colors.glowColor.withValues(alpha: 0.3),
                  blurRadius: 8,
                  spreadRadius: 0,
                ),
              ]
            : null,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            canAfford ? '🪙' : '🔒',
            style: const TextStyle(fontSize: 12),
          ),
          const SizedBox(width: 4),
          Text(
            _fmt(item.coinPrice),
            style: TextStyle(
              color: canAfford
                  ? colors.textPrimary
                  : colors.textPrimary.withValues(alpha: 0.3),
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  String _fmt(int n) =>
      n >= 1000 ? '${(n / 1000).toStringAsFixed(1)}K' : n.toString();
}

// ─────────────────────────────────────────────
//  Rewarded Ad Purchase Dialog
// ─────────────────────────────────────────────

class _RewardedAdDialog extends StatelessWidget {
  final StoreItem item;
  final GameThemeColors colors;
  final VoidCallback onWatchAd;
  final VoidCallback onBuyDirectly;

  const _RewardedAdDialog({
    required this.item,
    required this.colors,
    required this.onWatchAd,
    required this.onBuyDirectly,
  });

  @override
  Widget build(BuildContext context) {
    final rarityColor = Color(item.rarity.colors[0]);

    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.85,
        ),
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(
                (MediaQuery.of(context).size.width * 0.06)
                    .clamp(16.0, 28.0)),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colors.panelBg,
                  colors.panelBg.withValues(alpha: 0.9)
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                  color: rarityColor.withValues(alpha: 0.6), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: rarityColor.withValues(alpha: 0.3),
                  blurRadius: 40,
                  spreadRadius: 4,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.5),
                  blurRadius: 25,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(item.emoji, style: const TextStyle(fontSize: 52)),
                const SizedBox(height: 12),
                Text(
                  item.name,
                  style: TextStyle(
                    color: colors.textPrimary,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  item.description,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: colors.textPrimary.withValues(alpha: 0.5),
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 24),

                // Watch ad option
                GestureDetector(
                  onTap: onWatchAd,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color:
                              const Color(0xFF1565C0).withValues(alpha: 0.4),
                          blurRadius: 15,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('📺', style: TextStyle(fontSize: 20)),
                            SizedBox(width: 8),
                            Text(
                              'WATCH AD & GET FREE',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Watch a short ad — get it free!',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.7),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                // Pay coins option
                GestureDetector(
                  onTap: onBuyDirectly,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          colors.buttonPrimary,
                          colors.buttonSecondary
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: colors.glowColor.withValues(alpha: 0.35),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('🪙', style: TextStyle(fontSize: 18)),
                        const SizedBox(width: 8),
                        Text(
                          'BUY FOR ${item.coinPrice} COINS',
                          style: TextStyle(
                            color: colors.textPrimary,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Maybe later',
                    style: TextStyle(
                        color: colors.textPrimary.withValues(alpha: 0.35)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Purchase Success Dialog
// ─────────────────────────────────────────────

class _PurchaseSuccessDialog extends StatefulWidget {
  final StoreItem item;
  final GameThemeColors colors;

  const _PurchaseSuccessDialog(
      {required this.item, required this.colors});

  @override
  State<_PurchaseSuccessDialog> createState() =>
      _PurchaseSuccessDialogState();
}

class _PurchaseSuccessDialogState extends State<_PurchaseSuccessDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);

    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) Navigator.pop(context);
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  String get _successMessage => switch (widget.item.category) {
        ItemCategory.powerup => '${widget.item.name} Added!',
        ItemCategory.chest => 'Chest Opened!',
        ItemCategory.theme => 'Theme Unlocked!',
        ItemCategory.coins => 'Coins Added!',
      };

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [c.panelBg, c.panelBg.withValues(alpha: 0.9)],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
                color: const Color(0xFF4CAF50).withValues(alpha: 0.7),
                width: 2),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF4CAF50).withValues(alpha: 0.4),
                blurRadius: 40,
                spreadRadius: 4,
              ),
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.5),
                blurRadius: 25,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('🎉', style: TextStyle(fontSize: 52)),
              const SizedBox(height: 12),
              Text(
                _successMessage,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: c.textPrimary,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  shadows: [
                    Shadow(
                        color:
                            const Color(0xFF4CAF50).withValues(alpha: 0.5),
                        blurRadius: 12),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(widget.item.emoji,
                  style: const TextStyle(fontSize: 40)),
              const SizedBox(height: 8),
              Text(
                'Ready to use in your next game!',
                style: TextStyle(
                  color: c.textPrimary.withValues(alpha: 0.45),
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Insufficient Coins Dialog
// ─────────────────────────────────────────────

class _InsufficientCoinsDialog extends StatelessWidget {
  final GameThemeColors colors;
  final int coinsNeeded;
  final VoidCallback onWatchAd;

  const _InsufficientCoinsDialog({
    required this.colors,
    required this.coinsNeeded,
    required this.onWatchAd,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              colors.panelBg,
              colors.panelBg.withValues(alpha: 0.9)
            ],
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
              color: const Color(0xFFFFB300).withValues(alpha: 0.6),
              width: 1.5),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFFB300).withValues(alpha: 0.25),
              blurRadius: 35,
              spreadRadius: 3,
            ),
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.5),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🪙', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 12),
            Text(
              'Not Enough Coins',
              style: TextStyle(
                color: colors.textPrimary,
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'You need $coinsNeeded more coins.\nWatch an ad to earn free coins!',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colors.textPrimary.withValues(alpha: 0.5),
                fontSize: 13,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),
            GestureDetector(
              onTap: onWatchAd,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color:
                          const Color(0xFF1565C0).withValues(alpha: 0.4),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('📺', style: TextStyle(fontSize: 20)),
                    SizedBox(width: 8),
                    Text(
                      'WATCH AD FOR +150 COINS',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Later',
                style: TextStyle(
                    color: colors.textPrimary.withValues(alpha: 0.35)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Premium Dialog (IAP items)
// ─────────────────────────────────────────────

class _PremiumDialog extends StatelessWidget {
  final StoreItem item;
  final GameThemeColors colors;

  const _PremiumDialog({required this.item, required this.colors});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              colors.panelBg,
              colors.panelBg.withValues(alpha: 0.9)
            ],
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
              color: const Color(0xFFFFB300).withValues(alpha: 0.7),
              width: 2),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFFB300).withValues(alpha: 0.3),
              blurRadius: 40,
              spreadRadius: 4,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(item.emoji, style: const TextStyle(fontSize: 52)),
            const SizedBox(height: 12),
            Text(
              item.name,
              style: TextStyle(
                color: colors.textPrimary,
                fontSize: 22,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              item.description,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colors.textPrimary.withValues(alpha: 0.5),
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 24),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFFB300), Color(0xFFFF8F00)],
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFFB300).withValues(alpha: 0.4),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Text(
                '💎 PURCHASE',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel',
                  style: TextStyle(
                      color: colors.textPrimary.withValues(alpha: 0.35))),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Game Over / Revive Dialog
// ─────────────────────────────────────────────

class GameOverReviveDialog extends ConsumerStatefulWidget {
  final GameThemeData theme;
  final int score;
  final VoidCallback onReviveAd;
  final VoidCallback onReviveHammer;
  final VoidCallback onReviveBomb;
  final VoidCallback onRestart;

  const GameOverReviveDialog({
    super.key,
    required this.theme,
    required this.score,
    required this.onReviveAd,
    required this.onReviveHammer,
    required this.onReviveBomb,
    required this.onRestart,
  });

  @override
  ConsumerState<GameOverReviveDialog> createState() =>
      _GameOverReviveDialogState();
}

class _GameOverReviveDialogState extends ConsumerState<GameOverReviveDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  late Animation<double> _fade;
  int _countdown = 5;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _startCountdown();
  }

  void _startCountdown() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      setState(() => _countdown--);
      if (_countdown > 0) _startCountdown();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.theme.colors;
    final inventory = ref.watch(storeProvider).inventory;

    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Container(
        color: Colors.black.withValues(alpha: 0.85 * _fade.value),
        child: Center(
          child: ScaleTransition(
            scale: _scale,
            child: Container(
              margin: const EdgeInsets.all(32),
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    c.panelBg,
                    c.panelBg.withValues(alpha: 0.95)
                  ],
                ),
                borderRadius: BorderRadius.circular(32),
                border: Border.all(
                    color: const Color(0xFFFF1744).withValues(alpha: 0.7),
                    width: 2),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF1744).withValues(alpha: 0.3),
                    blurRadius: 50,
                    spreadRadius: 5,
                  ),
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.5),
                    blurRadius: 30,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('💀', style: TextStyle(fontSize: 52)),
                  const SizedBox(height: 8),
                  Text(
                    'GAME OVER',
                    style: TextStyle(
                      color: const Color(0xFFFF1744),
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                      shadows: [
                        Shadow(
                          color: const Color(0xFFFF1744)
                              .withValues(alpha: 0.6),
                          blurRadius: 16,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Score: ${widget.score}',
                    style: TextStyle(
                      color: c.textPrimary.withValues(alpha: 0.5),
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 6),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF1744).withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: const Color(0xFFFF1744)
                              .withValues(alpha: 0.4)),
                    ),
                    child: Text(
                      'Continue? $_countdown',
                      style: const TextStyle(
                        color: Color(0xFFFF1744),
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  _ReviveOption(
                    emoji: '📺',
                    label: 'Continue Watching Ad',
                    sublabel: 'Keep your current board',
                    gradient: const [Color(0xFF1565C0), Color(0xFF0D47A1)],
                    onTap: widget.onReviveAd,
                  ),
                  const SizedBox(height: 10),

                  if (inventory.hammers > 0) ...[
                    _ReviveOption(
                      emoji: '🔨',
                      label: 'Use Hammer (×${inventory.hammers})',
                      sublabel: 'Break a block and continue',
                      gradient: const [Color(0xFF795548), Color(0xFF4E342E)],
                      onTap: widget.onReviveHammer,
                    ),
                    const SizedBox(height: 10),
                  ],

                  if (inventory.bombs > 0) ...[
                    _ReviveOption(
                      emoji: '💣',
                      label: 'Use Bomb (×${inventory.bombs})',
                      sublabel: 'Blast an area and continue',
                      gradient: const [Color(0xFF424242), Color(0xFF212121)],
                      onTap: widget.onReviveBomb,
                    ),
                    const SizedBox(height: 10),
                  ],

                  GestureDetector(
                    onTap: widget.onRestart,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: c.panelBorder.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: c.panelBorder.withValues(alpha: 0.3)),
                      ),
                      child: Text(
                        '↺  Start Over',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: c.textPrimary.withValues(alpha: 0.5),
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ReviveOption extends StatelessWidget {
  final String emoji;
  final String label;
  final String sublabel;
  final List<Color> gradient;
  final VoidCallback onTap;

  const _ReviveOption({
    required this.emoji,
    required this.label,
    required this.sublabel,
    required this.gradient,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: gradient[0].withValues(alpha: 0.4),
              blurRadius: 12,
              spreadRadius: 1,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 22)),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  sublabel,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.6),
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}