import 'dart:math';
import 'package:flutter/material.dart';
import '../../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  BlastEffect — spawned on line/col clear
//  Overlay widget positioned over the grid
// ─────────────────────────────────────────────

class BlastEffect extends StatefulWidget {
  final Offset position;     // centre of blast in local coords
  final GameThemeColors colors;
  final VoidCallback onDone;

  const BlastEffect({
    super.key,
    required this.position,
    required this.colors,
    required this.onDone,
  });

  @override
  State<BlastEffect> createState() => _BlastEffectState();
}

class _BlastEffectState extends State<BlastEffect>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late List<_Shard> _shards;
  late List<_Sparkle> _sparkles;
  late List<_DustParticle> _dustParticles;
  final _rng = Random();

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )
      ..forward()
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) widget.onDone();
      });

    // Generate premium shard particles
    _shards = List.generate(24, (_) {
      final angle = _rng.nextDouble() * pi * 2;
      final speed = _rng.nextDouble() * 100 + 40;
      return _Shard(
        angle: angle,
        speed: speed,
        size: _rng.nextDouble() * 8 + 4,
        colorIndex: _rng.nextInt(3),
        spin: (_rng.nextDouble() - 0.5) * 12,
      );
    });
    
    // Generate sparkle particles
    _sparkles = List.generate(12, (_) {
      final angle = _rng.nextDouble() * pi * 2;
      final speed = _rng.nextDouble() * 60 + 20;
      return _Sparkle(
        angle: angle,
        speed: speed,
        size: _rng.nextDouble() * 4 + 2,
        delay: _rng.nextDouble() * 0.2,
      );
    });
    
    // Generate dust particles
    _dustParticles = List.generate(16, (_) {
      final angle = _rng.nextDouble() * pi * 2;
      final speed = _rng.nextDouble() * 40 + 15;
      return _DustParticle(
        angle: angle,
        speed: speed,
        size: _rng.nextDouble() * 3 + 1,
        drift: (_rng.nextDouble() - 0.5) * 20,
      );
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (ctx, _) => CustomPaint(
          painter: _BlastPainter(
            shards: _shards,
            sparkles: _sparkles,
            dustParticles: _dustParticles,
            progress: _ctrl.value,
            origin: widget.position,
            colors: widget.colors,
          ),
        ),
      ),
    );
  }
}

class _Shard {
  final double angle, speed, size, spin;
  final int colorIndex;
  _Shard({
    required this.angle,
    required this.speed,
    required this.size,
    required this.spin,
    required this.colorIndex,
  });
}

class _Sparkle {
  final double angle, speed, size, delay;
  _Sparkle({
    required this.angle,
    required this.speed,
    required this.size,
    required this.delay,
  });
}

class _DustParticle {
  final double angle, speed, size, drift;
  _DustParticle({
    required this.angle,
    required this.speed,
    required this.size,
    required this.drift,
  });
}

class _BlastPainter extends CustomPainter {
  final List<_Shard> shards;
  final List<_Sparkle> sparkles;
  final List<_DustParticle> dustParticles;
  final double progress;
  final Offset origin;
  final GameThemeColors colors;

  const _BlastPainter({
    required this.shards,
    required this.sparkles,
    required this.dustParticles,
    required this.progress,
    required this.origin,
    required this.colors,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final eased = Curves.easeOutExpo.transform(progress);
    final fade = 1.0 - progress;

    // Central flash with glow burst
    if (progress < 0.4) {
      final flashIntensity = (0.4 - progress) / 0.4;
      
      // Bright white flash
      final flashPaint = Paint()
        ..color = Colors.white.withValues(alpha: flashIntensity * 0.8)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30);
      canvas.drawCircle(origin, 40 * progress / 0.4, flashPaint);
      
      // Colored glow burst
      final glowPaint = Paint()
        ..color = colors.glowColor.withValues(alpha: flashIntensity * 0.6)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 50);
      canvas.drawCircle(origin, 60 * progress / 0.4, glowPaint);
    }
    
    // Glow ripple effect
    if (progress > 0.1 && progress < 0.8) {
      final rippleProgress = (progress - 0.1) / 0.7;
      final rippleRadius = rippleProgress * 80;
      final ripplePaint = Paint()
        ..color = colors.glowColor.withValues(alpha: (1.0 - rippleProgress) * 0.3)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3 * (1.0 - rippleProgress)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
      canvas.drawCircle(origin, rippleRadius, ripplePaint);
    }

    // Premium shards with glow
    for (final s in shards) {
      final dist = eased * s.speed;
      final x = origin.dx + cos(s.angle) * dist;
      final y = origin.dy + sin(s.angle) * dist;

      final shardColors = [
        colors.particleColor1,
        colors.particleColor2,
        colors.particleColor3,
      ];
      final baseColor = shardColors[s.colorIndex];
      
      // Outer glow for shard
      final glowPaint = Paint()
        ..color = baseColor.withValues(alpha: fade * 0.5)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, s.size * 0.8);
      
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(s.spin * progress);
      
      // Draw glow
      final glowPath = Path()
        ..moveTo(0, -s.size * 1.2)
        ..lineTo(s.size * 0.6, 0)
        ..lineTo(0, s.size * 0.8)
        ..lineTo(-s.size * 0.6, 0)
        ..close();
      canvas.drawPath(glowPath, glowPaint);

      // Main shard
      final paint = Paint()
        ..color = baseColor.withValues(alpha: fade);

      // Premium diamond shard
      final path = Path()
        ..moveTo(0, -s.size)
        ..lineTo(s.size * 0.5, 0)
        ..lineTo(0, s.size * 0.6)
        ..lineTo(-s.size * 0.5, 0)
        ..close();
      canvas.drawPath(path, paint);
      
      // Inner highlight
      final highlightPaint = Paint()
        ..color = Colors.white.withValues(alpha: fade * 0.6);
      final highlightPath = Path()
        ..moveTo(0, -s.size * 0.5)
        ..lineTo(s.size * 0.2, 0)
        ..lineTo(0, s.size * 0.2)
        ..lineTo(-s.size * 0.2, 0)
        ..close();
      canvas.drawPath(highlightPath, highlightPaint);
      
      canvas.restore();
    }
    
    // Sparkle particles
    for (final sp in sparkles) {
      final localProgress = (progress - sp.delay).clamp(0.0, 1.0);
      if (localProgress <= 0) continue;
      
      final sparkleEased = Curves.easeOut.transform(localProgress);
      final dist = sparkleEased * sp.speed;
      final x = origin.dx + cos(sp.angle) * dist;
      final y = origin.dy + sin(sp.angle) * dist;
      final sparkleFade = 1.0 - localProgress;
      
      final sparklePaint = Paint()
        ..color = Colors.white.withValues(alpha: sparkleFade * 0.8)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
      
      canvas.save();
      canvas.translate(x, y);
      
      // Draw star sparkle
      final starPath = Path();
      for (int i = 0; i < 5; i++) {
        final outerAngle = (i * 72 - 90) * pi / 180;
        final innerAngle = ((i * 72) + 36 - 90) * pi / 180;
        if (i == 0) {
          starPath.moveTo(cos(outerAngle) * sp.size, sin(outerAngle) * sp.size);
        } else {
          starPath.lineTo(cos(outerAngle) * sp.size, sin(outerAngle) * sp.size);
        }
        starPath.lineTo(cos(innerAngle) * sp.size * 0.4, sin(innerAngle) * sp.size * 0.4);
      }
      starPath.close();
      canvas.drawPath(starPath, sparklePaint);
      canvas.restore();
    }
    
    // Dust particles
    for (final d in dustParticles) {
      final dist = eased * d.speed;
      final x = origin.dx + cos(d.angle) * dist + d.drift * progress;
      final y = origin.dy + sin(d.angle) * dist;
      
      final dustPaint = Paint()
        ..color = colors.glowColor.withValues(alpha: fade * 0.4)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
      
      canvas.drawCircle(Offset(x, y), d.size, dustPaint);
    }
  }

  @override
  bool shouldRepaint(_BlastPainter o) => true;
}

// ─────────────────────────────────────────────
//  Combo Text Flyup
// ─────────────────────────────────────────────

class ComboFlyup extends StatefulWidget {
  final int combo;
  final Offset position;
  final GameThemeColors colors;
  final VoidCallback onDone;

  const ComboFlyup({
    super.key,
    required this.combo,
    required this.position,
    required this.colors,
    required this.onDone,
  });

  @override
  State<ComboFlyup> createState() => _ComboFlyupState();
}

class _ComboFlyupState extends State<ComboFlyup>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  late Animation<double> _y;
  late Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )
      ..forward()
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) widget.onDone();
      });

    _scale = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.3), weight: 30),
      TweenSequenceItem(tween: Tween(begin: 1.3, end: 1.0), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.0), weight: 50),
    ]).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));

    _y = Tween(begin: 0.0, end: -60.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOut),
    );

    _opacity = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.0), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 30),
    ]).animate(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: widget.position.dx - 60,
      top: widget.position.dy - 30,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (ctx, _) => Transform.translate(
          offset: Offset(0, _y.value),
          child: Transform.scale(
            scale: _scale.value,
            child: Opacity(
              opacity: _opacity.value,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: widget.colors.panelBg.withValues(alpha: 0.9),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: widget.colors.glowColor,
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: widget.colors.glowColor.withValues(alpha: 0.5),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Text(
                  'COMBO ×${widget.combo}!',
                  style: TextStyle(
                    color: widget.colors.textAccent,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                    shadows: [
                      Shadow(
                        color: widget.colors.glowColor,
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
