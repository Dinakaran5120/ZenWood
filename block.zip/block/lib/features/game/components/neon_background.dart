import 'package:flutter/material.dart';
import 'dart:math' as math;

// ─────────────────────────────────────────────
//  NeonBackground — Deep neon blue animated background
// ─────────────────────────────────────────────

class NeonBackground extends StatefulWidget {
  final Widget? child;
  const NeonBackground({super.key, this.child});

  @override
  State<NeonBackground> createState() => _NeonBackgroundState();
}

class _NeonBackgroundState extends State<NeonBackground>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => CustomPaint(
        painter: _NeonPainter(progress: _ctrl.value),
        child: widget.child,
      ),
    );
  }
}

class _NeonPainter extends CustomPainter {
  final double progress;
  _NeonPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    // Base gradient background
    final bgPaint = Paint()
      ..shader = const RadialGradient(
        center: Alignment(0, -0.3),
        radius: 1.4,
        colors: [
          Color(0xFF0A1628),
          Color(0xFF040D1A),
          Color(0xFF020810),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Animated neon glow orbs
    final glowPaint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 60);

    // Blue glow orb (top left)
    final blueOrb = Offset(
      size.width * 0.2 + math.sin(progress * math.pi * 2) * 20,
      size.height * 0.3 + math.cos(progress * math.pi * 2) * 20,
    );
    glowPaint.color = const Color(0xFF00F5FF).withValues(alpha: 0.15 + progress * 0.1);
    canvas.drawCircle(blueOrb, 150, glowPaint);

    // Purple glow orb (bottom right)
    final purpleOrb = Offset(
      size.width * 0.8 - math.sin(progress * math.pi * 2) * 20,
      size.height * 0.7 - math.cos(progress * math.pi * 2) * 20,
    );
    glowPaint.color = const Color(0xFFBF40FF).withValues(alpha: 0.12 + progress * 0.08);
    canvas.drawCircle(purpleOrb, 180, glowPaint);

    // Cyan glow orb (center)
    final cyanOrb = Offset(
      size.width * 0.5 + math.sin(progress * math.pi * 2 + 1) * 15,
      size.height * 0.5 + math.cos(progress * math.pi * 2 + 1) * 15,
    );
    glowPaint.color = const Color(0xFF00F5FF).withValues(alpha: 0.1 + progress * 0.05);
    canvas.drawCircle(cyanOrb, 120, glowPaint);

    // Floating particles
    final particlePaint = Paint();
    final random = math.Random(42);
    for (int i = 0; i < 30; i++) {
      final x = (random.nextDouble() * size.width);
      final y = (random.nextDouble() * size.height + progress * 50) % size.height;
      final particleSize = random.nextDouble() * 3 + 1;
      final alpha = (random.nextDouble() * 0.3 + 0.1).clamp(0.0, 0.4);
      
      particlePaint.color = const Color(0xFF00F5FF).withValues(alpha: alpha);
      canvas.drawCircle(Offset(x, y), particleSize, particlePaint);
    }

    // Vignette overlay
    final vignettePaint = Paint()
      ..shader = RadialGradient(
        center: Alignment.center,
        radius: 1.2,
        colors: [
          Colors.transparent,
          const Color(0xFF020810).withValues(alpha: 0.7),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), vignettePaint);
  }

  @override
  bool shouldRepaint(_NeonPainter old) => true;
}
