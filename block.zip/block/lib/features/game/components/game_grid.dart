import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../bloc/game_notifier.dart';
import '../../../core/constants/game_constants.dart';
import '../../../core/theme/game_theme.dart';
import '../../store/store_models.dart';

// ─────────────────────────────────────────────
//  GameGrid — 8×8 board + tray + drag & drop
//  Responsive: computes cellSize from LayoutBuilder
//  Powerup mode: hammer / bomb / lightning selection
// ─────────────────────────────────────────────

class GameGrid extends ConsumerStatefulWidget {
  final GameThemeData theme;

  /// Non-null when a powerup is active and the user must tap a grid cell.
  final PowerupType? activePowerup;

  /// Called when the user taps a cell in powerup-selection mode.
  final Future<void> Function(int row, int col)? onPowerupApplied;

  /// Called when the game transitions to isGameOver = true.
  /// When provided, the internal _GameOverPanel is suppressed.
  final void Function(int score)? onGameOver;

  /// Countdown seconds for level mode (null = no timer).
  final int? levelTimerSeconds;

  const GameGrid({
    super.key,
    required this.theme,
    this.activePowerup,
    this.onPowerupApplied,
    this.onGameOver,
    this.levelTimerSeconds,
  });

  @override
  ConsumerState<GameGrid> createState() => _GameGridState();
}

class _GameGridState extends ConsumerState<GameGrid>
    with TickerProviderStateMixin {
  // ── Drag state ────────────────────────────
  int?        _draggingTrayIndex;
  BlockShape? _draggingShape;
  Offset?     _dragPosition;
  int?        _hoverRow, _hoverCol;
  bool        _canDrop = false;

  // ── Powerup hover ─────────────────────────
  bool _powerupApplying = false;

  // ── Powerup animation state ─────────────────
  Offset? _powerupAnimPosition;
  PowerupType? _powerupAnimType;
  late AnimationController _powerupAnimCtrl;
  late Animation<double> _powerupScaleAnim;
  late Animation<double> _powerupFadeAnim;

  // ── Animations ────────────────────────────
  late AnimationController _comboCtrl;
  late AnimationController _shakeCtrl;
  late Animation<Offset> _shakeAnim;
  final GlobalKey _gridKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _comboCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: GameConstants.comboTextDurationMs),
    );
    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnim = TweenSequence<Offset>([
      TweenSequenceItem(tween: Tween(begin: Offset.zero, end: const Offset(3, 2)), weight: 25),
      TweenSequenceItem(tween: Tween(begin: const Offset(3, 2), end: const Offset(-3, -2)), weight: 25),
      TweenSequenceItem(tween: Tween(begin: const Offset(-3, -2), end: const Offset(2, -1)), weight: 25),
      TweenSequenceItem(tween: Tween(begin: const Offset(2, -1), end: Offset.zero), weight: 25),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeOut));
    
    _powerupAnimCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _powerupScaleAnim = Tween(begin: 0.0, end: 1.5)
        .animate(CurvedAnimation(parent: _powerupAnimCtrl, curve: Curves.elasticOut));
    _powerupFadeAnim = Tween(begin: 1.0, end: 0.0)
        .animate(CurvedAnimation(parent: _powerupAnimCtrl, curve: const Interval(0.5, 1.0, curve: Curves.easeIn)));
  }

  @override
  void dispose() {
    _comboCtrl.dispose();
    _shakeCtrl.dispose();
    _powerupAnimCtrl.dispose();
    super.dispose();
  }

  // ── Snap to grid cell ─────────────────────
  ({int row, int col})? _snapCell(Offset globalOffset, double cellSize) {
    final box = _gridKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return null;
    final local = box.globalToLocal(globalOffset);
    final ct = cellSize + GameConstants.cellGap;

    if (widget.activePowerup != null) {
      // In powerup mode, snap directly without shape-offset adjustment
      final col = (local.dx / ct).round().clamp(0, GameConstants.gridSize - 1);
      final row = (local.dy / ct).round().clamp(0, GameConstants.gridSize - 1);
      return (row: row, col: col);
    }

    if (_draggingShape == null) return null;
    final adjLocal = Offset(
      local.dx - (_draggingShape!.width  / 2.0) * ct,
      local.dy - (_draggingShape!.height / 2.0) * ct - 30,
    );
    final col = (adjLocal.dx / ct).round();
    final row = (adjLocal.dy / ct).round();
    return (row: row, col: col);
  }

  // ── Normal drag ───────────────────────────
  void _onDragStart(int idx, BlockShape shape, Offset globalPos, double cellSize) {
    setState(() {
      _draggingTrayIndex = idx;
      _draggingShape     = shape;
      _dragPosition      = globalPos;
    });
    _onDragUpdate(globalPos, cellSize);
  }

  void _onDragUpdate(Offset globalOffset, double cellSize) {
    final snap = _snapCell(globalOffset, cellSize);
    setState(() {
      _dragPosition = globalOffset;
      _hoverRow = snap?.row;
      _hoverCol = snap?.col;
      _canDrop  = snap != null && _draggingShape != null
          ? ref.read(gameProvider.notifier).canPlace(_draggingShape!, snap.row, snap.col)
          : false;
    });
  }

  Future<void> _onDragEnd() async {
    // Capture placement info before clearing drag state.
    // Clearing drag state first prevents stale shape ghost/preview during
    // the async placement animation (shape consistency fix).
    final trayIdx = _draggingTrayIndex;
    final row     = _hoverRow;
    final col     = _hoverCol;
    final canDrop = _canDrop;

    setState(() {
      _draggingTrayIndex = null;
      _draggingShape     = null;
      _dragPosition      = null;
      _hoverRow          = null;
      _hoverCol          = null;
      _canDrop           = false;
    });

    if (trayIdx != null && row != null && col != null && canDrop) {
      await ref.read(gameProvider.notifier).placeBlock(trayIdx, row, col);
    }
  }

  // ── Powerup selection ─────────────────────
  void _onPowerupMove(Offset globalOffset, double cellSize) {
    final snap = _snapCell(globalOffset, cellSize);
    if (snap == null) return;
    setState(() {
      _hoverRow = snap.row;
      _hoverCol = snap.col;
      _canDrop  = _isPowerupValid(snap.row, snap.col);
    });
  }

  Future<void> _onPowerupUp(Offset globalOffset, double cellSize) async {
    if (_powerupApplying) return;
    final snap = _snapCell(globalOffset, cellSize);
    if (snap != null && widget.onPowerupApplied != null) {
      _powerupApplying = true;
      
      // Trigger powerup animation
      _triggerPowerupAnimation(snap.row, snap.col, widget.activePowerup!, cellSize);
      
      await widget.onPowerupApplied!(snap.row, snap.col);
      _powerupApplying = false;
    }
    setState(() { _hoverRow = null; _hoverCol = null; _canDrop = false; });
  }

  void _triggerPowerupAnimation(int row, int col, PowerupType type, double cellSize) {
    final box = _gridKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return;
    
    final ct = cellSize + GameConstants.cellGap;
    final x = col * ct + ct / 2;
    final y = row * ct + ct / 2;
    
    setState(() {
      _powerupAnimPosition = Offset(x, y);
      _powerupAnimType = type;
    });
    
    _powerupAnimCtrl.forward(from: 0).then((_) {
      _powerupAnimCtrl.reset();
      setState(() {
        _powerupAnimPosition = null;
        _powerupAnimType = null;
      });
    });
  }

  bool _isPowerupValid(int row, int col) {
    final gs = ref.read(gameProvider);
    return switch (widget.activePowerup) {
      PowerupType.hammer =>
        row >= 0 && row < GameConstants.gridSize &&
        col >= 0 && col < GameConstants.gridSize &&
        gs.grid[row][col].filled,
      _ => true, // bomb and lightning are always applicable
    };
  }

  // ── Hover detection ───────────────────────
  bool _isCellHovered(int r, int c) {
    if (_hoverRow == null || _hoverCol == null) return false;

    if (widget.activePowerup != null) {
      return switch (widget.activePowerup!) {
        PowerupType.hammer   => r == _hoverRow && c == _hoverCol,
        PowerupType.bomb     =>
          (r - _hoverRow!).abs() <= 1 && (c - _hoverCol!).abs() <= 1,
        PowerupType.lightning => r == _hoverRow || c == _hoverCol,
        _                    => false,
      };
    }

    if (_draggingShape == null) return false;
    for (final cell in _draggingShape!.cells) {
      if (_hoverRow! + cell[0] == r && _hoverCol! + cell[1] == c) return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final gs = ref.watch(gameProvider);

    // Notify parent when game just ended
    ref.listen(gameProvider.select((s) => s.isGameOver), (prev, next) {
      if (next == true && prev == false) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          widget.onGameOver?.call(ref.read(gameProvider).score);
        });
      }
    });

    // Screen shake on line clear
    if (gs.clearingRows.isNotEmpty || gs.clearingCols.isNotEmpty) {
      if (_shakeCtrl.status == AnimationStatus.dismissed) {
        _shakeCtrl.forward(from: 0);
      }
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        // ── Responsive cell size ────────────
        const G   = GameConstants.gridSize;
        const gap = GameConstants.cellGap;

        // From width: fit grid in available width
        final cellFromW = ((constraints.maxWidth - gap) / G - gap).clamp(26.0, 44.0);

        // From height: reserve space for score panel + gaps + tray
        // scorePanelH ≈ 55, gaps = 16+20 = 36, tray = cellFromW*2.4+16
        final trayEstimate = (cellFromW * 2.4 + 16).clamp(80.0, 160.0);
        const scorePanelH  = 55.0;
        const gapsH        = 36.0;
        final gridH = (constraints.maxHeight - scorePanelH - gapsH - trayEstimate)
            .clamp(100.0, double.infinity);
        final cellFromH = ((gridH - gap) / G - gap).clamp(26.0, 44.0);

        final cs  = min(cellFromW, cellFromH);
        final ct  = cs + gap;
        final gridPx = ct * G - gap;
        final trayH  = (cs * 2.4 + 16).clamp(80.0, 160.0);
        final mini   = (cs * 0.5).clamp(14.0, 22.0);

        final renderBox = context.findRenderObject() as RenderBox?;
        final localDrag = _dragPosition != null && renderBox != null
            ? renderBox.globalToLocal(_dragPosition!)
            : null;

        return Listener(
          behavior: HitTestBehavior.translucent,
          onPointerMove: (e) {
            if (widget.activePowerup != null) {
              _onPowerupMove(e.position, cs);
            } else if (_draggingShape != null) {
              _onDragUpdate(e.position, cs);
            }
          },
          onPointerUp: (e) {
            if (widget.activePowerup != null) {
              _onPowerupUp(e.position, cs);
            } else {
              _onDragEnd();
            }
          },
          onPointerCancel: (_) {
            if (widget.activePowerup == null) _onDragEnd();
          },
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              AnimatedBuilder(
                animation: _shakeAnim,
                builder: (_, child) => Transform.translate(
                  offset: _shakeAnim.value,
                  child: child,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _ScorePanel(
                      theme: widget.theme,
                      gameState: gs,
                      levelTimerSeconds: widget.levelTimerSeconds,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: gridPx,
                      height: gridPx,
                      child: Stack(
                        children: [
                          _GridBackground(
                            gridPx: gridPx,
                            colors: widget.theme.colors,
                            gridKey: _gridKey,
                          ),
                          for (int r = 0; r < G; r++)
                            for (int c = 0; c < G; c++)
                              _GridCell(
                                row: r,
                                col: c,
                                state: gs.grid[r][c],
                                colors: widget.theme.colors,
                                isHovered: _isCellHovered(r, c),
                                canDrop: _canDrop,
                                isPowerupMode: widget.activePowerup != null,
                                cellSize: cs,
                                theme: widget.theme,
                              ),
                          if (_draggingShape != null &&
                              _hoverRow != null &&
                              _hoverCol != null &&
                              widget.activePowerup == null)
                            _GhostOverlay(
                              shape: _draggingShape!,
                              row: _hoverRow!,
                              col: _hoverCol!,
                              canDrop: _canDrop,
                              colors: widget.theme.colors,
                              cellSize: cs,
                            ),
                          // Powerup animation overlay
                          if (_powerupAnimPosition != null && _powerupAnimType != null)
                            _PowerupAnimationOverlay(
                              position: _powerupAnimPosition!,
                              type: _powerupAnimType!,
                              scaleAnim: _powerupScaleAnim,
                              fadeAnim: _powerupFadeAnim,
                              colors: widget.theme.colors,
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    _TrayRow(
                      theme: widget.theme,
                      gameState: gs,
                      trayHeight: trayH,
                      mini: mini,
                      cellSize: cs,
                      onDragStart: (i, s, p) => _onDragStart(i, s, p, cs),
                      onDragUpdate: (p) => _onDragUpdate(p, cs),
                      onDragEnd: _onDragEnd,
                      disabled: gs.isAnimating ||
                          gs.isGameOver ||
                          widget.activePowerup != null,
                    ),
                  ],
                ),
              ),

              // Floating drag preview
              if (_draggingShape != null && localDrag != null)
                _DragPreview(
                  shape: _draggingShape!,
                  position: localDrag,
                  colors: widget.theme.colors,
                  mini: mini,
                ),

              // Game Over panel only when no parent callback is wired
              if (gs.isGameOver && widget.onGameOver == null)
                _GameOverPanel(
                  theme: widget.theme,
                  score: gs.score,
                  highScore: gs.highScore,
                  onRestart: () => ref.read(gameProvider.notifier).resetGame(),
                ),
            ],
          ),
        );
      },
    );
  }
}

// ── Grid Background ────────────────────────────────────────────────────────

class _GridBackground extends StatelessWidget {
  final double gridPx;
  final GameThemeColors colors;
  final GlobalKey gridKey;
  const _GridBackground(
      {required this.gridPx, required this.colors, required this.gridKey});

  @override
  Widget build(BuildContext context) {
    return Container(
      key: gridKey,
      width: gridPx,
      height: gridPx,
      decoration: BoxDecoration(
        color: colors.gridBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.panelBorder.withValues(alpha: 0.5), width: 1.5),
        boxShadow: [
          BoxShadow(color: colors.glowColor.withValues(alpha: 0.15), blurRadius: 20, spreadRadius: 2),
        ],
      ),
      child: CustomPaint(painter: _GridLinePainter(colors: colors)),
    );
  }
}

class _GridLinePainter extends CustomPainter {
  final GameThemeColors colors;
  const _GridLinePainter({required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    const G  = GameConstants.gridSize;
    final ct = size.width / G;
    final p  = Paint()
      ..color = colors.gridLine.withValues(alpha: 0.4)
      ..strokeWidth = 0.5;
    for (int i = 0; i <= G; i++) {
      final pos = i * ct;
      canvas.drawLine(Offset(pos, 0), Offset(pos, size.height), p);
      canvas.drawLine(Offset(0, pos), Offset(size.width, pos), p);
    }
  }

  @override
  bool shouldRepaint(_GridLinePainter o) => false;
}

// ── Grid Cell ──────────────────────────────────────────────────────────────

class _GridCell extends StatefulWidget {
  final int row, col;
  final CellState state;
  final GameThemeColors colors;
  final bool isHovered, canDrop, isPowerupMode;
  final double cellSize;
  final GameThemeData theme;

  const _GridCell({
    required this.row,
    required this.col,
    required this.state,
    required this.colors,
    required this.isHovered,
    required this.canDrop,
    required this.isPowerupMode,
    required this.cellSize,
    required this.theme,
  });

  @override
  State<_GridCell> createState() => _GridCellState();
}

class _GridCellState extends State<_GridCell> with TickerProviderStateMixin {
  late AnimationController _clearCtrl;
  late AnimationController _shimmerCtrl;
  late Animation<double> _scaleAnim, _glowAnim, _shimmerAnim;

  @override
  void initState() {
    super.initState();
    _clearCtrl = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: GameConstants.lineClearDurationMs));
    _scaleAnim = Tween(begin: 1.0, end: 0.0)
        .animate(CurvedAnimation(parent: _clearCtrl, curve: Curves.easeIn));
    _glowAnim = Tween(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _clearCtrl, curve: Curves.easeOut));

    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat();
    _shimmerAnim = Tween(begin: -1.0, end: 1.0)
        .animate(CurvedAnimation(parent: _shimmerCtrl, curve: Curves.easeInOut));
  }

  @override
  void didUpdateWidget(_GridCell old) {
    super.didUpdateWidget(old);
    if (!old.state.clearing && widget.state.clearing) _clearCtrl.forward(from: 0);
    if (old.state.clearing && !widget.state.clearing) _clearCtrl.reset();
  }

  @override
  void dispose() {
    _clearCtrl.dispose();
    _shimmerCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = widget.cellSize;
    const gap = GameConstants.cellGap;
    final ct = cs + gap;
    final x = widget.col * ct + gap / 2;
    final y = widget.row * ct + gap / 2;

    Color cellColor;
    double glowOpacity = 0;

    if (widget.state.clearing) {
      final idx = widget.state.colorIndex.clamp(0, widget.colors.blockColors.length - 1);
      cellColor   = widget.colors.blockColors[idx];
      glowOpacity = _glowAnim.value;
    } else if (widget.state.filled) {
      final idx = widget.state.colorIndex.clamp(0, widget.colors.blockColors.length - 1);
      cellColor = widget.colors.blockColors[idx];
    } else if (widget.isHovered) {
      if (widget.isPowerupMode) {
        // Powerup hover: amber/yellow = targetable; red = invalid
        cellColor = widget.canDrop
            ? const Color(0xFFFFAB00).withValues(alpha: 0.55)
            : Colors.red.withValues(alpha: 0.35);
      } else {
        cellColor = widget.canDrop
            ? widget.colors.glowColor.withValues(alpha: 0.5)
            : Colors.red.withValues(alpha: 0.4);
      }
    } else {
      cellColor = widget.colors.cellEmpty;
    }

    return Positioned(
      left: x,
      top: y,
      child: AnimatedBuilder(
        animation: Listenable.merge([_clearCtrl, _shimmerCtrl]),
        builder: (_, __) => Transform.scale(
          scale: widget.state.clearing ? _scaleAnim.value : 1.0,
          child: Container(
            width: cs,
            height: cs,
            decoration: widget.state.filled
                ? _buildPremiumBlockDecoration(cellColor, glowOpacity, cs)
                : BoxDecoration(
                    color: cellColor,
                    borderRadius: BorderRadius.circular(cs * 0.2),
                  ),
            child: widget.state.filled
                ? _PremiumBlockHighlight(
                    color: cellColor,
                    shimmerValue: _shimmerAnim.value,
                    cellSize: cs,
                  )
                : null,
          ),
        ),
      ),
    );
  }

  BoxDecoration _buildPremiumBlockDecoration(
      Color color, double glowOpacity, double cs) {
    final baseColor = Color.fromARGB(
      (color.a * 255.0).round().clamp(0, 255),
      ((color.r * 255.0).round().clamp(0, 255) * 1.2).clamp(0, 255).round(),
      ((color.g * 255.0).round().clamp(0, 255) * 1.2).clamp(0, 255).round(),
      ((color.b * 255.0).round().clamp(0, 255) * 1.2).clamp(0, 255).round(),
    );
    final highlightColor = Color.fromARGB(
      (baseColor.a * 255.0).round().clamp(0, 255),
      ((baseColor.r * 255.0).round().clamp(0, 255) + 40).clamp(0, 255).round(),
      ((baseColor.g * 255.0).round().clamp(0, 255) + 40).clamp(0, 255).round(),
      ((baseColor.b * 255.0).round().clamp(0, 255) + 40).clamp(0, 255).round(),
    );
    final shadowColor = Color.fromARGB(
      (baseColor.a * 255.0).round().clamp(0, 255),
      ((baseColor.r * 255.0).round().clamp(0, 255) - 40).clamp(0, 255).round(),
      ((baseColor.g * 255.0).round().clamp(0, 255) - 40).clamp(0, 255).round(),
      ((baseColor.b * 255.0).round().clamp(0, 255) - 40).clamp(0, 255).round(),
    );
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          highlightColor.withValues(alpha: 0.95),
          baseColor.withValues(alpha: 0.85),
          baseColor.withValues(alpha: 0.65),
          shadowColor.withValues(alpha: 0.75),
        ],
        stops: const [0.0, 0.25, 0.75, 1.0],
      ),
      borderRadius: BorderRadius.circular(cs * 0.22),
      boxShadow: [
        BoxShadow(
          color: baseColor.withValues(alpha: 0.5 + glowOpacity * 0.4),
          blurRadius: 6 + glowOpacity * 12,
          offset: const Offset(0, -1),
        ),
        BoxShadow(
          color: baseColor.withValues(alpha: 0.25 + glowOpacity * 0.25),
          blurRadius: 18 + glowOpacity * 22,
        ),
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.4),
          blurRadius: 8,
          offset: const Offset(0, 4),
          spreadRadius: -2,
        ),
        BoxShadow(
          color: Colors.white.withValues(alpha: 0.15),
          blurRadius: 4,
          offset: const Offset(-2, -2),
          spreadRadius: -2,
        ),
      ],
      border: Border.all(color: baseColor.withValues(alpha: 0.85), width: 1.5),
    );
  }
}

// ── Premium Block Highlight ────────────────────────────────────────────────

class _PremiumBlockHighlight extends StatelessWidget {
  final Color color;
  final double shimmerValue;
  final double cellSize;

  const _PremiumBlockHighlight({
    required this.color,
    required this.shimmerValue,
    required this.cellSize,
  });

  @override
  Widget build(BuildContext context) {
    final radius = cellSize * 0.22;
    return Stack(
      children: [
        Positioned(
          top: 2, left: 2, right: 2,
          child: Container(
            height: cellSize * 0.28,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(radius),
                topRight: Radius.circular(radius),
              ),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white.withValues(alpha: 0.6),
                  Colors.white.withValues(alpha: 0.3),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(color: Colors.white.withValues(alpha: 0.4), width: 1),
            ),
          ),
        ),
        Positioned.fill(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(radius),
            child: Opacity(
              opacity: 0.3,
              child: Transform.translate(
                offset: Offset(shimmerValue * 40, 0),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        Colors.white.withValues(alpha: 0.5),
                        Colors.transparent,
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Center(
          child: Container(
            width: cellSize * 0.18,
            height: cellSize * 0.18,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: 0.4),
              boxShadow: [
                BoxShadow(color: Colors.white.withValues(alpha: 0.6), blurRadius: 4),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ── Floating Drag Preview ──────────────────────────────────────────────────

class _DragPreview extends StatelessWidget {
  final BlockShape shape;
  final Offset position;
  final GameThemeColors colors;
  final double mini;

  const _DragPreview({
    required this.shape,
    required this.position,
    required this.colors,
    required this.mini,
  });

  @override
  Widget build(BuildContext context) {
    final w = shape.width * mini;
    final h = shape.height * mini;
    return Positioned(
      left: position.dx - w / 2,
      top: position.dy - h / 2 - 30,
      child: IgnorePointer(
        child: Material(
          color: Colors.transparent,
          child: CustomPaint(
            size: Size(w, h),
            painter: _ShapePainter(shape: shape, colors: colors, cellSize: mini),
          ),
        ),
      ),
    );
  }
}

// ── Ghost Overlay ──────────────────────────────────────────────────────────

class _GhostOverlay extends StatelessWidget {
  final BlockShape shape;
  final int row, col;
  final bool canDrop;
  final GameThemeColors colors;
  final double cellSize;

  const _GhostOverlay({
    required this.shape,
    required this.row,
    required this.col,
    required this.canDrop,
    required this.colors,
    required this.cellSize,
  });

  @override
  Widget build(BuildContext context) {
    final ct    = cellSize + GameConstants.cellGap;
    final cs    = cellSize;
    final color = canDrop
        ? colors.glowColor.withValues(alpha: 0.6)
        : Colors.red.withValues(alpha: 0.5);
    return Stack(
      children: shape.cells.map((cell) {
        final r = row + cell[0];
        final c = col + cell[1];
        if (r < 0 || r >= GameConstants.gridSize) return const SizedBox();
        if (c < 0 || c >= GameConstants.gridSize) return const SizedBox();
        return Positioned(
          left: c * ct + GameConstants.cellGap / 2,
          top:  r * ct + GameConstants.cellGap / 2,
          child: Container(
            width: cs,
            height: cs,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(cs * 0.15),
              border: Border.all(
                color: canDrop ? colors.glowColor : Colors.red,
                width: 1,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ── Tray Row ───────────────────────────────────────────────────────────────

class _TrayRow extends StatelessWidget {
  final GameThemeData theme;
  final GameState gameState;
  final double trayHeight;
  final double mini;
  final double cellSize;
  final void Function(int, BlockShape, Offset) onDragStart;
  final void Function(Offset) onDragUpdate;
  final VoidCallback onDragEnd;
  final bool disabled;

  const _TrayRow({
    required this.theme,
    required this.gameState,
    required this.trayHeight,
    required this.mini,
    required this.cellSize,
    required this.onDragStart,
    required this.onDragUpdate,
    required this.onDragEnd,
    required this.disabled,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: trayHeight,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(
          3,
          (i) => _TrayPiece(
            index: i,
            shape: gameState.trayPieces[i],
            theme: theme,
            mini: mini,
            cellSize: cellSize,
            onDragStart: onDragStart,
            onDragUpdate: onDragUpdate,
            onDragEnd: onDragEnd,
            disabled: disabled,
          ),
        ),
      ),
    );
  }
}

class _TrayPiece extends StatefulWidget {
  final int index;
  final BlockShape? shape;
  final GameThemeData theme;
  final double mini;
  final double cellSize;
  final void Function(int, BlockShape, Offset) onDragStart;
  final void Function(Offset) onDragUpdate;
  final VoidCallback onDragEnd;
  final bool disabled;

  const _TrayPiece({
    required this.index,
    required this.shape,
    required this.theme,
    required this.mini,
    required this.cellSize,
    required this.onDragStart,
    required this.onDragUpdate,
    required this.onDragEnd,
    required this.disabled,
  });

  @override
  State<_TrayPiece> createState() => _TrayPieceState();
}

class _TrayPieceState extends State<_TrayPiece>
    with SingleTickerProviderStateMixin {
  late AnimationController _bounceCtrl;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _bounceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _bounceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.shape == null) {
      return SizedBox(width: widget.cellSize * 2.3, height: widget.cellSize * 2.3);
    }
    final shape  = widget.shape!;
    final colors = widget.theme.colors;
    final boxSz  = (widget.cellSize * 2.3).clamp(66.0, 100.0);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: widget.disabled
          ? null
          : (details) {
              setState(() => _isDragging = true);
              widget.onDragStart(widget.index, shape, details.globalPosition);
            },
      onPanUpdate: widget.disabled
          ? null
          : (details) => widget.onDragUpdate(details.globalPosition),
      onPanEnd: widget.disabled
          ? null
          : (_) {
              setState(() => _isDragging = false);
              widget.onDragEnd();
            },
      onPanCancel: widget.disabled
          ? null
          : () {
              setState(() => _isDragging = false);
              widget.onDragEnd();
            },
      child: AnimatedBuilder(
        animation: _bounceCtrl,
        builder: (_, __) {
          final bounce = sin(_bounceCtrl.value * pi) * 3;
          return Transform.translate(
            offset: Offset(0, _isDragging ? 0 : bounce),
            child: Opacity(
              opacity: _isDragging ? 0.3 : 1.0,
              child: Container(
                width: boxSz,
                height: boxSz,
                decoration: BoxDecoration(
                  color: colors.panelBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: colors.panelBorder.withValues(alpha: 0.5),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: colors.glowColor.withValues(alpha: 0.1),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: Center(
                  child: CustomPaint(
                    size: Size(shape.width * widget.mini, shape.height * widget.mini),
                    painter: _ShapePainter(
                      shape: shape,
                      colors: colors,
                      cellSize: widget.mini,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ── Shape Painter ──────────────────────────────────────────────────────────

class _ShapePainter extends CustomPainter {
  final BlockShape shape;
  final GameThemeColors colors;
  final double cellSize;

  const _ShapePainter(
      {required this.shape, required this.colors, required this.cellSize});

  @override
  void paint(Canvas canvas, Size size) {
    final idx       = shape.colorIndex.clamp(0, colors.blockColors.length - 1);
    final baseColor = colors.blockColors[idx];
    final cs        = cellSize;

    final color = Color.fromARGB(
      (baseColor.a * 255.0).round().clamp(0, 255),
      ((baseColor.r * 255.0).round().clamp(0, 255) * 1.2).clamp(0, 255).round(),
      ((baseColor.g * 255.0).round().clamp(0, 255) * 1.2).clamp(0, 255).round(),
      ((baseColor.b * 255.0).round().clamp(0, 255) * 1.2).clamp(0, 255).round(),
    );
    final highlightColor = Color.fromARGB(
      (baseColor.a * 255.0).round().clamp(0, 255),
      ((baseColor.r * 255.0).round().clamp(0, 255) + 40).clamp(0, 255).round(),
      ((baseColor.g * 255.0).round().clamp(0, 255) + 40).clamp(0, 255).round(),
      ((baseColor.b * 255.0).round().clamp(0, 255) + 40).clamp(0, 255).round(),
    );
    final shadowColor = Color.fromARGB(
      (baseColor.a * 255.0).round().clamp(0, 255),
      ((baseColor.r * 255.0).round().clamp(0, 255) - 40).clamp(0, 255).round(),
      ((baseColor.g * 255.0).round().clamp(0, 255) - 40).clamp(0, 255).round(),
      ((baseColor.b * 255.0).round().clamp(0, 255) - 40).clamp(0, 255).round(),
    );

    final glow1 = Paint()
      ..color = color.withValues(alpha: 0.5)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
    final glow2 = Paint()
      ..color = color.withValues(alpha: 0.3)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);

    for (final cell in shape.cells) {
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cell[1] * cs + 1, cell[0] * cs + 1, cs - 2, cs - 2),
        Radius.circular(cs * 0.18),
      );
      canvas.drawRRect(rect, glow2);
      canvas.drawRRect(rect, glow1);

      final gradient = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          highlightColor.withValues(alpha: 0.95),
          color.withValues(alpha: 0.85),
          color.withValues(alpha: 0.65),
          shadowColor.withValues(alpha: 0.75),
        ],
        stops: const [0.0, 0.25, 0.75, 1.0],
      );
      canvas.drawRRect(
        rect,
        Paint()..shader = gradient.createShader(rect.outerRect),
      );

      // Glossy highlight
      final highlightRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cell[1] * cs + 2, cell[0] * cs + 2, cs - 4, cs * 0.35),
        Radius.circular(cs * 0.1),
      );
      final highlightGradient = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Colors.white.withValues(alpha: 0.6),
          Colors.white.withValues(alpha: 0.3),
          Colors.transparent,
        ],
      );
      canvas.drawRRect(
        highlightRect,
        Paint()..shader = highlightGradient.createShader(highlightRect.outerRect),
      );

      // Inner gem glow
      final gemCenter = Offset(cell[1] * cs + cs / 2, cell[0] * cs + cs / 2);
      canvas.drawCircle(
        gemCenter,
        cs * 0.07,
        Paint()
          ..color = Colors.white.withValues(alpha: 0.35)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
      );

      // Border
      canvas.drawRRect(
        rect,
        Paint()
          ..color = color.withValues(alpha: 0.85)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(cell[1] * cs + 3, cell[0] * cs + 3, cs - 6, cs - 6),
          Radius.circular(cs * 0.1),
        ),
        Paint()
          ..color = Colors.white.withValues(alpha: 0.2)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1,
      );
    }
  }

  @override
  bool shouldRepaint(_ShapePainter o) => o.cellSize != cellSize;
}

// ── Score Panel ────────────────────────────────────────────────────────────

class _ScorePanel extends StatelessWidget {
  final GameThemeData theme;
  final GameState gameState;
  final int? levelTimerSeconds;

  const _ScorePanel({
    required this.theme,
    required this.gameState,
    this.levelTimerSeconds,
  });

  @override
  Widget build(BuildContext context) {
    final c = theme.colors;
    final level = gameState.levelConfig;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [c.panelBg, c.panelBg.withValues(alpha: 0.85)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.panelBorder.withValues(alpha: 0.6), width: 1.5),
        boxShadow: [
          BoxShadow(color: c.glowColor.withValues(alpha: 0.25), blurRadius: 15, spreadRadius: 1),
          BoxShadow(color: c.glowColor.withValues(alpha: 0.15), blurRadius: 25, spreadRadius: 2),
          BoxShadow(color: Colors.black.withValues(alpha: 0.4), blurRadius: 12, offset: const Offset(0, 4), spreadRadius: -3),
          BoxShadow(color: Colors.white.withValues(alpha: 0.08), blurRadius: 6, offset: const Offset(-1, -1), spreadRadius: -1),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          if (level != null)
            _StatBadge(
              label: 'LEVEL',
              value: '${level.number}',
              colors: c,
            ),
          _StatBadge(label: 'SCORE', value: gameState.score.toString(), colors: c),
          if (level != null)
            _StatBadge(
              label: 'GOAL',
              value: '${level.scoreGoal}',
              colors: c,
            )
          else
            _StatBadge(label: 'BEST', value: gameState.highScore.toString(), colors: c),
          if (levelTimerSeconds != null)
            _StatBadge(
              label: 'TIME',
              value: '${levelTimerSeconds}s',
              colors: c,
              isTimer: levelTimerSeconds! <= 10,
            ),
          if (gameState.combo > 1)
            _StatBadge(
              label: 'COMBO',
              value: '×${gameState.combo}',
              colors: c,
              isCombo: true,
            ),
          if (gameState.comboMultiplier > 1)
            _StatBadge(
              label: 'BOOST',
              value: '×${gameState.comboMultiplier}',
              colors: c,
              isBoost: true,
            ),
        ],
      ),
    );
  }
}

class _StatBadge extends StatelessWidget {
  final String label, value;
  final GameThemeColors colors;
  final bool isCombo;
  final bool isBoost;
  final bool isTimer;

  const _StatBadge({
    required this.label,
    required this.value,
    required this.colors,
    this.isCombo = false,
    this.isBoost = false,
    this.isTimer = false,
  });

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        label,
        style: TextStyle(
          color: colors.textPrimary.withValues(alpha: 0.6),
          fontSize: 10,
          letterSpacing: 2,
          fontWeight: FontWeight.w700,
        ),
      ),
      const SizedBox(height: 3),
      Text(
        value,
        style: TextStyle(
          color: isTimer
              ? const Color(0xFFFF5252)
              : isBoost
                  ? const Color(0xFFFFD740)
                  : isCombo
                      ? colors.textAccent
                      : colors.textPrimary,
          fontSize: isCombo || isBoost || isTimer ? 22 : 20,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
          shadows: [
            Shadow(
              color: isBoost
                  ? const Color(0xFFFFD740).withValues(alpha: 0.8)
                  : isCombo
                      ? colors.glowColor.withValues(alpha: 0.8)
                      : colors.glowColor.withValues(alpha: 0.3),
              blurRadius: 12,
            ),
          ],
        ),
      ),
    ],
  );
}

// ── Game Over Panel ────────────────────────────────────────────────────────

class _GameOverPanel extends StatelessWidget {
  final GameThemeData theme;
  final int score, highScore;
  final VoidCallback onRestart;

  const _GameOverPanel({
    required this.theme,
    required this.score,
    required this.highScore,
    required this.onRestart,
  });

  @override
  Widget build(BuildContext context) {
    final c = theme.colors;
    return Positioned.fill(
      child: Container(
        color: Colors.black.withValues(alpha: 0.80),
        child: Center(
          child: Container(
            margin: const EdgeInsets.all(32),
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: c.panelBg,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: c.panelBorder, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: c.glowColor.withValues(alpha: 0.25),
                  blurRadius: 30,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'GAME OVER',
                  style: TextStyle(
                    color: c.textPrimary,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                    shadows: [Shadow(color: c.glowColor, blurRadius: 12)],
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'Score: $score',
                  style: TextStyle(
                    color: c.textAccent,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  'Best: $highScore',
                  style: TextStyle(
                    color: c.textPrimary.withValues(alpha: 0.6),
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 28),
                _PremiumButton(label: 'PLAY AGAIN', colors: c, onTap: onRestart),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Premium Button ─────────────────────────────────────────────────────────

class _PremiumButton extends StatefulWidget {
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;
  const _PremiumButton(
      {required this.label, required this.colors, required this.onTap});

  @override
  State<_PremiumButton> createState() => _PremiumButtonState();
}

class _PremiumButtonState extends State<_PremiumButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween(begin: 1.0, end: 0.94)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [c.buttonPrimary, c.buttonSecondary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: c.panelBorder.withValues(alpha: 0.8), width: 1.5),
              boxShadow: [
                BoxShadow(color: c.glowColor.withValues(alpha: 0.5), blurRadius: 12, spreadRadius: 1),
                BoxShadow(color: c.glowColor.withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 4)),
                BoxShadow(color: Colors.black.withValues(alpha: 0.3), blurRadius: 8, offset: const Offset(0, 3), spreadRadius: -2),
                BoxShadow(color: Colors.white.withValues(alpha: 0.15), blurRadius: 6, offset: const Offset(-1, -1), spreadRadius: -1),
              ],
            ),
            child: Text(
              widget.label,
              style: TextStyle(
                color: c.textPrimary,
                fontSize: 17,
                fontWeight: FontWeight.w800,
                letterSpacing: 2.5,
                shadows: [Shadow(color: c.glowColor.withValues(alpha: 0.5), blurRadius: 8)],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Powerup Animation Overlay ────────────────────────────────────────────────

class _PowerupAnimationOverlay extends StatelessWidget {
  final Offset position;
  final PowerupType type;
  final Animation<double> scaleAnim;
  final Animation<double> fadeAnim;
  final GameThemeColors colors;

  const _PowerupAnimationOverlay({
    required this.position,
    required this.type,
    required this.scaleAnim,
    required this.fadeAnim,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    final emoji = switch (type) {
      PowerupType.hammer => '🔨',
      PowerupType.bomb => '💣',
      PowerupType.lightning => '⚡',
      _ => '✨',
    };

    return AnimatedBuilder(
      animation: Listenable.merge([scaleAnim, fadeAnim]),
      builder: (_, __) => Positioned(
        left: position.dx - 30,
        top: position.dy - 30,
        child: Opacity(
          opacity: fadeAnim.value,
          child: Transform.scale(
            scale: scaleAnim.value,
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: colors.glowColor.withValues(alpha: 0.3),
                boxShadow: [
                  BoxShadow(
                    color: colors.glowColor.withValues(alpha: 0.6),
                    blurRadius: 20,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  emoji,
                  style: const TextStyle(fontSize: 32),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
