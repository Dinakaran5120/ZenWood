import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/user_model.dart';
import '../../auth/data/auth_repository.dart';
import '../../auth/data/user_repository.dart';
import '../../auth/domain/auth_notifier.dart';

// ─────────────────────────────────────────────
//  StarterRewardsService
//  Grants one-time starter powerups to new users
//  Rewards: 1 Hammer, 1 Bomb, 1 Rainbow, 1 Shuffle, 1 Lightning, 1 Combo Booster
// ─────────────────────────────────────────────

class StarterRewardsService {
  final FirebaseFirestore _db;
  final AuthRepository _authRepo;
  final UserRepository _userRepo;

  StarterRewardsService({
    required FirebaseFirestore db,
    required AuthRepository authRepo,
    required UserRepository userRepo,
  })  : _db = db,
        _authRepo = authRepo,
        _userRepo = userRepo;

  // ── Check if starter rewards already granted ──
  bool canGrant(UserModel user) {
    return !user.starterRewardsGranted;
  }

  // ── Grant starter rewards (once per user) ─────
  Future<void> grantRewards() async {
    final uid = _authRepo.currentUid;
    if (uid == null) throw Exception('Not authenticated');

    final user = await _userRepo.getUserProfile(uid);
    if (user == null) throw Exception('User not found');

    if (!canGrant(user)) {
      throw Exception('Starter rewards already granted');
    }

    // Grant all starter powerups
    await _db.runTransaction((tx) async {
      final ref = _db.collection('users').doc(uid);
      
      // Update inventory with starter powerups
      final updates = <String, dynamic>{
        'starterRewardsGranted': true,
        'inventory.hammers': FieldValue.increment(1),
        'inventory.bombs': FieldValue.increment(1),
        'inventory.rainbows': FieldValue.increment(1),
        'inventory.shuffles': FieldValue.increment(1),
        'inventory.lightnings': FieldValue.increment(1),
        'inventory.comboBoosters': FieldValue.increment(1),
        'lastSeen': FieldValue.serverTimestamp(),
      };

      tx.update(ref, updates);

      // Log to reward_history
      final histRef = ref.collection('reward_history').doc();
      tx.set(histRef, {
        'type': 'starter_rewards',
        'description': 'Welcome bonus: 6 powerups',
        'grantedAt': FieldValue.serverTimestamp(),
        'rewards': {
          'hammers': 1,
          'bombs': 1,
          'rainbows': 1,
          'shuffles': 1,
          'lightnings': 1,
          'comboBoosters': 1,
        },
      });
    });
  }
}

// ─────────────────────────────────────────────
//  StarterRewardsState + Notifier
// ─────────────────────────────────────────────

class StarterRewardsState {
  final bool canGrant;
  final bool isGranted;
  final bool isLoading;
  final String? error;

  const StarterRewardsState({
    this.canGrant = false,
    this.isGranted = false,
    this.isLoading = false,
    this.error,
  });

  StarterRewardsState copyWith({
    bool? canGrant,
    bool? isGranted,
    bool? isLoading,
    String? error,
  }) =>
      StarterRewardsState(
        canGrant: canGrant ?? this.canGrant,
        isGranted: isGranted ?? this.isGranted,
        isLoading: isLoading ?? this.isLoading,
        error: error,
      );
}

class StarterRewardsNotifier extends StateNotifier<StarterRewardsState> {
  final StarterRewardsService _service;
  final UserRepository _userRepo;
  final String? _uid;

  StarterRewardsNotifier(this._service, this._userRepo, this._uid)
      : super(const StarterRewardsState()) {
    _checkStatus();
  }

  Future<void> _checkStatus() async {
    if (_uid == null) return;
    final user = await _userRepo.getUserProfile(_uid);
    if (user == null) return;

    state = state.copyWith(
      canGrant: _service.canGrant(user),
      isGranted: user.starterRewardsGranted,
    );
  }

  Future<void> grantRewards() async {
    state = state.copyWith(isLoading: true);
    try {
      await _service.grantRewards();
      state = state.copyWith(
        isLoading: false,
        canGrant: false,
        isGranted: true,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void refresh() => _checkStatus();
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final starterRewardsServiceProvider = Provider<StarterRewardsService>((ref) {
  return StarterRewardsService(
    db: FirebaseFirestore.instance,
    authRepo: ref.read(authRepositoryProvider),
    userRepo: ref.read(userRepositoryProvider),
  );
});

final starterRewardsProvider =
    StateNotifierProvider<StarterRewardsNotifier, StarterRewardsState>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  return StarterRewardsNotifier(
    ref.read(starterRewardsServiceProvider),
    ref.read(userRepositoryProvider),
    uid,
  );
});
