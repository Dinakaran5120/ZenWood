import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// ─────────────────────────────────────────────
//  AdType enum — used by analytics too
// ─────────────────────────────────────────────
enum AdType { banner, interstitial, rewarded, dailyReward, continueAfterFail }

// ─────────────────────────────────────────────
//  Ad Unit IDs
// ─────────────────────────────────────────────
class AdIds {
  static const _testBanner        = 'ca-app-pub-3940256099942544/6300978111';
  static const _testInterstitial  = 'ca-app-pub-3940256099942544/1033173712';
  static const _testRewarded      = 'ca-app-pub-3940256099942544/5224354917';

  static const _prodBanner        = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
  static const _prodInterstitial  = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
  static const _prodRewarded      = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';

  static String get banner        => kDebugMode ? _testBanner       : _prodBanner;
  static String get interstitial  => kDebugMode ? _testInterstitial  : _prodInterstitial;
  static String get rewarded      => kDebugMode ? _testRewarded      : _prodRewarded;
}

// ─────────────────────────────────────────────
//  AdResult
// ─────────────────────────────────────────────
class AdResult {
  final bool earned;
  final int coinsEarned;
  final String? message;
  const AdResult({this.earned = false, this.coinsEarned = 0, this.message});
}

// ─────────────────────────────────────────────
//  AdMobService
// ─────────────────────────────────────────────
class AdMobService {
  InterstitialAd? _interstitialAd;
  RewardedAd?     _rewardedAd;
  RewardedAd?     _dailyRewardAd;
  RewardedAd?     _continueAd;
  BannerAd?       _bannerAd;

  bool _interstitialLoading  = false;
  bool _rewardedLoading      = false;
  bool _dailyRewardLoading   = false;
  bool _continueLoading      = false;
  bool _bannerLoaded         = false;

  Completer<AdResult>? _rewardCompleter;

  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    await Future.wait([
      _loadInterstitial(),
      _loadRewarded(),
      _loadDailyReward(),
      _loadContinueAd(),
      _loadBanner(),
    ]);
  }

  // ── Banner ────────────────────────────────
  Future<void> _loadBanner() async {
    _bannerAd?.dispose();
    _bannerAd = BannerAd(
      adUnitId: AdIds.banner,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => _bannerLoaded = true,
        onAdFailedToLoad: (_, __) {
          _bannerLoaded = false;
          Future.delayed(const Duration(seconds: 30), _loadBanner);
        },
      ),
    );
    await _bannerAd!.load();
  }

  BannerAd? get bannerAd => _bannerLoaded ? _bannerAd : null;

  // ── Interstitial ──────────────────────────
  Future<void> _loadInterstitial() async {
    if (_interstitialLoading) return;
    _interstitialLoading = true;
    await InterstitialAd.load(
      adUnitId: AdIds.interstitial,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd     = ad;
          _interstitialLoading = false;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (_) {
              _interstitialAd = null;
              _loadInterstitial();
            },
            onAdFailedToShowFullScreenContent: (_, __) {
              _interstitialAd = null;
              _loadInterstitial();
            },
          );
        },
        onAdFailedToLoad: (_) {
          _interstitialLoading = false;
          Future.delayed(const Duration(seconds: 60), _loadInterstitial);
        },
      ),
    );
  }

  Future<bool> showInterstitial() async {
    if (_interstitialAd == null) { await _loadInterstitial(); return false; }
    await _interstitialAd!.show();
    return true;
  }

  // ── Rewarded ──────────────────────────────
  Future<void> _loadRewarded() async {
    if (_rewardedLoading) return;
    _rewardedLoading = true;
    await RewardedAd.load(
      adUnitId: AdIds.rewarded,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd     = ad;
          _rewardedLoading = false;
          _setupCallbacks(ad, AdType.rewarded);
        },
        onAdFailedToLoad: (_) {
          _rewardedLoading = false;
          Future.delayed(const Duration(seconds: 60), _loadRewarded);
        },
      ),
    );
  }

  void _setupCallbacks(RewardedAd ad, AdType type) {
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (_) {
        if (_rewardCompleter != null && !_rewardCompleter!.isCompleted) {
          _rewardCompleter!.complete(
              const AdResult(earned: false, message: 'Ad skipped'));
        }
        _rewardCompleter = null;
        if (type == AdType.rewarded)        _loadRewarded();
        if (type == AdType.dailyReward)     _loadDailyReward();
        if (type == AdType.continueAfterFail) _loadContinueAd();
      },
      onAdFailedToShowFullScreenContent: (_, __) {
        _rewardCompleter?.complete(
            const AdResult(earned: false, message: 'Ad failed'));
        _rewardCompleter = null;
      },
    );
  }

  Future<AdResult> showRewardedAd({int coinsOnSuccess = 100}) async {
    if (_rewardedAd == null) {
      await _loadRewarded();
      return const AdResult(earned: false, message: 'Ad not ready');
    }
    _rewardCompleter = Completer<AdResult>();
    await _rewardedAd!.show(
      onUserEarnedReward: (_, __) {
        _rewardCompleter?.complete(AdResult(
          earned: true,
          coinsEarned: coinsOnSuccess,
          message: '+$coinsOnSuccess coins!',
        ));
        _rewardedAd = null;
      },
    );
    return _rewardCompleter!.future;
  }

  // ── Daily Reward Ad ───────────────────────
  Future<void> _loadDailyReward() async {
    if (_dailyRewardLoading) return;
    _dailyRewardLoading = true;
    await RewardedAd.load(
      adUnitId: AdIds.rewarded,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _dailyRewardAd      = ad;
          _dailyRewardLoading = false;
          _setupCallbacks(ad, AdType.dailyReward);
        },
        onAdFailedToLoad: (_) {
          _dailyRewardLoading = false;
          Future.delayed(const Duration(seconds: 60), _loadDailyReward);
        },
      ),
    );
  }

  Future<AdResult> showDailyRewardAd({required int baseCoins}) async {
    if (_dailyRewardAd == null) {
      return const AdResult(earned: false, message: 'Ad not ready');
    }
    _rewardCompleter = Completer<AdResult>();
    await _dailyRewardAd!.show(
      onUserEarnedReward: (_, __) {
        _rewardCompleter?.complete(AdResult(
          earned: true,
          coinsEarned: baseCoins,
          message: 'Daily reward doubled! +$baseCoins bonus coins!',
        ));
        _dailyRewardAd = null;
      },
    );
    return _rewardCompleter!.future;
  }

  // ── Continue After Fail ───────────────────
  Future<void> _loadContinueAd() async {
    if (_continueLoading) return;
    _continueLoading = true;
    await RewardedAd.load(
      adUnitId: AdIds.rewarded,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _continueAd     = ad;
          _continueLoading = false;
          _setupCallbacks(ad, AdType.continueAfterFail);
        },
        onAdFailedToLoad: (_) {
          _continueLoading = false;
          Future.delayed(const Duration(seconds: 60), _loadContinueAd);
        },
      ),
    );
  }

  Future<AdResult> showContinueAfterFailAd() async {
    if (_continueAd == null) {
      return const AdResult(earned: false, message: 'Ad not ready');
    }
    _rewardCompleter = Completer<AdResult>();
    await _continueAd!.show(
      onUserEarnedReward: (_, __) {
        _rewardCompleter?.complete(
            const AdResult(earned: true, message: 'Keep going!'));
        _continueAd = null;
      },
    );
    return _rewardCompleter!.future;
  }

  bool get canContinueAfterFail => _continueAd != null;
  bool get canShowRewarded      => _rewardedAd != null;
  bool get canShowInterstitial  => _interstitialAd != null;

  void dispose() {
    _bannerAd?.dispose();
    _interstitialAd?.dispose();
    _rewardedAd?.dispose();
    _dailyRewardAd?.dispose();
    _continueAd?.dispose();
  }
}

// ─────────────────────────────────────────────
//  Banner Widget
// ─────────────────────────────────────────────
class BannerAdWidget extends ConsumerWidget {
  const BannerAdWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final adService = ref.read(adMobServiceProvider);
    final banner = adService.bannerAd;
    if (banner == null) return const SizedBox.shrink();
    return SizedBox(
      width: banner.size.width.toDouble(),
      height: banner.size.height.toDouble(),
      child: AdWidget(ad: banner),
    );
  }
}

// ─────────────────────────────────────────────
//  Provider
// ─────────────────────────────────────────────
final adMobServiceProvider = Provider<AdMobService>((ref) => AdMobService());
