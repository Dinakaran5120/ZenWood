import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/auth_notifier.dart';
import '../../game/components/neon_background.dart';
import '../../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  Neon Theme Colors for Auth Screens
// ─────────────────────────────────────────────

const neonThemeColors = GameThemeColors(
  background1: Color(0xFF040D1A),
  background2: Color(0xFF0A1628),
  background3: Color(0xFF020810),
  gridBg: Color(0xFF0A1628),
  gridLine: Color(0xFF1A2F4A),
  cellEmpty: Color(0xFF0D1F3C),
  panelBg: Color(0xFF0A1628),
  panelBorder: Color(0xFF1A3F5C),
  textPrimary: Color(0xFFE8F5FF),
  textAccent: Color(0xFF00F5FF),
  particleColor1: Color(0xFF00F5FF),
  particleColor2: Color(0xFFBF40FF),
  particleColor3: Color(0xFF0DFFE4),
  glowColor: Color(0xFF00F5FF),
  blockColors: [
    Color(0xFF00F5FF),
    Color(0xFFBF40FF),
    Color(0xFF0DFFE4),
    Color(0xFF4CAF50),
    Color(0xFFFFD700),
  ],
  buttonPrimary: Color(0xFF00F5FF),
  buttonSecondary: Color(0xFFBF40FF),
);

// ─────────────────────────────────────────────
//  UsernameSetupPage
//  For new users to choose their username
// ─────────────────────────────────────────────

class UsernameSetupPage extends ConsumerStatefulWidget {
  const UsernameSetupPage({super.key});

  @override
  ConsumerState<UsernameSetupPage> createState() => _UsernameSetupPageState();
}

class _UsernameSetupPageState extends ConsumerState<UsernameSetupPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeIn;
  late Animation<Offset> _slideUp;
  final _usernameCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  Timer? _debounce;
  bool _isChecking = false;
  bool _isAvailable = false;
  bool _hasChecked = false;
  final _colors = neonThemeColors;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    _fadeIn = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _slideUp = Tween(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _usernameCtrl.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _onUsernameChanged(String value) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    
    setState(() {
      _hasChecked = false;
      _isAvailable = false;
    });

    if (value.isEmpty) return;

    _debounce = Timer(const Duration(milliseconds: 500), () async {
      if (!mounted) return;
      
      setState(() => _isChecking = true);
      
      final isValid = _validateUsernameFormat(value);
      if (!isValid) {
        setState(() {
          _isChecking = false;
          _hasChecked = true;
          _isAvailable = false;
        });
        return;
      }

      final available = await ref
          .read(authNotifierProvider.notifier)
          .checkUsernameAvailable(value);
      
      if (!mounted) return;
      
      setState(() {
        _isChecking = false;
        _hasChecked = true;
        _isAvailable = available;
      });
    });
  }

  bool _validateUsernameFormat(String username) {
    if (username.length < 3 || username.length > 16) return false;
    final regex = RegExp(r'^[a-zA-Z0-9_]+$');
    return regex.hasMatch(username);
  }

  String? _getValidationMessage() {
    final username = _usernameCtrl.text.trim();
    
    if (username.isEmpty) return null;
    if (!_validateUsernameFormat(username)) {
      return '3-16 characters, letters, numbers, underscores only';
    }
    if (_isChecking) return 'Checking availability...';
    if (!_hasChecked) return null;
    if (_isAvailable) return 'Username available!';
    return 'Username already taken';
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);

    // Listen for errors
    ref.listen<AuthState>(authNotifierProvider, (_, next) {
      if (next.errorMessage != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.errorMessage!),
            backgroundColor: Colors.red.shade800,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
        ref.read(authNotifierProvider.notifier).clearError();
      }
    });

    return Scaffold(
      backgroundColor: _colors.background1,
      body: Stack(
        children: [
          const NeonBackground(),
          SafeArea(
            child: SingleChildScrollView(
              child: FadeTransition(
                opacity: _fadeIn,
                child: SlideTransition(
                  position: _slideUp,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const SizedBox(height: 60),
                          // Avatar/emoji
                          Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [
                                  _colors.glowColor.withValues(alpha: 0.3),
                                  _colors.buttonSecondary.withValues(alpha: 0.2),
                                ],
                              ),
                              border: Border.all(
                                color: _colors.glowColor.withValues(alpha: 0.5),
                                width: 2,
                              ),
                            ),
                            child: const Center(
                              child: Text(
                                '🎮',
                                style: TextStyle(fontSize: 48),
                              ),
                            ),
                          ),
                          const SizedBox(height: 32),
                          // Title
                          ShaderMask(
                            shaderCallback: (bounds) => const LinearGradient(
                              colors: [
                                Color(0xFF00F5FF),
                                Color(0xFFBF40FF),
                                Color(0xFF00F5FF),
                              ],
                              stops: [0.0, 0.5, 1.0],
                            ).createShader(bounds),
                            child: const Text(
                              'Choose Your Name',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 28,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'This is how other players will see you',
                            style: TextStyle(
                              color: _colors.textPrimary.withValues(alpha: 0.6),
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 48),
                          // Username field
                          TextFormField(
                            controller: _usernameCtrl,
                            onChanged: _onUsernameChanged,
                            style: TextStyle(
                              color: _colors.textPrimary,
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                            decoration: InputDecoration(
                              hintText: 'Enter username',
                              hintStyle: TextStyle(
                                color: _colors.textPrimary.withValues(alpha: 0.3),
                              ),
                              filled: true,
                              fillColor: _colors.background3,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: BorderSide(color: _colors.panelBorder),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: BorderSide(color: _colors.panelBorder),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: BorderSide(color: _colors.glowColor),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: const BorderSide(color: Colors.red),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: const BorderSide(color: Colors.red),
                              ),
                              suffixIcon: _buildStatusIcon(),
                            ),
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Please enter a username';
                              }
                              if (!_validateUsernameFormat(value.trim())) {
                                return '3-16 characters, letters, numbers, underscores only';
                              }
                              if (_hasChecked && !_isAvailable) {
                                return 'Username already taken';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 8),
                          // Validation message
                          if (_usernameCtrl.text.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(left: 16),
                              child: Row(
                                children: [
                                  if (_isChecking)
                                    SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: _colors.textAccent,
                                      ),
                                    )
                                  else if (_hasChecked)
                                    Icon(
                                      _isAvailable ? Icons.check_circle : Icons.cancel,
                                      color: _isAvailable ? Colors.green : Colors.red,
                                      size: 20,
                                    ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      _getValidationMessage() ?? '',
                                      style: TextStyle(
                                        color: _isChecking
                                            ? _colors.textPrimary.withValues(alpha: 0.6)
                                            : _isAvailable
                                                ? Colors.green
                                                : Colors.red,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          const SizedBox(height: 32),
                          // Submit button
                          SizedBox(
                            width: double.infinity,
                            height: 56,
                            child: ElevatedButton(
                              onPressed: authState.isLoading ||
                                      !_hasChecked ||
                                      !_isAvailable
                                  ? null
                                  : () => _handleSubmit(),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: null,
                                foregroundColor: _colors.textPrimary,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              child: authState.isLoading
                                  ? const SizedBox(
                                      width: 24,
                                      height: 24,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(Colors.white),
                                      ),
                                    )
                                  : ShaderMask(
                                      shaderCallback: (bounds) => LinearGradient(
                                        colors: [
                                          _colors.buttonPrimary,
                                          _colors.buttonSecondary,
                                        ],
                                      ).createShader(bounds),
                                      child: const Text(
                                        "Let's Play!",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                            ),
                          ),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget? _buildStatusIcon() {
    if (_usernameCtrl.text.isEmpty) return null;
    if (_isChecking) {
      return const SizedBox(
        width: 20,
        height: 20,
        child: CircularProgressIndicator(strokeWidth: 2),
      );
    }
    if (_hasChecked) {
      return Icon(
        _isAvailable ? Icons.check_circle : Icons.cancel,
        color: _isAvailable ? Colors.green : Colors.red,
      );
    }
    return null;
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    final username = _usernameCtrl.text.trim();
    final success = await ref
        .read(authNotifierProvider.notifier)
        .setUsername(username);

    if (success && mounted) {
      // Navigation will be handled by AppShell based on auth state
    }
  }
}
