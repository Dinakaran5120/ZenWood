import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/auth_notifier.dart';

// ─────────────────────────────────────────────
//  TermsPage — shown once after username setup
//  User must accept T&C before reaching LevelsPage.
// ─────────────────────────────────────────────

class TermsPage extends ConsumerStatefulWidget {
  const TermsPage({super.key});

  @override
  ConsumerState<TermsPage> createState() => _TermsPageState();
}

class _TermsPageState extends ConsumerState<TermsPage>
    with SingleTickerProviderStateMixin {
  bool _accepted = false;
  bool _loading = false;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  Future<void> _onContinue() async {
    if (!_accepted || _loading) return;
    setState(() => _loading = true);
    await ref.read(authNotifierProvider.notifier).acceptTerms();
    // AppShell will automatically navigate to LevelsPage on state change.
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF040D1A),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: Stack(
          children: [
            // Background gradient
            Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(0, -0.4),
                  radius: 1.3,
                  colors: [
                    Color(0xFF0A1830),
                    Color(0xFF040D1A),
                    Color(0xFF020810),
                  ],
                  stops: [0.0, 0.6, 1.0],
                ),
              ),
            ),

            SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Header ──────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFF00F5FF),
                                Color(0xFFBF40FF),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF00F5FF)
                                    .withValues(alpha: 0.35),
                                blurRadius: 18,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.description_rounded,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),
                        const SizedBox(height: 20),
                        ShaderMask(
                          shaderCallback: (bounds) =>
                              const LinearGradient(
                            colors: [Color(0xFF00F5FF), Color(0xFFBF40FF)],
                          ).createShader(bounds),
                          child: const Text(
                            'Terms &\nConditions',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.5,
                              height: 1.15,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Please read and accept to continue',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.5),
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ── Scrollable content ───────────────────────
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFF0A1628),
                              Color(0xFF0D1F3C),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: const Color(0xFF00F5FF)
                                .withValues(alpha: 0.2),
                            width: 1,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: SingleChildScrollView(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: _termsSections
                                  .map((s) => _SectionWidget(
                                        heading: s.heading,
                                        body: s.body,
                                      ))
                                  .toList(),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  // ── Checkbox + Button ────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
                    child: Column(
                      children: [
                        // Checkbox row
                        GestureDetector(
                          onTap: () =>
                              setState(() => _accepted = !_accepted),
                          child: Row(
                            children: [
                              AnimatedContainer(
                                duration:
                                    const Duration(milliseconds: 200),
                                width: 24,
                                height: 24,
                                decoration: BoxDecoration(
                                  color: _accepted
                                      ? const Color(0xFF00F5FF)
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(
                                    color: _accepted
                                        ? const Color(0xFF00F5FF)
                                        : Colors.white
                                            .withValues(alpha: 0.3),
                                    width: 1.5,
                                  ),
                                  boxShadow: _accepted
                                      ? [
                                          BoxShadow(
                                            color: const Color(0xFF00F5FF)
                                                .withValues(alpha: 0.4),
                                            blurRadius: 8,
                                          ),
                                        ]
                                      : null,
                                ),
                                child: _accepted
                                    ? const Icon(
                                        Icons.check_rounded,
                                        color: Colors.black,
                                        size: 16,
                                      )
                                    : null,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  'I agree to the Terms & Conditions and Privacy Policy',
                                  style: TextStyle(
                                    color: Colors.white
                                        .withValues(alpha: 0.8),
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // Continue button
                        SizedBox(
                          width: double.infinity,
                          child: GestureDetector(
                            onTap: _accepted ? _onContinue : null,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 250),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 16),
                              decoration: BoxDecoration(
                                gradient: _accepted
                                    ? const LinearGradient(
                                        colors: [
                                          Color(0xFF00F5FF),
                                          Color(0xFFBF40FF),
                                        ],
                                      )
                                    : LinearGradient(
                                        colors: [
                                          Colors.white.withValues(alpha: 0.08),
                                          Colors.white.withValues(alpha: 0.05),
                                        ],
                                      ),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: _accepted
                                    ? [
                                        BoxShadow(
                                          color: const Color(0xFF00F5FF)
                                              .withValues(alpha: 0.4),
                                          blurRadius: 16,
                                          offset: const Offset(0, 4),
                                        ),
                                      ]
                                    : null,
                              ),
                              child: _loading
                                  ? const Center(
                                      child: SizedBox(
                                        width: 22,
                                        height: 22,
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2.5,
                                        ),
                                      ),
                                    )
                                  : Text(
                                      'Continue',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: _accepted
                                            ? Colors.white
                                            : Colors.white
                                                .withValues(alpha: 0.3),
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Section widget
// ─────────────────────────────────────────────

class _SectionWidget extends StatelessWidget {
  final String heading;
  final String body;
  const _SectionWidget({required this.heading, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            heading,
            style: const TextStyle(
              color: Color(0xFF00F5FF),
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.4,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            body,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.68),
              fontSize: 12.5,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  T&C content
// ─────────────────────────────────────────────

class _TermsSection {
  final String heading;
  final String body;
  const _TermsSection(this.heading, this.body);
}

const _termsSections = [
  _TermsSection('1. Acceptance of Terms',
      'By downloading, installing, or using ZenBlock Blast, you agree to comply with these terms and all applicable laws.'),
  _TermsSection('2. Usage Rules',
      'Users agree not to:\n• Modify, hack, or exploit the game\n• Use cheats, bots, or unauthorized tools\n• Copy or redistribute game assets without permission\n• Interfere with the normal operation of the game'),
  _TermsSection('3. Advertisements',
      'The game may contain advertisements including rewarded ads and interstitial ads. Rewarded ads are optional and may provide in-game benefits.'),
  _TermsSection('4. Intellectual Property',
      'All content related to ZenBlock Blast including logos, designs, graphics, gameplay elements, and audio are the property of Gmind Technologies unless otherwise stated.'),
  _TermsSection('5. Availability',
      'We may modify, suspend, or discontinue any part of the game at any time without prior notice.'),
  _TermsSection('6. Limitation of Liability',
      'ZenBlock Blast is provided on an "as is" basis. We are not responsible for data loss, device incompatibility, temporary service interruptions, or third-party advertisement content.'),
  _TermsSection('7. Privacy',
      'We may collect device type, gameplay activity, crash reports, and advertising identifiers to improve the experience. We do not collect sensitive personal information. See our full Privacy Policy in Settings.'),
  _TermsSection('8. Changes to Terms',
      'These Terms & Conditions may be updated periodically. Continued use of the game after updates constitutes acceptance of the revised terms.'),
  _TermsSection('9. Governing Law',
      'These terms shall be governed in accordance with the laws of India.'),
  _TermsSection('10. Contact',
      'Gmind Technologies\nEmail: zenblockblast@outlook.com'),
];
