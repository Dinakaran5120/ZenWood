import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/game_theme.dart';
import '../../core/services/sound_manager.dart';
import '../auth/domain/auth_notifier.dart';

// ─────────────────────────────────────────────
//  SettingsSheet — shared between LevelsPage and GameScreen
// ─────────────────────────────────────────────

class SettingsSheet extends ConsumerStatefulWidget {
  final GameThemeData theme;

  /// Called when the user selects a new theme. Optional — pass null when
  /// there is no parent game state to update (e.g. from the levels page).
  final ValueChanged<GameThemeData>? onThemeChanged;

  const SettingsSheet({
    super.key,
    required this.theme,
    this.onThemeChanged,
  });

  @override
  ConsumerState<SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends ConsumerState<SettingsSheet>
    with SingleTickerProviderStateMixin {
  late AnimationController _sheetCtrl;
  late Animation<double> _fadeAnim;
  bool _showShareOptions = false;

  @override
  void initState() {
    super.initState();
    _sheetCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnim =
        CurvedAnimation(parent: _sheetCtrl, curve: Curves.easeOut);
    _sheetCtrl.forward();
  }

  @override
  void dispose() {
    _sheetCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors      = widget.theme.colors;
    final sound       = ref.read(soundManagerProvider);
    final screenHeight = MediaQuery.of(context).size.height;
    final auth        = ref.watch(authNotifierProvider);
    final isGuest     = auth.user?.isGuest ?? false;
    final username    = auth.user?.username ?? '';

    return AnimatedBuilder(
      animation: _fadeAnim,
      builder: (_, __) => FadeTransition(
        opacity: _fadeAnim,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.1),
            end: Offset.zero,
          ).animate(_fadeAnim),
          child: Container(
            constraints: BoxConstraints(maxHeight: screenHeight * 0.85),
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colors.panelBg,
                  colors.panelBg.withValues(alpha: 0.85),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: colors.panelBorder.withValues(alpha: 0.6),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: colors.glowColor.withValues(alpha: 0.25),
                  blurRadius: 35,
                  spreadRadius: 3,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.4),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                  spreadRadius: -5,
                ),
                BoxShadow(
                  color: Colors.white.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(-2, -2),
                  spreadRadius: -2,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [
                              colors.buttonPrimary.withValues(alpha: 0.2),
                              colors.buttonSecondary.withValues(alpha: 0.15),
                            ]),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: colors.glowColor.withValues(alpha: 0.3),
                              width: 1,
                            ),
                          ),
                          child: Icon(Icons.settings_rounded,
                              color: colors.textAccent, size: 24),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Settings',
                                style: TextStyle(
                                  color: colors.textPrimary,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              if (username.isNotEmpty)
                                Text(
                                  username,
                                  style: TextStyle(
                                    color: colors.textPrimary
                                        .withValues(alpha: 0.5),
                                    fontSize: 12,
                                  ),
                                ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: colors.panelBorder.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(Icons.close_rounded,
                                color: colors.textPrimary.withValues(alpha: 0.6),
                                size: 20),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Audio
                    _SettingsSection(
                      title: 'AUDIO',
                      icon: Icons.volume_up_rounded,
                      colors: colors,
                      children: [
                        _SettingsRow(
                          label: 'Music',
                          icon: Icons.music_note_outlined,
                          value: sound.musicEnabled,
                          colors: colors,
                          onChanged: (_) => sound.toggleMusic(),
                        ),
                        const SizedBox(height: 12),
                        _SettingsRow(
                          label: 'Sound Effects',
                          icon: Icons.volume_up_outlined,
                          value: sound.sfxEnabled,
                          colors: colors,
                          onChanged: (_) => sound.toggleSfx(),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Theme
                    _SettingsSection(
                      title: 'THEME',
                      icon: Icons.palette_rounded,
                      colors: colors,
                      children: [
                        _ThemeChips(
                          currentTheme: widget.theme,
                          colors: colors,
                          onThemeSelected: (t) {
                            widget.onThemeChanged?.call(t);
                            Navigator.pop(context);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // More
                    _SettingsSection(
                      title: 'MORE',
                      icon: Icons.more_horiz_rounded,
                      colors: colors,
                      children: [
                        _SettingsButton(
                          icon: Icons.description_outlined,
                          label: 'Terms & Conditions',
                          colors: colors,
                          onTap: () => _showTermsDialog(context, colors),
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.privacy_tip_outlined,
                          label: 'Privacy Policy',
                          colors: colors,
                          onTap: () => _showPrivacyDialog(context, colors),
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.contact_mail_outlined,
                          label: 'Contact Us',
                          colors: colors,
                          onTap: () => _showContactDialog(context, colors),
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.share_outlined,
                          label: 'Share with Friends',
                          colors: colors,
                          onTap: () => setState(
                              () => _showShareOptions = !_showShareOptions),
                        ),
                        if (_showShareOptions) ...[
                          const SizedBox(height: 12),
                          _ShareOptions(colors: colors),
                        ],
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.star_rate_outlined,
                          label: 'Rate App',
                          colors: colors,
                          onTap: () {},
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.restore_outlined,
                          label: 'Restore Purchases',
                          colors: colors,
                          onTap: () {},
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Account
                    _SettingsSection(
                      title: 'ACCOUNT',
                      icon: Icons.account_circle_rounded,
                      colors: colors,
                      children: [
                        _LogoutButton(
                          colors: colors,
                          isGuest: isGuest,
                          onLogout: () async {
                            Navigator.pop(context);
                            await ref
                                .read(authNotifierProvider.notifier)
                                .signOut();
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showContactDialog(BuildContext context, GameThemeColors colors) {
    showDialog<void>(
      context: context,
      builder: (_) => _ContactDialog(colors: colors),
    );
  }

  void _showTermsDialog(BuildContext context, GameThemeColors colors) {
    showDialog<void>(
      context: context,
      builder: (_) => _LegalDialog(
        colors: colors,
        title: 'Terms & Conditions',
        icon: Icons.description_outlined,
        sections: const [
          _LegalSection('1. Acceptance of Terms',
              'By downloading, installing, or using ZenBlock Blast, you agree to comply with these terms and all applicable laws.'),
          _LegalSection('2. Usage Rules',
              'Users agree not to:\n• Modify, hack, or exploit the game\n• Use cheats, bots, or unauthorized tools\n• Copy or redistribute game assets without permission\n• Interfere with the normal operation of the game'),
          _LegalSection('3. Advertisements',
              'The game may contain advertisements including rewarded ads and interstitial ads. Rewarded ads are optional and may provide in-game benefits.'),
          _LegalSection('4. Intellectual Property',
              'All content related to ZenBlock Blast including logos, designs, graphics, gameplay elements, and audio are the property of Gmind Technologies unless otherwise stated.'),
          _LegalSection('5. Availability',
              'We may modify, suspend, or discontinue any part of the game at any time without prior notice.'),
          _LegalSection('6. Limitation of Liability',
              'ZenBlock Blast is provided on an "as is" basis. We are not responsible for data loss, device incompatibility, temporary service interruptions, or third-party advertisement content.'),
          _LegalSection('7. Changes to Terms',
              'These Terms & Conditions may be updated periodically. Continued use of the game after updates constitutes acceptance of the revised terms.'),
          _LegalSection('8. Governing Law',
              'These terms shall be governed in accordance with the laws of India.'),
          _LegalSection('9. Contact',
              'Gmind Technologies\nEmail: zenblockblast@outlook.com'),
        ],
      ),
    );
  }

  void _showPrivacyDialog(BuildContext context, GameThemeColors colors) {
    showDialog<void>(
      context: context,
      builder: (_) => _LegalDialog(
        colors: colors,
        title: 'Privacy Policy',
        icon: Icons.privacy_tip_outlined,
        sections: const [
          _LegalSection('1. Information We Collect',
              'While using ZenBlock Blast, we may collect:\n• Device type and operating system\n• Gameplay progress and in-game activity\n• Crash reports and diagnostics\n• Advertising identifiers\n• General usage analytics\n\nWe do not knowingly collect sensitive personal information such as passwords, banking information, or government identification details.'),
          _LegalSection('2. How We Use Information',
              'The collected information may be used to:\n• Improve gameplay experience\n• Maintain game performance and stability\n• Analyze user engagement\n• Deliver advertisements and rewards\n• Prevent abuse, cheating, or unauthorized activity'),
          _LegalSection('3. Advertisements & Third-Party Services',
              'ZenBlock Blast may use third-party services such as Google Play Services, Google AdMob, and analytics providers. These services may collect information per their own privacy policies.'),
          _LegalSection("4. Children's Privacy",
              'ZenBlock Blast is intended for general audiences. Children under the age of 13 should use the game under parental guidance.'),
          _LegalSection('5. Data Security',
              'We take reasonable steps to protect user information. However, no digital platform or internet transmission can be guaranteed to be completely secure.'),
          _LegalSection('6. Changes to This Policy',
              'We may update this Privacy Policy from time to time. Any changes will be reflected within the game or store listing.'),
          _LegalSection('7. Contact',
              'Gmind Technologies\nEmail: zenblockblast@outlook.com'),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Settings helpers
// ─────────────────────────────────────────────

class _SettingsSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final GameThemeColors colors;
  final List<Widget> children;

  const _SettingsSection({
    required this.title,
    required this.icon,
    required this.colors,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: colors.textAccent, size: 16),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: colors.textPrimary.withValues(alpha: 0.6),
                fontSize: 11,
                letterSpacing: 1.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                colors.panelBorder.withValues(alpha: 0.15),
                colors.panelBorder.withValues(alpha: 0.08),
              ],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: colors.panelBorder.withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }
}

class _SettingsButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _SettingsButton({
    required this.icon,
    required this.label,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_SettingsButton> createState() => _SettingsButtonState();
}

class _SettingsButtonState extends State<_SettingsButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scale = Tween(begin: 1.0, end: 0.95)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: widget.colors.panelBorder.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: widget.colors.panelBorder.withValues(alpha: 0.25),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: widget.colors.glowColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(widget.icon,
                      color: widget.colors.textAccent, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    widget.label,
                    style: TextStyle(
                      color: widget.colors.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Icon(
                  Icons.chevron_right_rounded,
                  color: widget.colors.textPrimary.withValues(alpha: 0.4),
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SettingsRow extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool value;
  final GameThemeColors colors;
  final ValueChanged<bool> onChanged;

  const _SettingsRow({
    required this.label,
    required this.icon,
    required this.value,
    required this.colors,
    required this.onChanged,
  });

  @override
  State<_SettingsRow> createState() => _SettingsRowState();
}

class _SettingsRowState extends State<_SettingsRow> {
  late bool _value;

  @override
  void initState() {
    super.initState();
    _value = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    final colors = widget.colors;
    return Row(
      children: [
        Icon(widget.icon,
            color: colors.textPrimary.withValues(alpha: 0.7), size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            widget.label,
            style: TextStyle(color: colors.textPrimary, fontSize: 14),
          ),
        ),
        Switch.adaptive(
          value: _value,
          onChanged: (v) {
            setState(() => _value = v);
            widget.onChanged(v);
          },
          activeThumbColor: colors.glowColor,
        ),
      ],
    );
  }
}

class _ThemeChips extends StatelessWidget {
  final GameThemeData currentTheme;
  final GameThemeColors colors;
  final ValueChanged<GameThemeData> onThemeSelected;

  const _ThemeChips({
    required this.currentTheme,
    required this.colors,
    required this.onThemeSelected,
  });

  @override
  Widget build(BuildContext context) {
    final themes = ThemeRegistry.themes.values.toList();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: themes.map((t) {
        final isActive = t.type == currentTheme.type;
        return GestureDetector(
          onTap: () => onThemeSelected(t),
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: isActive
                  ? colors.buttonPrimary.withValues(alpha: 0.3)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isActive
                    ? colors.panelBorder
                    : colors.panelBorder.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Text(
              t.name,
              style: TextStyle(
                color: isActive
                    ? colors.textAccent
                    : colors.textPrimary.withValues(alpha: 0.5),
                fontSize: 12,
                fontWeight:
                    isActive ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ─────────────────────────────────────────────
//  Share Options
// ─────────────────────────────────────────────

class _ShareOptions extends StatefulWidget {
  final GameThemeColors colors;
  const _ShareOptions({required this.colors});

  @override
  State<_ShareOptions> createState() => _ShareOptionsState();
}

class _ShareOptionsState extends State<_ShareOptions>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, -0.2),
          end: Offset.zero,
        ).animate(_fade),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                widget.colors.buttonPrimary.withValues(alpha: 0.15),
                widget.colors.buttonSecondary.withValues(alpha: 0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: widget.colors.glowColor.withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Share via',
                style: TextStyle(
                  color: widget.colors.textPrimary.withValues(alpha: 0.6),
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _SocialButton(
                    icon: Icons.message_rounded,
                    label: 'WhatsApp',
                    color: const Color(0xFF25D366),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                  _SocialButton(
                    icon: Icons.camera_alt_rounded,
                    label: 'Instagram',
                    color: const Color(0xFFE4405F),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                  _SocialButton(
                    icon: Icons.facebook_rounded,
                    label: 'Facebook',
                    color: const Color(0xFF1877F2),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SocialButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final Color color;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _SocialButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_SocialButton> createState() => _SocialButtonState();
}

class _SocialButtonState extends State<_SocialButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scale = Tween(begin: 1.0, end: 0.9)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Column(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: widget.color,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: widget.color.withValues(alpha: 0.4),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(widget.icon, color: Colors.white, size: 24),
              ),
              const SizedBox(height: 6),
              Text(
                widget.label,
                style: TextStyle(
                  color: widget.colors.textPrimary.withValues(alpha: 0.7),
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Logout Button
// ─────────────────────────────────────────────

class _LogoutButton extends StatefulWidget {
  final GameThemeColors colors;
  final bool isGuest;
  final VoidCallback onLogout;

  const _LogoutButton({
    required this.colors,
    required this.isGuest,
    required this.onLogout,
  });

  @override
  State<_LogoutButton> createState() => _LogoutButtonState();
}

class _LogoutButtonState extends State<_LogoutButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scale = Tween(begin: 1.0, end: 0.96)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const dangerColor = Color(0xFFFF4757);
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onLogout();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            decoration: BoxDecoration(
              color: dangerColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: dangerColor.withValues(alpha: 0.35),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: dangerColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: const Icon(Icons.logout_rounded,
                      color: dangerColor, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    widget.isGuest ? 'Exit Guest Mode' : 'Log Out',
                    style: const TextStyle(
                      color: dangerColor,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Icon(
                  Icons.chevron_right_rounded,
                  color: dangerColor.withValues(alpha: 0.5),
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Contact Dialog
// ─────────────────────────────────────────────

class _ContactDialog extends StatelessWidget {
  final GameThemeColors colors;
  const _ContactDialog({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 28),
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.85,
        ),
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [colors.panelBg, colors.panelBg.withValues(alpha: 0.85)],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: colors.panelBorder.withValues(alpha: 0.6),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: colors.glowColor.withValues(alpha: 0.25),
                  blurRadius: 35,
                  spreadRadius: 3,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.5),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                  spreadRadius: -5,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [
                          colors.buttonPrimary.withValues(alpha: 0.2),
                          colors.buttonSecondary.withValues(alpha: 0.15),
                        ]),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(Icons.contact_mail_rounded,
                          color: colors.textAccent, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Contact Us',
                            style: TextStyle(
                              color: colors.textPrimary,
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            'Gmind Technologies',
                            style: TextStyle(
                              color: colors.textPrimary.withValues(alpha: 0.5),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Icon(Icons.close_rounded,
                          color: colors.textPrimary.withValues(alpha: 0.5),
                          size: 22),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                _ContactOption(
                  icon: Icons.business_rounded,
                  label: 'Gmind Technologies',
                  subtitle: 'Game Developer',
                  colors: colors,
                  onTap: () {},
                ),
                const SizedBox(height: 10),
                _ContactOption(
                  icon: Icons.email_rounded,
                  label: 'Email Us',
                  subtitle: 'zenblockblast@outlook.com',
                  colors: colors,
                  onTap: () {},
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ContactOption extends StatefulWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _ContactOption({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_ContactOption> createState() => _ContactOptionState();
}

class _ContactOptionState extends State<_ContactOption>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scale = Tween(begin: 1.0, end: 0.96)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  widget.colors.panelBorder.withValues(alpha: 0.2),
                  widget.colors.panelBorder.withValues(alpha: 0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: widget.colors.panelBorder.withValues(alpha: 0.35),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: widget.colors.glowColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(widget.icon,
                      color: widget.colors.textAccent, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.label,
                        style: TextStyle(
                          color: widget.colors.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        widget.subtitle,
                        style: TextStyle(
                          color: widget.colors.textPrimary.withValues(alpha: 0.5),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: widget.colors.textPrimary.withValues(alpha: 0.4),
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Legal Section Data
// ─────────────────────────────────────────────

class _LegalSection {
  final String heading;
  final String body;
  const _LegalSection(this.heading, this.body);
}

// ─────────────────────────────────────────────
//  Legal Dialog (Privacy Policy / Terms)
// ─────────────────────────────────────────────

class _LegalDialog extends StatelessWidget {
  final GameThemeColors colors;
  final String title;
  final IconData icon;
  final List<_LegalSection> sections;

  const _LegalDialog({
    required this.colors,
    required this.title,
    required this.icon,
    required this.sections,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        padding: const EdgeInsets.all(24),
        constraints: const BoxConstraints(maxHeight: 560),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [colors.panelBg, colors.panelBg.withValues(alpha: 0.92)],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: colors.panelBorder.withValues(alpha: 0.6),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withValues(alpha: 0.2),
              blurRadius: 30,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: colors.buttonPrimary.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: colors.textAccent, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: colors.textPrimary,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        'Gmind Technologies · Effective May 22, 2026',
                        style: TextStyle(
                          color: colors.textPrimary.withValues(alpha: 0.45),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close_rounded,
                      color: colors.textPrimary.withValues(alpha: 0.5),
                      size: 22),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Scrollable content
            Flexible(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: sections
                      .map((s) => Padding(
                            padding: const EdgeInsets.only(bottom: 14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  s.heading,
                                  style: TextStyle(
                                    color: colors.textAccent,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.4,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  s.body,
                                  style: TextStyle(
                                    color: colors.textPrimary
                                        .withValues(alpha: 0.72),
                                    fontSize: 12.5,
                                    height: 1.6,
                                  ),
                                ),
                              ],
                            ),
                          ))
                      .toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
