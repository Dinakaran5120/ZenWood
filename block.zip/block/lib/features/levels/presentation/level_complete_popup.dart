import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../data/level_config.dart';

// ─────────────────────────────────────────────
//  Level Complete Popup
//  Animated dialog shown when score goal is met.
//  Shows stars, score, coins earned.
//  Offers Next Level (via rewarded ad) or Home.
// ─────────────────────────────────────────────

class LevelCompletePopup extends StatefulWidget {
  final LevelConfig level;
  final int score;
  final int coinsEarned;

  /// Called when user wants to go to the next level.
  /// The caller is responsible for showing the rewarded ad.
  final VoidCallback onNextLevel;

  /// Called when user wants to go back to the levels page.
  final VoidCallback onHome;

  const LevelCompletePopup({
    super.key,
    required this.level,
    required this.score,
    required this.coinsEarned,
    required this.onNextLevel,
    required this.onHome,
  });

  @override
  State<LevelCompletePopup> createState() => _LevelCompletePopupState();
}

class _LevelCompletePopupState extends State<LevelCompletePopup>
    with TickerProviderStateMixin {
  // Entry animation
  late AnimationController _entryCtrl;
  late Animation<double> _scaleAnim;
  late Animation<double> _fadeAnim;

  // Star reveal animation
  late AnimationController _starCtrl;

  // Coin counter animation
  late AnimationController _coinCtrl;
  late Animation<int> _coinAnim;

  // Confetti
  late AnimationController _confettiCtrl;
  final _rng = Random();
  late List<_ConfettiParticle> _particles;

  int get _stars => widget.level.starsEarned(widget.score);

  @override
  void initState() {
    super.initState();
    HapticFeedback.heavyImpact();

    _particles = List.generate(
      30,
      (_) => _ConfettiParticle(_rng),
    );

    // Entry
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _scaleAnim =
        CurvedAnimation(parent: _entryCtrl, curve: Curves.elasticOut);
    _fadeAnim =
        CurvedAnimation(parent: _entryCtrl, curve: Curves.easeIn);

    // Stars reveal (staggered)
    _starCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    // Coin counter
    _coinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _coinAnim = IntTween(begin: 0, end: widget.coinsEarned)
        .animate(CurvedAnimation(parent: _coinCtrl, curve: Curves.easeOut));

    // Confetti
    _confettiCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );

    // Sequence: entry → stars → coins + confetti
    _entryCtrl.forward().then((_) {
      _starCtrl.forward();
      Future.delayed(const Duration(milliseconds: 300), () {
        if (mounted) {
          _coinCtrl.forward();
          _confettiCtrl.forward();
        }
      });
    });
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _starCtrl.dispose();
    _coinCtrl.dispose();
    _confettiCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final neon = _neonForLevel(widget.level.number);

    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          // ── Dim backdrop ──────────────────────
          FadeTransition(
            opacity: _fadeAnim,
            child: Container(color: Colors.black.withValues(alpha: 0.82)),
          ),

          // ── Confetti ──────────────────────────
          AnimatedBuilder(
            animation: _confettiCtrl,
            builder: (_, __) => Stack(
              children: _particles
                  .map((p) => p.build(_confettiCtrl.value, size))
                  .toList(),
            ),
          ),

          // ── Dialog ────────────────────────────
          Center(
            child: ScaleTransition(
              scale: _scaleAnim,
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 28),
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.85,
                ),
                child: SingleChildScrollView(
                  child: Container(
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF0D1628),
                          Color(0xFF090E1C),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(32),
                      border: Border.all(
                        color: neon.withValues(alpha: 0.7),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: neon.withValues(alpha: 0.35),
                          blurRadius: 50,
                          spreadRadius: 4,
                        ),
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.6),
                          blurRadius: 25,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Trophy / Title
                    const Text('🏆', style: TextStyle(fontSize: 52)),
                    const SizedBox(height: 10),
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [neon, Colors.white, neon],
                      ).createShader(bounds),
                      child: const Text(
                        'LEVEL COMPLETE!',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Level ${widget.level.number} • ${widget.level.difficulty.emoji} ${widget.level.difficulty.label}',
                      style: TextStyle(
                        color: neon.withValues(alpha: 0.7),
                        fontSize: 12,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Stars
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(3, (i) {
                        return _AnimatedStar(
                          filled: i < _stars,
                          delay: Duration(milliseconds: 200 + i * 150),
                          controller: _starCtrl,
                          index: i,
                        );
                      }),
                    ),
                    const SizedBox(height: 20),

                    // Score + Coins row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _StatBox(
                          emoji: '⭐',
                          label: 'Score',
                          value: _formatNum(widget.score),
                          color: const Color(0xFF00F5FF),
                        ),
                        _StatBox(
                          emoji: '🪙',
                          label: 'Coins',
                          valueWidget: AnimatedBuilder(
                            animation: _coinAnim,
                            builder: (_, __) => Text(
                              '+${_coinAnim.value}',
                              style: const TextStyle(
                                color: Color(0xFFFFD700),
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          color: const Color(0xFFFFD700),
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),

                    // Next Level button (→ rewarded ad then next level)
                    _ActionButton(
                      emoji: '▶️',
                      label: 'NEXT LEVEL',
                      sublabel: 'Watch a short ad to continue',
                      gradient: [
                        neon.withValues(alpha: 0.9),
                        neon.withValues(alpha: 0.55),
                      ],
                      glowColor: neon,
                      onTap: widget.onNextLevel,
                    ),
                    const SizedBox(height: 12),

                    // Home button
                    _ActionButton(
                      emoji: '🏠',
                      label: 'HOME',
                      sublabel: 'Back to level select',
                      gradient: const [
                        Color(0xFF1A2A40),
                        Color(0xFF0D1628),
                      ],
                      glowColor: Colors.transparent,
                      onTap: widget.onHome,
                      bordered: true,
                    ),
                  ],
                ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatNum(int n) {
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}

// ── Animated Star ────────────────────────────

class _AnimatedStar extends StatelessWidget {
  final bool filled;
  final Duration delay;
  final AnimationController controller;
  final int index;

  const _AnimatedStar({
    required this.filled,
    required this.delay,
    required this.controller,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    // Each star animates at a different point in the timeline
    final start = 0.1 + index * 0.25;
    final end = start + 0.35;
    final anim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: controller,
        curve: Interval(start.clamp(0.0, 1.0), end.clamp(0.0, 1.0),
            curve: Curves.elasticOut),
      ),
    );

    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Transform.scale(
          scale: anim.value,
          child: Icon(
            filled ? Icons.star_rounded : Icons.star_outline_rounded,
            color: filled
                ? const Color(0xFFFFD700)
                : Colors.white.withValues(alpha: 0.2),
            size: 48,
            shadows: filled
                ? [
                    const Shadow(
                      color: Color(0xFFFFD700),
                      blurRadius: 20,
                    ),
                    Shadow(
                      color: const Color(0xFFFFD700).withValues(alpha: 0.4),
                      blurRadius: 35,
                    ),
                  ]
                : null,
          ),
        ),
      ),
    );
  }
}

// ── Stat Box ─────────────────────────────────

class _StatBox extends StatelessWidget {
  final String emoji;
  final String label;
  final String? value;
  final Widget? valueWidget;
  final Color color;

  const _StatBox({
    required this.emoji,
    required this.label,
    this.value,
    this.valueWidget,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withValues(alpha: 0.3), width: 1.5),
        boxShadow: [
          BoxShadow(color: color.withValues(alpha: 0.1), blurRadius: 12),
        ],
      ),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(height: 6),
          valueWidget ??
              Text(
                value ?? '',
                style: TextStyle(
                  color: color,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                ),
              ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.4),
              fontSize: 11,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Action Button ─────────────────────────────

class _ActionButton extends StatefulWidget {
  final String emoji;
  final String label;
  final String sublabel;
  final List<Color> gradient;
  final Color glowColor;
  final VoidCallback onTap;
  final bool bordered;

  const _ActionButton({
    required this.emoji,
    required this.label,
    required this.sublabel,
    required this.gradient,
    required this.glowColor,
    required this.onTap,
    this.bordered = false,
  });

  @override
  State<_ActionButton> createState() => _ActionButtonState();
}

class _ActionButtonState extends State<_ActionButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scale = Tween(begin: 1.0, end: 0.95)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: widget.gradient),
              borderRadius: BorderRadius.circular(18),
              border: widget.bordered
                  ? Border.all(
                      color: Colors.white.withValues(alpha: 0.15),
                      width: 1.5,
                    )
                  : null,
              boxShadow: widget.glowColor != Colors.transparent
                  ? [
                      BoxShadow(
                        color: widget.glowColor.withValues(alpha: 0.4),
                        blurRadius: 18,
                        spreadRadius: 1,
                        offset: const Offset(0, 4),
                      ),
                    ]
                  : null,
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(widget.emoji, style: const TextStyle(fontSize: 18)),
                    const SizedBox(width: 8),
                    Text(
                      widget.label,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 3,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  widget.sublabel,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.55),
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Confetti Particle ─────────────────────────

class _ConfettiParticle {
  final double startX;
  final double startY;
  final double velX;
  final double velY;
  final Color color;
  final double size;
  final double rotation;

  _ConfettiParticle(Random rng)
      : startX = rng.nextDouble(),
        startY = -0.1 - rng.nextDouble() * 0.3,
        velX = (rng.nextDouble() - 0.5) * 0.3,
        velY = 0.4 + rng.nextDouble() * 0.6,
        color = _confettiColors[rng.nextInt(_confettiColors.length)],
        size = 6 + rng.nextDouble() * 8,
        rotation = rng.nextDouble() * pi * 2;

  static const _confettiColors = [
    Color(0xFF00F5FF),
    Color(0xFFFFD700),
    Color(0xFFBF40FF),
    Color(0xFFFF4081),
    Color(0xFF4CAF50),
    Color(0xFFFF6600),
  ];

  Widget build(double progress, Size screenSize) {
    final x = (startX + velX * progress) * screenSize.width;
    final y = (startY + velY * progress) * screenSize.height;
    final opacity = progress < 0.7
        ? 1.0
        : 1.0 - ((progress - 0.7) / 0.3).clamp(0.0, 1.0);

    if (y > screenSize.height + 20) return const SizedBox.shrink();

    return Positioned(
      left: x,
      top: y,
      child: Opacity(
        opacity: opacity,
        child: Transform.rotate(
          angle: rotation + progress * pi * 4,
          child: Container(
            width: size,
            height: size * 0.6,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Neon color per level ──────────────────────

Color _neonForLevel(int n) {
  final hue = (n * 24.0) % 360.0;
  return HSLColor.fromAHSL(1.0, hue, 0.95, 0.65).toColor();
}
