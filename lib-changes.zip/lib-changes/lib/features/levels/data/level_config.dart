import 'package:flutter/material.dart';

// ─────────────────────────────────────────────
//  zenBlock — Progressive Level Configuration
//  Scalable: levels auto-generate via forLevel(n)
// ─────────────────────────────────────────────

enum LevelDifficulty {
  easy,
  medium,
  hard,
  extreme;

  String get label => switch (this) {
        easy    => 'Easy',
        medium  => 'Medium',
        hard    => 'Hard',
        extreme => 'Extreme',
      };

  Color get color => switch (this) {
        easy    => const Color(0xFF4CAF50),
        medium  => const Color(0xFFFFAA00),
        hard    => const Color(0xFFFF5722),
        extreme => const Color(0xFFBF40FF),
      };

  String get emoji => switch (this) {
        easy    => '🌱',
        medium  => '⚡',
        hard    => '🔥',
        extreme => '💀',
      };
}

class LevelConfig {
  final int number;

  /// Score required to complete (pass) the level.
  final int scoreGoal;

  /// Cumulative coin thresholds for star awards.
  /// Stars are based on score compared to goal multiples.
  final int scoreFor1Star;
  final int scoreFor2Stars;
  final int scoreFor3Stars;

  /// null = no timer (levels 1-2).
  /// int  = countdown seconds shown on screen.
  final int? timerSeconds;

  final LevelDifficulty difficulty;

  /// If true, 3×3 full blocks are excluded from tray (easier).
  final bool excludeHeavyShapes;

  const LevelConfig({
    required this.number,
    required this.scoreGoal,
    required this.scoreFor1Star,
    required this.scoreFor2Stars,
    required this.scoreFor3Stars,
    this.timerSeconds,
    this.difficulty = LevelDifficulty.easy,
    this.excludeHeavyShapes = true,
  });

  // ── Stars from score ────────────────────────
  int starsEarned(int score) {
    if (score >= scoreFor3Stars) return 3;
    if (score >= scoreFor2Stars) return 2;
    if (score >= scoreFor1Star)  return 1;
    return 0;
  }

  /// Flat coin reward for completing the level.
  int coinsEarned(int score) {
    final stars = starsEarned(score);
    final base = 20 + number * 5;
    return switch (stars) {
      3 => base * 4,
      2 => base * 2,
      1 => base,
      _ => (base * 0.5).round(),
    };
  }

  // ── Dynamic level generator ─────────────────
  static LevelConfig forLevel(int n) {
    final goal = _scoreGoal(n);
    return LevelConfig(
      number:            n,
      scoreGoal:         goal,
      scoreFor1Star:     (goal * 1.1).round(),
      scoreFor2Stars:    (goal * 1.4).round(),
      scoreFor3Stars:    (goal * 1.9).round(),
      timerSeconds:      _timer(n),
      difficulty:        _diff(n),
      excludeHeavyShapes: n <= 5,
    );
  }

  static int _scoreGoal(int n) {
    if (n == 1) return 300;
    if (n == 2) return 600;
    if (n <= 5) return 500 + (n - 2) * 350;
    if (n <= 10) return 2000 + (n - 5) * 450;
    if (n <= 20) return 4250 + (n - 10) * 550;
    return 9750 + (n - 20) * 700;
  }

  static int? _timer(int n) {
    if (n <= 2) return null;    // free play
    if (n <= 5) return 120;
    if (n <= 10) return 90;
    if (n <= 20) return 60;
    return 45;
  }

  static LevelDifficulty _diff(int n) {
    if (n <= 2)  return LevelDifficulty.easy;
    if (n <= 7)  return LevelDifficulty.medium;
    if (n <= 15) return LevelDifficulty.hard;
    return LevelDifficulty.extreme;
  }
}
