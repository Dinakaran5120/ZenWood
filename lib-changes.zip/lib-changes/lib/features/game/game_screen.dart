import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'components/game_grid.dart';
import 'components/theme_backgrounds.dart';
import 'bloc/game_notifier.dart';
import '../../core/theme/game_theme.dart';
import '../../core/services/sound_manager.dart';
import '../spin_wheel/spin_wheel_screen.dart';
import '../leaderboard/presentation/leaderboard_screen.dart';
import '../store/store_screen.dart';
import '../store/store_models.dart';
import '../store/store_repository.dart';
import '../auth/domain/auth_notifier.dart';
import '../daily_reward/presentation/daily_reward_screen.dart';
import '../admob/admob_service.dart';
import '../levels/data/level_config.dart';
import '../levels/presentation/level_complete_popup.dart';
import 'components/powerup_effects.dart';

// ─────────────────────────────────────────────
//  Game Screen
// ─────────────────────────────────────────────

class GameScreen extends ConsumerStatefulWidget {
  final LevelConfig? levelConfig;

  const GameScreen({super.key, this.levelConfig});

  @override
  ConsumerState<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends ConsumerState<GameScreen>
    with TickerProviderStateMixin {
  GameThemeData _theme = beachTheme;

  // ── Powerup selection mode ─────────────────
  PowerupType? _activePowerup;
  bool _powerupApplying = false;

  // ── Freeze Time state ─────────────────────
  int _freezeCountdown = 0;
  Timer? _freezeTimer;

  // ── Combo Booster state ───────────────────
  bool _comboBoosterActive = false;
  int _comboBoosterCountdown = 0;
  Timer? _comboBoosterTimer;

  // ── Score popup ───────────────────────────
  OverlayEntry? _feedbackOverlay;

  // ── Reward-ad loading guard ───────────────
  bool _adLoading = false;

  // ── Game-over-dialog guard ────────────────
  bool _reviveDialogShowing = false;

  // ── Level mode ────────────────────────────
  Timer? _levelTimer;
  int? _levelTimerRemaining;
  bool _levelCompleteShowing = false;

  // ── Powerup visual effects ────────────────
  OverlayEntry? _powerupEffectEntry;
  final _shakeCtrl = ScreenShakeController();
  final _gridKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _startAmbient();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (widget.levelConfig != null) {
        ref.read(gameProvider.notifier).startLevel(widget.levelConfig!);
        _levelTimerRemaining = widget.levelConfig!.timerSeconds;
        if (_levelTimerRemaining != null) _startLevelTimer();
      } else {
        ref.read(gameProvider.notifier).clearLevelMode();
      }
    });
  }


  @override
  void dispose() {
    _levelTimer?.cancel();
    if (widget.levelConfig != null) {
      ref.read(gameProvider.notifier).clearLevelMode();
    }
    _freezeTimer?.cancel();
    _comboBoosterTimer?.cancel();
    _feedbackOverlay?.remove();
    _powerupEffectEntry?.remove();
    _shakeCtrl.dispose();
    super.dispose();
  }

  Future<void> _startAmbient() async {
    final sound = ref.read(soundManagerProvider);
    await sound.preload();
    await sound.playMusic(_theme.ambientSound);
  }

  void _onThemeChanged(GameThemeData theme) {
    if (theme.type == _theme.type) return;
    setState(() => _theme = theme);
    ref.read(soundManagerProvider).playMusic(theme.ambientSound);
  }

  Widget _themedBackground({required Widget child}) {
    return switch (_theme.type) {
      GameThemeType.beach => BeachBackground(child: child),
      GameThemeType.devil => DevilBackground(child: child),
      GameThemeType.angel => AngelBackground(child: child),
    };
  }

  // ─────────────────────────────────────────
  //  Game Over flow
  // ─────────────────────────────────────────

  void _onLevelFailed(int score) {
    if (_levelCompleteShowing) return;
    _levelTimer?.cancel();
    _onGameOver(score);
  }

  void _onGameOver(int score) {
    if (_reviveDialogShowing) return;
    _reviveDialogShowing = true;
    final inventory = ref.read(inventoryProvider).value;
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => GameOverReviveDialog(
        theme: _theme,
        score: score,
        inventory: inventory,
        onReviveAd:    _handleReviveAd,
        onReviveHammer: _handleReviveHammer,
        onReviveBomb:   _handleReviveBomb,
        onRestart:      _handleRestart,
      ),
    ).then((_) => _reviveDialogShowing = false);
  }

  Future<void> _handleReviveAd() async {
    Navigator.pop(context);
    setState(() => _adLoading = true);

    final adService = ref.read(adMobServiceProvider);
    final result    = await adService.showContinueAfterFailAd();

    setState(() => _adLoading = false);

    if (result.earned) {
      ref.read(gameProvider.notifier).revive();
      _showPowerupFeedback('▶️ Keep going!');
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message ?? 'Ad not available right now'),
            backgroundColor: _theme.colors.panelBg,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  void _handleReviveHammer() {
    Navigator.pop(context);
    final uid = ref.read(authNotifierProvider).user?.uid;
    final inv = ref.read(inventoryProvider).value;
    if (uid != null && inv != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.hammer, inv);
    }
    ref.read(gameProvider.notifier).revive();
    // Activate hammer mode so player can immediately clear a block
    setState(() => _activePowerup = PowerupType.hammer);
  }

  void _handleReviveBomb() {
    Navigator.pop(context);
    final uid = ref.read(authNotifierProvider).user?.uid;
    final inv = ref.read(inventoryProvider).value;
    if (uid != null && inv != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.bomb, inv);
    }
    ref.read(gameProvider.notifier).revive();
    // Activate bomb mode so player can blast an area
    setState(() => _activePowerup = PowerupType.bomb);
  }

  void _handleRestart() async {
    Navigator.pop(context);
    
    // Update user's highScore and coins when game ends
    final gameState = ref.read(gameProvider);
    final uid = ref.read(authNotifierProvider).user?.uid;
    if (uid != null) {
      try {
        // Update highScore
        await ref.read(storeRepositoryProvider).updateHighScore(uid, gameState.highScore);
        // Update coins (1 coin per 10 points)
        final coinsEarned = (gameState.score / 10).floor();
        if (coinsEarned > 0) {
          await ref.read(storeRepositoryProvider).addCoins(uid, coinsEarned);
        }
      } catch (e) {
        // Update failed, but game should continue
      }
    }
    
    ref.read(gameProvider.notifier).resetGame();
    setState(() {
      _activePowerup = null;
      _freezeCountdown = 0;
      _comboBoosterActive = false;
      _freezeTimer?.cancel();
      _comboBoosterTimer?.cancel();
    });
  }

  // ─────────────────────────────────────────
  //  Powerup HUD actions
  // ─────────────────────────────────────────

  /// Activates selection mode for Hammer / Bomb / Lightning.
  void _activatePowerupMode(PowerupType type) {
    final inventory = ref.read(inventoryProvider).value;
    if (inventory == null) return;
    final count = inventory.countForPowerup(type);
    if (count <= 0) {
      _showNoPowerupSnack(_noPowerupMessage(type));
      return;
    }
    if (_activePowerup == type) {
      setState(() => _activePowerup = null); // toggle off
    } else {
      setState(() => _activePowerup = type);
      HapticFeedback.lightImpact();
    }
  }

  /// Called by GameGrid when user taps a cell in powerup mode.
  Future<void> _onPowerupApplied(int row, int col) async {
    if (_powerupApplying) return;
    final type = _activePowerup;
    if (type == null) return;
    _powerupApplying = true;

    setState(() => _activePowerup = null);

    final uid = ref.read(authNotifierProvider).user?.uid;
    final inv = ref.read(inventoryProvider).value;
    if (uid != null && inv != null) {
      await ref.read(storeRepositoryProvider).usePowerup(uid, type, inv);
    }

    final notifier = ref.read(gameProvider.notifier);
    switch (type) {
      case PowerupType.hammer:
        await notifier.applyHammer(row, col);
        HapticFeedback.heavyImpact();
        _showPowerupEffect(PowerupType.hammer, row, col);
        _showPowerupFeedback('🔨 Hammer');
      case PowerupType.bomb:
        await notifier.applyBomb(row, col);
        HapticFeedback.heavyImpact();
        _showPowerupEffect(PowerupType.bomb, row, col);
        _showPowerupFeedback('💣 Bomb');
      case PowerupType.lightning:
        await notifier.applyLightning(row, col);
        HapticFeedback.heavyImpact();
        _showPowerupEffect(PowerupType.lightning, row, col);
        _showPowerupFeedback('⚡ Lightning');
      default:
        break;
    }

    _powerupApplying = false;
  }

  void _useShuffle() {
    final inventory = ref.read(inventoryProvider).value;
    if (inventory == null || inventory.shuffles <= 0) {
      _showNoPowerupSnack('🔀 No shuffles left! Buy more in the Store.');
      return;
    }
    final uid = ref.read(authNotifierProvider).user?.uid;
    if (uid != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.shuffle, inventory);
    }
    ref.read(gameProvider.notifier).shuffleTray();
    HapticFeedback.mediumImpact();
    _showPowerupFeedback('🔀 Pieces reshuffled!');
  }

  void _useFreezeTime() {
    if (_freezeCountdown > 0) return; // already frozen
    final inventory = ref.read(inventoryProvider).value;
    if (inventory == null || inventory.freezes <= 0) {
      _showNoPowerupSnack('❄️ No Freeze Time left! Buy more in the Store.');
      return;
    }
    final uid = ref.read(authNotifierProvider).user?.uid;
    if (uid != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.freezeTime, inventory);
    }
    _startFreeze(10);
    HapticFeedback.mediumImpact();
    _showPowerupFeedback('❄️ Time frozen for 10s!');
  }

  void _startFreeze(int seconds) {
    _freezeTimer?.cancel();
    setState(() => _freezeCountdown = seconds);
    _freezeTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() {
        _freezeCountdown--;
        if (_freezeCountdown <= 0) {
          _freezeCountdown = 0;
          t.cancel();
        }
      });
    });
  }

  void _useRainbow() {
    final inventory = ref.read(inventoryProvider).value;
    if (inventory == null || inventory.rainbows <= 0) {
      _showNoPowerupSnack('🌈 No Rainbow blocks left! Buy more in the Store.');
      return;
    }
    final uid = ref.read(authNotifierProvider).user?.uid;
    if (uid != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.rainbow, inventory);
    }
    // Rainbow: reshuffle with a guaranteed wildcard-like tray
    ref.read(gameProvider.notifier).shuffleTray();
    HapticFeedback.mediumImpact();
    _showPowerupFeedback('🌈 Rainbow pieces loaded!');
  }

  void _useComboBooster() {
    if (_comboBoosterActive) return;
    final inventory = ref.read(inventoryProvider).value;
    if (inventory == null || inventory.comboBoosters <= 0) {
      _showNoPowerupSnack('⭐ No Combo Boosters left! Buy more in the Store.');
      return;
    }
    final uid = ref.read(authNotifierProvider).user?.uid;
    if (uid != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.comboBooster, inventory);
    }
    ref.read(gameProvider.notifier).activateComboBooster();
    setState(() {
      _comboBoosterActive = true;
      _comboBoosterCountdown = 30;
    });
    HapticFeedback.mediumImpact();
    _showPowerupFeedback('⭐ Score ×2 for 30 seconds!');

    _comboBoosterTimer?.cancel();
    _comboBoosterTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() {
        _comboBoosterCountdown--;
        if (_comboBoosterCountdown <= 0) {
          _comboBoosterCountdown = 0;
          _comboBoosterActive = false;
          ref.read(gameProvider.notifier).deactivateComboBooster();
          t.cancel();
        }
      });
    });
  }

  // ── Feedback helpers ──────────────────────

  void _showNoPowerupSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message,
            style: const TextStyle(fontWeight: FontWeight.w600)),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: _theme.colors.panelBg,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _showPowerupFeedback(String message) {
    if (!mounted) return;
    _feedbackOverlay?.remove();
    final overlay = Overlay.of(context);
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => _FloatingFeedback(
        message: message,
        colors: _theme.colors,
        onDone: () {
          entry.remove();
          _feedbackOverlay = null;
        },
      ),
    );
    _feedbackOverlay = entry;
    overlay.insert(entry);
  }

  String _noPowerupMessage(PowerupType type) => switch (type) {
        PowerupType.hammer    => '🔨 No hammers left! Visit the Store.',
        PowerupType.bomb      => '💣 No bombs left! Visit the Store.',
        PowerupType.lightning => '⚡ No lightning left! Visit the Store.',
        _                     => 'Out of stock! Visit the Store.',
      };

  // ─────────────────────────────────────────
  //  Level system
  // ─────────────────────────────────────────

  void _startLevelTimer() {
    _levelTimer?.cancel();
    _levelTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final remaining = _levelTimerRemaining;
      if (remaining == null) return;
      if (remaining <= 1) {
        _levelTimer?.cancel();
        setState(() => _levelTimerRemaining = 0);
        ref.read(gameProvider.notifier).expireLevelTimer();
        return;
      }
      setState(() => _levelTimerRemaining = remaining - 1);
    });
  }

  Future<void> _persistLevelRewards(int score, int coins) async {
    final uid = ref.read(authNotifierProvider).user?.uid;
    if (uid == null) return;
    try {
      await ref.read(storeRepositoryProvider).updateHighScore(uid, score);
      if (coins > 0) {
        await ref.read(storeRepositoryProvider).addCoins(uid, coins);
      }
    } catch (_) {}
  }

  void _onLevelComplete() {
    if (_levelCompleteShowing || widget.levelConfig == null) return;
    _levelCompleteShowing = true;
    _levelTimer?.cancel();

    final level = widget.levelConfig!;
    final score = ref.read(gameProvider).score;
    final coins = level.coinsEarned(score);
    _persistLevelRewards(score, coins);

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogCtx) => LevelCompletePopup(
        level: level,
        score: score,
        coinsEarned: coins,
        onNextLevel: () async {
          Navigator.pop(dialogCtx);
          final adService = ref.read(adMobServiceProvider);
          final result = await adService.showRewardedAd();
          if (!mounted) return;
          if (!result.earned) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(result.message ?? 'Ad not available'),
                backgroundColor: _theme.colors.panelBg,
              ),
            );
            return;
          }
          final next = LevelConfig.forLevel(level.number + 1);
          Navigator.of(context).pushReplacement(
            MaterialPageRoute<void>(
              builder: (_) => GameScreen(levelConfig: next),
            ),
          );
        },
        onHome: () {
          Navigator.pop(dialogCtx);
          Navigator.of(context).pop();
        },
      ),
    ).then((_) => _levelCompleteShowing = false);
  }

  // ── Powerup visual effects ────────────────

  void _showPowerupEffect(PowerupType type, int row, int col) {
    _powerupEffectEntry?.remove();
    _powerupEffectEntry = null;

    final overlay = Overlay.of(context);
    final box = _gridKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return;

    final gridPos = box.localToGlobal(Offset.zero);
    final gridW   = box.size.width;
    final cellPx  = gridW / 8;
    final cellX   = gridPos.dx + col * cellPx + cellPx / 2;
    final cellY   = gridPos.dy + row * cellPx + cellPx / 2;
    final center  = Offset(cellX, cellY);

    late OverlayEntry entry;
    void removeEntry() {
      if (_powerupEffectEntry == entry) _powerupEffectEntry = null;
      entry.remove();
    }

    Widget effect;
    switch (type) {
      case PowerupType.hammer:
        effect = HammerEffect(cellCenter: center, onDone: removeEntry);
      case PowerupType.bomb:
        effect = BombBlastEffect(center: center, cellSize: cellPx, onDone: removeEntry);
      case PowerupType.lightning:
        effect = LightningEffect(
          tapCenter: center,
          gridLeft: gridPos.dx,
          gridTop: gridPos.dy,
          gridSize: gridW,
          tapRow: row,
          tapCol: col,
          gridCells: 8,
          onDone: removeEntry,
        );
      default:
        return;
    }

    entry = OverlayEntry(
      builder: (_) => IgnorePointer(child: SizedBox.expand(child: effect)),
    );
    _powerupEffectEntry = entry;
    overlay.insert(entry);
    _shakeCtrl.shake(magnitude: type == PowerupType.bomb ? 8.0 : 5.0);
  }

  // ─────────────────────────────────────────
  //  Build
  // ─────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final inventory  = ref.watch(inventoryProvider).value;

    ref.listen<bool>(
      gameProvider.select((s) => s.isLevelComplete),
      (prev, next) {
        if (next == true && prev != true) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) _onLevelComplete();
          });
        }
      },
    );

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          _themedBackground(
            child: SafeArea(
              child: Column(
                children: [
                  _TopHUD(
                    theme: _theme,
                    onThemeChanged: _onThemeChanged,
                  ),
                  const SizedBox(height: 4),

                  // ── Game area (Expanded = takes all remaining space) ──
                  Expanded(
                    child: ScreenShakeWidget(
                      controller: _shakeCtrl,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Padding(
                            key: _gridKey,
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: GameGrid(
                              theme: _theme,
                              activePowerup: _activePowerup,
                              onPowerupApplied: _onPowerupApplied,
                              onGameOver: widget.levelConfig == null
                                  ? _onGameOver
                                  : _onLevelFailed,
                              levelTimerSeconds: _levelTimerRemaining,
                            ),
                          ),

                          // Frozen overlay
                          if (_freezeCountdown > 0)
                            _FrozenOverlay(
                              theme: _theme,
                              countdown: _freezeCountdown,
                            ),

                          // Powerup selection banner
                          if (_activePowerup != null)
                            _PowerupSelectionBanner(
                              powerup: _activePowerup!,
                              theme: _theme,
                              onCancel: () => setState(() => _activePowerup = null),
                            ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 4),

                  // ── Full 7-item powerup HUD ──
                  _PowerupHUD(
                    theme: _theme,
                    inventory: inventory,
                    activePowerup: _activePowerup,
                    comboBoosterActive: _comboBoosterActive,
                    comboBoosterCountdown: _comboBoosterCountdown,
                    freezeActive: _freezeCountdown > 0,
                    onHammer:       () => _activatePowerupMode(PowerupType.hammer),
                    onBomb:         () => _activatePowerupMode(PowerupType.bomb),
                    onLightning:    () => _activatePowerupMode(PowerupType.lightning),
                    onShuffle:      _useShuffle,
                    onFreezeTime:   _useFreezeTime,
                    onRainbow:      _useRainbow,
                    onComboBooster: _useComboBooster,
                  ),

                  const SizedBox(height: 6),
                  _FeatureNavBar(
                    theme: _theme,
                    themedBackground: _themedBackground,
                  ),
                  const SizedBox(height: 4),
                ],
              ),
            ),
          ),

          // Ad loading overlay
          if (_adLoading)
            Container(
              color: Colors.black54,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.all(28),
                  decoration: BoxDecoration(
                    color: _theme.colors.panelBg,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: _theme.colors.panelBorder.withValues(alpha: 0.6)),
                    boxShadow: [
                      BoxShadow(
                        color: _theme.colors.glowColor.withValues(alpha: 0.3),
                        blurRadius: 30,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(
                        valueColor:
                            AlwaysStoppedAnimation(_theme.colors.glowColor),
                        strokeWidth: 3,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Loading ad...',
                        style: TextStyle(
                          color: _theme.colors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Floating Feedback Toast
// ─────────────────────────────────────────────

class _FloatingFeedback extends StatefulWidget {
  final String message;
  final GameThemeColors colors;
  final VoidCallback onDone;

  const _FloatingFeedback({
    required this.message,
    required this.colors,
    required this.onDone,
  });

  @override
  State<_FloatingFeedback> createState() => _FloatingFeedbackState();
}

class _FloatingFeedbackState extends State<_FloatingFeedback>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _opacity;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    );
    _opacity = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 20),
      TweenSequenceItem(tween: ConstantTween(1.0), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 30),
    ]).animate(_ctrl);
    _slide = TweenSequence<Offset>([
      TweenSequenceItem(
          tween: Tween(begin: const Offset(0, 0.3), end: Offset.zero),
          weight: 20),
      TweenSequenceItem(tween: ConstantTween(Offset.zero), weight: 50),
      TweenSequenceItem(
          tween: Tween(begin: Offset.zero, end: const Offset(0, -0.3)),
          weight: 30),
    ]).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _ctrl.forward().then((_) => widget.onDone());
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: MediaQuery.of(context).size.height * 0.25,
      left: 0,
      right: 0,
      child: IgnorePointer(
        child: FadeTransition(
          opacity: _opacity,
          child: SlideTransition(
            position: _slide,
            child: Center(
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: widget.colors.glowColor.withValues(alpha: 0.9),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: widget.colors.glowColor.withValues(alpha: 0.4),
                      blurRadius: 16,
                    ),
                  ],
                ),
                child: Text(
                  widget.message,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Frozen Overlay
// ─────────────────────────────────────────────

class _FrozenOverlay extends StatefulWidget {
  final GameThemeData theme;
  final int countdown;

  const _FrozenOverlay({required this.theme, required this.countdown});

  @override
  State<_FrozenOverlay> createState() => _FrozenOverlayState();
}

class _FrozenOverlayState extends State<_FrozenOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulse = Tween(begin: 0.06, end: 0.14)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _pulse,
        builder: (_, __) => Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.2,
              colors: [
                const Color(0xFF4FC3F7).withValues(alpha: _pulse.value),
                const Color(0xFF00BCD4).withValues(alpha: _pulse.value * 0.4),
                Colors.transparent,
              ],
            ),
          ),
          child: Stack(
            children: [
              const Positioned(top: 12, right: 16,
                child: _IceCrystal(size: 36, opacity: 0.35)),
              const Positioned(top: 12, left: 16,
                child: _IceCrystal(size: 28, opacity: 0.28)),
              const Positioned(bottom: 16, left: 20,
                child: _IceCrystal(size: 32, opacity: 0.3)),
              const Positioned(bottom: 16, right: 20,
                child: _IceCrystal(size: 24, opacity: 0.25)),
              // Countdown badge
              Positioned(
                top: 10,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF4FC3F7).withValues(alpha: 0.25),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFF4FC3F7).withValues(alpha: 0.6),
                        width: 1.5,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('❄️', style: TextStyle(fontSize: 16)),
                        const SizedBox(width: 6),
                        Text(
                          '${widget.countdown}s',
                          style: const TextStyle(
                            color: Color(0xFF4FC3F7),
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _IceCrystal extends StatelessWidget {
  final double size;
  final double opacity;
  const _IceCrystal({required this.size, required this.opacity});

  @override
  Widget build(BuildContext context) => Opacity(
        opacity: opacity,
        child: Text('❄️', style: TextStyle(fontSize: size)),
      );
}

// ─────────────────────────────────────────────
//  Powerup Selection Banner
// ─────────────────────────────────────────────

class _PowerupSelectionBanner extends StatefulWidget {
  final PowerupType powerup;
  final GameThemeData theme;
  final VoidCallback onCancel;

  const _PowerupSelectionBanner({
    required this.powerup,
    required this.theme,
    required this.onCancel,
  });

  @override
  State<_PowerupSelectionBanner> createState() =>
      _PowerupSelectionBannerState();
}

class _PowerupSelectionBannerState extends State<_PowerupSelectionBanner>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _scale =
        CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  String get _hint => switch (widget.powerup) {
        PowerupType.hammer    => 'Tap a filled block to smash it',
        PowerupType.bomb      => 'Tap to blast a 3×3 area',
        PowerupType.lightning => 'Tap to clear the row & column',
        _                     => 'Tap to use powerup',
      };

  String get _emoji => switch (widget.powerup) {
        PowerupType.hammer    => '🔨',
        PowerupType.bomb      => '💣',
        PowerupType.lightning => '⚡',
        _                     => '✨',
      };

  @override
  Widget build(BuildContext context) {
    final colors = widget.theme.colors;
    return Positioned(
      top: 8,
      left: 16,
      right: 16,
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                colors.glowColor.withValues(alpha: 0.92),
                colors.buttonPrimary.withValues(alpha: 0.88),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: colors.glowColor.withValues(alpha: 0.4),
                blurRadius: 14,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_emoji, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _hint,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: widget.onCancel,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close_rounded,
                      color: Colors.white, size: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Full 7-Powerup HUD
// ─────────────────────────────────────────────

class _PowerupHUD extends StatelessWidget {
  final GameThemeData theme;
  final Inventory? inventory;
  final PowerupType? activePowerup;
  final bool comboBoosterActive;
  final int comboBoosterCountdown;
  final bool freezeActive;
  final VoidCallback onHammer;
  final VoidCallback onBomb;
  final VoidCallback onLightning;
  final VoidCallback onShuffle;
  final VoidCallback onFreezeTime;
  final VoidCallback onRainbow;
  final VoidCallback onComboBooster;

  const _PowerupHUD({
    required this.theme,
    required this.inventory,
    required this.activePowerup,
    required this.comboBoosterActive,
    required this.comboBoosterCountdown,
    required this.freezeActive,
    required this.onHammer,
    required this.onBomb,
    required this.onLightning,
    required this.onShuffle,
    required this.onFreezeTime,
    required this.onRainbow,
    required this.onComboBooster,
  });

  @override
  Widget build(BuildContext context) {
    final colors = theme.colors;
    final inv = inventory;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
        decoration: BoxDecoration(
          color: colors.panelBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: colors.panelBorder.withValues(alpha: 0.4)),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withValues(alpha: 0.08),
              blurRadius: 12,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _PowerupButton(
              emoji: '🔨',
              label: 'Hammer',
              count: inv?.hammers ?? 0,
              colors: colors,
              isActive: activePowerup == PowerupType.hammer,
              onTap: onHammer,
            ),
            _PowerupButton(
              emoji: '💣',
              label: 'Bomb',
              count: inv?.bombs ?? 0,
              colors: colors,
              isActive: activePowerup == PowerupType.bomb,
              onTap: onBomb,
            ),
            _PowerupButton(
              emoji: '⚡',
              label: 'Lightning',
              count: inv?.lightnings ?? 0,
              colors: colors,
              isActive: activePowerup == PowerupType.lightning,
              onTap: onLightning,
            ),
            _PowerupButton(
              emoji: '🔀',
              label: 'Shuffle',
              count: inv?.shuffles ?? 0,
              colors: colors,
              isActive: false,
              onTap: onShuffle,
            ),
            _PowerupButton(
              emoji: '❄️',
              label: 'Freeze',
              count: inv?.freezes ?? 0,
              colors: colors,
              isActive: freezeActive,
              overrideLabel: freezeActive ? null : null,
              onTap: freezeActive ? () {} : onFreezeTime,
            ),
            _PowerupButton(
              emoji: '🌈',
              label: 'Rainbow',
              count: inv?.rainbows ?? 0,
              colors: colors,
              isActive: false,
              onTap: onRainbow,
            ),
            _PowerupButton(
              emoji: '⭐',
              label: 'Boost',
              count: inv?.comboBoosters ?? 0,
              colors: colors,
              isActive: comboBoosterActive,
              overrideLabel: comboBoosterActive
                  ? '${comboBoosterCountdown}s'
                  : null,
              onTap: comboBoosterActive ? () {} : onComboBooster,
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Powerup Button (with glow pulse animation)
// ─────────────────────────────────────────────

class _PowerupButton extends StatefulWidget {
  final String emoji;
  final String label;
  final int count;
  final GameThemeColors colors;
  final bool isActive;
  final String? overrideLabel; // shown instead of count badge when set
  final VoidCallback onTap;

  const _PowerupButton({
    required this.emoji,
    required this.label,
    required this.count,
    required this.colors,
    required this.isActive,
    required this.onTap,
    this.overrideLabel,
  });

  @override
  State<_PowerupButton> createState() => _PowerupButtonState();
}

class _PowerupButtonState extends State<_PowerupButton>
    with TickerProviderStateMixin {
  late AnimationController _pressCtrl;
  late AnimationController _glowCtrl;
  late Animation<double> _pressScale;
  late Animation<double> _glowAnim;

  @override
  void initState() {
    super.initState();
    _pressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _pressScale = Tween(begin: 1.0, end: 0.87)
        .animate(CurvedAnimation(parent: _pressCtrl, curve: Curves.easeInOut));

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);
    _glowAnim = Tween(begin: 0.10, end: 0.38)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _pressCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasStock = widget.count > 0;
    final colors   = widget.colors;
    final isActive = widget.isActive;

    // Determine glow color
    final glowCol = isActive
        ? colors.glowColor
        : hasStock
            ? colors.glowColor
            : colors.panelBorder;

    return GestureDetector(
      onTapDown: (_) => _pressCtrl.forward(),
      onTapUp: (_) {
        _pressCtrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _pressCtrl.reverse(),
      child: AnimatedBuilder(
        animation: Listenable.merge([_pressScale, _glowAnim]),
        builder: (_, __) => Transform.scale(
          scale: _pressScale.value,
          child: SizedBox(
            width: 42,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.center,
                  children: [
                    // Glow ring (active or pulsing when usable)
                    if (isActive || hasStock)
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: glowCol.withValues(alpha: 
                                isActive ? 0.55 : _glowAnim.value,
                              ),
                              blurRadius: isActive ? 16 : 10,
                              spreadRadius: isActive ? 2 : 0,
                            ),
                          ],
                        ),
                      ),

                    // Icon container
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: isActive
                            ? glowCol.withValues(alpha: 0.25)
                            : hasStock
                                ? glowCol.withValues(alpha: 0.12)
                                : colors.panelBorder.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isActive
                              ? glowCol
                              : hasStock
                                  ? glowCol.withValues(alpha: 0.45)
                                  : colors.panelBorder.withValues(alpha: 0.18),
                          width: isActive ? 1.8 : 1.2,
                        ),
                      ),
                      child: Center(
                        child: Opacity(
                          opacity: hasStock || isActive ? 1.0 : 0.3,
                          child: Text(
                            widget.emoji,
                            style: const TextStyle(fontSize: 20),
                          ),
                        ),
                      ),
                    ),

                    // Count / override badge
                    Positioned(
                      top: -5,
                      right: -5,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 1.5),
                        decoration: BoxDecoration(
                          color: isActive
                              ? glowCol
                              : hasStock
                                  ? glowCol
                                  : colors.panelBorder.withValues(alpha: 0.4),
                          borderRadius: BorderRadius.circular(7),
                          border: Border.all(
                            color: colors.panelBg,
                            width: 1.3,
                          ),
                        ),
                        child: Text(
                          widget.overrideLabel ?? '×${widget.count}',
                          style: TextStyle(
                            color: hasStock || isActive
                                ? Colors.white
                                : colors.textPrimary.withValues(alpha: 0.4),
                            fontSize: 8,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  widget.label,
                  style: TextStyle(
                    color: hasStock || isActive
                        ? colors.textPrimary.withValues(alpha: 0.8)
                        : colors.textPrimary.withValues(alpha: 0.3),
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.1,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Game Over Revive Dialog
// ─────────────────────────────────────────────

class GameOverReviveDialog extends StatefulWidget {
  final GameThemeData theme;
  final int score;
  final Inventory? inventory;
  final VoidCallback onReviveAd;
  final VoidCallback onReviveHammer;
  final VoidCallback onReviveBomb;
  final VoidCallback onRestart;

  const GameOverReviveDialog({
    super.key,
    required this.theme,
    required this.score,
    this.inventory,
    required this.onReviveAd,
    required this.onReviveHammer,
    required this.onReviveBomb,
    required this.onRestart,
  });

  @override
  State<GameOverReviveDialog> createState() => _GameOverReviveDialogState();
}

class _GameOverReviveDialogState extends State<GameOverReviveDialog>
    with TickerProviderStateMixin {
  late AnimationController _entryCtrl;
  late Animation<double> _scaleAnim;
  late AnimationController _countdownCtrl;
  int _countdown = 5;
  Timer? _countdownTimer;

  @override
  void initState() {
    super.initState();

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scaleAnim = CurvedAnimation(
      parent: _entryCtrl,
      curve: Curves.elasticOut,
    );
    _entryCtrl.forward();

    _countdownCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..forward();

    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _countdown--);
      if (_countdown <= 0) {
        t.cancel();
        widget.onRestart();
      }
    });
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _countdownCtrl.dispose();
    _countdownTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors   = widget.theme.colors;
    final inv      = widget.inventory;
    final hasHammer = (inv?.hammers ?? 0) > 0;
    final hasBomb   = (inv?.bombs ?? 0) > 0;

    return Dialog(
      backgroundColor: Colors.transparent,
      child: ScaleTransition(
        scale: _scaleAnim,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 12),
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.85,
          ),
          child: SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [colors.panelBg, colors.panelBg.withValues(alpha: 0.9)],
                ),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(
                  color: colors.panelBorder.withValues(alpha: 0.6),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: colors.glowColor.withValues(alpha: 0.3),
                    blurRadius: 40,
                    spreadRadius: 4,
                  ),
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.5),
                    blurRadius: 20,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Title
              ShaderMask(
                shaderCallback: (rect) => LinearGradient(
                  colors: [colors.textAccent, colors.glowColor],
                ).createShader(rect),
                child: const Text(
                  'Game Over',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Score: ${widget.score}',
                style: TextStyle(
                  color: colors.textAccent,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 18),

              // Countdown ring
              _CountdownRing(
                countdown: _countdown,
                colors: colors,
                controller: _countdownCtrl,
              ),
              const SizedBox(height: 4),
              Text(
                'Continue?',
                style: TextStyle(
                  color: colors.textPrimary.withValues(alpha: 0.6),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 20),

              // Watch Ad — always available
              _ReviveButton(
                icon: Icons.play_circle_fill_rounded,
                emoji: null,
                label: 'Watch Ad to Revive',
                sublabel: 'FREE  •  Continue where you left off',
                colors: colors,
                isPrimary: true,
                onTap: widget.onReviveAd,
              ),

              if (hasHammer) ...[
                const SizedBox(height: 8),
                _ReviveButton(
                  icon: null,
                  emoji: '🔨',
                  label: 'Use Hammer  ×${inv!.hammers}',
                  sublabel: 'Smash a block and revive',
                  colors: colors,
                  isPrimary: false,
                  onTap: widget.onReviveHammer,
                ),
              ],

              if (hasBomb) ...[
                const SizedBox(height: 8),
                _ReviveButton(
                  icon: null,
                  emoji: '💣',
                  label: 'Use Bomb  ×${inv!.bombs}',
                  sublabel: 'Blast an area and revive',
                  colors: colors,
                  isPrimary: false,
                  onTap: widget.onReviveBomb,
                ),
              ],

              Divider(
                color: colors.panelBorder.withValues(alpha: 0.3),
                height: 24,
              ),

              GestureDetector(
                onTap: widget.onRestart,
                child: Text(
                  'Restart',
                  style: TextStyle(
                    color: colors.textPrimary.withValues(alpha: 0.45),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
          ),
      ),
    ),
  );
  }
}

class _CountdownRing extends StatelessWidget {
  final int countdown;
  final GameThemeColors colors;
  final AnimationController controller;

  const _CountdownRing({
    required this.countdown,
    required this.colors,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 60,
      height: 60,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: controller,
            builder: (_, __) => CircularProgressIndicator(
              value: 1.0 - controller.value,
              strokeWidth: 4,
              backgroundColor: colors.panelBorder.withValues(alpha: 0.2),
              valueColor: AlwaysStoppedAnimation(colors.glowColor),
            ),
          ),
          Text(
            '$countdown',
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _ReviveButton extends StatefulWidget {
  final IconData? icon;
  final String? emoji;
  final String label;
  final String sublabel;
  final GameThemeColors colors;
  final bool isPrimary;
  final VoidCallback onTap;

  const _ReviveButton({
    required this.icon,
    required this.emoji,
    required this.label,
    required this.sublabel,
    required this.colors,
    required this.isPrimary,
    required this.onTap,
  });

  @override
  State<_ReviveButton> createState() => _ReviveButtonState();
}

class _ReviveButtonState extends State<_ReviveButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _s;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 130));
    _s = Tween(begin: 1.0, end: 0.95)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return GestureDetector(
      onTapDown: (_) => _c.forward(),
      onTapUp: (_) {
        _c.reverse();
        widget.onTap();
      },
      onTapCancel: () => _c.reverse(),
      child: AnimatedBuilder(
        animation: _s,
        builder: (_, __) => Transform.scale(
          scale: _s.value,
          child: Container(
            width: double.infinity,
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              gradient: widget.isPrimary
                  ? LinearGradient(
                      colors: [c.buttonPrimary, c.buttonSecondary])
                  : null,
              color: widget.isPrimary
                  ? null
                  : c.panelBorder.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: widget.isPrimary
                    ? c.glowColor.withValues(alpha: 0.5)
                    : c.panelBorder.withValues(alpha: 0.3),
                width: 1.5,
              ),
              boxShadow: widget.isPrimary
                  ? [
                      BoxShadow(
                        color: c.glowColor.withValues(alpha: 0.3),
                        blurRadius: 14,
                        offset: const Offset(0, 4),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              children: [
                if (widget.emoji != null)
                  Text(widget.emoji!, style: const TextStyle(fontSize: 20))
                else if (widget.icon != null)
                  Icon(widget.icon!, color: Colors.white, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.label,
                        style: TextStyle(
                          color: widget.isPrimary ? Colors.white : c.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        widget.sublabel,
                        style: TextStyle(
                          color: widget.isPrimary
                              ? Colors.white.withValues(alpha: 0.75)
                              : c.textPrimary.withValues(alpha: 0.5),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Top HUD
// ─────────────────────────────────────────────

class _TopHUD extends StatelessWidget {
  final GameThemeData theme;
  final ValueChanged<GameThemeData> onThemeChanged;

  const _TopHUD({required this.theme, required this.onThemeChanged});

  @override
  Widget build(BuildContext context) {
    final colors   = theme.colors;
    final canGoBack = Navigator.canPop(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              if (canGoBack) ...[
                _HudButton(
                  icon: Icons.arrow_back_ios_new_rounded,
                  colors: colors,
                  onTap: () => Navigator.of(context).pop(),
                ),
                const SizedBox(width: 8),
              ],
              // Theme pill
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: colors.panelBg,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: colors.panelBorder.withValues(alpha: 0.4),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: colors.glowColor,
                        boxShadow: [
                          BoxShadow(color: colors.glowColor, blurRadius: 4),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      theme.name,
                      style: TextStyle(
                        color: colors.textPrimary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          _HudButton(
            icon: Icons.settings_outlined,
            colors: colors,
            onTap: () => _showSettings(context),
          ),
        ],
      ),
    );
  }

  void _showSettings(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _SettingsSheet(
        theme: theme,
        onThemeChanged: onThemeChanged,
      ),
    );
  }
}

class _HudButton extends StatelessWidget {
  final IconData icon;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _HudButton({
    required this.icon,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: colors.panelBg,
          shape: BoxShape.circle,
          border: Border.all(
            color: colors.panelBorder.withValues(alpha: 0.4),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(color: colors.glowColor.withValues(alpha: 0.1), blurRadius: 8),
          ],
        ),
        child: Icon(icon, color: colors.textPrimary, size: 20),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Feature Nav Bar
// ─────────────────────────────────────────────

class _FeatureNavBar extends StatelessWidget {
  final GameThemeData theme;
  final Widget Function({required Widget child}) themedBackground;

  const _FeatureNavBar({
    required this.theme,
    required this.themedBackground,
  });

  void _open(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => themedBackground(child: screen),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = theme.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
        decoration: BoxDecoration(
          color: colors.panelBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: colors.panelBorder.withValues(alpha: 0.4)),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withValues(alpha: 0.08),
              blurRadius: 12,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _NavItem(
              icon: Icons.rotate_right_outlined,
              label: 'Spin',
              colors: colors,
              onTap: () => _open(context, SpinWheelScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.leaderboard_outlined,
              label: 'Ranks',
              colors: colors,
              onTap: () => _open(context, LeaderboardScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.card_giftcard_outlined,
              label: 'Daily',
              colors: colors,
              onTap: () => _open(context, DailyRewardScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.storefront_outlined,
              label: 'Store',
              colors: colors,
              onTap: () => _open(context, StoreScreen(theme: theme)),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: colors.textAccent, size: 24),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                color: colors.textPrimary.withValues(alpha: 0.75),
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Settings Sheet
// ─────────────────────────────────────────────

class _SettingsSheet extends ConsumerStatefulWidget {
  final GameThemeData theme;
  final ValueChanged<GameThemeData> onThemeChanged;

  const _SettingsSheet(
      {required this.theme, required this.onThemeChanged});

  @override
  ConsumerState<_SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends ConsumerState<_SettingsSheet>
    with SingleTickerProviderStateMixin {
  late AnimationController _sheetCtrl;
  late Animation<double> _fadeAnim;
  bool _showShareOptions = false;

  @override
  void initState() {
    super.initState();
    _sheetCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnim =
        CurvedAnimation(parent: _sheetCtrl, curve: Curves.easeOut);
    _sheetCtrl.forward();
  }

  @override
  void dispose() {
    _sheetCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors      = widget.theme.colors;
    final sound       = ref.read(soundManagerProvider);
    final screenHeight = MediaQuery.of(context).size.height;

    return AnimatedBuilder(
      animation: _fadeAnim,
      builder: (_, __) => FadeTransition(
        opacity: _fadeAnim,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.1),
            end: Offset.zero,
          ).animate(_fadeAnim),
          child: Container(
            constraints: BoxConstraints(maxHeight: screenHeight * 0.85),
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colors.panelBg,
                  colors.panelBg.withValues(alpha: 0.85),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: colors.panelBorder.withValues(alpha: 0.6),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: colors.glowColor.withValues(alpha: 0.25),
                  blurRadius: 35,
                  spreadRadius: 3,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.4),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                  spreadRadius: -5,
                ),
                BoxShadow(
                  color: Colors.white.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(-2, -2),
                  spreadRadius: -2,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [
                              colors.buttonPrimary.withValues(alpha: 0.2),
                              colors.buttonSecondary.withValues(alpha: 0.15),
                            ]),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: colors.glowColor.withValues(alpha: 0.3),
                              width: 1,
                            ),
                          ),
                          child: Icon(Icons.settings_rounded,
                              color: colors.textAccent, size: 24),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Settings',
                                style: TextStyle(
                                  color: colors.textPrimary,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              Text(
                                'Customize your experience',
                                style: TextStyle(
                                  color: colors.textPrimary.withValues(alpha: 0.5),
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: colors.panelBorder.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(Icons.close_rounded,
                                color: colors.textPrimary.withValues(alpha: 0.6),
                                size: 20),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Audio
                    _SettingsSection(
                      title: 'AUDIO',
                      icon: Icons.volume_up_rounded,
                      colors: colors,
                      children: [
                        _SettingsRow(
                          label: 'Music',
                          icon: Icons.music_note_outlined,
                          value: sound.musicEnabled,
                          colors: colors,
                          onChanged: (_) => sound.toggleMusic(),
                        ),
                        const SizedBox(height: 12),
                        _SettingsRow(
                          label: 'Sound Effects',
                          icon: Icons.volume_up_outlined,
                          value: sound.sfxEnabled,
                          colors: colors,
                          onChanged: (_) => sound.toggleSfx(),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Theme
                    _SettingsSection(
                      title: 'THEME',
                      icon: Icons.palette_rounded,
                      colors: colors,
                      children: [
                        _ThemeChips(
                          currentTheme: widget.theme,
                          colors: colors,
                          onThemeSelected: (t) {
                            widget.onThemeChanged(t);
                            Navigator.pop(context);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // More
                    _SettingsSection(
                      title: 'MORE',
                      icon: Icons.more_horiz_rounded,
                      colors: colors,
                      children: [
                        _SettingsButton(
                          icon: Icons.description_outlined,
                          label: 'Terms & Conditions',
                          colors: colors,
                          onTap: () => _showTermsDialog(context, colors),
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.privacy_tip_outlined,
                          label: 'Privacy Policy',
                          colors: colors,
                          onTap: () => _showPrivacyDialog(context, colors),
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.contact_mail_outlined,
                          label: 'Contact Us',
                          colors: colors,
                          onTap: () => _showContactDialog(context, colors),
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.share_outlined,
                          label: 'Share with Friends',
                          colors: colors,
                          onTap: () => setState(
                              () => _showShareOptions = !_showShareOptions),
                        ),
                        if (_showShareOptions) ...[
                          const SizedBox(height: 12),
                          _ShareOptions(colors: colors),
                        ],
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.star_rate_outlined,
                          label: 'Rate App',
                          colors: colors,
                          onTap: () {},
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.restore_outlined,
                          label: 'Restore Purchases',
                          colors: colors,
                          onTap: () {},
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showContactDialog(BuildContext context, GameThemeColors colors) {
    showDialog<void>(
      context: context,
      builder: (_) => _ContactDialog(colors: colors),
    );
  }

  void _showTermsDialog(BuildContext context, GameThemeColors colors) {
    showDialog<void>(
      context: context,
      builder: (_) => _LegalDialog(
        colors: colors,
        title: 'Terms & Conditions',
        icon: Icons.description_outlined,
        sections: const [
          _LegalSection('1. Acceptance of Terms',
              'By downloading, installing, or using ZenBlock Blast, you agree to comply with these terms and all applicable laws.'),
          _LegalSection('2. Usage Rules',
              'Users agree not to:\n\u2022 Modify, hack, or exploit the game\n\u2022 Use cheats, bots, or unauthorized tools\n\u2022 Copy or redistribute game assets without permission\n\u2022 Interfere with the normal operation of the game'),
          _LegalSection('3. Advertisements',
              'The game may contain advertisements including rewarded ads and interstitial ads. Rewarded ads are optional and may provide in-game benefits.'),
          _LegalSection('4. Intellectual Property',
              'All content related to ZenBlock Blast including logos, designs, graphics, gameplay elements, and audio are the property of Gmind Technologies unless otherwise stated.'),
          _LegalSection('5. Availability',
              'We may modify, suspend, or discontinue any part of the game at any time without prior notice.'),
          _LegalSection('6. Limitation of Liability',
              'ZenBlock Blast is provided on an "as is" basis. We are not responsible for data loss, device incompatibility, temporary service interruptions, or third-party advertisement content.'),
          _LegalSection('7. Changes to Terms',
              'These Terms & Conditions may be updated periodically. Continued use of the game after updates constitutes acceptance of the revised terms.'),
          _LegalSection('8. Governing Law',
              'These terms shall be governed in accordance with the laws of India.'),
          _LegalSection('9. Contact',
              'Gmind Technologies\nEmail: zenblockblast@outlook.com'),
        ],
      ),
    );
  }

  void _showPrivacyDialog(BuildContext context, GameThemeColors colors) {
    showDialog<void>(
      context: context,
      builder: (_) => _LegalDialog(
        colors: colors,
        title: 'Privacy Policy',
        icon: Icons.privacy_tip_outlined,
        sections: const [
          _LegalSection('1. Information We Collect',
              'While using ZenBlock Blast, we may collect:\n\u2022 Device type and operating system\n\u2022 Gameplay progress and in-game activity\n\u2022 Crash reports and diagnostics\n\u2022 Advertising identifiers\n\u2022 General usage analytics\n\nWe do not knowingly collect sensitive personal information such as passwords, banking information, or government identification details.'),
          _LegalSection('2. How We Use Information',
              'The collected information may be used to:\n\u2022 Improve gameplay experience\n\u2022 Maintain game performance and stability\n\u2022 Analyze user engagement\n\u2022 Deliver advertisements and rewards\n\u2022 Prevent abuse, cheating, or unauthorized activity'),
          _LegalSection('3. Advertisements & Third-Party Services',
              'ZenBlock Blast may use third-party services such as Google Play Services, Google AdMob, and analytics providers. These services may collect information per their own privacy policies.'),
          _LegalSection("4. Children's Privacy",
              'ZenBlock Blast is intended for general audiences. Children under the age of 13 should use the game under parental guidance.'),
          _LegalSection('5. Data Security',
              'We take reasonable steps to protect user information. However, no digital platform or internet transmission can be guaranteed to be completely secure.'),
          _LegalSection('6. Changes to This Policy',
              'We may update this Privacy Policy from time to time. Any changes will be reflected within the game or store listing.'),
          _LegalSection('7. Contact',
              'Gmind Technologies\nEmail: zenblockblast@outlook.com'),
        ],
      ),
    );
  }

}

// ─────────────────────────────────────────────
//  Settings helpers (reused from original)
// ─────────────────────────────────────────────

class _SettingsSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final GameThemeColors colors;
  final List<Widget> children;

  const _SettingsSection({
    required this.title,
    required this.icon,
    required this.colors,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: colors.textAccent, size: 16),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: colors.textPrimary.withValues(alpha: 0.6),
                fontSize: 11,
                letterSpacing: 1.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                colors.panelBorder.withValues(alpha: 0.15),
                colors.panelBorder.withValues(alpha: 0.08),
              ],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: colors.panelBorder.withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }
}

class _SettingsButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _SettingsButton({
    required this.icon,
    required this.label,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_SettingsButton> createState() => _SettingsButtonState();
}

class _SettingsButtonState extends State<_SettingsButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scale = Tween(begin: 1.0, end: 0.95)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: widget.colors.panelBorder.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: widget.colors.panelBorder.withValues(alpha: 0.25),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: widget.colors.glowColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(widget.icon,
                      color: widget.colors.textAccent, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    widget.label,
                    style: TextStyle(
                      color: widget.colors.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Icon(
                  Icons.chevron_right_rounded,
                  color: widget.colors.textPrimary.withValues(alpha: 0.4),
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SettingsRow extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool value;
  final GameThemeColors colors;
  final ValueChanged<bool> onChanged;

  const _SettingsRow({
    required this.label,
    required this.icon,
    required this.value,
    required this.colors,
    required this.onChanged,
  });

  @override
  State<_SettingsRow> createState() => _SettingsRowState();
}

class _SettingsRowState extends State<_SettingsRow> {
  late bool _value;

  @override
  void initState() {
    super.initState();
    _value = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    final colors = widget.colors;
    return Row(
      children: [
        Icon(widget.icon,
            color: colors.textPrimary.withValues(alpha: 0.7), size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            widget.label,
            style: TextStyle(color: colors.textPrimary, fontSize: 14),
          ),
        ),
        Switch.adaptive(
          value: _value,
          onChanged: (v) {
            setState(() => _value = v);
            widget.onChanged(v);
          },
          activeThumbColor: colors.glowColor,
        ),
      ],
    );
  }
}

class _ThemeChips extends StatelessWidget {
  final GameThemeData currentTheme;
  final GameThemeColors colors;
  final ValueChanged<GameThemeData> onThemeSelected;

  const _ThemeChips({
    required this.currentTheme,
    required this.colors,
    required this.onThemeSelected,
  });

  @override
  Widget build(BuildContext context) {
    final themes = ThemeRegistry.themes.values.toList();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: themes.map((t) {
        final isActive = t.type == currentTheme.type;
        return GestureDetector(
          onTap: () => onThemeSelected(t),
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: isActive
                  ? colors.buttonPrimary.withValues(alpha: 0.3)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isActive
                    ? colors.panelBorder
                    : colors.panelBorder.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Text(
              t.name,
              style: TextStyle(
                color: isActive
                    ? colors.textAccent
                    : colors.textPrimary.withValues(alpha: 0.5),
                fontSize: 12,
                fontWeight:
                    isActive ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ─────────────────────────────────────────────
//  Share Options
// ─────────────────────────────────────────────

class _ShareOptions extends StatefulWidget {
  final GameThemeColors colors;
  const _ShareOptions({required this.colors});

  @override
  State<_ShareOptions> createState() => _ShareOptionsState();
}

class _ShareOptionsState extends State<_ShareOptions>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, -0.2),
          end: Offset.zero,
        ).animate(_fade),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                widget.colors.buttonPrimary.withValues(alpha: 0.15),
                widget.colors.buttonSecondary.withValues(alpha: 0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: widget.colors.glowColor.withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Share via',
                style: TextStyle(
                  color: widget.colors.textPrimary.withValues(alpha: 0.6),
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _SocialButton(
                    icon: Icons.message_rounded,
                    label: 'WhatsApp',
                    color: const Color(0xFF25D366),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                  _SocialButton(
                    icon: Icons.camera_alt_rounded,
                    label: 'Instagram',
                    color: const Color(0xFFE4405F),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                  _SocialButton(
                    icon: Icons.facebook_rounded,
                    label: 'Facebook',
                    color: const Color(0xFF1877F2),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SocialButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final Color color;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _SocialButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_SocialButton> createState() => _SocialButtonState();
}

class _SocialButtonState extends State<_SocialButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scale = Tween(begin: 1.0, end: 0.9)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Column(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: widget.color,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: widget.color.withValues(alpha: 0.4),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(widget.icon, color: Colors.white, size: 24),
              ),
              const SizedBox(height: 6),
              Text(
                widget.label,
                style: TextStyle(
                  color: widget.colors.textPrimary.withValues(alpha: 0.7),
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Contact Dialog
// ─────────────────────────────────────────────

class _ContactDialog extends StatelessWidget {
  final GameThemeColors colors;
  const _ContactDialog({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 28),
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.85,
        ),
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [colors.panelBg, colors.panelBg.withValues(alpha: 0.85)],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: colors.panelBorder.withValues(alpha: 0.6),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: colors.glowColor.withValues(alpha: 0.25),
                  blurRadius: 35,
                  spreadRadius: 3,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.5),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                  spreadRadius: -5,
                ),
              ],
            ),
            child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      colors.buttonPrimary.withValues(alpha: 0.2),
                      colors.buttonSecondary.withValues(alpha: 0.15),
                    ]),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(Icons.contact_mail_rounded,
                      color: colors.textAccent, size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Contact Us',
                        style: TextStyle(
                          color: colors.textPrimary,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        'Gmind Technologies',
                        style: TextStyle(
                          color: colors.textPrimary.withValues(alpha: 0.5),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close_rounded,
                      color: colors.textPrimary.withValues(alpha: 0.5), size: 22),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _ContactOption(
              icon: Icons.business_rounded,
              label: 'Gmind Technologies',
              subtitle: 'Game Developer',
              colors: colors,
              onTap: () {},
            ),
            const SizedBox(height: 10),
            _ContactOption(
              icon: Icons.email_rounded,
              label: 'Email Us',
              subtitle: 'zenblockblast@outlook.com',
              colors: colors,
              onTap: () {},
            ),
            const SizedBox(height: 8),
          ],
          ),
          ),
        ),
      ),
    );
  }
}

class _ContactOption extends StatefulWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _ContactOption({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_ContactOption> createState() => _ContactOptionState();
}

class _ContactOptionState extends State<_ContactOption>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scale = Tween(begin: 1.0, end: 0.96)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  widget.colors.panelBorder.withValues(alpha: 0.2),
                  widget.colors.panelBorder.withValues(alpha: 0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: widget.colors.panelBorder.withValues(alpha: 0.35),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: widget.colors.glowColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(widget.icon,
                      color: widget.colors.textAccent, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.label,
                        style: TextStyle(
                          color: widget.colors.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        widget.subtitle,
                        style: TextStyle(
                          color: widget.colors.textPrimary.withValues(alpha: 0.5),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: widget.colors.textPrimary.withValues(alpha: 0.4),
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Legal Section Data
// ─────────────────────────────────────────────

class _LegalSection {
  final String heading;
  final String body;
  const _LegalSection(this.heading, this.body);
}

// ─────────────────────────────────────────────
//  Legal Dialog (Privacy Policy / Terms)
// ─────────────────────────────────────────────

class _LegalDialog extends StatelessWidget {
  final GameThemeColors colors;
  final String title;
  final IconData icon;
  final List<_LegalSection> sections;

  const _LegalDialog({
    required this.colors,
    required this.title,
    required this.icon,
    required this.sections,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        padding: const EdgeInsets.all(24),
        constraints: const BoxConstraints(maxHeight: 560),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [colors.panelBg, colors.panelBg.withValues(alpha: 0.92)],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: colors.panelBorder.withValues(alpha: 0.6),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withValues(alpha: 0.2),
              blurRadius: 30,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: colors.buttonPrimary.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: colors.textAccent, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: colors.textPrimary,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        'Gmind Technologies · Effective May 22, 2026',
                        style: TextStyle(
                          color: colors.textPrimary.withValues(alpha: 0.45),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close_rounded,
                      color: colors.textPrimary.withValues(alpha: 0.5), size: 22),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Scrollable content
            Flexible(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: sections.map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          s.heading,
                          style: TextStyle(
                            color: colors.textAccent,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.4,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          s.body,
                          style: TextStyle(
                            color: colors.textPrimary.withValues(alpha: 0.72),
                            fontSize: 12.5,
                            height: 1.6,
                          ),
                        ),
                      ],
                    ),
                  )).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}