import 'dart:math';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:equatable/equatable.dart';
import '../../../core/constants/game_constants.dart';
import '../../../core/services/sound_manager.dart';
import '../../levels/data/level_config.dart';

// ─────────────────────────────────────────────
//  Game State Model
// ─────────────────────────────────────────────

class CellState extends Equatable {
  final bool filled;
  final int colorIndex; // index into theme blockColors
  final bool clearing;  // true during clear animation

  const CellState({
    this.filled = false,
    this.colorIndex = 0,
    this.clearing = false,
  });

  CellState copyWith({bool? filled, int? colorIndex, bool? clearing}) =>
      CellState(
        filled: filled ?? this.filled,
        colorIndex: colorIndex ?? this.colorIndex,
        clearing: clearing ?? this.clearing,
      );

  @override
  List<Object?> get props => [filled, colorIndex, clearing];
}

class GameState extends Equatable {
  final List<List<CellState>> grid;       // [row][col]
  final List<BlockShape?> trayPieces;     // 3 pieces in tray
  final int score;
  final int highScore;
  final int combo;
  final bool isGameOver;
  final bool isAnimating;
  final Set<int> clearingRows;
  final Set<int> clearingCols;
  final int comboMultiplier;              // 1 = normal, 2 = boosted
  final LevelConfig? levelConfig;
  final bool isLevelComplete;

  const GameState({
    required this.grid,
    required this.trayPieces,
    this.score = 0,
    this.highScore = 0,
    this.combo = 0,
    this.isGameOver = false,
    this.isAnimating = false,
    this.clearingRows = const {},
    this.clearingCols = const {},
    this.comboMultiplier = 1,
    this.levelConfig,
    this.isLevelComplete = false,
  });

  static GameState initial({LevelConfig? levelConfig}) {
    final grid = List.generate(
      GameConstants.gridSize,
      (_) => List.generate(GameConstants.gridSize, (_) => const CellState()),
    );
    return GameState(
      grid: grid,
      trayPieces: _generateTray(
        excludeHeavyShapes: levelConfig?.excludeHeavyShapes ?? true,
      ),
      highScore: 0,
      levelConfig: levelConfig,
    );
  }

  static List<BlockShape?> _generateTray({bool excludeHeavyShapes = true}) {
    final rng = Random();
    var pool = allShapes;
    if (excludeHeavyShapes) {
      pool = pool.where((s) => s.id != 'sq3x3').toList();
    }
    return List.generate(3, (_) => pool[rng.nextInt(pool.length)]);
  }

  GameState copyWith({
    List<List<CellState>>? grid,
    List<BlockShape?>? trayPieces,
    int? score,
    int? highScore,
    int? combo,
    bool? isGameOver,
    bool? isAnimating,
    Set<int>? clearingRows,
    Set<int>? clearingCols,
    int? comboMultiplier,
    LevelConfig? levelConfig,
    bool? isLevelComplete,
    bool clearLevelConfig = false,
  }) =>
      GameState(
        grid: grid ?? this.grid,
        trayPieces: trayPieces ?? this.trayPieces,
        score: score ?? this.score,
        highScore: highScore ?? this.highScore,
        combo: combo ?? this.combo,
        isGameOver: isGameOver ?? this.isGameOver,
        isAnimating: isAnimating ?? this.isAnimating,
        clearingRows: clearingRows ?? this.clearingRows,
        clearingCols: clearingCols ?? this.clearingCols,
        comboMultiplier: comboMultiplier ?? this.comboMultiplier,
        levelConfig: clearLevelConfig ? null : (levelConfig ?? this.levelConfig),
        isLevelComplete: isLevelComplete ?? this.isLevelComplete,
      );

  @override
  List<Object?> get props => [
        grid, trayPieces, score, highScore, combo,
        isGameOver, isAnimating, clearingRows, clearingCols, comboMultiplier,
        levelConfig, isLevelComplete,
      ];
}

// ─────────────────────────────────────────────
//  Game Notifier
// ─────────────────────────────────────────────

class GameNotifier extends StateNotifier<GameState> {
  final SoundManager _sound;
  final void Function(int scoreEarned)? onScoreUpdated;

  GameNotifier(this._sound, {this.onScoreUpdated}) : super(GameState.initial());

  void startLevel(LevelConfig config) {
    state = GameState.initial(levelConfig: config)
        .copyWith(highScore: state.highScore);
  }

  void clearLevelMode() {
    state = GameState.initial().copyWith(highScore: state.highScore);
  }

  void resetGame() {
    final level = state.levelConfig;
    if (level != null) {
      startLevel(level);
      return;
    }
    state = GameState.initial().copyWith(highScore: state.highScore);
  }

  void expireLevelTimer() {
    if (state.levelConfig == null || state.isGameOver || state.isLevelComplete) {
      return;
    }
    _sound.gameOver();
    state = state.copyWith(isGameOver: true);
  }

  // ── Revive: keep board, clear game-over flag ──
  void revive() {
    if (!state.isGameOver) return;
    state = state.copyWith(isGameOver: false);
  }

  // ── Shuffle: generate fresh tray ──
  void shuffleTray() {
    if (state.isAnimating) return;
    _sound.tap();
    state = state.copyWith(
      trayPieces: GameState._generateTray(
        excludeHeavyShapes: state.levelConfig?.excludeHeavyShapes ?? true,
      ),
    );
  }

  // ── Combo Booster: double scoring ──
  void activateComboBooster() {
    state = state.copyWith(comboMultiplier: 2);
  }

  void deactivateComboBooster() {
    state = state.copyWith(comboMultiplier: 1);
  }

  // ── Can a shape be placed at (row, col)? ──
  bool canPlace(BlockShape shape, int row, int col) {
    for (final cell in shape.cells) {
      final r = row + cell[0];
      final c = col + cell[1];
      if (r < 0 || r >= GameConstants.gridSize) return false;
      if (c < 0 || c >= GameConstants.gridSize) return false;
      if (state.grid[r][c].filled) return false;
    }
    return true;
  }

  // ── Place a tray piece at grid position ──
  Future<void> placeBlock(int trayIndex, int row, int col) async {
    if (state.isGameOver || state.isLevelComplete) return;
    final piece = state.trayPieces[trayIndex];
    if (piece == null) return;
    if (!canPlace(piece, row, col)) return;
    if (state.isAnimating) return;

    _sound.placeBlock();

    // Place cells on grid
    final newGrid = _copyGrid(state.grid);
    for (final cell in piece.cells) {
      newGrid[row + cell[0]][col + cell[1]] = CellState(
        filled: true,
        colorIndex: piece.colorIndex,
      );
    }

    // Remove from tray
    final newTray = List<BlockShape?>.from(state.trayPieces);
    newTray[trayIndex] = null;

    // Score placed cells (multiplied by combo booster)
    final placedScore =
        piece.cells.length * GameConstants.pointsPerCell * state.comboMultiplier;

    state = state.copyWith(
      grid: newGrid,
      trayPieces: newTray,
      score: state.score + placedScore,
      isAnimating: true,
    );

    await _checkAndClearLines(newGrid, newTray);
  }

  // ── Hammer powerup: remove a single filled cell ──
  Future<void> applyHammer(int row, int col) async {
    if (row < 0 || row >= GameConstants.gridSize) return;
    if (col < 0 || col >= GameConstants.gridSize) return;
    if (!state.grid[row][col].filled) return;

    _sound.placeBlock();
    final newGrid = _copyGrid(state.grid);
    newGrid[row][col] = const CellState();
    const scoreEarned = GameConstants.pointsPerCell;
    final newScore = state.score + scoreEarned;
    state = state.copyWith(
      grid: newGrid,
      score: newScore,
      highScore: max(newScore, state.highScore),
    );
    _afterScoreUpdate(newGrid, state.trayPieces);
    onScoreUpdated?.call(scoreEarned);
  }

  // ── Bomb powerup: clear 3×3 area around tap ──
  Future<void> applyBomb(int row, int col) async {
    _sound.lineClear();
    final newGrid = _copyGrid(state.grid);
    int cleared = 0;
    const G = GameConstants.gridSize;
    for (int r = row - 1; r <= row + 1; r++) {
      for (int c = col - 1; c <= col + 1; c++) {
        if (r >= 0 && r < G && c >= 0 && c < G && newGrid[r][c].filled) {
          newGrid[r][c] = const CellState();
          cleared++;
        }
      }
    }
    final scoreEarned = cleared * GameConstants.pointsPerCell;
    final newScore = state.score + scoreEarned;
    state = state.copyWith(
      grid: newGrid,
      score: newScore,
      highScore: max(newScore, state.highScore),
    );
    _afterScoreUpdate(newGrid, state.trayPieces);
    onScoreUpdated?.call(scoreEarned);
  }

  // ── Lightning powerup: clear full row + full column (cross) ──
  Future<void> applyLightning(int row, int col) async {
    _sound.lineClear();
    _sound.combo();
    final newGrid = _copyGrid(state.grid);
    int cleared = 0;
    const G = GameConstants.gridSize;
    // Clear entire row
    for (int c = 0; c < G; c++) {
      if (newGrid[row][c].filled) {
        newGrid[row][c] = const CellState();
        cleared++;
      }
    }
    // Clear entire column (skip row already cleared)
    for (int r = 0; r < G; r++) {
      if (r != row && newGrid[r][col].filled) {
        newGrid[r][col] = const CellState();
        cleared++;
      }
    }
    // Cross clear = 2-line bonus
    const bonus = GameConstants.pointsPerLine * 2;
    final scoreEarned = cleared * GameConstants.pointsPerCell + bonus;
    final newScore = state.score + scoreEarned;
    state = state.copyWith(
      grid: newGrid,
      score: newScore,
      highScore: max(newScore, state.highScore),
    );
    _afterScoreUpdate(newGrid, state.trayPieces);
    onScoreUpdated?.call(scoreEarned);
  }

  Future<void> _checkAndClearLines(
      List<List<CellState>> grid, List<BlockShape?> tray) async {
    final clearRows = <int>{};
    final clearCols = <int>{};
    const G = GameConstants.gridSize;

    for (int r = 0; r < G; r++) {
      if (grid[r].every((c) => c.filled)) clearRows.add(r);
    }
    for (int c = 0; c < G; c++) {
      if (List.generate(G, (r) => grid[r][c]).every((cs) => cs.filled)) {
        clearCols.add(c);
      }
    }

    if (clearRows.isEmpty && clearCols.isEmpty) {
      await _finalizeTurn(grid, tray, 0);
      return;
    }

    // Mark clearing
    final animGrid = _copyGrid(grid);
    for (final r in clearRows) {
      for (int c = 0; c < G; c++) {
        animGrid[r][c] = animGrid[r][c].copyWith(clearing: true);
      }
    }
    for (final c in clearCols) {
      for (int r = 0; r < G; r++) {
        animGrid[r][c] = animGrid[r][c].copyWith(clearing: true);
      }
    }

    state = state.copyWith(
      grid: animGrid,
      clearingRows: clearRows,
      clearingCols: clearCols,
    );

    _sound.lineClear();
    await Future.delayed(
        const Duration(milliseconds: GameConstants.lineClearDurationMs));

    // Remove cleared cells
    final clearedGrid = _copyGrid(animGrid);
    for (final r in clearRows) {
      for (int c = 0; c < G; c++) {
        clearedGrid[r][c] = const CellState();
      }
    }
    for (final c in clearCols) {
      for (int r = 0; r < G; r++) {
        clearedGrid[r][c] = const CellState();
      }
    }

    final linesCleared = clearRows.length + clearCols.length;
    // Score multiplied by combo booster
    final lineScore =
        linesCleared * GameConstants.pointsPerLine * state.comboMultiplier;
    final newCombo = state.combo + 1;
    final comboBonus = (newCombo > 1)
        ? (newCombo - 1) * GameConstants.comboMultiplierStep * state.comboMultiplier
        : 0;

    if (newCombo > 1) _sound.combo();

    await _finalizeTurn(clearedGrid, tray, lineScore + comboBonus, combo: newCombo);
  }

  Future<void> _finalizeTurn(
    List<List<CellState>> grid,
    List<BlockShape?> tray,
    int bonusScore, {
    int combo = 0,
  }) async {
    // Refill tray if all used
    final newTray = tray.every((p) => p == null)
        ? GameState._generateTray(
            excludeHeavyShapes: state.levelConfig?.excludeHeavyShapes ?? true,
          )
        : List<BlockShape?>.from(tray);

    final newScore = state.score + bonusScore;
    final newHigh = max(newScore, state.highScore);

    state = state.copyWith(
      grid: grid,
      trayPieces: newTray,
      score: newScore,
      highScore: newHigh,
      combo: combo,
      clearingRows: {},
      clearingCols: {},
      isAnimating: false,
    );

    // Notify score update for coin conversion
    onScoreUpdated?.call(bonusScore);

    _afterScoreUpdate(grid, newTray);
  }

  void _afterScoreUpdate(List<List<CellState>> grid, List<BlockShape?> tray) {
    if (_checkLevelWin(state.score)) return;
    if (_isGameOver(grid, tray)) {
      _sound.gameOver();
      state = state.copyWith(isGameOver: true);
    }
  }

  bool _checkLevelWin(int score) {
    final level = state.levelConfig;
    if (level == null || state.isLevelComplete) return false;
    if (score >= level.scoreGoal) {
      state = state.copyWith(isLevelComplete: true, isAnimating: false);
      return true;
    }
    return false;
  }

  bool _isGameOver(List<List<CellState>> grid, List<BlockShape?> tray) {
    const G = GameConstants.gridSize;
    for (final piece in tray) {
      if (piece == null) continue;
      for (int r = 0; r < G; r++) {
        for (int c = 0; c < G; c++) {
          if (canPlaceOnGrid(piece, r, c, grid)) return false;
        }
      }
    }
    return true;
  }

  bool canPlaceOnGrid(
      BlockShape shape, int row, int col, List<List<CellState>> grid) {
    const G = GameConstants.gridSize;
    for (final cell in shape.cells) {
      final r = row + cell[0];
      final c = col + cell[1];
      if (r < 0 || r >= G || c < 0 || c >= G) return false;
      if (grid[r][c].filled) return false;
    }
    return true;
  }

  List<List<CellState>> _copyGrid(List<List<CellState>> src) =>
      src.map((row) => List<CellState>.from(row)).toList();
}

final gameProvider = StateNotifierProvider<GameNotifier, GameState>((ref) {
  final sound = ref.read(soundManagerProvider);
  return GameNotifier(sound, onScoreUpdated: null);
});
