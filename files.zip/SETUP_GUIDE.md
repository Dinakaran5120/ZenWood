# ZenWood: Complete Setup & Deployment Guide

---

## 1. Firebase Setup (5 minutes)

```bash
# Install Firebase CLI
npm install -g firebase-tools
firebase login

# Create project at console.firebase.google.com
# Then:
firebase init

# Select: Firestore, Functions, Authentication, Remote Config
# Choose your project
# TypeScript for functions

# Deploy rules + functions
firebase deploy --only firestore:rules
firebase deploy --only functions
```

### Enable Authentication Providers
1. Firebase Console → Authentication → Sign-in method
2. Enable: **Google** and **Email/Password**
3. Add your app's SHA-1 (for Google Sign-In): `keytool -list -v -keystore ~/.android/debug.keystore`

### Add google-services.json
1. Firebase Console → Project Settings → Your Apps → Android
2. Register package: `com.yourcompany.zenwood`
3. Download `google-services.json` → place in `android/app/`

---

## 2. AdMob Setup

1. Go to [admob.google.com](https://admob.google.com)
2. Create app → Android → ZenWood
3. Create 3 ad units:
   - Banner (`ca-app-pub-XXXX/banner_id`)
   - Interstitial (`ca-app-pub-XXXX/interstitial_id`)
   - Rewarded (`ca-app-pub-XXXX/rewarded_id`)
4. Link AdMob to Google Play Console

### Add App ID to AndroidManifest.xml
```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-XXXXXXXXXXXXXXXX~AAAAAAAAAA"/>
```

### Build with real IDs
```bash
flutter build appbundle --release \
  --dart-define=ADMOB_BANNER_ID=ca-app-pub-XXX/yyy \
  --dart-define=ADMOB_INTERSTITIAL_ID=ca-app-pub-XXX/zzz \
  --dart-define=ADMOB_REWARDED_ID=ca-app-pub-XXX/www
```

---

## 3. RevenueCat (Subscriptions)

```bash
# Add to pubspec.yaml (already included)
flutter pub get
```

1. Create account at [revenuecat.com](https://revenuecat.com)
2. Create new app → Android
3. Connect to Google Play Console
4. Create **Entitlements**: `premium`, `no_ads`
5. Create **Products** in Play Console first, then import to RevenueCat
6. Add your API key:

```dart
// In main.dart
await Purchases.configure(PurchasesConfiguration('<your_revenuecat_api_key>'));
```

---

## 4. Google Play Store Submission

### Step 1: Generate Keystore
```bash
keytool -genkey -v \
  -keystore zenwood-release.jks \
  -keyalg RSA -keysize 2048 \
  -validity 10000 \
  -alias zenwood-key

# Store safely — losing it = can't update your app!
```

### Step 2: Create key.properties (NEVER commit this)
```
storePassword=<your_store_password>
keyPassword=<your_key_password>
keyAlias=zenwood-key
storeFile=<absolute_path_to_zenwood-release.jks>
```
Add to `.gitignore`:
```
android/key.properties
android/app/zenwood-release.jks
```

### Step 3: Build Release AAB
```bash
flutter build appbundle --release \
  --obfuscate \
  --split-debug-info=build/symbols \
  --dart-define=ADMOB_BANNER_ID=... \
  --dart-define=ADMOB_INTERSTITIAL_ID=... \
  --dart-define=ADMOB_REWARDED_ID=...
```
Output: `build/app/outputs/bundle/release/app-release.aab`

### Step 4: Play Console Checklist

| Item | Status |
|---|---|
| ☐ Upload AAB (not APK) | |
| ☐ Internal testing track first | |
| ☐ Content rating questionnaire completed | |
| ☐ Target audience: 13+ (or 3+) | |
| ☐ Data Safety form completed | |
| ☐ Privacy policy URL added | |
| ☐ Short description (80 chars) | |
| ☐ Full description | |
| ☐ Screenshots: Phone, 7" tablet, 10" tablet | |
| ☐ Feature graphic (1024×500) | |
| ☐ App icon (512×512 PNG, no alpha) | |
| ☐ AdMob linked | |
| ☐ Merchant account for IAP | |
| ☐ IAP products created in Play Console | |
| ☐ Upload debug symbols ZIP (from build/symbols) | |

---

## 5. Data Safety Form Answers

| Category | Answer |
|---|---|
| Location | No |
| Personal info (name/email) | Yes — collected via Google Sign-In |
| Financial info | Yes — via IAP |
| App activity (game progress) | Yes |
| Data shared with 3rd parties | Yes — AdMob (advertising) |
| Data encrypted in transit | Yes (Firebase/HTTPS) |
| Users can request deletion | Yes (account deletion) |

---

## 6. Security Checklist

```
☐ No API keys in source code (use --dart-define or environment)
☐ google-services.json NOT in git (or use secrets in CI/CD)
☐ key.properties NOT in git
☐ Firestore security rules deployed (not "allow all")
☐ Firebase App Check enabled
☐ Firebase Crashlytics enabled
☐ All scores validated server-side (Cloud Functions)
☐ Purchase tokens validated server-side
☐ ProGuard + obfuscation enabled in release build
☐ HTTPS-only API calls
☐ No sensitive logs in release build
☐ Rate limiting on Cloud Functions (via Firebase)
```

---

## 7. Build Commands Reference

```bash
# Debug run
flutter run

# Release build (AAB for Play Store)
flutter build appbundle --release --obfuscate --split-debug-info=build/symbols

# Release APK (for direct device testing)
flutter build apk --release

# Run tests
flutter test

# Analyze code
flutter analyze

# Deploy Cloud Functions
cd functions && npm run build && firebase deploy --only functions

# Deploy Firestore rules
firebase deploy --only firestore:rules

# Deploy all Firebase
firebase deploy
```

---

## 8. Monetization Revenue Breakdown

| Stream | Type | Estimated Revenue |
|---|---|---|
| AdMob Banner | CPM $0.5–2 | Low (filler) |
| AdMob Interstitial | CPM $5–15 | **Primary ad revenue** |
| AdMob Rewarded | CPM $10–30 | **Highest CPM** |
| Remove Ads IAP | $2.99 one-time | Good LTV |
| Coin Pack Small | $0.99 | Impulse buy |
| Coin Pack Medium | $2.99 | Mid-tier |
| Coin Pack Large | $9.99 | Whale segment |
| Premium Monthly | $4.99/mo | **Recurring revenue** |

**RevenueCat** handles all subscription state management, expiry, and grace periods automatically across Android + iOS.

---

## 9. Admin Dashboard Access

The admin dashboard (Next.js) reads from Firebase:
- Collection `users` — user list, revenue indicators
- Collection `suspicious_activity` — cheat detection
- Remote Config — toggle ads, control reward values

```bash
cd admin
npm install
npm run dev

# Deploy to Firebase Hosting
firebase deploy --only hosting
```

---

## 10. Folder Structure Quick Reference

```
lib/
├── main.dart                     ← Entry point, Firebase init
├── firebase_options.dart         ← Generated by FlutterFire CLI
├── core/
│   ├── constants/
│   │   ├── app_colors.dart       ← All colors + gradients
│   │   └── app_text_styles.dart  ← All text styles
│   ├── theme/app_theme.dart      ← MaterialApp theme + dimensions
│   ├── router/app_router.dart    ← GoRouter navigation
│   └── utils/
│       ├── haptic_utils.dart     ← Haptic feedback wrapper
│       └── analytics_utils.dart  ← Firebase Analytics wrapper
├── domain/
│   ├── models/
│   │   ├── block_model.dart      ← All block shapes
│   │   ├── board_model.dart      ← 8x8 grid + game logic
│   │   └── game_state_model.dart ← Full game state
│   └── use_cases/game/
│       └── calculate_score_use_case.dart
├── data/local/
│   └── game_local_dao.dart       ← SharedPreferences (score, settings)
├── services/
│   ├── ads/admob_service.dart    ← Banner/Interstitial/Rewarded
│   └── audio/audio_service.dart ← SFX + music with just_audio
├── presentation/
│   ├── splash/splash_screen.dart ← Loading screen with progress bar
│   ├── home/home_screen.dart     ← Main menu
│   ├── game/
│   │   ├── game_screen.dart      ← Board + tray + overlays
│   │   └── game_controller.dart  ← Riverpod game state notifier
│   ├── leaderboard/leaderboard_screen.dart
│   └── settings/settings_screen.dart
└── widgets/
    ├── wood_button.dart          ← Animated press button
    ├── wood_toggle.dart          ← Green toggle + segmented control
    └── wood_background.dart      ← Wood texture + leaf decorations
```
