import 'package:flame_audio/flame_audio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/game_constants.dart';

// ─────────────────────────────────────────────
//  SoundManager — centralized audio with persistence
//  Wraps flame_audio for low-latency SFX + BGM.
// ─────────────────────────────────────────────

class SoundManager {
  bool _sfxEnabled   = true;
  bool _musicEnabled = true;
  String? _currentMusic;
  String? _lastMusicFile;   // tracks the last requested file regardless of enabled state
  bool _initialized  = false;

  // SFX file constants — centralised to avoid string typos.
  static const _sfxPlaceBlock   = 'place_block.mp3';
  static const _sfxLineClear    = 'line_clear.mp3';
  static const _sfxCombo        = 'combo.mp3';
  static const _sfxGameOver     = 'game_over.mp3';
  static const _sfxTap          = 'tap.mp3';
  static const _sfxLevelComplete = 'level_complete.mp3';

  Future<void> preload() async {
    if (_initialized) return;

    final prefs = await SharedPreferences.getInstance();
    _sfxEnabled   = prefs.getBool('sfx_enabled')   ?? true;
    _musicEnabled = prefs.getBool('music_enabled')  ?? true;

    // Pre-warm the audio cache; missing files are skipped gracefully.
    final sfxFiles = [
      _sfxPlaceBlock,
      _sfxLineClear,
      _sfxCombo,
      _sfxGameOver,
      _sfxTap,
      _sfxLevelComplete,
    ];
    try {
      await FlameAudio.audioCache.loadAll(sfxFiles);
    } catch (_) {
      // Individual files may be missing in dev; playback will still attempt.
    }

    _initialized = true;
  }

  // ── Music ─────────────────────────────────

  Future<void> playMusic(String file) async {
    _lastMusicFile = file;           // always remember what was requested
    if (!_musicEnabled) return;
    if (_currentMusic == file) return;
    try {
      await FlameAudio.bgm.stop();
      await FlameAudio.bgm.play(file, volume: GameConstants.musicVolume);
      _currentMusic = file;
    } catch (_) {}
  }

  Future<void> stopMusic() async {
    try {
      await FlameAudio.bgm.stop();
    } catch (_) {}
    _currentMusic = null;
  }

  // ── SFX ───────────────────────────────────

  void playSfx(String file) {
    if (!_sfxEnabled) return;
    try {
      FlameAudio.play(file, volume: GameConstants.sfxVolume);
    } catch (_) {}
  }

  // Named SFX helpers — one call site per event type.
  void placeBlock()   => playSfx(_sfxPlaceBlock);
  void lineClear()    => playSfx(_sfxLineClear);
  void combo()        => playSfx(_sfxCombo);
  void gameOver()     => playSfx(_sfxGameOver);
  void tap()          => playSfx(_sfxTap);
  void buttonClick()  => playSfx(_sfxTap);           // alias for UI buttons
  void levelComplete() => playSfx(_sfxLevelComplete); // level won

  // ── Settings ─────────────────────────────

  Future<void> toggleSfx() async {
    _sfxEnabled = !_sfxEnabled;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sfx_enabled', _sfxEnabled);
  }

  Future<void> toggleMusic() async {
    _musicEnabled = !_musicEnabled;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('music_enabled', _musicEnabled);

    if (!_musicEnabled) {
      // Stop cleanly so state is unambiguous
      try { await FlameAudio.bgm.stop(); } catch (_) {}
      _currentMusic = null;
    } else {
      // Re-enable: replay the last known track.
      // bgm.resume() only works when paused; using playMusic() is reliable
      // regardless of whether bgm was paused, stopped, or never started.
      final fileToPlay = _lastMusicFile ?? _currentMusic;
      if (fileToPlay != null) {
        _currentMusic = null; // force playMusic to actually start it
        await playMusic(fileToPlay);
      }
    }
  }

  // ── Volume (future expansion) ────────────

  /// Sets SFX volume in [0.0, 1.0]. Does not persist — call per session.
  void setSfxVolume(double v) {
    // flame_audio handles volume per-play call; stored in GameConstants.
    // Override at play time if needed.
  }

  bool get sfxEnabled   => _sfxEnabled;
  bool get musicEnabled => _musicEnabled;
  bool get initialized  => _initialized;
}

final soundManagerProvider = Provider<SoundManager>((ref) => SoundManager());
