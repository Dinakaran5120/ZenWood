import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../auth/domain/auth_notifier.dart';
import '../../core/analytics/analytics_service.dart';
import '../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  Prize definitions
// ─────────────────────────────────────────────

enum SpinPrizeType { coins, bomb, theme, jackpot }

class SpinPrize {
  final String label;
  final String emoji;
  final SpinPrizeType type;
  final int value;
  final String? themeId;
  final Color color;
  final double weight;

  const SpinPrize({
    required this.label,
    required this.emoji,
    required this.type,
    required this.value,
    this.themeId,
    required this.color,
    required this.weight,
  });
}

// ─────────────────────────────────────────────
//  8-segment wheel definition
//  Even slots (0,2,4,6) = prizes
//  Odd slots  (1,3,5,7) = empty / "try again"
// ─────────────────────────────────────────────

class WheelSegment {
  final String label;
  final String emoji;
  final SpinPrize? prize; // null = no prize
  final Color color;
  final double weight;

  const WheelSegment({
    required this.label,
    required this.emoji,
    this.prize,
    required this.color,
    required this.weight,
  });
}

// Internal prize values (referenced by segments)
const _p100 = SpinPrize(
  label: '100 Coins', emoji: '🪙',
  type: SpinPrizeType.coins, value: 100,
  color: Color(0xFFFFB300), weight: 28,
);
const _p250 = SpinPrize(
  label: '250 Coins', emoji: '💎',
  type: SpinPrizeType.coins, value: 250,
  color: Color(0xFF1565C0), weight: 21,
);
const _pBomb = SpinPrize(
  label: '1 Bomb', emoji: '💣',
  type: SpinPrizeType.bomb, value: 1,
  color: Color(0xFF37474F), weight: 15,
);
const _p1000 = SpinPrize(
  label: '1000 Coins!', emoji: '🎰',
  type: SpinPrizeType.jackpot, value: 1000,
  color: Color(0xFFE65100), weight: 8,
);

// Keep for backward compat where wheelPrizes is referenced externally
const List<SpinPrize> wheelPrizes = [_p100, _p250, _pBomb, _p1000];

const List<WheelSegment> wheelSegments = [
  // slot 0 — prize
  WheelSegment(label: '100 Coins',    emoji: '🪙', prize: _p100,  color: Color(0xFFFFB300), weight: 28),
  // slot 1 — empty
  WheelSegment(label: 'No Prize',     emoji: '💨', prize: null,   color: Color(0xFF1A1F3C), weight: 7),
  // slot 2 — prize
  WheelSegment(label: '1 Bomb',       emoji: '💣', prize: _pBomb, color: Color(0xFF37474F), weight: 15),
  // slot 3 — empty
  WheelSegment(label: 'Try Again',    emoji: '🎯', prize: null,   color: Color(0xFF12172E), weight: 7),
  // slot 4 — prize
  WheelSegment(label: '250 Coins',    emoji: '💎', prize: _p250,  color: Color(0xFF1565C0), weight: 21),
  // slot 5 — empty
  WheelSegment(label: 'No Prize',     emoji: '💨', prize: null,   color: Color(0xFF1A1F3C), weight: 7),
  // slot 6 — prize (jackpot)
  WheelSegment(label: '1000 Coins!',  emoji: '🎰', prize: _p1000, color: Color(0xFFBF360C), weight: 8),
  // slot 7 — empty
  WheelSegment(label: 'Better Luck!', emoji: '🍀', prize: null,   color: Color(0xFF12172E), weight: 7),
];

// ─────────────────────────────────────────────
//  SpinWheelService
// ─────────────────────────────────────────────

class SpinWheelService {
  final FirebaseFirestore _db;
  final AnalyticsService _analytics;

  SpinWheelService({
    required FirebaseFirestore db,
    required AnalyticsService analytics,
  })  : _db = db,
        _analytics = analytics;

  Future<bool> canSpin(String uid) async {
    final snap = await _db.collection('users').doc(uid).get();
    final ts = snap.data()?['lastSpinAt'] as Timestamp?;
    if (ts == null) return true;
    return DateTime.now().difference(ts.toDate()).inHours >= 24;
  }

  Future<Duration> timeUntilNextSpin(String uid) async {
    final snap = await _db.collection('users').doc(uid).get();
    final ts = snap.data()?['lastSpinAt'] as Timestamp?;
    if (ts == null) return Duration.zero;
    final next = ts.toDate().add(const Duration(hours: 24));
    final diff = next.difference(DateTime.now());
    return diff.isNegative ? Duration.zero : diff;
  }

  /// Returns (segmentIndex, prize). prize is null for empty segments.
  (int, SpinPrize?) selectSegment() {
    final total = wheelSegments.fold(0.0, (s, seg) => s + seg.weight);
    final roll  = Random().nextDouble() * total;
    double cum  = 0;
    for (int i = 0; i < wheelSegments.length; i++) {
      cum += wheelSegments[i].weight;
      if (roll <= cum) return (i, wheelSegments[i].prize);
    }
    return (0, wheelSegments[0].prize);
  }

  Future<void> executeSpin(String uid, SpinPrize? prize) async {
    final ref = _db.collection('users').doc(uid);

    await _db.runTransaction((tx) async {
      final updates = <String, dynamic>{
        'lastSpinAt': FieldValue.serverTimestamp(),
        'spinCount': FieldValue.increment(1),
      };

      if (prize != null) {
        if (prize.type == SpinPrizeType.coins ||
            prize.type == SpinPrizeType.jackpot) {
          updates['coins'] = FieldValue.increment(prize.value);
        } else if (prize.type == SpinPrizeType.bomb) {
          updates['inventory.bombs'] = FieldValue.increment(prize.value);
        } else if (prize.type == SpinPrizeType.theme &&
            prize.themeId != null) {
          final snap = await tx.get(ref);
          final inv = snap.data()?['inventory'] as Map<String, dynamic>? ?? {};
          final themes = List<String>.from(inv['unlockedThemes'] ?? ['beach']);
          if (!themes.contains(prize.themeId!)) themes.add(prize.themeId!);
          updates['inventory.unlockedThemes'] = themes;
        }
      }

      tx.update(ref, updates);

      final histRef = ref.collection('spin_history').doc();
      tx.set(histRef, {
        'prize':   prize?.label ?? 'No Prize',
        'type':    prize?.type.name ?? 'empty',
        'value':   prize?.value ?? 0,
        'spunAt':  FieldValue.serverTimestamp(),
      });
    });

    await _analytics.logSpinWheel(
      rewardType: prize?.type.name ?? 'empty',
      value: prize?.value ?? 0,
    );
  }
}

// ─────────────────────────────────────────────
//  State + Notifier
// ─────────────────────────────────────────────

enum SpinStatus { idle, spinning, result, cooldown }

class SpinWheelState {
  final SpinStatus status;
  final SpinPrize? lastPrize;   // null after a no-prize spin
  final bool spinCompleted;     // true once a spin has landed (even no-prize)
  final bool canSpin;
  final Duration? timeUntilNext;
  final double targetAngle;

  const SpinWheelState({
    this.status = SpinStatus.idle,
    this.lastPrize,
    this.spinCompleted = false,
    this.canSpin = true,
    this.timeUntilNext,
    this.targetAngle = 0,
  });

  SpinWheelState copyWith({
    SpinStatus? status,
    SpinPrize? lastPrize,
    bool? spinCompleted,
    bool? canSpin,
    Duration? timeUntilNext,
    double? targetAngle,
    bool clearPrize = false,
  }) =>
      SpinWheelState(
        status:         status         ?? this.status,
        lastPrize:      clearPrize ? null : (lastPrize ?? this.lastPrize),
        spinCompleted:  spinCompleted  ?? this.spinCompleted,
        canSpin:        canSpin        ?? this.canSpin,
        timeUntilNext:  timeUntilNext  ?? this.timeUntilNext,
        targetAngle:    targetAngle    ?? this.targetAngle,
      );
}

class SpinWheelNotifier extends StateNotifier<SpinWheelState> {
  final SpinWheelService _service;
  final String? _uid;

  SpinWheelNotifier(this._service, this._uid) : super(const SpinWheelState()) {
    _checkCanSpin();
  }

  Future<void> _checkCanSpin() async {
    if (_uid == null) return;
    final can = await _service.canSpin(_uid);
    Duration? until;
    if (!can) until = await _service.timeUntilNextSpin(_uid);
    state = state.copyWith(
      canSpin: can,
      status: can ? SpinStatus.idle : SpinStatus.cooldown,
      timeUntilNext: until,
    );
  }

  void recheckSpin() => _checkCanSpin();

  /// Returns the selected prize (nullable — null = no prize segment).
  Future<(int, SpinPrize?)> spin() async {
    if (!state.canSpin || _uid == null) return (-1, null);
    if (state.status == SpinStatus.spinning) return (-1, null);

    final (segIdx, prize) = _service.selectSegment();

    // Calculate landing angle for this segment index
    const segCount = 8;
    const sliceAngle = (pi * 2) / segCount;
    final spins = 5 + Random().nextInt(3);
    // Spin multiple full rotations then land on the chosen segment
    final targetAngle = spins * pi * 2 +
        (segCount - segIdx) * sliceAngle -
        sliceAngle / 2;

    state = state.copyWith(
      status:      SpinStatus.spinning,
      targetAngle: targetAngle,
    );

    await _service.executeSpin(_uid, prize);
    return (segIdx, prize);
  }

  void onSpinComplete(SpinPrize? prize) {
    state = state.copyWith(
      status:        SpinStatus.result,
      lastPrize:     prize,
      spinCompleted: true,
      canSpin:       false,
    );
  }

  void dismissResult() {
    state = state.copyWith(
      status:     SpinStatus.cooldown,
      clearPrize: true,
    );
    _checkCanSpin();
  }
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final spinWheelServiceProvider = Provider<SpinWheelService>((ref) =>
    SpinWheelService(
      db:        FirebaseFirestore.instance,
      analytics: ref.read(analyticsServiceProvider),
    ));

final spinWheelProvider =
    StateNotifierProvider<SpinWheelNotifier, SpinWheelState>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  return SpinWheelNotifier(ref.read(spinWheelServiceProvider), uid);
});

// ─────────────────────────────────────────────
//  Spin Wheel Screen
// ─────────────────────────────────────────────

class SpinWheelScreen extends ConsumerStatefulWidget {
  final GameThemeData theme;
  const SpinWheelScreen({super.key, required this.theme});

  @override
  ConsumerState<SpinWheelScreen> createState() => _SpinWheelScreenState();
}

class _SpinWheelScreenState extends ConsumerState<SpinWheelScreen>
    with TickerProviderStateMixin {
  late AnimationController _spinCtrl;
  late AnimationController _resultCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _bgPulseCtrl;
  late Animation<double> _spinAnim;
  late Animation<double> _resultScale;
  late Animation<double> _bgPulse;

  // Track pending prize across async gap
  SpinPrize? _pendingPrize;
  bool _pendingSet = false;
  double _currentAngle = 0;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4500),
    );
    _resultCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _bgPulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);

    _resultScale = CurvedAnimation(
      parent: _resultCtrl,
      curve: Curves.elasticOut,
    );
    _bgPulse = CurvedAnimation(parent: _bgPulseCtrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    _resultCtrl.dispose();
    _glowCtrl.dispose();
    _bgPulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _triggerSpin() async {
    final notifier = ref.read(spinWheelProvider.notifier);
    final (_, prize) = await notifier.spin();

    _pendingPrize = prize;
    _pendingSet   = true;

    final st = ref.read(spinWheelProvider);

    _spinAnim = Tween<double>(
      begin: _currentAngle,
      end:   _currentAngle + st.targetAngle,
    ).animate(CurvedAnimation(
      parent: _spinCtrl,
      curve:  const _SpinCurve(),
    ));

    _spinCtrl.reset();
    _spinCtrl.forward().then((_) {
      _currentAngle = _spinAnim.value % (pi * 2);
      if (_pendingSet) {
        notifier.onSpinComplete(_pendingPrize);
        _pendingSet = false;
        _resultCtrl.forward(from: 0);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final wheelState = ref.watch(spinWheelProvider);
    final colors     = widget.theme.colors;
    final size       = MediaQuery.of(context).size;

    // Wheel diameter: 94% of screen width, max 400px
    final wheelDiameter = (size.width * 0.94).clamp(0.0, 400.0);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Stack(
          children: [
            // Animated background pulse
            AnimatedBuilder(
              animation: _bgPulse,
              builder: (_, __) => Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: const Alignment(0, -0.3),
                      radius: 1.3,
                      colors: [
                        colors.glowColor.withValues(
                            alpha: 0.04 + _bgPulse.value * 0.04),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),

            Column(
              children: [
                _WheelHeader(colors: colors),
                const Spacer(),

                // ── Wheel + glow ────────────────
                AnimatedBuilder(
                  animation: Listenable.merge([_spinCtrl, _glowCtrl]),
                  builder: (_, __) {
                    final angle = _spinCtrl.isAnimating
                        ? _spinAnim.value
                        : _currentAngle;

                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Prize label hint row
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _SegmentHints(colors: colors),
                        ),

                        Stack(
                          alignment: Alignment.center,
                          children: [
                            // Outer animated glow ring
                            Container(
                              width:  wheelDiameter + 20 + _glowCtrl.value * 16,
                              height: wheelDiameter + 20 + _glowCtrl.value * 16,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: colors.glowColor.withValues(
                                        alpha: 0.18 + _glowCtrl.value * 0.18),
                                    blurRadius: 40 + _glowCtrl.value * 25,
                                    spreadRadius: 6,
                                  ),
                                  BoxShadow(
                                    color: const Color(0xFFBF40FF).withValues(
                                        alpha: 0.1 + _glowCtrl.value * 0.1),
                                    blurRadius: 60,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                            ),

                            // Decorative tick marks ring
                            CustomPaint(
                              size: Size(wheelDiameter + 18, wheelDiameter + 18),
                              painter: _TickRingPainter(
                                  glowColor: colors.glowColor),
                            ),

                            // Spinning wheel
                            Transform.rotate(
                              angle: angle,
                              child: CustomPaint(
                                size: Size(wheelDiameter, wheelDiameter),
                                painter: const _WheelPainter(),
                              ),
                            ),

                            // Center hub
                            _CenterHub(colors: colors, isSpinning: _spinCtrl.isAnimating),

                            // Pointer arrow (top, fixed)
                            Positioned(
                              top: 4,
                              child: CustomPaint(
                                size: const Size(28, 36),
                                painter: _PointerPainter(color: colors.glowColor),
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                ),

                const Spacer(),

                // Spin button / cooldown
                Padding(
                  padding: const EdgeInsets.fromLTRB(28, 0, 28, 36),
                  child: wheelState.status == SpinStatus.cooldown
                      ? _CooldownTimer(
                          duration: wheelState.timeUntilNext ?? Duration.zero,
                          colors: colors,
                          onExpired: () =>
                              ref.read(spinWheelProvider.notifier).recheckSpin(),
                        )
                      : _SpinButton(
                          colors: colors,
                          enabled: wheelState.canSpin &&
                              wheelState.status != SpinStatus.spinning,
                          onSpin: _triggerSpin,
                        ),
                ),
              ],
            ),

            // Result popup (prize or no prize)
            if (wheelState.status == SpinStatus.result)
              _PrizePopup(
                prize:     wheelState.lastPrize,
                colors:    colors,
                scale:     _resultScale,
                onDismiss: () {
                  ref.read(spinWheelProvider.notifier).dismissResult();
                  _resultCtrl.reset();
                },
              ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Segment hint row (small legend below header)
// ─────────────────────────────────────────────

class _SegmentHints extends StatelessWidget {
  final GameThemeColors colors;
  const _SegmentHints({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _hint('🪙', '100', colors),
        _hint('💎', '250', colors),
        _hint('💣', 'Bomb', colors),
        _hint('🎰', 'x1000', colors),
      ],
    );
  }

  Widget _hint(String emoji, String label, GameThemeColors c) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 3),
          Text(
            label,
            style: TextStyle(
              color: c.textPrimary.withValues(alpha: 0.7),
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Wheel Painter — 8 segments, text centered in
//  each quadrant, readable via hemisphere flip
// ─────────────────────────────────────────────

class _WheelPainter extends CustomPainter {
  const _WheelPainter();

  static const _segCount  = 8;
  static const _sliceAngle = (pi * 2) / _segCount; // 45° per segment

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // ── 1. Draw filled arcs ──────────────────
    for (int i = 0; i < _segCount; i++) {
      final seg   = wheelSegments[i];
      final start = i * _sliceAngle - pi / 2;

      // Base fill
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        start, _sliceAngle, true,
        Paint()..color = seg.color..style = PaintingStyle.fill,
      );

      // Radial highlight band on outer third
      final highlightPaint = Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 1,
          colors: [
            Colors.transparent,
            Colors.white.withValues(alpha: seg.prize != null ? 0.13 : 0.04),
          ],
          stops: const [0.55, 1.0],
        ).createShader(Rect.fromCircle(center: center, radius: radius));
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        start, _sliceAngle, true,
        highlightPaint,
      );
    }

    // ── 2. Divider lines between segments ────
    final divPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.35)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    for (int i = 0; i < _segCount; i++) {
      final angle = i * _sliceAngle - pi / 2;
      canvas.drawLine(
        center,
        Offset(
          center.dx + radius * cos(angle),
          center.dy + radius * sin(angle),
        ),
        divPaint,
      );
    }

    // ── 3. Outer ring ────────────────────────
    canvas.drawCircle(
      center,
      radius - 1,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.4)
        ..strokeWidth = 3
        ..style = PaintingStyle.stroke,
    );

    // Inner decorative ring
    canvas.drawCircle(
      center,
      radius * 0.22,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.15)
        ..strokeWidth = 1
        ..style = PaintingStyle.stroke,
    );

    // ── 4. Text in each segment ──────────────
    final tp = TextPainter(textDirection: TextDirection.ltr);
    for (int i = 0; i < _segCount; i++) {
      _paintSegmentText(canvas, size, i, tp);
    }
  }

  void _paintSegmentText(
      Canvas canvas, Size size, int i, TextPainter tp) {
    final seg    = wheelSegments[i];
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final midAngle = i * _sliceAngle - pi / 2 + _sliceAngle / 2;

    // Determine if this segment is in the left hemisphere — if so, flip 180°
    // so text reads from inside outward on both halves of the wheel.
    final normAngle = (midAngle % (2 * pi) + 2 * pi) % (2 * pi);
    final needsFlip = normAngle > pi / 2 && normAngle < 3 * pi / 2;

    // Direction multiplier: after flip, positive x still needs to go "outward"
    final dir = needsFlip ? -1.0 : 1.0;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(midAngle);
    if (needsFlip) canvas.rotate(pi);

    // ── Emoji (at ~68% of radius from center) ─
    final emojiStyle = TextStyle(
      fontSize: radius * 0.115, // scales with wheel size
    );
    tp.text = TextSpan(text: seg.emoji, style: emojiStyle);
    tp.layout();
    tp.paint(
      canvas,
      Offset(
        dir * radius * 0.68 - tp.width / 2,
        -(tp.height / 2) - radius * 0.045,
      ),
    );

    // ── Label (at ~44% of radius from center) ─
    final hasPrize = seg.prize != null;
    final labelStyle = TextStyle(
      color: hasPrize ? Colors.white : Colors.white54,
      fontSize: (radius * 0.075).clamp(9.0, 13.0),
      fontWeight: FontWeight.w800,
      letterSpacing: -0.2,
      shadows: const [Shadow(color: Colors.black87, blurRadius: 3)],
    );
    tp.text = TextSpan(text: seg.label, style: labelStyle);
    tp.layout(maxWidth: radius * 0.58);
    tp.paint(
      canvas,
      Offset(
        dir * radius * 0.44 - tp.width / 2,
        -(tp.height / 2) + radius * 0.045,
      ),
    );

    canvas.restore();
  }

  @override
  bool shouldRepaint(_WheelPainter _) => false;
}

// ─────────────────────────────────────────────
//  Tick Ring Painter — decorative notches around wheel
// ─────────────────────────────────────────────

class _TickRingPainter extends CustomPainter {
  final Color glowColor;
  const _TickRingPainter({required this.glowColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    const tickCount = 48;
    const tickStep = (pi * 2) / tickCount;

    for (int i = 0; i < tickCount; i++) {
      final angle = i * tickStep;
      final isMajor = i % 6 == 0;
      final tickLen = isMajor ? 8.0 : 4.0;
      final alpha   = isMajor ? 0.7 : 0.35;

      canvas.drawLine(
        Offset(center.dx + (r - tickLen) * cos(angle),
               center.dy + (r - tickLen) * sin(angle)),
        Offset(center.dx + r * cos(angle),
               center.dy + r * sin(angle)),
        Paint()
          ..color = glowColor.withValues(alpha: alpha)
          ..strokeWidth = isMajor ? 2.5 : 1.2
          ..strokeCap = StrokeCap.round,
      );
    }
  }

  @override
  bool shouldRepaint(_TickRingPainter o) => o.glowColor != glowColor;
}

// ─────────────────────────────────────────────
//  Center Hub
// ─────────────────────────────────────────────

class _CenterHub extends StatelessWidget {
  final GameThemeColors colors;
  final bool isSpinning;
  const _CenterHub({required this.colors, required this.isSpinning});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width:  isSpinning ? 64 : 56,
      height: isSpinning ? 64 : 56,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            colors.panelBg,
            colors.panelBg.withValues(alpha: 0.85),
          ],
        ),
        border: Border.all(
          color: colors.panelBorder.withValues(alpha: isSpinning ? 1.0 : 0.7),
          width: 3,
        ),
        boxShadow: [
          BoxShadow(
            color: colors.glowColor.withValues(alpha: isSpinning ? 0.7 : 0.4),
            blurRadius: isSpinning ? 20 : 12,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: const Center(
        child: Text('⭐', style: TextStyle(fontSize: 26)),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Pointer Painter
// ─────────────────────────────────────────────

class _PointerPainter extends CustomPainter {
  final Color color;
  const _PointerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(size.width / 2, size.height)
      ..lineTo(0, 0)
      ..lineTo(size.width, 0)
      ..close();
    canvas.drawPath(path, Paint()..color = color..style = PaintingStyle.fill);
    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
    // Drop shadow
    canvas.drawPath(
      path,
      Paint()
        ..color = color.withValues(alpha: 0.6)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
  }

  @override
  bool shouldRepaint(_) => false;
}

// ─────────────────────────────────────────────
//  Custom spin easing
// ─────────────────────────────────────────────

class _SpinCurve extends Curve {
  const _SpinCurve();

  @override
  double transformInternal(double t) {
    if (t < 0.25) return Curves.easeIn.transform(t / 0.25) * 0.25;
    return 0.25 + Curves.decelerate.transform((t - 0.25) / 0.75) * 0.75;
  }
}

// ─────────────────────────────────────────────
//  Spin Button
// ─────────────────────────────────────────────

class _SpinButton extends StatefulWidget {
  final GameThemeColors colors;
  final bool enabled;
  final VoidCallback onSpin;

  const _SpinButton({
    required this.colors,
    required this.enabled,
    required this.onSpin,
  });

  @override
  State<_SpinButton> createState() => _SpinButtonState();
}

class _SpinButtonState extends State<_SpinButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulse;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) => GestureDetector(
        onTapDown: widget.enabled ? (_) => setState(() => _pressed = true) : null,
        onTapUp: widget.enabled
            ? (_) {
                setState(() => _pressed = false);
                widget.onSpin();
              }
            : null,
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          scale: _pressed ? 0.95 : (widget.enabled ? 1.0 + _pulse.value * 0.025 : 1.0),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 20),
            decoration: BoxDecoration(
              gradient: widget.enabled
                  ? LinearGradient(
                      colors: [c.buttonPrimary, c.buttonSecondary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : LinearGradient(
                      colors: [
                        c.panelBorder.withValues(alpha: 0.2),
                        c.panelBorder.withValues(alpha: 0.1),
                      ],
                    ),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: widget.enabled
                    ? c.panelBorder.withValues(alpha: 0.8)
                    : c.panelBorder.withValues(alpha: 0.3),
                width: widget.enabled ? 1.5 : 1,
              ),
              boxShadow: widget.enabled
                  ? [
                      BoxShadow(
                        color: c.glowColor.withValues(
                            alpha: 0.4 + _pulse.value * 0.25),
                        blurRadius: 28 + _pulse.value * 12,
                        spreadRadius: 2,
                        offset: const Offset(0, 5),
                      ),
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                        spreadRadius: -3,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.15),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  widget.enabled ? '🎡' : '⏳',
                  style: const TextStyle(fontSize: 28),
                ),
                const SizedBox(width: 14),
                Text(
                  widget.enabled ? 'SPIN NOW — FREE!' : 'SPINNING...',
                  style: TextStyle(
                    color: widget.enabled
                        ? c.textPrimary
                        : c.textPrimary.withValues(alpha: 0.4),
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    shadows: widget.enabled
                        ? [
                            Shadow(
                              color: c.glowColor.withValues(alpha: 0.6),
                              blurRadius: 10,
                            ),
                          ]
                        : null,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Cooldown Timer
// ─────────────────────────────────────────────

class _CooldownTimer extends StatefulWidget {
  final Duration duration;
  final GameThemeColors colors;
  final VoidCallback? onExpired;
  const _CooldownTimer(
      {required this.duration, required this.colors, this.onExpired});

  @override
  State<_CooldownTimer> createState() => _CooldownTimerState();
}

class _CooldownTimerState extends State<_CooldownTimer> {
  late Duration _remaining;

  @override
  void initState() {
    super.initState();
    _remaining = widget.duration;
    _tick();
  }

  void _tick() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      setState(() {
        _remaining = _remaining.inSeconds > 0
            ? _remaining - const Duration(seconds: 1)
            : Duration.zero;
      });
      if (_remaining.inSeconds > 0) {
        _tick();
      } else {
        widget.onExpired?.call();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final h = _remaining.inHours.toString().padLeft(2, '0');
    final m = (_remaining.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_remaining.inSeconds % 60).toString().padLeft(2, '0');
    final c = widget.colors;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [c.panelBg, c.panelBg.withValues(alpha: 0.85)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
            color: c.panelBorder.withValues(alpha: 0.5), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Next free spin in',
            style: TextStyle(
                color: c.textPrimary.withValues(alpha: 0.5), fontSize: 15),
          ),
          const SizedBox(height: 8),
          Text(
            '$h:$m:$s',
            style: TextStyle(
              color: c.textPrimary,
              fontSize: 42,
              fontWeight: FontWeight.w800,
              fontFamily: 'monospace',
              shadows: [
                Shadow(
                    color: c.glowColor.withValues(alpha: 0.8), blurRadius: 18),
                Shadow(
                    color: c.glowColor.withValues(alpha: 0.4),
                    blurRadius: 8,
                    offset: const Offset(0, 2)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Prize Popup (handles both win and no-prize)
// ─────────────────────────────────────────────

class _PrizePopup extends StatelessWidget {
  final SpinPrize? prize; // null = no prize
  final GameThemeColors colors;
  final Animation<double> scale;
  final VoidCallback onDismiss;

  const _PrizePopup({
    required this.prize,
    required this.colors,
    required this.scale,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    final hasPrize  = prize != null;
    final accentCol = hasPrize ? prize!.color : const Color(0xFF37474F);

    return Positioned.fill(
      child: GestureDetector(
        onTap: onDismiss,
        child: Container(
          color: Colors.black.withValues(alpha: 0.75),
          child: Center(
            child: ScaleTransition(
              scale: scale,
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 36),
                padding: const EdgeInsets.all(36),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      colors.panelBg,
                      colors.panelBg.withValues(alpha: 0.88),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(32),
                  border: Border.all(
                    color: accentCol.withValues(alpha: 0.8),
                    width: 2.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accentCol.withValues(alpha: 0.55),
                      blurRadius: 55,
                      spreadRadius: 5,
                    ),
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.5),
                      blurRadius: 30,
                      offset: const Offset(0, 12),
                      spreadRadius: -5,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Big emoji
                    Text(
                      hasPrize ? prize!.emoji : '😢',
                      style: const TextStyle(fontSize: 72),
                    ),
                    const SizedBox(height: 12),

                    // YOU WON / BETTER LUCK
                    Text(
                      hasPrize ? 'YOU WON!' : 'BETTER LUCK!',
                      style: TextStyle(
                        color: hasPrize
                            ? colors.textPrimary.withValues(alpha: 0.6)
                            : Colors.white38,
                        fontSize: 16,
                        letterSpacing: 4,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),

                    // Prize name
                    Text(
                      hasPrize ? prize!.label : 'No prize this time',
                      style: TextStyle(
                        color: hasPrize ? colors.textPrimary : Colors.white54,
                        fontSize: hasPrize ? 30 : 18,
                        fontWeight: FontWeight.w800,
                        shadows: hasPrize
                            ? [
                                Shadow(
                                  color:
                                      accentCol.withValues(alpha: 0.8),
                                  blurRadius: 16,
                                ),
                              ]
                            : null,
                      ),
                    ),
                    const SizedBox(height: 28),

                    // Dismiss button
                    GestureDetector(
                      onTap: onDismiss,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 40, vertical: 14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              accentCol,
                              accentCol.withValues(alpha: 0.8),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: accentCol.withValues(alpha: 0.5),
                              blurRadius: 15,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Text(
                          hasPrize ? 'AWESOME!' : 'TRY TOMORROW',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 17,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Wheel Header
// ─────────────────────────────────────────────

class _WheelHeader extends StatelessWidget {
  final GameThemeColors colors;
  const _WheelHeader({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Icon(Icons.arrow_back_ios,
                color: colors.textPrimary, size: 22),
          ),
          const SizedBox(width: 12),
          ShaderMask(
            shaderCallback: (b) => LinearGradient(
              colors: [colors.glowColor, const Color(0xFFBF40FF)],
            ).createShader(b),
            child: Text(
              'LUCKY SPIN',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.w900,
                letterSpacing: 3,
              ),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: colors.panelBg,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: colors.panelBorder.withValues(alpha: 0.5), width: 1),
              boxShadow: [
                BoxShadow(
                    color: colors.glowColor.withValues(alpha: 0.25),
                    blurRadius: 10),
              ],
            ),
            child: const Text('🎡', style: TextStyle(fontSize: 24)),
          ),
        ],
      ),
    );
  }
}
