import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/auth_notifier.dart';
import '../../game/components/neon_background.dart';
import '../../../core/theme/game_theme.dart';
import '../../../core/widgets/app_logo.dart';

// ─────────────────────────────────────────────
//  Neon Theme Colors for Auth Screens
// ─────────────────────────────────────────────

const neonThemeColors = GameThemeColors(
  background1: Color(0xFF040D1A),
  background2: Color(0xFF0A1628),
  background3: Color(0xFF020810),
  gridBg: Color(0xFF0A1628),
  gridLine: Color(0xFF1A2F4A),
  cellEmpty: Color(0xFF0D1F3C),
  panelBg: Color(0xFF0A1628),
  panelBorder: Color(0xFF1A3F5C),
  textPrimary: Color(0xFFE8F5FF),
  textAccent: Color(0xFF00F5FF),
  particleColor1: Color(0xFF00F5FF),
  particleColor2: Color(0xFFBF40FF),
  particleColor3: Color(0xFF0DFFE4),
  glowColor: Color(0xFF00F5FF),
  blockColors: [
    Color(0xFF00F5FF),
    Color(0xFFBF40FF),
    Color(0xFF0DFFE4),
    Color(0xFF4CAF50),
    Color(0xFFFFD700),
  ],
  buttonPrimary: Color(0xFF00F5FF),
  buttonSecondary: Color(0xFFBF40FF),
);

// ─────────────────────────────────────────────
//  SignInPage
//  Neon-themed sign-in UI with Google/Email/Guest
// ─────────────────────────────────────────────

class SignInPage extends ConsumerStatefulWidget {
  const SignInPage({super.key});

  @override
  ConsumerState<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends ConsumerState<SignInPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeIn;
  late Animation<Offset> _slideUp;
  final _colors = neonThemeColors;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    _fadeIn = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _slideUp = Tween(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);

    // Listen for errors
    ref.listen<AuthState>(authNotifierProvider, (_, next) {
      if (next.errorMessage != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.errorMessage!),
            backgroundColor: Colors.red.shade800,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
        ref.read(authNotifierProvider.notifier).clearError();
      }
    });

    return Scaffold(
      backgroundColor: _colors.background1,
      body: Stack(
        children: [
          const NeonBackground(),
          SafeArea(
            child: SingleChildScrollView(
              child: FadeTransition(
                opacity: _fadeIn,
                child: SlideTransition(
                  position: _slideUp,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(height: 60),
                        // Logo
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: _colors.glowColor.withValues(alpha: 0.5),
                              width: 2,
                            ),
                            gradient: RadialGradient(
                              colors: [
                                _colors.glowColor.withValues(alpha: 0.2),
                                Colors.transparent,
                              ],
                            ),
                          ),
                          padding: const EdgeInsets.all(16),
                          child: const AppLogo(size: 60),
                        ),
                        const SizedBox(height: 24),
                        // App name
                        ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [
                              Color(0xFF00F5FF),
                              Color(0xFFBF40FF),
                              Color(0xFF00F5FF),
                            ],
                            stops: [0.0, 0.5, 1.0],
                          ).createShader(bounds),
                          child: const Text(
                            'zenBlock',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 6,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Block Blast',
                          style: TextStyle(
                            color: _colors.textPrimary.withValues(alpha: 0.6),
                            fontSize: 14,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 60),
                        // Email Register (primary CTA)
                        _SignInButton(
                          icon: '✉',
                          label: 'Create Account',
                          backgroundColor: null,
                          gradient: LinearGradient(
                            colors: [
                              _colors.buttonPrimary,
                              _colors.buttonSecondary,
                            ],
                          ),
                          textColor: Colors.white,
                          isLoading: authState.isLoading,
                          onPressed: () => _handleEmailRegister(),
                        ),
                        const SizedBox(height: 16),
                        // Guest
                        _SignInButton(
                          icon: '🎮',
                          label: 'Play as Guest',
                          backgroundColor: null,
                          borderColor: _colors.panelBorder,
                          textColor: _colors.textPrimary.withValues(alpha: 0.7),
                          isLoading: authState.isLoading,
                          onPressed: () => _handleGuestSignIn(),
                        ),
                        const SizedBox(height: 32),
                        // Already have account
                        TextButton(
                          onPressed: () => _showLoginBottomSheet(),
                          child: Text(
                            'Already have an account? Login',
                            style: TextStyle(
                              color: _colors.textAccent,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _handleEmailRegister() async {
    _showEmailAuthBottomSheet(isRegister: true);
  }

  Future<void> _handleGuestSignIn() async {
    await ref.read(authNotifierProvider.notifier).signInAnonymously();
  }

  void _showLoginBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _EmailAuthBottomSheet(isRegister: false),
    );
  }

  void _showEmailAuthBottomSheet({required bool isRegister}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _EmailAuthBottomSheet(isRegister: isRegister),
    );
  }
}

// ─────────────────────────────────────────────
//  Sign In Button
// ─────────────────────────────────────────────

class _SignInButton extends StatelessWidget {
  final String icon;
  final String label;
  final Color? backgroundColor;
  final Gradient? gradient;
  final Color? borderColor;
  final Color textColor;
  final bool isLoading;
  final VoidCallback onPressed;

  const _SignInButton({
    required this.icon,
    required this.label,
    this.backgroundColor,
    this.gradient,
    this.borderColor,
    required this.textColor,
    required this.isLoading,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor,
          foregroundColor: textColor,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: borderColor != null
                ? BorderSide(color: borderColor!, width: 1.5)
                : BorderSide.none,
          ),
        ),
        child: isLoading
            ? const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            : gradient != null
                ? ShaderMask(
                    shaderCallback: (bounds) => gradient!.createShader(bounds),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          icon,
                          style: const TextStyle(fontSize: 20),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          label,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        icon,
                        style: const TextStyle(fontSize: 20),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        label,
                        style: TextStyle(
                          color: textColor,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Email Auth Bottom Sheet
// ─────────────────────────────────────────────

class _EmailAuthBottomSheet extends ConsumerStatefulWidget {
  final bool isRegister;

  const _EmailAuthBottomSheet({required this.isRegister});

  @override
  ConsumerState<_EmailAuthBottomSheet> createState() =>
      _EmailAuthBottomSheetState();
}

class _EmailAuthBottomSheetState
    extends ConsumerState<_EmailAuthBottomSheet> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmPassCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _obscurePass = true;
  bool _obscureConfirm = true;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _confirmPassCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);
    final colors = neonThemeColors;

    return Container(
      decoration: BoxDecoration(
        color: colors.panelBg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(
            color: colors.panelBorder.withValues(alpha: 0.5),
            width: 1,
          ),
        ),
      ),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              Text(
                widget.isRegister ? 'Create Account' : 'Login',
                style: TextStyle(
                  color: colors.textPrimary,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                style: TextStyle(color: colors.textPrimary),
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(color: colors.textPrimary.withValues(alpha: 0.6)),
                  filled: true,
                  fillColor: colors.background3,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.panelBorder, width: 1),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.panelBorder, width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.glowColor, width: 2),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email';
                  }
                  if (!value.contains('@')) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passCtrl,
                obscureText: _obscurePass,
                style: TextStyle(color: colors.textPrimary),
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: TextStyle(color: colors.textPrimary.withValues(alpha: 0.6)),
                  filled: true,
                  fillColor: colors.background3,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.panelBorder),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.panelBorder),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.glowColor),
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscurePass ? Icons.visibility_off : Icons.visibility,
                      color: colors.textPrimary.withValues(alpha: 0.5),
                    ),
                    onPressed: () {
                      setState(() => _obscurePass = !_obscurePass);
                    },
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your password';
                  }
                  if (value.length < 6) {
                    return 'Password must be at least 6 characters';
                  }
                  return null;
                },
              ),
              if (widget.isRegister) ...[
                const SizedBox(height: 16),
                TextFormField(
                  controller: _confirmPassCtrl,
                  obscureText: _obscureConfirm,
                  style: TextStyle(color: colors.textPrimary),
                  decoration: InputDecoration(
                    labelText: 'Confirm Password',
                    labelStyle: TextStyle(color: colors.textPrimary.withValues(alpha: 0.6)),
                    filled: true,
                    fillColor: colors.background3,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: colors.panelBorder),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: colors.panelBorder),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: colors.glowColor),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscureConfirm ? Icons.visibility_off : Icons.visibility,
                        color: colors.textPrimary.withValues(alpha: 0.5),
                      ),
                      onPressed: () {
                        setState(() => _obscureConfirm = !_obscureConfirm);
                      },
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please confirm your password';
                    }
                    if (value != _passCtrl.text) {
                      return 'Passwords do not match';
                    }
                    return null;
                  },
                ),
              ],
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: authState.isLoading
                      ? null
                      : () => _handleSubmit(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: null,
                    foregroundColor: colors.textPrimary,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: authState.isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : ShaderMask(
                          shaderCallback: (bounds) => LinearGradient(
                            colors: [
                              colors.buttonPrimary,
                              colors.buttonSecondary,
                            ],
                          ).createShader(bounds),
                          child: Text(
                            widget.isRegister ? 'Create Account' : 'Login',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 16),
              if (!widget.isRegister)
                Center(
                  child: TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        backgroundColor: Colors.transparent,
                        builder: (_) => _EmailAuthBottomSheet(isRegister: true),
                      );
                    },
                    child: Text(
                      "Don't have an account? Register",
                      style: TextStyle(
                        color: colors.textAccent,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    final email = _emailCtrl.text.trim();
    final password = _passCtrl.text;

    if (widget.isRegister) {
      await ref.read(authNotifierProvider.notifier).createAccount(
            email: email,
            password: password,
            username: '', // Will be set in UsernameSetupPage
          );
    } else {
      await ref.read(authNotifierProvider.notifier).signInWithEmail(
            email: email,
            password: password,
          );
    }

    if (mounted) Navigator.pop(context);
  }
}
