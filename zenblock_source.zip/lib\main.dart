import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/performance/performance_optimizer.dart';
import 'core/widgets/app_logo.dart';
import 'core/services/sound_manager.dart';
import 'features/auth/domain/auth_notifier.dart';
import 'features/auth/presentation/sign_in_page.dart';
import 'features/auth/presentation/username_setup_page.dart';
import 'features/auth/presentation/terms_page.dart';
import 'features/levels/presentation/levels_page.dart';

// ─────────────────────────────────────────────
//  main.dart — zenBlock production entry point
// ─────────────────────────────────────────────

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'firebase_options.dart';
import 'core/analytics/analytics_service.dart';
import 'features/admob/admob_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

  configureImageCache();

  await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform);
  await FirebaseCrashlytics.instance
      .setCrashlyticsCollectionEnabled(true);
  FlutterError.onError =
      FirebaseCrashlytics.instance.recordFlutterFatalError;

  runApp(const ProviderScope(child: BlockBlastApp()));
}

class BlockBlastApp extends ConsumerStatefulWidget {
  const BlockBlastApp({super.key});

  @override
  ConsumerState<BlockBlastApp> createState() => _BlockBlastAppState();
}

class _BlockBlastAppState extends ConsumerState<BlockBlastApp> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    ref.read(performanceProvider);

    try {
      await ref.read(soundManagerProvider).preload();
      await ref.read(soundManagerProvider).playMusic('background.mp3');
    } catch (_) {}

    try {
      await ref.read(analyticsServiceProvider).initialize();
    } catch (_) {}

    try {
      await ref
          .read(adMobServiceProvider)
          .initialize()
          .timeout(const Duration(seconds: 8));
    } catch (_) {}

    if (mounted) setState(() => _ready = true);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'zenBlock',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00F5FF),
          secondary: Color(0xFFBF40FF),
        ),
        pageTransitionsTheme: const PageTransitionsTheme(
          builders: {
            TargetPlatform.android: CupertinoPageTransitionsBuilder(),
            TargetPlatform.iOS:     CupertinoPageTransitionsBuilder(),
          },
        ),
      ),
      home: _ready ? const AppShell() : const _SplashScreen(),
    );
  }
}

// ─────────────────────────────────────────────
//  AppShell — routes based on auth state
// ─────────────────────────────────────────────

class AppShell extends ConsumerWidget {
  const AppShell({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authNotifierProvider);
    return switch (auth.status) {
      AuthStatus.initial ||
      AuthStatus.loading      => const _SplashScreen(),
      AuthStatus.unauthenticated ||
      AuthStatus.error        => const SignInPage(),
      AuthStatus.authenticated => auth.needsUsername
          ? const UsernameSetupPage()
          : auth.needsTermsAcceptance
              ? const TermsPage()
              : const LevelsPage(),
    };
  }
}

// ─────────────────────────────────────────────
//  Premium Splash / Loading Screen
//
//  Requirements met:
//  ✓ Logo at exact center of screen
//  ✓ Shadow effects REMOVED
//  ✓ Soft glow/highlight effect only
//  ✓ Premium and smooth
//  ✓ Responsive for all screen sizes
//  ✓ "zenBlock" branding
// ─────────────────────────────────────────────

class _SplashScreen extends StatefulWidget {
  const _SplashScreen();

  @override
  State<_SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<_SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _glowCtrl;
  late final AnimationController _fadeCtrl;
  late final Animation<double> _glowAnim;
  late final Animation<double> _fadeAnim;
  late final Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();

    // Soft glow pulse (slow and smooth, not shadow)
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _glowAnim = Tween(begin: 0.4, end: 0.85)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _pulseAnim = Tween(begin: 1.0, end: 1.04)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    // Fade-in for the whole screen
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screen = MediaQuery.of(context).size;
    // Logo: responsive size, clamped for all devices
    final logoSize = (screen.width * 0.38).clamp(100.0, 170.0);

    return Scaffold(
      backgroundColor: const Color(0xFF040D1A),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: Stack(
          children: [
            // Background gradient — no shadows
            Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(0, -0.15),
                  radius: 1.4,
                  colors: [
                    Color(0xFF071428),
                    Color(0xFF040D1A),
                    Color(0xFF020810),
                  ],
                ),
              ),
            ),

            // Centered content — logo EXACTLY at center
            Center(
              child: AnimatedBuilder(
                animation: _glowCtrl,
                builder: (_, __) => Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // ── Logo with glow ring (NO shadow) ──
                    Transform.scale(
                      scale: _pulseAnim.value,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Outer glow ring — highlight/glow only
                          Container(
                            width: logoSize + 32,
                            height: logoSize + 32,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  const Color(0xFF00F5FF)
                                      .withValues(alpha: _glowAnim.value * 0.3),
                                  const Color(0xFF00F5FF)
                                      .withValues(alpha: _glowAnim.value * 0.08),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                          // Inner glow accent
                          Container(
                            width: logoSize + 16,
                            height: logoSize + 16,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  const Color(0xFF00F5FF)
                                      .withValues(alpha: _glowAnim.value * 0.15),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                          // Logo container — clean, no shadow
                          Container(
                            width: logoSize,
                            height: logoSize,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              // Subtle border highlight
                              border: Border.all(
                                color: const Color(0xFF00F5FF)
                                    .withValues(alpha: _glowAnim.value * 0.45),
                                width: 1.5,
                              ),
                              // Soft inner gradient — NOT a shadow
                              gradient: const RadialGradient(
                                colors: [
                                  Color(0xFF0E2040),
                                  Color(0xFF050F1E),
                                ],
                              ),
                            ),
                            padding: EdgeInsets.all(logoSize * 0.12),
                            child: AppLogo(
                              size: logoSize * 0.76,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 32),

                    // ── zenBlock branding ──
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [
                          Color(0xFF00F5FF),
                          Color(0xFFBF40FF),
                          Color(0xFF00F5FF),
                        ],
                        stops: [0.0, 0.5, 1.0],
                      ).createShader(bounds),
                      child: const Text(
                        'zenBlock',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 6,
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'BLOCK PUZZLE GAME',
                      style: TextStyle(
                        color: const Color(0xFF00F5FF).withValues(alpha: 0.6),
                        fontSize: 11,
                        letterSpacing: 4,
                        fontWeight: FontWeight.w500,
                      ),
                    ),

                    const SizedBox(height: 48),

                    // ── Loading indicator ──
                    SizedBox(
                      width: 28,
                      height: 28,
                      child: CircularProgressIndicator(
                        color: const Color(0xFF00F5FF)
                            .withValues(alpha: 0.55 + _glowAnim.value * 0.3),
                        strokeWidth: 2.5,
                      ),
                    ),

                    const SizedBox(height: 12),
                    Text(
                      'Loading...',
                      style: TextStyle(
                        color: const Color(0xFF00F5FF).withValues(alpha: 0.35),
                        fontSize: 11,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
