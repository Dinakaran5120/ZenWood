import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/user_model.dart';
import '../../../core/theme/game_theme.dart';
import '../../../core/services/sound_manager.dart';
import '../../../core/widgets/coin_display_widget.dart';
import '../../auth/data/user_repository.dart';
import '../../auth/domain/auth_notifier.dart';
import '../../game/game_screen.dart';
import '../../starter_rewards/presentation/starter_rewards_popup.dart';
import '../data/level_config.dart';

// ─────────────────────────────────────────────
//  LevelsPage — neon dark UI
//  Unlocking: highScore-based
//  Stars: score-based per level goal
// ─────────────────────────────────────────────

// Hard cap: only first 50 levels are available; levels 51+ show "Coming Soon".
const int _kMaxLevel = 50;

// All 50 levels are visible; individual locks are strictly progression-based.
int _visibleCount() => _kMaxLevel;

bool _isLevelUnlocked(int levelNumber, int highestUnlockedLevel) {
  return levelNumber <= highestUnlockedLevel;
}

int _computeStars(LevelConfig level, Set<int> completedLevels) {
  return completedLevels.contains(level.number) ? 3 : 0;
}

Color _neonColorForLevel(int number) {
  final hue = (number * 24.0) % 360.0;
  return HSLColor.fromAHSL(1.0, hue, 0.95, 0.65).toColor();
}

// ─────────────────────────────────────────────
//  LevelsPage
// ─────────────────────────────────────────────

class LevelsPage extends ConsumerStatefulWidget {
  const LevelsPage({super.key});

  @override
  ConsumerState<LevelsPage> createState() => _LevelsPageState();
}

class _LevelsPageState extends ConsumerState<LevelsPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _headerCtrl;
  late Animation<double> _headerAnim;

  @override
  void initState() {
    super.initState();
    _headerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _headerAnim = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerCtrl.forward();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(soundManagerProvider).playMusic('background.mp3');
    });
  }

  @override
  void dispose() {
    _headerCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userAsync = ref.watch(userProfileProvider);
    final auth = ref.watch(authNotifierProvider);

    return Scaffold(
      backgroundColor: const Color(0xFF040D1A),
      body: Stack(
        children: [
          const _NeonBg(),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FadeTransition(
                  opacity: _headerAnim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, -0.3),
                      end: Offset.zero,
                    ).animate(_headerAnim),
                    child: _Header(
                      userAsync: userAsync,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: userAsync.when(
                    data: (user) => _LevelPager(
                      highestUnlockedLevel: user?.highestUnlockedLevel ?? 1,
                      completedLevels: user?.completedLevels.toSet() ?? const <int>{},
                    ),
                    loading: () => const Center(
                      child: CircularProgressIndicator(
                          color: Color(0xFF00F5FF)),
                    ),
                    error: (_, __) =>
                        const _LevelPager(highestUnlockedLevel: 1, completedLevels: <int>{}),
                  ),
                ),
              ],
            ),
          ),

          // Starter rewards popup
          if (auth.shouldShowStarterRewards)
            StarterRewardsPopup(
              theme: beachTheme,
              onDismiss: () {
                ref
                    .read(authNotifierProvider.notifier)
                    .clearStarterRewardsFlag();
              },
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Animated Neon Background
// ─────────────────────────────────────────────

class _NeonBg extends StatelessWidget {
  const _NeonBg();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -0.5),
          radius: 1.4,
          colors: [
            Color(0xFF0A1830),
            Color(0xFF040D1A),
            Color(0xFF020810),
          ],
          stops: [0.0, 0.6, 1.0],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Header
// ─────────────────────────────────────────────

String _rankLabel(int highScore) {
  if (highScore >= 10000) return 'Diamond';
  if (highScore >= 5000) return 'Gold';
  if (highScore >= 1000) return 'Silver';
  return 'Bronze';
}

Color _rankColor(int highScore) {
  if (highScore >= 10000) return const Color(0xFF00E5FF);
  if (highScore >= 5000) return const Color(0xFFFFD700);
  if (highScore >= 1000) return const Color(0xFFB0BEC5);
  return const Color(0xFFCD7F32);
}

class _Header extends ConsumerWidget {
  final AsyncValue<UserModel?> userAsync;

  const _Header({required this.userAsync});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final highScore = userAsync.valueOrNull?.highScore ?? 0;
    final username = userAsync.valueOrNull?.username ?? '';
    final rank = _rankLabel(highScore);
    final rankColor = _rankColor(highScore);

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 12, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (username.isNotEmpty)
                      Text(
                        'Hello, $username 👋',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.5),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Color(0xFF00F5FF), Color(0xFFBF40FF)],
                      ).createShader(bounds),
                      child: const Text(
                        'LEVELS',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 34,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 6,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Rank badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: rankColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: rankColor.withValues(alpha: 0.6), width: 1),
                    ),
                    child: Text(
                      rank,
                      style: TextStyle(
                        color: rankColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  const CoinDisplayWidget(),
                ],
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(
                Icons.emoji_events_rounded,
                color: const Color(0xFFFFD700).withValues(alpha: 0.7),
                size: 14,
              ),
              const SizedBox(width: 4),
              Text(
                'Best  $highScore pts',
                style: const TextStyle(
                  color: Color(0x8000F5FF),
                  fontSize: 12,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Level Pager with PageView (2x3 grid per page)
// ─────────────────────────────────────────────

class _LevelPager extends StatefulWidget {
  final int highestUnlockedLevel;
  final Set<int> completedLevels;
  const _LevelPager({
    required this.highestUnlockedLevel,
    required this.completedLevels,
  });

  @override
  State<_LevelPager> createState() => _LevelPagerState();
}

class _LevelPagerState extends State<_LevelPager> {
  late PageController _pageController;
  late int _currentPage;
  late int _totalPages;

  @override
  void initState() {
    super.initState();
    _totalPages = (_visibleCount() / 6).ceil();
    _currentPage = 0;
    _pageController = PageController(initialPage: 0);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(_LevelPager oldWidget) {
    super.didUpdateWidget(oldWidget);
    final newTotalPages = (_visibleCount() / 6).ceil();
    if (newTotalPages != _totalPages) {
      setState(() {
        _totalPages = newTotalPages;
        _currentPage = 0;
        _pageController.jumpToPage(0);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: PageView.builder(
            controller: _pageController,
            onPageChanged: (page) {
              setState(() {
                _currentPage = page;
              });
            },
            itemCount: _totalPages,
            itemBuilder: (context, pageIndex) {
              return _LevelGridPage(
                highestUnlockedLevel: widget.highestUnlockedLevel,
                completedLevels: widget.completedLevels,
                pageIndex: pageIndex,
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        _PageIndicator(
          currentPage: _currentPage,
          totalPages: _totalPages,
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}

// ─────────────────────────────────────────────
//  Level Grid Page (2x3 grid)
// ─────────────────────────────────────────────

class _LevelGridPage extends StatelessWidget {
  final int highestUnlockedLevel;
  final Set<int> completedLevels;
  final int pageIndex;

  const _LevelGridPage({
    required this.highestUnlockedLevel,
    required this.completedLevels,
    required this.pageIndex,
  });

  @override
  Widget build(BuildContext context) {
    final totalLevels = _visibleCount();
    final startLevel  = pageIndex * 6 + 1;
    final endLevel    = (startLevel + 5).clamp(startLevel, totalLevels);
    final levelCount  = endLevel - startLevel + 1;

    // Show "Coming Soon" card on the last page when cap is reached.
    final isLastPage    = endLevel >= totalLevels;
    final showComingSoon = isLastPage && totalLevels >= _kMaxLevel;
    final extraItem      = showComingSoon ? 1 : 0;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.94,
        ),
        itemCount: levelCount + extraItem,
        itemBuilder: (context, i) {
          if (i >= levelCount) {
            return const _ComingSoonCard();
          }
          final levelNum  = startLevel + i;
          final config    = LevelConfig.forLevel(levelNum);
          final isUnlocked = _isLevelUnlocked(levelNum, highestUnlockedLevel);
          final stars     = isUnlocked ? _computeStars(config, completedLevels) : 0;
          return _LevelCard(
            config: config,
            isUnlocked: isUnlocked,
            stars: stars,
          );
        },
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Coming Soon card shown after level 50
// ─────────────────────────────────────────────

class _ComingSoonCard extends StatelessWidget {
  const _ComingSoonCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0A1628), Color(0xFF0D1F3C)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: const Color(0xFF00F5FF).withValues(alpha: 0.4),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00F5FF).withValues(alpha: 0.15),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🚀', style: TextStyle(fontSize: 36)),
          const SizedBox(height: 10),
          const Text(
            'Coming\nSoon',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF00F5FF),
              fontSize: 16,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
              height: 1.3,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'More levels\nin the next update',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.4),
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Page Indicator Dots
// ─────────────────────────────────────────────

class _PageIndicator extends StatelessWidget {
  final int currentPage;
  final int totalPages;

  const _PageIndicator({
    required this.currentPage,
    required this.totalPages,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(totalPages, (index) {
        final isActive = index == currentPage;
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: isActive ? 24 : 8,
          height: 8,
          decoration: BoxDecoration(
            color: isActive
                ? const Color(0xFF00F5FF)
                : Colors.white.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(4),
          ),
        );
      }),
    );
  }
}

// ─────────────────────────────────────────────
//  Level Card - Redesigned with better states
// ─────────────────────────────────────────────

class _LevelCard extends ConsumerStatefulWidget {
  final LevelConfig config;
  final bool isUnlocked;
  final int stars;

  const _LevelCard({
    required this.config,
    required this.isUnlocked,
    required this.stars,
  });

  @override
  ConsumerState<_LevelCard> createState() => _LevelCardState();
}

class _LevelCardState extends ConsumerState<_LevelCard>
    with TickerProviderStateMixin {
  late AnimationController _tapCtrl;
  late Animation<double> _tapScale;

  @override
  void initState() {
    super.initState();
    _tapCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 110),
    );
    _tapScale = Tween(begin: 1.0, end: 0.95)
        .animate(CurvedAnimation(parent: _tapCtrl, curve: Curves.easeIn));
  }

  @override
  void dispose() {
    _tapCtrl.dispose();
    super.dispose();
  }

  void _onTap(BuildContext context) {
    if (!widget.isUnlocked) return;
    ref.read(soundManagerProvider).tap();
    HapticFeedback.lightImpact();
    _tapCtrl.reverse();
    final nav = Navigator.of(context);
    showDialog<void>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.75),
      builder: (_) => _LevelDialog(
        config: widget.config,
        stars: widget.stars,
        onPlay: () {
          nav.pop();
          nav.push(MaterialPageRoute<void>(
            builder: (_) => GameScreen(levelConfig: widget.config),
          ));
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final neon = _neonColorForLevel(widget.config.number);
    final isUnlocked = widget.isUnlocked;
    final stars = widget.stars;
    final isCompleted = stars > 0;

    return GestureDetector(
      onTapDown: isUnlocked ? (_) => _tapCtrl.forward() : null,
      onTapUp: isUnlocked
          ? (_) {
              _tapCtrl.reverse();
              _onTap(context);
            }
          : null,
      onTapCancel: isUnlocked ? () => _tapCtrl.reverse() : null,
      child: AnimatedBuilder(
        animation: _tapScale,
        builder: (_, child) =>
            Transform.scale(scale: _tapScale.value, child: child),
        child: Container(
          decoration: BoxDecoration(
            gradient: isUnlocked
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      const Color(0xFF0A1628).withValues(alpha: 0.95),
                      const Color(0xFF0D1F3C).withValues(alpha: 0.9),
                    ],
                  )
                : LinearGradient(
                    colors: [
                      const Color(0xFF070C14).withValues(alpha: 0.8),
                      const Color(0xFF050A10).withValues(alpha: 0.7),
                    ],
                  ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isUnlocked
                  ? neon.withValues(alpha: 0.6)
                  : Colors.white.withValues(alpha: 0.1),
              width: isUnlocked ? 2 : 1,
            ),
            boxShadow: isUnlocked
                ? [
                    BoxShadow(
                      color: neon.withValues(alpha: 0.3),
                      blurRadius: 16,
                      spreadRadius: 2,
                    ),
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.2),
                      blurRadius: 8,
                    ),
                  ],
          ),
          child: Stack(
            children: [
              // Content
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Level number
                    isUnlocked
                        ? ShaderMask(
                            shaderCallback: (bounds) =>
                                LinearGradient(
                              colors: [Colors.white, neon],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ).createShader(bounds),
                            child: Text(
                              '${widget.config.number}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 42,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          )
                        : Text(
                            '${widget.config.number}',
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.25),
                              fontSize: 42,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                    const SizedBox(height: 12),
                    // Stars (only show if unlocked)
                    if (isUnlocked)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(3, (i) {
                          final filled = i < stars;
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: Icon(
                              filled
                                  ? Icons.star_rounded
                                  : Icons.star_outline_rounded,
                              color: filled
                                  ? const Color(0xFFFFD700)
                                  : Colors.white.withValues(alpha: 0.15),
                              size: 20,
                              shadows: filled
                                  ? [
                                      Shadow(
                                        color: const Color(0xFFFFD700)
                                            .withValues(alpha: 0.8),
                                        blurRadius: 8,
                                      )
                                    ]
                                  : null,
                            ),
                          );
                        }),
                      ),
                  ],
                ),
              ),

              // Lock overlay
              if (!isUnlocked)
                Positioned.fill(
                  child: Center(
                    child: Icon(
                      Icons.lock_rounded,
                      color: Colors.white.withValues(alpha: 0.2),
                      size: 36,
                    ),
                  ),
                ),

              // Completed badge
              if (isCompleted)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF4CAF50).withValues(alpha: 0.9),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF4CAF50).withValues(alpha: 0.5),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.check_rounded,
                      color: Colors.white,
                      size: 16,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Level Dialog Popup
// ─────────────────────────────────────────────

class _LevelDialog extends StatefulWidget {
  final LevelConfig config;
  final int stars;
  final VoidCallback onPlay;

  const _LevelDialog({
    required this.config,
    required this.stars,
    required this.onPlay,
  });

  @override
  State<_LevelDialog> createState() => _LevelDialogState();
}

class _LevelDialogState extends State<_LevelDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final neon = _neonColorForLevel(widget.config.number);
    final diff = widget.config.difficulty;
    final hasTimer = widget.config.timerSeconds != null;
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.symmetric(horizontal: screenWidth * 0.08),
      child: Container(
        constraints: BoxConstraints(
          maxHeight: screenHeight * 0.85,
        ),
        child: SingleChildScrollView(
          child: ScaleTransition(
            scale: _scale,
            child: Container(
              padding: EdgeInsets.all((screenWidth * 0.06).clamp(20.0, 28.0)),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xF80D1628), Color(0xF8090E1C)],
                ),
                borderRadius: BorderRadius.circular(28),
                border:
                    Border.all(color: neon.withValues(alpha: 0.6), width: 1.5),
                boxShadow: [
                  BoxShadow(
                      color: neon.withValues(alpha: 0.25),
                      blurRadius: 35,
                      spreadRadius: 2),
                  BoxShadow(
                      color: Colors.black.withValues(alpha: 0.6),
                      blurRadius: 20),
                ],
              ),
              child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Accent bar
              Container(
                height: 3,
                width: 48,
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, neon, Colors.transparent],
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              Text(
                'LEVEL',
                style: TextStyle(
                  color: neon.withValues(alpha: 0.7),
                  fontSize: 11,
                  letterSpacing: 5,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [neon, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ).createShader(bounds),
                child: Text(
                  '${widget.config.number}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 64,
                    fontWeight: FontWeight.w900,
                    height: 1.0,
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // Difficulty badge
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: diff.color.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: diff.color.withValues(alpha: 0.5), width: 1),
                ),
                child: Text(
                  '${diff.emoji}  ${diff.label.toUpperCase()}',
                  style: TextStyle(
                    color: diff.color,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ),

              const SizedBox(height: 14),

              // Goal info row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _InfoChip(
                    icon: Icons.flag_rounded,
                    label: 'Goal',
                    value: '${widget.config.scoreGoal} pts',
                    color: const Color(0xFF00F5FF),
                  ),
                  if (hasTimer)
                    _InfoChip(
                      icon: Icons.timer_rounded,
                      label: 'Time',
                      value: '${widget.config.timerSeconds}s',
                      color: const Color(0xFFFF6B35),
                    )
                  else
                    const _InfoChip(
                      icon: Icons.all_inclusive_rounded,
                      label: 'Time',
                      value: 'Unlimited',
                      color: Color(0xFF4CAF50),
                    ),
                ],
              ),

              const SizedBox(height: 16),

              // Stars
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(3, (i) {
                  final filled = i < widget.stars;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Icon(
                      filled
                          ? Icons.star_rounded
                          : Icons.star_outline_rounded,
                      color: filled
                          ? const Color(0xFFFFD700)
                          : Colors.white.withValues(alpha: 0.2),
                      size: 30,
                      shadows: filled
                          ? [
                              Shadow(
                                color: const Color(0xFFFFD700)
                                    .withValues(alpha: 0.7),
                                blurRadius: 12,
                              )
                            ]
                          : null,
                    ),
                  );
                }),
              ),

              const SizedBox(height: 6),
              Text(
                _starMessage,
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.4),
                  fontSize: 12,
                  letterSpacing: 0.3,
                ),
              ),

              const SizedBox(height: 24),
              _PlayButton(onTap: widget.onPlay, color: neon),
              const SizedBox(height: 14),

              GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Text(
                  'CANCEL',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.25),
                    fontSize: 11,
                    letterSpacing: 2.5,
                  ),
                ),
              ),
            ],
          ),
        ),
          ),
        ),
      ),
    );
  }

  String get _starMessage {
    switch (widget.stars) {
      case 0:
        return 'Play to earn stars!';
      case 1:
        return 'Good start! Keep going!';
      case 2:
        return 'Impressive! Almost perfect!';
      default:
        return 'Legendary! All 3 stars!';
    }
  }
}

// ── Info Chip ──────────────────────────────

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _InfoChip({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.3), width: 1),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(height: 3),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.35),
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Neon Play Button
// ─────────────────────────────────────────────

class _PlayButton extends StatefulWidget {
  final VoidCallback onTap;
  final Color color;

  const _PlayButton({required this.onTap, required this.color});

  @override
  State<_PlayButton> createState() => _PlayButtonState();
}

class _PlayButtonState extends State<_PlayButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scale = Tween(begin: 1.0, end: 0.94)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        HapticFeedback.mediumImpact();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  widget.color.withValues(alpha: 0.85),
                  widget.color.withValues(alpha: 0.55),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: widget.color.withValues(alpha: 0.75),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: widget.color.withValues(alpha: 0.45),
                  blurRadius: 18,
                  spreadRadius: 1,
                ),
                BoxShadow(
                  color: widget.color.withValues(alpha: 0.2),
                  blurRadius: 35,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.play_arrow_rounded,
                    color: Colors.white, size: 26),
                SizedBox(width: 8),
                Text(
                  'PLAY',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 5,
                    shadows: [
                      Shadow(color: Colors.white54, blurRadius: 8)
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
