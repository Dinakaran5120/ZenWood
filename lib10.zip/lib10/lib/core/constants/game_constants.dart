// ─────────────────────────────────────────────
//  Game constants & block shape definitions
// ─────────────────────────────────────────────

class GameConstants {
  static const int gridSize = 8;
  static const double cellSize = 44.0;    // px per cell
  static const double cellGap = 2.0;
  static const double blockPieceTrayHeight = 160.0;
  static const double snapThreshold = 0.6; // fraction of cellSize

  // Scoring — only blast/clear events award points
  static const int pointsPerBlastedBlock = 2; // 2 pts per block cleared in a blast
  static const int pointsPerCell = 2;         // alias kept for powerup handlers
  static const int comboMultiplierStep = 50;
  static const int maxComboMultiplier = 8;

  // Animation durations (ms)
  static const int blockPlaceDurationMs = 120;
  static const int lineClearDurationMs = 300;
  static const int particleDurationMs = 600;
  static const int comboTextDurationMs = 800;
  static const int shakeAmplitude = 6;

  // Sound
  static const double sfxVolume = 0.8;
  static const double musicVolume = 0.3;
}

// A block piece is defined as a list of [row, col] offsets from pivot (0,0)
class BlockShape {
  final String id;
  final List<List<int>> cells; // [[r,c], ...]
  final int colorIndex;

  const BlockShape({
    required this.id,
    required this.cells,
    required this.colorIndex,
  });

  int get width {
    int maxC = 0;
    for (final c in cells) {
      if (c[1] > maxC) maxC = c[1];
    }
    return maxC + 1;
  }

  int get height {
    int maxR = 0;
    for (final c in cells) {
      if (c[0] > maxR) maxR = c[0];
    }
    return maxR + 1;
  }
}

// ─── All possible block shapes ────────────────
const List<BlockShape> allShapes = [
  // Singles
  BlockShape(id: 'dot',      cells: [[0,0]], colorIndex: 0),

  // Dominoes
  BlockShape(id: 'h2',       cells: [[0,0],[0,1]], colorIndex: 1),
  BlockShape(id: 'v2',       cells: [[0,0],[1,0]], colorIndex: 2),

  // Triominoes
  BlockShape(id: 'h3',       cells: [[0,0],[0,1],[0,2]], colorIndex: 3),
  BlockShape(id: 'v3',       cells: [[0,0],[1,0],[2,0]], colorIndex: 4),
  BlockShape(id: 'lTL',      cells: [[0,0],[1,0],[1,1]], colorIndex: 5),
  BlockShape(id: 'lTR',      cells: [[0,1],[1,0],[1,1]], colorIndex: 6),
  BlockShape(id: 'lBL',      cells: [[0,0],[0,1],[1,0]], colorIndex: 0),
  BlockShape(id: 'lBR',      cells: [[0,0],[0,1],[1,1]], colorIndex: 1),

  // Tetrominoes
  BlockShape(id: 'I4h',      cells: [[0,0],[0,1],[0,2],[0,3]], colorIndex: 2),
  BlockShape(id: 'I4v',      cells: [[0,0],[1,0],[2,0],[3,0]], colorIndex: 3),
  BlockShape(id: 'sq',       cells: [[0,0],[0,1],[1,0],[1,1]], colorIndex: 4),
  BlockShape(id: 'Ls',       cells: [[0,0],[1,0],[2,0],[2,1]], colorIndex: 5),
  BlockShape(id: 'Js',       cells: [[0,1],[1,1],[2,0],[2,1]], colorIndex: 6),
  BlockShape(id: 'Ts',       cells: [[0,0],[0,1],[0,2],[1,1]], colorIndex: 0),
  BlockShape(id: 'Ss',       cells: [[0,1],[0,2],[1,0],[1,1]], colorIndex: 1),
  BlockShape(id: 'Zs',       cells: [[0,0],[0,1],[1,1],[1,2]], colorIndex: 2),

  // Pentominoes (3x3 and smaller)
  BlockShape(id: 'P3x3',    cells: [[0,0],[0,1],[1,0],[1,1],[2,0]], colorIndex: 3),
  BlockShape(id: 'cross',   cells: [[0,1],[1,0],[1,1],[1,2],[2,1]], colorIndex: 4),
  BlockShape(id: 'U5',      cells: [[0,0],[0,2],[1,0],[1,1],[1,2]], colorIndex: 5),

  // 2x2
  BlockShape(id: 'sq2x2',   cells: [[0,0],[0,1],[1,0],[1,1]], colorIndex: 6),

  // 3x3 full
  BlockShape(id: 'sq3x3',   cells: [
    [0,0],[0,1],[0,2],
    [1,0],[1,1],[1,2],
    [2,0],[2,1],[2,2],
  ], colorIndex: 0),
];
