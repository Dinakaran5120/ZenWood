import 'package:cloud_firestore/cloud_firestore.dart';

// ─────────────────────────────────────────────
//  UserModel — Firestore document schema
//  Collection: /users/{uid}
// ─────────────────────────────────────────────

class UserModel {
  final String uid;
  final String username;
  final String email;
  final String? photoUrl;
  final String? country;       // ISO-3166 e.g. "IN"
  final String? countryName;   // e.g. "India"
  final double? latitude;
  final double? longitude;
  final int highScore;
  final int totalScore;
  final int gamesPlayed;
  final int totalLinesCleared;
  final int totalBlocksPlaced;
  final String selectedTheme;  // "beach" | "devil" | "angel"
  final String selectedAvatar;
  final int coins;
  final DateTime createdAt;
  final DateTime lastSeen;
  final bool isGuest;          // Added for guest users

  // Daily reward
  final DateTime? lastDailyRewardAt;
  final int dailyRewardStreak;

  // Starter rewards
  final bool starterRewardsGranted;

  // Cloud save
  final Map<String, dynamic>? cloudSaveData;
  final List<int> completedLevels;
  final int highestUnlockedLevel;

  const UserModel({
    required this.uid,
    required this.username,
    required this.email,
    this.photoUrl,
    this.country,
    this.countryName,
    this.latitude,
    this.longitude,
    this.highScore = 0,
    this.totalScore = 0,
    this.gamesPlayed = 0,
    this.totalLinesCleared = 0,
    this.totalBlocksPlaced = 0,
    this.selectedTheme = 'beach',
    this.selectedAvatar = 'default',
    this.coins = 0,
    required this.createdAt,
    required this.lastSeen,
    this.isGuest = false,
    this.lastDailyRewardAt,
    this.dailyRewardStreak = 0,
    this.starterRewardsGranted = false,
    this.cloudSaveData,
    this.completedLevels = const [],
    this.highestUnlockedLevel = 1,
  });

  bool get hasUsername => username.isNotEmpty;

  // ── Firestore → Model ─────────────────────
  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: doc.id,
      username: d['username'] ?? '',
      email: d['email'] ?? '',
      photoUrl: d['photoUrl'],
      country: d['country'],
      countryName: d['countryName'],
      latitude: (d['latitude'] as num?)?.toDouble(),
      longitude: (d['longitude'] as num?)?.toDouble(),
      highScore: (d['highScore'] as num?)?.toInt() ?? 0,
      totalScore: (d['totalScore'] as num?)?.toInt() ?? 0,
      gamesPlayed: (d['gamesPlayed'] as num?)?.toInt() ?? 0,
      totalLinesCleared: (d['totalLinesCleared'] as num?)?.toInt() ?? 0,
      totalBlocksPlaced: (d['totalBlocksPlaced'] as num?)?.toInt() ?? 0,
      selectedTheme: d['selectedTheme'] ?? 'beach',
      selectedAvatar: d['selectedAvatar'] ?? 'default',
      coins: (d['coins'] as num?)?.toInt() ?? 0,
      createdAt: (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      lastSeen: (d['lastSeen'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isGuest: d['isGuest'] as bool? ?? false,
      lastDailyRewardAt: (d['lastDailyRewardAt'] as Timestamp?)?.toDate(),
      dailyRewardStreak: (d['dailyRewardStreak'] as num?)?.toInt() ?? 0,
      starterRewardsGranted: d['starterRewardsGranted'] as bool? ?? false,
      cloudSaveData: d['cloudSaveData'] as Map<String, dynamic>?,
      completedLevels:
          (d['completedLevels'] as List<dynamic>? ?? const <dynamic>[])
              .map((e) => (e as num).toInt())
              .toList(),
      highestUnlockedLevel: (d['highestUnlockedLevel'] as num?)?.toInt() ?? 1,
    );
  }

  // ── Model → Firestore ─────────────────────
  Map<String, dynamic> toFirestore() => {
        'username': username,
        'email': email,
        if (photoUrl != null) 'photoUrl': photoUrl,
        if (country != null) 'country': country,
        if (countryName != null) 'countryName': countryName,
        if (latitude != null) 'latitude': latitude,
        if (longitude != null) 'longitude': longitude,
        'highScore': highScore,
        'totalScore': totalScore,
        'gamesPlayed': gamesPlayed,
        'totalLinesCleared': totalLinesCleared,
        'totalBlocksPlaced': totalBlocksPlaced,
        'selectedTheme': selectedTheme,
        'selectedAvatar': selectedAvatar,
        'coins': coins,
        'createdAt': Timestamp.fromDate(createdAt),
        'lastSeen': Timestamp.fromDate(lastSeen),
        'isGuest': isGuest,
        if (lastDailyRewardAt != null)
          'lastDailyRewardAt': Timestamp.fromDate(lastDailyRewardAt!),
        'dailyRewardStreak': dailyRewardStreak,
        'starterRewardsGranted': starterRewardsGranted,
        if (cloudSaveData != null) 'cloudSaveData': cloudSaveData,
        'completedLevels': completedLevels,
        'highestUnlockedLevel': highestUnlockedLevel,
      };

  UserModel copyWith({
    String? username,
    String? email,
    String? photoUrl,
    String? country,
    String? countryName,
    double? latitude,
    double? longitude,
    int? highScore,
    int? totalScore,
    int? gamesPlayed,
    int? totalLinesCleared,
    int? totalBlocksPlaced,
    String? selectedTheme,
    String? selectedAvatar,
    int? coins,
    DateTime? lastSeen,
    bool? isGuest,
    DateTime? lastDailyRewardAt,
    int? dailyRewardStreak,
    bool? starterRewardsGranted,
    Map<String, dynamic>? cloudSaveData,
    List<int>? completedLevels,
    int? highestUnlockedLevel,
  }) =>
      UserModel(
        uid: uid,
        username: username ?? this.username,
        email: email ?? this.email,
        photoUrl: photoUrl ?? this.photoUrl,
        country: country ?? this.country,
        countryName: countryName ?? this.countryName,
        latitude: latitude ?? this.latitude,
        longitude: longitude ?? this.longitude,
        highScore: highScore ?? this.highScore,
        totalScore: totalScore ?? this.totalScore,
        gamesPlayed: gamesPlayed ?? this.gamesPlayed,
        totalLinesCleared: totalLinesCleared ?? this.totalLinesCleared,
        totalBlocksPlaced: totalBlocksPlaced ?? this.totalBlocksPlaced,
        selectedTheme: selectedTheme ?? this.selectedTheme,
        selectedAvatar: selectedAvatar ?? this.selectedAvatar,
        coins: coins ?? this.coins,
        createdAt: createdAt,
        lastSeen: lastSeen ?? this.lastSeen,
        isGuest: isGuest ?? this.isGuest,
        lastDailyRewardAt: lastDailyRewardAt ?? this.lastDailyRewardAt,
        dailyRewardStreak: dailyRewardStreak ?? this.dailyRewardStreak,
        starterRewardsGranted: starterRewardsGranted ?? this.starterRewardsGranted,
        cloudSaveData: cloudSaveData ?? this.cloudSaveData,
        completedLevels: completedLevels ?? this.completedLevels,
        highestUnlockedLevel: highestUnlockedLevel ?? this.highestUnlockedLevel,
      );
}

// ─────────────────────────────────────────────
//  LeaderboardEntry — /leaderboard/{uid}
// ─────────────────────────────────────────────

class LeaderboardEntry {
  final String uid;
  final String username;
  final String? photoUrl;
  final int score;

  /// Best score within the current 24-hour window.
  final int dailyScore;

  /// UTC timestamp when the current daily window started.
  final DateTime? dailyWindowStart;

  final String? country;
  final String? countryName;
  final DateTime updatedAt;
  int rank; // computed client-side

  LeaderboardEntry({
    required this.uid,
    required this.username,
    this.photoUrl,
    required this.score,
    this.dailyScore = 0,
    this.dailyWindowStart,
    this.country,
    this.countryName,
    required this.updatedAt,
    this.rank = 0,
  });

  /// Whether this entry's daily window is still active (< 24 h ago).
  bool get isDailyActive {
    final ws = dailyWindowStart;
    if (ws == null) return false;
    return DateTime.now().difference(ws).inHours < 24;
  }

  /// Effective daily score — 0 if the window has expired.
  int get effectiveDailyScore => isDailyActive ? dailyScore : 0;

  factory LeaderboardEntry.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return LeaderboardEntry(
      uid: doc.id,
      username: d['username'] ?? 'Player',
      photoUrl: d['photoUrl'],
      score: (d['score'] as num?)?.toInt() ?? 0,
      dailyScore: (d['dailyScore'] as num?)?.toInt() ?? 0,
      dailyWindowStart: (d['dailyWindowStart'] as Timestamp?)?.toDate(),
      country: d['country'],
      countryName: d['countryName'],
      updatedAt: (d['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() => {
        'username': username,
        if (photoUrl != null) 'photoUrl': photoUrl,
        'score': score,
        'dailyScore': dailyScore,
        if (dailyWindowStart != null)
          'dailyWindowStart': Timestamp.fromDate(dailyWindowStart!),
        if (country != null) 'country': country,
        if (countryName != null) 'countryName': countryName,
        'updatedAt': Timestamp.fromDate(updatedAt),
      };
}

// ─────────────────────────────────────────────
//  DailyRewardConfig
// ─────────────────────────────────────────────

class DailyRewardDay {
  final int day;
  final int coins;
  final String? bonusItem; // e.g. 'theme_beach'
  final bool isSpecial;

  const DailyRewardDay({
    required this.day,
    required this.coins,
    this.bonusItem,
    this.isSpecial = false,
  });
}

const List<DailyRewardDay> dailyRewardSchedule = [
  DailyRewardDay(day: 1, coins: 50),
  DailyRewardDay(day: 2, coins: 75),
  DailyRewardDay(day: 3, coins: 100),
  DailyRewardDay(day: 4, coins: 125),
  DailyRewardDay(day: 5, coins: 150),
  DailyRewardDay(day: 6, coins: 200),
  DailyRewardDay(day: 7, coins: 500, bonusItem: 'theme_beach', isSpecial: true),
];
