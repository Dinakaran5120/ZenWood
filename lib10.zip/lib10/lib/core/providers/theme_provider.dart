import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../theme/game_theme.dart';

// ─────────────────────────────────────────────
//  Theme Provider — Global theme state management
// ─────────────────────────────────────────────

class ThemeNotifier extends StateNotifier<GameThemeData> {
  ThemeNotifier() : super(beachTheme);

  void setTheme(GameThemeData theme) {
    state = theme;
  }

  void setThemeType(GameThemeType type) {
    state = ThemeRegistry.get(type);
  }

  void setThemeFromString(String themeId) {
    state = ThemeRegistry.fromString(themeId);
  }
}

final themeProvider = StateNotifierProvider<ThemeNotifier, GameThemeData>((ref) {
  return ThemeNotifier();
});

// ─────────────────────────────────────────────
//  Theme Extension for easy access
// ─────────────────────────────────────────────

extension GameThemeExtension on WidgetRef {
  GameThemeData get currentTheme => watch(themeProvider);
  GameThemeColors get themeColors => watch(themeProvider).colors;
}

extension GameThemeContextExtension on BuildContext {
  GameThemeData get currentTheme {
    return ProviderScope.containerOf(this).read(themeProvider);
  }
  GameThemeColors get themeColors {
    return ProviderScope.containerOf(this).read(themeProvider).colors;
  }
}
