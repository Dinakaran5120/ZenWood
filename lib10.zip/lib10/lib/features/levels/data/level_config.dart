import 'dart:math' show max;
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────
//  Zenblock— Progressive Level Configuration
//  Scalable: levels auto-generate via forLevel(n)
// ─────────────────────────────────────────────

enum LevelDifficulty {
  easy,
  medium,
  hard,
  extreme;

  String get label => switch (this) {
        easy    => 'Easy',
        medium  => 'Medium',
        hard    => 'Hard',
        extreme => 'Extreme',
      };

  Color get color => switch (this) {
        easy    => const Color(0xFF4CAF50),
        medium  => const Color(0xFFFFAA00),
        hard    => const Color(0xFFFF5722),
        extreme => const Color(0xFFBF40FF),
      };

  String get emoji => switch (this) {
        easy    => '🌱',
        medium  => '⚡',
        hard    => '🔥',
        extreme => '💀',
      };
}

class LevelConfig {
  final int number;

  /// Score required to complete (pass) the level.
  final int scoreGoal;

  /// Cumulative coin thresholds for star awards.
  /// Stars are based on score compared to goal multiples.
  final int scoreFor1Star;
  final int scoreFor2Stars;
  final int scoreFor3Stars;

  /// null = no timer (levels 1-2).
  /// int  = countdown seconds shown on screen.
  final int? timerSeconds;

  final LevelDifficulty difficulty;

  /// If true, 3×3 full blocks are excluded from tray (easier).
  final bool excludeHeavyShapes;

  const LevelConfig({
    required this.number,
    required this.scoreGoal,
    required this.scoreFor1Star,
    required this.scoreFor2Stars,
    required this.scoreFor3Stars,
    this.timerSeconds,
    this.difficulty = LevelDifficulty.easy,
    this.excludeHeavyShapes = true,
  });

  // ── Stars from score ────────────────────────
  int starsEarned(int score) {
    if (score >= scoreFor3Stars) return 3;
    if (score >= scoreFor2Stars) return 2;
    if (score >= scoreFor1Star)  return 1;
    return 0;
  }

  /// Flat coin reward for completing the level.
  int coinsEarned(int score) {
    final stars = starsEarned(score);
    final base = 20 + number * 5;
    return switch (stars) {
      3 => base * 4,
      2 => base * 2,
      1 => base,
      _ => (base * 0.5).round(),
    };
  }

  // ── Dynamic level generator ─────────────────
  static LevelConfig forLevel(int n) {
    final goal = _scoreGoal(n);
    return LevelConfig(
      number:            n,
      scoreGoal:         goal,
      scoreFor1Star:     (goal * 1.1).round(),
      scoreFor2Stars:    (goal * 1.4).round(),
      scoreFor3Stars:    (goal * 1.9).round(),
      timerSeconds:      _timer(n),
      difficulty:        _diff(n),
      excludeHeavyShapes: n <= 5,
    );
  }

  // Score goals are calibrated for 5 pts/blasted-block scoring.
  // A typical 60-second level yields ~600-900 pts for a competent player.
  static int _scoreGoal(int n) {
    if (n == 1)  return 80;                          // ~2 line clears, no timer
    if (n == 2)  return 150;                         // ~4 line clears, no timer
    if (n <= 5)  return 130 + (n - 2) * 90;         // 220–400, no timer
    if (n <= 9)  return 400 + (n - 5) * 80;         // 480–720, no timer
    if (n <= 14) return 720 + (n - 9) * 80;         // 800–1120 in 60 s
    if (n <= 24) return 1120 + (n - 14) * 90;       // 1210–2020 in 50 s
    if (n <= 34) return 2020 + (n - 24) * 100;      // 2120–3020 in 45 s
    if (n <= 50) return 3020 + (n - 34) * 120;      // 3140–5000 in 40 s
    return 5000 + (n - 50) * 150;                   // 51+: keeps scaling
  }

  // Timer starts at Level 10 (60 s), decreasing with difficulty.
  // Levels 1-9: no timer (free play).
  static int? _timer(int n) {
    if (n <= 9)  return null;  // levels 1-9: no timer
    if (n <= 14) return 60;    // levels 10-14: 60 s
    if (n <= 24) return 50;    // levels 15-24: 50 s
    if (n <= 34) return 45;    // levels 25-34: 45 s
    if (n <= 50) return 40;    // levels 35-50: 40 s
    // Levels 51+: decreasing floor at 20 s
    return max(20, 60 - (n - 10) * 2);
  }

  static LevelDifficulty _diff(int n) {
    if (n <= 2)  return LevelDifficulty.easy;
    if (n <= 7)  return LevelDifficulty.medium;
    if (n <= 15) return LevelDifficulty.hard;
    return LevelDifficulty.extreme;
  }
}
