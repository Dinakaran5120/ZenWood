import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/auth_notifier.dart';
import '../../game/components/neon_background.dart';
import '../../../core/providers/theme_provider.dart';
import '../../../core/widgets/app_logo.dart';

// ─────────────────────────────────────────────
//  SignInPage
//  Neon-themed sign-in UI with Google/Email/Guest
// ─────────────────────────────────────────────

class SignInPage extends ConsumerStatefulWidget {
  const SignInPage({super.key});

  @override
  ConsumerState<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends ConsumerState<SignInPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeIn;
  late Animation<Offset> _slideUp;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    _fadeIn = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _slideUp = Tween(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);
    final colors = ref.watch(themeProvider).colors;

    // Listen for errors
    ref.listen<AuthState>(authNotifierProvider, (_, next) {
      if (next.errorMessage != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.errorMessage!),
            backgroundColor: Colors.red.shade800,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
        ref.read(authNotifierProvider.notifier).clearError();
      }
    });

    return Scaffold(
      backgroundColor: colors.background1,
      body: Stack(
        children: [
          const NeonBackground(),
          SafeArea(
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height -
                      MediaQuery.of(context).padding.top,
                ),
              child: FadeTransition(
                opacity: _fadeIn,
                child: SlideTransition(
                  position: _slideUp,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(height: 60),
                        // Logo
                        Container(
                          width: 140,
                          height: 140,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: colors.glowColor.withValues(alpha: 0.5),
                              width: 2,
                            ),
                            gradient: RadialGradient(
                              colors: [
                                colors.glowColor.withValues(alpha: 0.2),
                                Colors.transparent,
                              ],
                            ),
                          ),
                          padding: const EdgeInsets.all(18),
                          child: const AppLogo(size: 96),
                        ),
                        const SizedBox(height: 28),
                        // App name
                        ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [
                              Color(0xFF00F5FF),
                              Color(0xFFBF40FF),
                              Color(0xFF00F5FF),
                            ],
                            stops: [0.0, 0.5, 1.0],
                          ).createShader(bounds),
                          child: const Text(
                            'Zenblock',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 36,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 6,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Block Blast',
                          style: TextStyle(
                            color: colors.textPrimary.withValues(alpha: 0.6),
                            fontSize: 16,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 56),
                        // Email Register (primary CTA)
                        _SignInButton(
                          icon: '✉',
                          label: 'Create Account',
                          backgroundColor: null,
                          gradient: LinearGradient(
                            colors: [
                              colors.buttonPrimary,
                              colors.buttonSecondary,
                            ],
                          ),
                          textColor: Colors.white,
                          isLoading: authState.isLoading,
                          onPressed: () => _handleEmailRegister(),
                        ),
                        const SizedBox(height: 16),
                        // Guest
                        _SignInButton(
                          icon: '🎮',
                          label: 'Play as Guest',
                          backgroundColor: null,
                          borderColor: colors.panelBorder,
                          textColor: colors.textPrimary.withValues(alpha: 0.7),
                          isLoading: authState.isLoading,
                          onPressed: () => _handleGuestSignIn(),
                        ),
                        const SizedBox(height: 32),
                        // Already have account
                        TextButton(
                          onPressed: () => _showLoginBottomSheet(),
                          child: Text(
                            'Already have an account? Login',
                            style: TextStyle(
                              color: colors.textAccent,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _handleEmailRegister() async {
    _showEmailAuthBottomSheet(isRegister: true);
  }

  Future<void> _handleGuestSignIn() async {
    await ref.read(authNotifierProvider.notifier).signInAnonymously();
  }

  void _showLoginBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _EmailAuthBottomSheet(isRegister: false),
    );
  }

  void _showEmailAuthBottomSheet({required bool isRegister}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _EmailAuthBottomSheet(isRegister: isRegister),
    );
  }
}

// ─────────────────────────────────────────────
//  Sign In Button
// ─────────────────────────────────────────────

class _SignInButton extends StatelessWidget {
  final String icon;
  final String label;
  final Color? backgroundColor;
  final Gradient? gradient;
  final Color? borderColor;
  final Color textColor;
  final bool isLoading;
  final VoidCallback onPressed;

  const _SignInButton({
    required this.icon,
    required this.label,
    this.backgroundColor,
    this.gradient,
    this.borderColor,
    required this.textColor,
    required this.isLoading,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor,
          foregroundColor: textColor,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: borderColor != null
                ? BorderSide(color: borderColor!, width: 1.5)
                : BorderSide.none,
          ),
        ),
        child: isLoading
            ? const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            : gradient != null
                ? ShaderMask(
                    shaderCallback: (bounds) => gradient!.createShader(bounds),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          icon,
                          style: const TextStyle(fontSize: 20),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          label,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        icon,
                        style: const TextStyle(fontSize: 20),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        label,
                        style: TextStyle(
                          color: textColor,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Email Auth Bottom Sheet
// ─────────────────────────────────────────────

class _EmailAuthBottomSheet extends ConsumerStatefulWidget {
  final bool isRegister;

  const _EmailAuthBottomSheet({required this.isRegister});

  @override
  ConsumerState<_EmailAuthBottomSheet> createState() =>
      _EmailAuthBottomSheetState();
}

class _EmailAuthBottomSheetState
    extends ConsumerState<_EmailAuthBottomSheet> {
  static final RegExp _emailRegex =
      RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
  final _emailCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _emailCtrl.dispose();
    _usernameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);
    final colors = ref.watch(themeProvider).colors;

    return Container(
      decoration: BoxDecoration(
        color: colors.panelBg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(
            color: colors.panelBorder.withValues(alpha: 0.5),
            width: 1,
          ),
        ),
      ),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              Text(
                widget.isRegister ? 'Create Account' : 'Login',
                style: TextStyle(
                  color: colors.textPrimary,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                style: TextStyle(color: colors.textPrimary),
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(color: colors.textPrimary.withValues(alpha: 0.6)),
                  filled: true,
                  fillColor: colors.background3,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.panelBorder, width: 1),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.panelBorder, width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.glowColor, width: 2),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email';
                  }
                  if (!_emailRegex.hasMatch(value.trim())) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _usernameCtrl,
                style: TextStyle(color: colors.textPrimary),
                decoration: InputDecoration(
                  labelText: 'Username',
                  labelStyle: TextStyle(color: colors.textPrimary.withValues(alpha: 0.6)),
                  filled: true,
                  fillColor: colors.background3,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.panelBorder, width: 1),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.panelBorder, width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: colors.glowColor, width: 2),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter a username';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: authState.isLoading
                      ? null
                      : () => _handleSubmit(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: null,
                    foregroundColor: colors.textPrimary,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: authState.isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : ShaderMask(
                          shaderCallback: (bounds) => LinearGradient(
                            colors: [
                              colors.buttonPrimary,
                              colors.buttonSecondary,
                            ],
                          ).createShader(bounds),
                          child: Text(
                            widget.isRegister ? 'Create Account' : 'Login',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 16),
              if (!widget.isRegister)
                Center(
                  child: TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        backgroundColor: Colors.transparent,
                        builder: (_) => _EmailAuthBottomSheet(isRegister: true),
                      );
                    },
                    child: Text(
                      "Don't have an account? Register",
                      style: TextStyle(
                        color: colors.textAccent,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    final notifier = ref.read(authNotifierProvider.notifier);
    final email = _emailCtrl.text.trim();
    final username = _usernameCtrl.text.trim();

    if (widget.isRegister) {
      await notifier.createAccount(
            email: email,
            username: username,
          );
    } else {
      await notifier.loginWithEmailUsername(
            email: email,
            username: username,
          );
    }

    final auth = ref.read(authNotifierProvider);
    if (mounted && auth.status == AuthStatus.authenticated) {
      Navigator.pop(context);
    }
  }
}
