import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/firebase_app_ready.dart';
import '../../../core/models/user_model.dart';
import '../data/auth_repository.dart';

// ─────────────────────────────────────────────
//  UserRepository
//  Firestore collection: /users/{uid}
//  Manages: profile · score · location · coins
// ─────────────────────────────────────────────

class UserRepository {
  final FirebaseFirestore? _db;

  UserRepository({FirebaseFirestore? db})
      : _db = db ??
            (isFirebaseInitialized ? FirebaseFirestore.instance : null);

  bool get _offline => _db == null;

  CollectionReference<Map<String, dynamic>> get _users =>
      _db!.collection('users');

  CollectionReference<Map<String, dynamic>> get _usernames =>
      _db!.collection('usernames');

  DocumentReference<Map<String, dynamic>> _doc(String uid) =>
      _users.doc(uid);

  // ── Create profile on first sign-in ──────
  Future<void> createUserProfile({
    required String uid,
    required String email,
    required String username,
    String? photoUrl,
    bool isGuest = false,
  }) async {
    if (_offline) return;
    final existing = await _doc(uid).get();
    if (existing.exists) {
      // Just update lastSeen if already exists
      await _doc(uid).update({'lastSeen': FieldValue.serverTimestamp()});
      return;
    }

    final user = UserModel(
      uid: uid,
      username: username,
      email: email,
      photoUrl: photoUrl,
      createdAt: DateTime.now(),
      lastSeen: DateTime.now(),
      isGuest: isGuest,
    );
    await _doc(uid).set(user.toFirestore());
    
    // Save username to usernames collection for uniqueness
    await _usernames.doc(username.toLowerCase()).set({
      'uid': uid,
      'email': email.toLowerCase(),
      'username': username,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<String?> findUsernameByUid(String uid) async {
    if (_offline) return null;
    final query = await _usernames.where('uid', isEqualTo: uid).limit(1).get();
    if (query.docs.isEmpty) return null;
    return query.docs.first.data()['username'] as String?;
  }

  // ── Fetch user profile ────────────────────
  Future<UserModel?> getUserProfile(String uid) async {
    if (_offline) return null;
    final doc = await _doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromFirestore(doc);
  }

  // ── Real-time user stream ─────────────────
  Stream<UserModel?> watchUserProfile(String uid) {
    if (_offline) return const Stream<UserModel?>.empty();
    return _doc(uid).snapshots().map((doc) {
      if (!doc.exists) return null;
      return UserModel.fromFirestore(doc);
    });
  }

  // ── Update username ───────────────────────
  Future<void> updateUsername(String uid, String username) async {
    if (_offline) return;
    // Check uniqueness using usernames collection
    final existingUsername = await _usernames.doc(username.toLowerCase()).get();
    if (existingUsername.exists && existingUsername.data()?['uid'] != uid) {
      throw Exception('Username already taken. Try a different one.');
    }
    
    // Get old username to delete from usernames collection
    final oldDoc = await _doc(uid).get();
    final oldUsername = oldDoc.data()?['username'] as String?;
    
    // Update user document
    await _doc(uid).update({
      'username': username,
      'lastSeen': FieldValue.serverTimestamp(),
    });
    
    // Update usernames collection
    if (oldUsername != null && oldUsername.isNotEmpty) {
      await _usernames.doc(oldUsername.toLowerCase()).delete();
    }
    final user = await _doc(uid).get();
    final email = (user.data()?['email'] as String? ?? '').toLowerCase();
    await _usernames.doc(username.toLowerCase()).set({
      'uid': uid,
      'email': email,
      'username': username,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ── Check if username is available ───────────
  Future<bool> checkUsernameAvailable(String username) async {
    if (_offline) return true;
    final doc = await _usernames.doc(username.toLowerCase()).get();
    return !doc.exists;
  }

  // ── Verify username belongs to uid ───────────
  Future<bool> verifyUsername(String username, String uid) async {
    if (_offline) return false;
    final doc = await _usernames.doc(username.toLowerCase()).get();
    if (!doc.exists) return false;
    return doc.data()?['uid'] == uid;
  }

  // ── Get uid by username ─────────────────────
  Future<String?> getUidByUsername(String username) async {
    if (_offline) return null;
    final doc = await _usernames.doc(username.toLowerCase()).get();
    if (!doc.exists) return null;
    return doc.data()?['uid'] as String?;
  }

  // ── Find user by username ───────────────────
  Future<String?> findEmailByUsername(String username) async {
    if (_offline) return null;
    final query = await _users
        .where('username', isEqualTo: username)
        .limit(1)
        .get();
    if (query.docs.isEmpty) return null;
    return query.docs.first.data()['email'] as String?;
  }

  // ── Verify email + username match ─────────────
  Future<bool> verifyEmailUsername(String email, String username) async {
    if (_offline) return false;
    final usernameDoc = await _usernames.doc(username.toLowerCase()).get();
    if (!usernameDoc.exists) return false;
    final data = usernameDoc.data();
    final storedEmail = (data?['email'] as String?)?.toLowerCase();
    return storedEmail == email.toLowerCase();
  }

  Future<({String uid, String email})?> getLoginMapping({
    required String email,
    required String username,
  }) async {
    if (_offline) return null;
    final usernameDoc = await _usernames.doc(username.toLowerCase()).get();
    if (!usernameDoc.exists) return null;
    final data = usernameDoc.data();
    final storedEmail = (data?['email'] as String?)?.toLowerCase();
    final uid = data?['uid'] as String?;
    if (uid == null || storedEmail != email.toLowerCase()) return null;
    return (uid: uid, email: storedEmail!);
  }

  Future<({String uid, String email, String username})?> getLoginMappingFromUsers({
    required String email,
    required String username,
  }) async {
    if (_offline) return null;
    final query = await _users.where('email', isEqualTo: email.toLowerCase()).limit(1).get();
    if (query.docs.isEmpty) return null;
    final doc = query.docs.first;
    final data = doc.data();
    final storedUsername = (data['username'] as String? ?? '').trim();
    if (storedUsername.toLowerCase() != username.toLowerCase()) return null;
    return (uid: doc.id, email: email.toLowerCase(), username: storedUsername);
  }

  Future<void> ensureUsernameIndex({
    required String uid,
    required String email,
    required String username,
  }) async {
    if (_offline) return;
    await _usernames.doc(username.toLowerCase()).set({
      'uid': uid,
      'email': email.toLowerCase(),
      'username': username,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> markLevelCompleted({
    required String uid,
    required int levelNumber,
  }) async {
    if (_offline) return;
    final nextLevel = levelNumber + 1;
    await _doc(uid).set({
      'completedLevels': FieldValue.arrayUnion([levelNumber]),
      'highestUnlockedLevel': nextLevel,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  // ── Store user location ───────────────────
  Future<void> updateLocation({
    required String uid,
    required double latitude,
    required double longitude,
    required String country,      // ISO code e.g. "IN"
    required String countryName,  // e.g. "India"
  }) async {
    if (_offline) return;
    await _doc(uid).update({
      'latitude': latitude,
      'longitude': longitude,
      'country': country,
      'countryName': countryName,
      'lastSeen': FieldValue.serverTimestamp(),
    });
  }

  // ── Submit score after game ───────────────
  Future<void> submitScore({
    required String uid,
    required int score,
    required int linesCleared,
    required int blocksPlaced,
  }) async {
    if (_offline) return;
    await _db!.runTransaction((tx) async {
      final ref = _doc(uid);
      final snap = await tx.get(ref);
      if (!snap.exists) return;

      final current = snap.data()!;
      final currentHigh = (current['highScore'] as num?)?.toInt() ?? 0;
      final currentTotal = (current['totalScore'] as num?)?.toInt() ?? 0;
      final currentGames = (current['gamesPlayed'] as num?)?.toInt() ?? 0;
      final currentLines = (current['totalLinesCleared'] as num?)?.toInt() ?? 0;
      final currentBlocks = (current['totalBlocksPlaced'] as num?)?.toInt() ?? 0;

      tx.update(ref, {
        'highScore': score > currentHigh ? score : currentHigh,
        'totalScore': currentTotal + score,
        'gamesPlayed': currentGames + 1,
        'totalLinesCleared': currentLines + linesCleared,
        'totalBlocksPlaced': currentBlocks + blocksPlaced,
        'lastSeen': FieldValue.serverTimestamp(),
      });
    });
  }

  // ── Update theme / avatar ─────────────────
  Future<void> updatePreferences({
    required String uid,
    String? selectedTheme,
    String? selectedAvatar,
  }) async {
    if (_offline) return;
    final updates = <String, dynamic>{
      'lastSeen': FieldValue.serverTimestamp(),
    };
    if (selectedTheme != null) updates['selectedTheme'] = selectedTheme;
    if (selectedAvatar != null) updates['selectedAvatar'] = selectedAvatar;
    await _doc(uid).update(updates);
  }

  // ── Add / deduct coins ────────────────────
  Future<void> addCoins(String uid, int amount) async {
    if (_offline) return;
    await _doc(uid).update({
      'coins': FieldValue.increment(amount),
      'lastSeen': FieldValue.serverTimestamp(),
    });
  }

  Future<bool> spendCoins(String uid, int amount) async {
    if (_offline) return false;
    bool success = false;
    await _db!.runTransaction((tx) async {
      final snap = await tx.get(_doc(uid));
      final current = (snap.data()?['coins'] as num?)?.toInt() ?? 0;
      if (current >= amount) {
        tx.update(_doc(uid), {'coins': current - amount});
        success = true;
      }
    });
    return success;
  }

  // ── Update lastSeen ───────────────────────
  Future<void> touchLastSeen(String uid) async {
    if (_offline) return;
    await _doc(uid).update({'lastSeen': FieldValue.serverTimestamp()});
  }

  // ── Delete user data (GDPR) ───────────────
  Future<void> deleteUserData(String uid) async {
    if (_offline) return;
    await _doc(uid).delete();
  }
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final userRepositoryProvider = Provider<UserRepository>((ref) {
  return UserRepository();
});

final userProfileProvider = StreamProvider.autoDispose<UserModel?>((ref) {
  final uid = ref.watch(currentUserProvider)?.uid;
  if (uid == null) return Stream.value(null);
  return ref.watch(userRepositoryProvider).watchUserProfile(uid);
});
