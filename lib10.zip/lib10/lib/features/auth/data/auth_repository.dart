import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../../../core/firebase_app_ready.dart';

// ─────────────────────────────────────────────
//  AuthRepository
// ─────────────────────────────────────────────
class AuthRepository {
  final FirebaseAuth? _auth;
  final GoogleSignIn? _googleSignIn;
  bool _persistenceSet = false;

  AuthRepository({FirebaseAuth? auth, GoogleSignIn? googleSignIn})
      : _auth = auth ??
            (isFirebaseInitialized ? FirebaseAuth.instance : null),
        _googleSignIn = googleSignIn ??
            (isFirebaseInitialized ? GoogleSignIn() : null);

  Future<void> _ensurePersistence() async {
    if (_persistenceSet || _offline) return;
    try {
      await _auth!.setPersistence(Persistence.LOCAL);
      _persistenceSet = true;
    } catch (e) {
      // Persistence might already be set, ignore error
    }
  }

  bool get _offline => _auth == null;

  Stream<User?> get authStateChanges async* {
    await _ensurePersistence();
    if (_offline) {
      yield* const Stream<User?>.empty();
    } else {
      yield* _auth!.authStateChanges();
    }
  }

  User? get currentUser => _offline ? null : _auth!.currentUser;

  String? get currentUid => currentUser?.uid;

  Future<UserCredential?> signInWithGoogle() async {
    _requireFirebase();
    try {
      final googleUser = await _googleSignIn!.signIn();
      if (googleUser == null) return null;
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken:     googleAuth.idToken,
      );
      return await _auth!.signInWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      throw AuthException.fromFirebase(e);
    }
  }

  Future<UserCredential> signInAnonymously() async {
    _requireFirebase();
    try {
      return await _auth!.signInAnonymously();
    } on FirebaseAuthException catch (e) {
      throw AuthException.fromFirebase(e);
    }
  }

  Future<UserCredential> createUserWithEmail(
      {required String email, required String password}) async {
    _requireFirebase();
    try {
      return await _auth!.createUserWithEmailAndPassword(
          email: email, password: password);
    } on FirebaseAuthException catch (e) {
      throw AuthException.fromFirebase(e);
    }
  }

  Future<UserCredential> signInWithEmail(
      {required String email, required String password}) async {
    _requireFirebase();
    try {
      return await _auth!.signInWithEmailAndPassword(
          email: email, password: password);
    } on FirebaseAuthException catch (e) {
      throw AuthException.fromFirebase(e);
    }
  }

  Future<UserCredential> signInWithCustomToken(String customToken) async {
    _requireFirebase();
    try {
      return await _auth!.signInWithCustomToken(customToken);
    } on FirebaseAuthException catch (e) {
      throw AuthException.fromFirebase(e);
    }
  }

  Future<UserCredential?> linkAnonymousWithGoogle() async {
    _requireFirebase();
    try {
      final googleUser = await _googleSignIn!.signIn();
      if (googleUser == null) return null;
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken:     googleAuth.idToken,
      );
      return await _auth!.currentUser?.linkWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      throw AuthException.fromFirebase(e);
    }
  }

  Future<void> signOut() async {
    if (_offline) return;
    await _googleSignIn?.signOut();
    await _auth!.signOut();
  }

  void _requireFirebase() {
    if (_offline) {
      throw const AuthException(
        code: 'firebase-not-configured',
        message: 'Firebase is not configured. Run flutterfire configure.',
      );
    }
  }
}

// ─────────────────────────────────────────────
//  AuthException
// ─────────────────────────────────────────────
class AuthException implements Exception {
  final String code;
  final String message;
  const AuthException({required this.code, required this.message});

  factory AuthException.fromFirebase(FirebaseAuthException e) {
    const messages = {
      'user-not-found':         'No account found with this email.',
      'wrong-password':         'Username and Email ID not found',
      'email-already-in-use':   'An account already exists with this email.',
      'weak-password':          'Password must be at least 6 characters.',
      'invalid-email':          'Please enter a valid email address.',
      'too-many-requests':      'Too many attempts. Please try again later.',
      'network-request-failed': 'No internet connection.',
    };
    return AuthException(
      code:    e.code,
      message: messages[e.code] ?? e.message ?? 'Authentication failed.',
    );
  }

  @override
  String toString() => message;
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────
final authRepositoryProvider = Provider<AuthRepository>(
    (_) => AuthRepository());

final authStateProvider = StreamProvider<User?>((ref) =>
    ref.watch(authRepositoryProvider).authStateChanges);

final currentUserProvider = Provider<User?>((ref) =>
    ref.watch(authStateProvider).valueOrNull);
