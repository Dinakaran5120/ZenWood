import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:async';
import '../../../core/models/user_model.dart';
import '../../auth/domain/auth_notifier.dart';

// ─────────────────────────────────────────────
//  LeaderboardRepository
//  Collection: /leaderboard/{uid}
//  Indexes needed in Firestore console:
//    score DESC
//    country ASC, score DESC
// ─────────────────────────────────────────────

class LeaderboardRepository {
  final FirebaseFirestore _db;

  LeaderboardRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _lb =>
      _db.collection('leaderboard');

  // ── Upsert entry after game ───────────────
  /// Writes all-time high score and updates the 24-hour rolling daily score.
  Future<void> submitScore({
    required String uid,
    required String username,
    required int score,
    String? photoUrl,
    String? country,
    String? countryName,
  }) async {
    final docRef = _lb.doc(uid);
    final snap   = await docRef.get();
    final data   = snap.exists ? (snap.data() ?? {}) : <String, dynamic>{};

    final currentScore = (data['score'] as num?)?.toInt() ?? 0;
    final newAllTime   = score > currentScore ? score : currentScore;

    // ── 24-hour daily window logic ─────────────────────────────────────────
    final now = DateTime.now().toUtc();
    final storedWindowStart =
        (data['dailyWindowStart'] as Timestamp?)?.toDate().toUtc();

    int newDailyScore;
    DateTime newWindowStart;

    final windowStillActive = storedWindowStart != null &&
        now.difference(storedWindowStart).inHours < 24;

    if (windowStillActive) {
      final currentDailyScore = (data['dailyScore'] as num?)?.toInt() ?? 0;
      // Keep the best score within the current window
      newDailyScore   = score > currentDailyScore ? score : currentDailyScore;
      newWindowStart  = storedWindowStart;
    } else {
      // Start a fresh 24-hour window
      newDailyScore  = score;
      newWindowStart = now;
    }

    await docRef.set(
      LeaderboardEntry(
        uid: uid,
        username: username,
        photoUrl: photoUrl,
        score: newAllTime,
        dailyScore: newDailyScore,
        dailyWindowStart: newWindowStart,
        country: country,
        countryName: countryName,
        updatedAt: now,
      ).toFirestore(),
      SetOptions(merge: true),
    );
  }

  // ── Global top 100 (all-time) ─────────────
  Future<List<LeaderboardEntry>> getGlobalLeaderboard({int limit = 100}) async {
    final snap = await _lb
        .orderBy('score', descending: true)
        .limit(limit)
        .get();
    return _ranked(snap.docs.map(LeaderboardEntry.fromFirestore).toList());
  }

  // ── Real-time global top 50 (all-time) ───
  Stream<List<LeaderboardEntry>> watchGlobalLeaderboard({int limit = 500}) {
    return _lb
        .orderBy('score', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) =>
            _ranked(snap.docs.map(LeaderboardEntry.fromFirestore).toList()));
  }

  // ── Global top 50 — daily (24-hour window) ─
  /// Returns entries whose dailyWindowStart is within the last 24 hours,
  /// sorted by dailyScore DESC, client-side (avoids Firestore composite index).
  Future<List<LeaderboardEntry>> getDailyLeaderboard({int limit = 50}) async {
    final cutoff = Timestamp.fromDate(
      DateTime.now().toUtc().subtract(const Duration(hours: 24)),
    );
    final snap = await _lb
        .where('dailyWindowStart', isGreaterThan: cutoff)
        .orderBy('dailyWindowStart', descending: true)
        .limit(limit * 2) // fetch extra; we sort client-side
        .get();

    final entries = snap.docs.map(LeaderboardEntry.fromFirestore).toList()
      ..sort((a, b) => b.dailyScore.compareTo(a.dailyScore));

    return _ranked(entries.take(limit).toList());
  }

  Stream<List<LeaderboardEntry>> watchDailyLeaderboard({int limit = 500}) {
    final cutoff = Timestamp.fromDate(
      DateTime.now().toUtc().subtract(const Duration(hours: 24)),
    );
    return _lb
        .where('dailyWindowStart', isGreaterThan: cutoff)
        .orderBy('dailyWindowStart', descending: true)
        .limit(limit * 2)
        .snapshots()
        .map((snap) {
      final entries =
          snap.docs.map(LeaderboardEntry.fromFirestore).toList()
            ..sort((a, b) => b.dailyScore.compareTo(a.dailyScore));
      return _ranked(entries.take(limit).toList());
    });
  }

  // ── Country leaderboard ───────────────────
  Future<List<LeaderboardEntry>> getCountryLeaderboard({
    required String country,
    int limit = 500,
  }) async {
    final snap = await _lb
        .where('country', isEqualTo: country)
        .orderBy('score', descending: true)
        .limit(limit)
        .get();
    return _ranked(snap.docs.map(LeaderboardEntry.fromFirestore).toList());
  }

  Stream<List<LeaderboardEntry>> watchCountryLeaderboard({
    required String country,
    int limit = 500,
  }) {
    return _lb
        .where('country', isEqualTo: country)
        .orderBy('score', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) =>
            _ranked(snap.docs.map(LeaderboardEntry.fromFirestore).toList()));
  }

  // ── Get my all-time rank ──────────────────
  Future<int> getMyRank(String uid) async {
    final mySnap = await _lb.doc(uid).get();
    if (!mySnap.exists) return -1;
    final myScore = (mySnap.data()?['score'] as num?)?.toInt() ?? 0;
    final countSnap = await _lb
        .where('score', isGreaterThan: myScore)
        .count()
        .get();
    return (countSnap.count ?? 0) + 1;
  }

  List<LeaderboardEntry> _ranked(List<LeaderboardEntry> entries) {
    for (int i = 0; i < entries.length; i++) {
      entries[i].rank = i + 1;
    }
    return entries;
  }
}

// ─────────────────────────────────────────────
//  LeaderboardState + Notifier
// ─────────────────────────────────────────────

enum LeaderboardFilter { global, daily, country }

class LeaderboardState {
  final List<LeaderboardEntry> entries;
  final LeaderboardFilter filter;
  final bool isLoading;
  final String? error;
  final int? myRank;

  const LeaderboardState({
    this.entries = const [],
    this.filter = LeaderboardFilter.global,
    this.isLoading = false,
    this.error,
    this.myRank,
  });

  LeaderboardState copyWith({
    List<LeaderboardEntry>? entries,
    LeaderboardFilter? filter,
    bool? isLoading,
    String? error,
    int? myRank,
  }) =>
      LeaderboardState(
        entries: entries ?? this.entries,
        filter: filter ?? this.filter,
        isLoading: isLoading ?? this.isLoading,
        error: error,
        myRank: myRank ?? this.myRank,
      );
}

class LeaderboardNotifier extends StateNotifier<LeaderboardState> {
  final LeaderboardRepository _repo;
  final AuthState _authState;
  StreamSubscription<List<LeaderboardEntry>>? _entriesSub;

  LeaderboardNotifier(this._repo, this._authState)
      : super(const LeaderboardState()) {
    loadGlobal();
  }

  Future<void> loadGlobal() async {
    state = state.copyWith(isLoading: true, filter: LeaderboardFilter.global);
    try {
      final myRank = _authState.user != null
          ? await _repo.getMyRank(_authState.user!.uid)
          : null;
      await _entriesSub?.cancel();
      _entriesSub = _repo.watchGlobalLeaderboard().listen(
        (entries) {
          state = state.copyWith(
            entries: entries,
            isLoading: false,
            myRank: myRank,
          );
        },
        onError: (Object e) {
          state = state.copyWith(isLoading: false, error: e.toString());
        },
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> loadDaily() async {
    state = state.copyWith(isLoading: true, filter: LeaderboardFilter.daily);
    try {
      await _entriesSub?.cancel();
      _entriesSub = _repo.watchDailyLeaderboard().listen(
        (entries) {
          state = state.copyWith(entries: entries, isLoading: false);
        },
        onError: (Object e) {
          state = state.copyWith(isLoading: false, error: e.toString());
        },
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> loadCountry() async {
    final country = _authState.user?.country;
    if (country == null || country == 'Unknown') {
      state = state.copyWith(error: 'No country data available');
      return;
    }
    state = state.copyWith(isLoading: true, filter: LeaderboardFilter.country);
    try {
      await _entriesSub?.cancel();
      _entriesSub = _repo.watchCountryLeaderboard(country: country).listen(
        (entries) {
          state = state.copyWith(entries: entries, isLoading: false);
        },
        onError: (Object e) {
          state = state.copyWith(isLoading: false, error: e.toString());
        },
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void switchFilter(LeaderboardFilter f) {
    switch (f) {
      case LeaderboardFilter.global:  loadGlobal();  break;
      case LeaderboardFilter.daily:   loadDaily();   break;
      case LeaderboardFilter.country: loadCountry(); break;
    }
  }

  @override
  void dispose() {
    _entriesSub?.cancel();
    super.dispose();
  }
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final leaderboardRepositoryProvider = Provider<LeaderboardRepository>((ref) {
  return LeaderboardRepository();
});

final leaderboardProvider =
    StateNotifierProvider<LeaderboardNotifier, LeaderboardState>((ref) {
  return LeaderboardNotifier(
    ref.read(leaderboardRepositoryProvider),
    ref.read(authNotifierProvider),
  );
});
