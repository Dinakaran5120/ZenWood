package com.yourcompany.blockblast

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
