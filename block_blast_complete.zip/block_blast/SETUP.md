# Block Blast — Quick Setup Guide

## Folder structure you should see after extracting
```
block_blast/
├── lib/                    ← all Dart source code
│   ├── main.dart
│   ├── firebase_options.dart
│   ├── core/
│   │   ├── analytics/
│   │   ├── constants/
│   │   ├── models/
│   │   ├── performance/
│   │   ├── services/
│   │   └── theme/
│   └── features/
│       ├── admob/
│       ├── auth/
│       ├── cloud_save/
│       ├── daily_reward/
│       ├── game/
│       ├── leaderboard/
│       ├── spin_wheel/
│       └── store/
├── android/                ← Android project files
├── assets/
│   ├── audio/              ← put your MP3 files here
│   └── images/             ← put your PNG files here
├── pubspec.yaml            ← dependencies
└── SETUP.md                ← this file
```

---

## Step 1 — Install Flutter (if not done)
Download from: https://flutter.dev/docs/get-started/install/windows
Extract to C:\flutter and add C:\flutter\bin to your PATH

## Step 2 — Open project in VSCode
```
File → Open Folder → select the block_blast folder
```

## Step 3 — Get packages
Open terminal in VSCode (Ctrl + `) and run:
```
flutter pub get
```

## Step 4 — Add audio files
Put 6 MP3 files in assets/audio/ folder (see assets/audio/README.txt)
Download free sounds from: https://mixkit.co/free-sound-effects/game/

## Step 5 — Firebase setup (required)
```
dart pub global activate flutterfire_cli
flutterfire configure
```
Select your Firebase project → it generates lib/firebase_options.dart automatically

## Step 6 — Run the app
Start your Android emulator first, then:
```
flutter run
```

---

## To skip Firebase for quick local testing

Open lib/main.dart and comment out these 3 lines:
```dart
// await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
// await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(true);
// FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
```

Then in lib/features/auth/domain/auth_notifier.dart
change _init() to directly set authenticated state for testing.

---

## All 40 source files included

Core:
- lib/main.dart
- lib/firebase_options.dart (stub — replace after flutterfire configure)
- lib/core/analytics/analytics_service.dart
- lib/core/constants/game_constants.dart
- lib/core/models/user_model.dart
- lib/core/performance/performance_optimizer.dart
- lib/core/services/location_service.dart
- lib/core/services/sound_manager.dart
- lib/core/theme/game_theme.dart

Features:
- lib/features/admob/admob_service.dart
- lib/features/auth/data/auth_repository.dart
- lib/features/auth/data/user_repository.dart
- lib/features/auth/domain/auth_notifier.dart
- lib/features/auth/presentation/login_screen.dart
- lib/features/cloud_save/data/cloud_save_service.dart
- lib/features/daily_reward/data/daily_reward_service.dart
- lib/features/daily_reward/presentation/daily_reward_screen.dart
- lib/features/game/bloc/game_notifier.dart
- lib/features/game/components/blast_effect.dart
- lib/features/game/components/forest_background.dart
- lib/features/game/components/game_grid.dart
- lib/features/game/components/theme_backgrounds.dart
- lib/features/game/game_screen.dart
- lib/features/leaderboard/data/leaderboard_repository.dart
- lib/features/leaderboard/presentation/leaderboard_screen.dart
- lib/features/spin_wheel/spin_wheel_screen.dart
- lib/features/store/store_models.dart
- lib/features/store/store_repository.dart
- lib/features/store/store_screen.dart

Android:
- android/app/build.gradle
- android/app/proguard-rules.pro
- android/app/src/main/AndroidManifest.xml
- android/app/src/main/kotlin/.../MainActivity.kt
- android/app/src/main/res/values/styles.xml
- android/app/src/main/res/drawable/launch_background.xml
- android/build.gradle
- android/gradle.properties
- android/settings.gradle
- android/gradle/wrapper/gradle-wrapper.properties
- android/app/google-services.json (stub — replace with real one)

Config:
- pubspec.yaml
- analysis_options.yaml
- firestore.rules
- firestore.indexes.json
- flutter_native_splash.yaml
- PLAYSTORE_CHECKLIST.md
- SETUP.md
