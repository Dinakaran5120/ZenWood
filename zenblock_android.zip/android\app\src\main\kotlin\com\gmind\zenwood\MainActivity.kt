package com.gmind.zenwood

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
