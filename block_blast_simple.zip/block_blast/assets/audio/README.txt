AUDIO FILES — Place your MP3 files here
========================================

Required files (rename your MP3s to match exactly):

  place_block.mp3     — short click/thud when block is placed
  line_clear.mp3      — whoosh or chime when row is cleared  
  combo.mp3           — rising chime for combo clears
  game_over.mp3       — short sad tone when game ends
  tap.mp3             — UI click for button taps
  forest_ambient.mp3  — looping background music (forest/nature)

Free sound sources:
  https://mixkit.co/free-sound-effects/game/
  https://freesound.org
  https://pixabay.com/sound-effects/

NOTE: The app will crash with "Unable to load asset" if these
files do not exist. Even a silent/empty MP3 works for testing.
