IMAGE FILES — Place your PNG/JPG files here
============================================

Required for full app build:

  app_icon.png        — 1024x1024 PNG, no transparency (app icon)
  app_icon_fg.png     — 1024x1024 PNG with transparency (adaptive icon foreground)
  splash_logo.png     — your logo for splash screen (any size, transparent bg)

Optional:
  branding.png        — small branding shown at bottom of splash screen

Tools to create icons:
  https://icon.kitchen          — free app icon generator
  https://canva.com             — design tool
  https://appicon.co            — resize to all required sizes

NOTE: Without app_icon.png the app still runs fine on emulator.
It is only needed when you run: dart run flutter_launcher_icons
