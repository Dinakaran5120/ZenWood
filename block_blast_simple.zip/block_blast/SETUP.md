# Block Blast — Run Instructions

## This version has NO Firebase, NO AdMob
Pure game — runs immediately with 3 commands.

## Commands to run
```
flutter clean
flutter pub get
flutter run
```

## What you will see
1. Dark green splash → game screen opens
2. Forest animated background with fireflies
3. 8x8 grid with 3 block pieces in tray
4. Drag pieces onto grid to play
5. Complete lines to clear and score points

## Controls
- Long press + drag a tray piece onto the grid
- Green = valid placement, Red = invalid
- Settings button (top right) → change theme, toggle sound

## Adding Firebase later (Step 2)
When you are ready, tell me and I will guide you to:
1. Create Firebase project (free)
2. Run flutterfire configure
3. Add back Firebase packages one by one
4. Test each feature before adding next

## Adding AdMob later (Step 3)  
1. Create AdMob account (free)
2. Get real ad unit IDs
3. Add google_mobile_ads package
4. Add banner + rewarded ads
