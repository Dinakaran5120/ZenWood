# ══════════════════════════════════════════════
#  BLOCK BLAST — Play Store Release Checklist
# ══════════════════════════════════════════════

## ✅ CODE & BUILD

### Firebase
- [ ] Run: flutterfire configure --project=YOUR_PROJECT_ID
- [ ] Replace lib/firebase_options.dart with generated file
- [ ] Enable Auth methods: Google, Email, Anonymous
- [ ] Enable Firestore + Storage + Analytics in Firebase Console
- [ ] Deploy rules: firebase deploy --only firestore
- [ ] Add SHA-1 fingerprint to Firebase Android app

### AdMob
- [ ] Create AdMob account at admob.google.com
- [ ] Replace AdIds._prod* constants in admob_service.dart
- [ ] Replace AdMob App ID in AndroidManifest.xml
- [ ] Test with test device ID added to RequestConfiguration

### Signing
- [ ] Generate release keystore:
      keytool -genkey -v -keystore blockblast-release.jks \
        -keyalg RSA -keysize 2048 -validity 10000 -alias blockblast
- [ ] Create android/key.properties (never commit to git)
- [ ] Add android/key.properties to .gitignore
- [ ] Add android/blockblast-release.jks to .gitignore

### App identity
- [ ] Set applicationId in build.gradle: com.yourcompany.blockblast
- [ ] Set versionCode and versionName in pubspec.yaml
- [ ] Add app icon: flutter_launcher_icons
- [ ] Generate splash: dart run flutter_native_splash:create

### Dependencies
- [ ] flutter pub get
- [ ] dart pub global activate flutterfire_cli
- [ ] flutter pub add firebase_crashlytics firebase_analytics
- [ ] flutter pub add flutter_native_splash flutter_launcher_icons

---

## ✅ PLAY STORE ASSETS

### Required
- [ ] App icon: 512×512 PNG (no alpha)
- [ ] Feature graphic: 1024×500 PNG
- [ ] Screenshots: min 2, portrait (1080×1920 recommended)
- [ ] Short description: max 80 chars
- [ ] Full description: max 4000 chars
- [ ] Content rating questionnaire completed
- [ ] Privacy policy URL (required for apps with accounts/ads)

### Optional but recommended
- [ ] Promo video (YouTube URL)
- [ ] Phone screenshots (min 2, max 8)
- [ ] Tablet screenshots

---

## ✅ PLAY STORE SETTINGS

### App content
- [ ] Content rating: Everyone (PEGI 3 / Everyone)
- [ ] Target audience: 13+ (due to ads)
- [ ] Ads declaration: YES — contains ads
- [ ] Data safety form filled:
  - Location: Approximate (optional, not shared with third parties)
  - Personal info: Name, Email (account management)
  - App activity: In-app purchases, App interactions
  - Financial info: Purchase history

### Pricing & distribution
- [ ] Free app (revenue from ads + IAP)
- [ ] All countries selected (or specific list)
- [ ] Contains ads: Yes
- [ ] In-app purchases: Yes

---

## ✅ FIREBASE CONFIGURATION

### Firestore Indexes (create in console)
Collection: leaderboard
  - score DESC
  - country ASC + score DESC (composite)
Collection: users
  - username ASC

### Security rules: deploy firestore.rules

### Crashlytics
- [ ] Enabled in Firebase Console
- [ ] Test crash: FirebaseCrashlytics.instance.crash()
- [ ] Verify reports appear in Firebase Console

---

## ✅ FINAL BUILD COMMANDS

```bash
# 1. Get dependencies
flutter pub get

# 2. Generate splash screen
dart run flutter_native_splash:create

# 3. Generate app icons (after adding flutter_launcher_icons to pubspec)
dart run flutter_launcher_icons

# 4. Build release AAB (recommended for Play Store)
flutter build appbundle --release --obfuscate \
  --split-debug-info=build/debug-info

# 5. Build release APK (for direct testing)
flutter build apk --release --split-per-abi

# 6. Test release build on device
flutter install --release

# 7. Upload to Play Store
# Upload build/app/outputs/bundle/release/app-release.aab
```

---

## ✅ PERFORMANCE CHECKLIST

- [ ] Test on low-end device (2GB RAM)
- [ ] Profile with Flutter DevTools: no jank >16ms
- [ ] Cold start time < 3 seconds
- [ ] APK size < 30MB (AAB will be smaller after Play delivery)
- [ ] No memory leaks (check with DevTools Memory tab)
- [ ] Background → foreground: animations resume correctly
- [ ] No crash on permission denial (location, ads)
- [ ] Offline mode: game works without internet

---

## ✅ TESTING CHECKLIST

- [ ] Fresh install → Login → Play → Score saved
- [ ] Google Sign-In works on real device
- [ ] Anonymous sign-in → play → link to Google
- [ ] Leaderboard loads within 3 seconds
- [ ] Daily reward: claims once per day
- [ ] Spin wheel: once per 24 hours
- [ ] Store: buy item → deducted from coins → item in inventory
- [ ] Equip hat/wing/glasses → shows in avatar preview
- [ ] Banner ad visible on game screen
- [ ] Interstitial shows between games (after 2nd game)
- [ ] Rewarded ad: watch → coins credited
- [ ] Continue-after-fail: watch ad → game continues
- [ ] Game over detected correctly when no moves remain
- [ ] Combo scoring works: 2+ lines cleared together

---

## ✅ ADMOB POLICIES (MUST READ)

- Never click your own ads
- Never encourage users to click ads
- Do not show ads on loading/splash screens
- Interstitials must not appear before content loads
- Rewarded ads must be clearly voluntary
- Banner ads must not be placed near interactive elements (buttons)
  — keep banner at very bottom, away from game grid

---

## ✅ STORE LISTING TEMPLATE

Short description (80 chars):
"Enchanted block puzzle game — blast your way to the top of the leaderboard!"

Keywords: block blast, puzzle game, block puzzle, casual game, forest theme
