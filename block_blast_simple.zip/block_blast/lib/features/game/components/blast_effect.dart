import 'dart:math';
import 'package:flutter/material.dart';
import '../../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  BlastEffect — spawned on line/col clear
//  Overlay widget positioned over the grid
// ─────────────────────────────────────────────

class BlastEffect extends StatefulWidget {
  final Offset position;     // centre of blast in local coords
  final GameThemeColors colors;
  final VoidCallback onDone;

  const BlastEffect({
    super.key,
    required this.position,
    required this.colors,
    required this.onDone,
  });

  @override
  State<BlastEffect> createState() => _BlastEffectState();
}

class _BlastEffectState extends State<BlastEffect>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late List<_Shard> _shards;
  final _rng = Random();

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )
      ..forward()
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) widget.onDone();
      });

    _shards = List.generate(18, (_) {
      final angle = _rng.nextDouble() * pi * 2;
      final speed = _rng.nextDouble() * 80 + 30;
      return _Shard(
        angle: angle,
        speed: speed,
        size: _rng.nextDouble() * 6 + 3,
        colorIndex: _rng.nextInt(3),
        spin: (_rng.nextDouble() - 0.5) * 10,
      );
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (ctx, _) => CustomPaint(
          painter: _BlastPainter(
            shards: _shards,
            progress: _ctrl.value,
            origin: widget.position,
            colors: widget.colors,
          ),
        ),
      ),
    );
  }
}

class _Shard {
  final double angle, speed, size, spin;
  final int colorIndex;
  _Shard({
    required this.angle,
    required this.speed,
    required this.size,
    required this.spin,
    required this.colorIndex,
  });
}

class _BlastPainter extends CustomPainter {
  final List<_Shard> shards;
  final double progress;
  final Offset origin;
  final GameThemeColors colors;

  const _BlastPainter({
    required this.shards,
    required this.progress,
    required this.origin,
    required this.colors,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final eased = Curves.easeOut.transform(progress);
    final fade = 1.0 - progress;

    // Central flash
    if (progress < 0.3) {
      final flashPaint = Paint()
        ..color = colors.glowColor.withOpacity((0.3 - progress) * 2)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20);
      canvas.drawCircle(origin, 30 * progress / 0.3, flashPaint);
    }

    // Shards
    for (final s in shards) {
      final dist = eased * s.speed;
      final x = origin.dx + cos(s.angle) * dist;
      final y = origin.dy + sin(s.angle) * dist;

      final shardColors = [
        colors.particleColor1,
        colors.particleColor2,
        colors.particleColor3,
      ];
      final color = shardColors[s.colorIndex].withOpacity(fade);

      final paint = Paint()
        ..color = color
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, s.size * 0.4);

      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(s.spin * progress);

      // Diamond shard
      final path = Path()
        ..moveTo(0, -s.size)
        ..lineTo(s.size * 0.5, 0)
        ..lineTo(0, s.size * 0.6)
        ..lineTo(-s.size * 0.5, 0)
        ..close();
      canvas.drawPath(path, paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_BlastPainter o) => true;
}

// ─────────────────────────────────────────────
//  Combo Text Flyup
// ─────────────────────────────────────────────

class ComboFlyup extends StatefulWidget {
  final int combo;
  final Offset position;
  final GameThemeColors colors;
  final VoidCallback onDone;

  const ComboFlyup({
    super.key,
    required this.combo,
    required this.position,
    required this.colors,
    required this.onDone,
  });

  @override
  State<ComboFlyup> createState() => _ComboFlyupState();
}

class _ComboFlyupState extends State<ComboFlyup>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  late Animation<double> _y;
  late Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )
      ..forward()
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) widget.onDone();
      });

    _scale = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.3), weight: 30),
      TweenSequenceItem(tween: Tween(begin: 1.3, end: 1.0), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.0), weight: 50),
    ]).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));

    _y = Tween(begin: 0.0, end: -60.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOut),
    );

    _opacity = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.0), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 30),
    ]).animate(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: widget.position.dx - 60,
      top: widget.position.dy - 30,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (ctx, _) => Transform.translate(
          offset: Offset(0, _y.value),
          child: Transform.scale(
            scale: _scale.value,
            child: Opacity(
              opacity: _opacity.value,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: widget.colors.panelBg.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: widget.colors.glowColor,
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: widget.colors.glowColor.withOpacity(0.5),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Text(
                  'COMBO ×${widget.combo}!',
                  style: TextStyle(
                    color: widget.colors.textAccent,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                    shadows: [
                      Shadow(
                        color: widget.colors.glowColor,
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
