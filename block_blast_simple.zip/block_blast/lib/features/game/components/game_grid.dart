import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../bloc/game_notifier.dart';
import '../../../core/constants/game_constants.dart';
import '../../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  GameGrid — 8×8 board + tray + drag & drop
//  FIX: GameOverPanel in Stack not Column
//  FIX: Drag uses onPanStart (immediate, no long press)
// ─────────────────────────────────────────────

class GameGrid extends ConsumerStatefulWidget {
  final GameThemeData theme;
  const GameGrid({super.key, required this.theme});

  @override
  ConsumerState<GameGrid> createState() => _GameGridState();
}

class _GameGridState extends ConsumerState<GameGrid>
    with TickerProviderStateMixin {
  int?        _draggingTrayIndex;
  BlockShape? _draggingShape;
  Offset?     _dragPosition;
  int?        _hoverRow, _hoverCol;
  bool        _canDrop = false;

  late AnimationController _comboCtrl;
  final GlobalKey _gridKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _comboCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: GameConstants.comboTextDurationMs),
    );
  }

  @override
  void dispose() {
    _comboCtrl.dispose();
    super.dispose();
  }

  // ── Snap cell calculation ─────────────────
  ({int row, int col})? _snapCell(Offset globalOffset) {
    if (_draggingShape == null) return null;
    final box = _gridKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return null;
    final local = box.globalToLocal(globalOffset);
    final ct = GameConstants.cellSize + GameConstants.cellGap;
    final adjLocal = Offset(
      local.dx - (_draggingShape!.width  / 2.0) * ct,
      local.dy - (_draggingShape!.height / 2.0) * ct - 30,
    );
    final col = (adjLocal.dx / ct).round();
    final row = (adjLocal.dy / ct).round();
    return (row: row, col: col);
  }

  void _onDragStart(int idx, BlockShape shape, Offset globalPos) {
    setState(() {
      _draggingTrayIndex = idx;
      _draggingShape     = shape;
      _dragPosition      = globalPos;
    });
    _onDragUpdate(globalPos);
  }

  void _onDragUpdate(Offset globalOffset) {
    final snap = _snapCell(globalOffset);
    setState(() {
      _dragPosition = globalOffset;
      _hoverRow = snap?.row;
      _hoverCol = snap?.col;
      _canDrop  = snap != null && _draggingShape != null
          ? ref.read(gameProvider.notifier).canPlace(_draggingShape!, snap.row, snap.col)
          : false;
    });
  }

  Future<void> _onDragEnd() async {
    if (_draggingTrayIndex != null &&
        _draggingShape != null &&
        _hoverRow != null &&
        _hoverCol != null &&
        _canDrop) {
      await ref.read(gameProvider.notifier)
          .placeBlock(_draggingTrayIndex!, _hoverRow!, _hoverCol!);
    }
    setState(() {
      _draggingTrayIndex = null;
      _draggingShape     = null;
      _dragPosition      = null;
      _hoverRow          = null;
      _hoverCol          = null;
      _canDrop           = false;
    });
  }

  bool _isCellHovered(int r, int c) {
    if (_draggingShape == null || _hoverRow == null || _hoverCol == null) return false;
    for (final cell in _draggingShape!.cells) {
      if (_hoverRow! + cell[0] == r && _hoverCol! + cell[1] == c) return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final gs     = ref.watch(gameProvider);
    final colors = widget.theme.colors;
    final G      = GameConstants.gridSize;
    final ct     = GameConstants.cellSize + GameConstants.cellGap;
    final gridPx = ct * G - GameConstants.cellGap;

    // ── Wrap everything in a Stack so GameOverPanel can overlay ──
    return Stack(
      children: [
        Column(
          children: [
            // Score panel
            _ScorePanel(theme: widget.theme, gameState: gs),
            const SizedBox(height: 16),

            // Grid
            Listener(
              onPointerMove: (e) => _onDragUpdate(e.position),
              onPointerUp:   (_) => _onDragEnd(),
              child: SizedBox(
                width: gridPx, height: gridPx,
                child: Stack(
                  children: [
                    _GridBackground(gridPx: gridPx, colors: colors, gridKey: _gridKey),
                    for (int r = 0; r < G; r++)
                      for (int c = 0; c < G; c++)
                        _GridCell(
                          row: r, col: c,
                          state: gs.grid[r][c],
                          colors: colors,
                          isHovered: _isCellHovered(r, c),
                          canDrop: _canDrop,
                          theme: widget.theme,
                        ),
                    if (_draggingShape != null && _hoverRow != null && _hoverCol != null)
                      _GhostOverlay(
                        shape: _draggingShape!, row: _hoverRow!, col: _hoverCol!,
                        canDrop: _canDrop, colors: colors,
                      ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Tray
            _TrayRow(
              theme: widget.theme,
              gameState: gs,
              onDragStart: _onDragStart,
            ),
          ],
        ),

        // ── Game Over overlay sits on top in the Stack ──
        if (gs.isGameOver)
          _GameOverPanel(
            theme: widget.theme,
            score: gs.score,
            highScore: gs.highScore,
            onRestart: () => ref.read(gameProvider.notifier).resetGame(),
          ),
      ],
    );
  }
}

// ── Grid Background ────────────────────────────────────────────────────────

class _GridBackground extends StatelessWidget {
  final double gridPx;
  final GameThemeColors colors;
  final GlobalKey gridKey;
  const _GridBackground({required this.gridPx, required this.colors, required this.gridKey});

  @override
  Widget build(BuildContext context) {
    return Container(
      key: gridKey,
      width: gridPx, height: gridPx,
      decoration: BoxDecoration(
        color: colors.gridBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.panelBorder.withOpacity(0.5), width: 1.5),
        boxShadow: [BoxShadow(color: colors.glowColor.withOpacity(0.15), blurRadius: 20, spreadRadius: 2)],
      ),
      child: CustomPaint(painter: _GridLinePainter(colors: colors)),
    );
  }
}

class _GridLinePainter extends CustomPainter {
  final GameThemeColors colors;
  const _GridLinePainter({required this.colors});
  @override
  void paint(Canvas canvas, Size size) {
    final G  = GameConstants.gridSize;
    final ct = GameConstants.cellSize + GameConstants.cellGap;
    final p  = Paint()..color = colors.gridLine.withOpacity(0.4)..strokeWidth = 0.5;
    for (int i = 0; i <= G; i++) {
      final pos = i * ct;
      canvas.drawLine(Offset(pos, 0), Offset(pos, size.height), p);
      canvas.drawLine(Offset(0, pos), Offset(size.width, pos), p);
    }
  }
  @override bool shouldRepaint(_GridLinePainter o) => false;
}

// ── Grid Cell ──────────────────────────────────────────────────────────────

class _GridCell extends StatefulWidget {
  final int row, col;
  final CellState state;
  final GameThemeColors colors;
  final bool isHovered, canDrop;
  final GameThemeData theme;
  const _GridCell({
    required this.row, required this.col, required this.state,
    required this.colors, required this.isHovered, required this.canDrop,
    required this.theme,
  });
  @override State<_GridCell> createState() => _GridCellState();
}

class _GridCellState extends State<_GridCell> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scaleAnim, _glowAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: GameConstants.lineClearDurationMs));
    _scaleAnim = Tween(begin: 1.0, end: 0.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
    _glowAnim  = Tween(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void didUpdateWidget(_GridCell old) {
    super.didUpdateWidget(old);
    if (!old.state.clearing && widget.state.clearing) _ctrl.forward(from: 0);
    if ( old.state.clearing && !widget.state.clearing) _ctrl.reset();
  }

  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final ct = GameConstants.cellSize + GameConstants.cellGap;
    final x  = widget.col * ct + GameConstants.cellGap / 2;
    final y  = widget.row * ct + GameConstants.cellGap / 2;
    final cs = GameConstants.cellSize;

    Color cellColor;
    double glowOpacity = 0;

    if (widget.state.clearing) {
      final idx = widget.state.colorIndex.clamp(0, widget.colors.blockColors.length - 1);
      cellColor   = widget.colors.blockColors[idx];
      glowOpacity = _glowAnim.value;
    } else if (widget.state.filled) {
      final idx = widget.state.colorIndex.clamp(0, widget.colors.blockColors.length - 1);
      cellColor   = widget.colors.blockColors[idx];
    } else if (widget.isHovered) {
      cellColor = widget.canDrop
          ? widget.colors.glowColor.withOpacity(0.5)
          : Colors.red.withOpacity(0.4);
    } else {
      cellColor = widget.colors.cellEmpty;
    }

    return Positioned(
      left: x, top: y,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => Transform.scale(
          scale: widget.state.clearing ? _scaleAnim.value : 1.0,
          child: Container(
            width: cs, height: cs,
            decoration: BoxDecoration(
              color: cellColor,
              borderRadius: BorderRadius.circular(6),
              border: widget.state.filled
                  ? Border.all(color: cellColor.withOpacity(0.8), width: 0.5)
                  : null,
              boxShadow: (widget.state.filled || widget.isHovered)
                  ? [BoxShadow(
                      color: cellColor.withOpacity(0.4 + glowOpacity * 0.4),
                      blurRadius: 6 + glowOpacity * 10,
                      spreadRadius: glowOpacity * 3)]
                  : null,
            ),
            child: widget.state.filled ? _CellHighlight(color: cellColor) : null,
          ),
        ),
      ),
    );
  }
}

class _CellHighlight extends StatelessWidget {
  final Color color;
  const _CellHighlight({required this.color});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(4),
    child: Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(3),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Colors.white.withOpacity(0.25), Colors.transparent],
        ),
      ),
    ),
  );
}

// ── Ghost Overlay ──────────────────────────────────────────────────────────

class _GhostOverlay extends StatelessWidget {
  final BlockShape shape;
  final int row, col;
  final bool canDrop;
  final GameThemeColors colors;
  const _GhostOverlay({required this.shape, required this.row, required this.col,
    required this.canDrop, required this.colors});

  @override
  Widget build(BuildContext context) {
    final ct    = GameConstants.cellSize + GameConstants.cellGap;
    final cs    = GameConstants.cellSize;
    final color = canDrop ? colors.glowColor.withOpacity(0.6) : Colors.red.withOpacity(0.5);
    return Stack(
      children: shape.cells.map((cell) {
        final r = row + cell[0];
        final c = col + cell[1];
        if (r < 0 || r >= GameConstants.gridSize) return const SizedBox();
        if (c < 0 || c >= GameConstants.gridSize) return const SizedBox();
        return Positioned(
          left: c * ct + GameConstants.cellGap / 2,
          top:  r * ct + GameConstants.cellGap / 2,
          child: Container(
            width: cs, height: cs,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: canDrop ? colors.glowColor : Colors.red, width: 1),
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ── Tray Row ───────────────────────────────────────────────────────────────

class _TrayRow extends StatelessWidget {
  final GameThemeData theme;
  final GameState gameState;
  final void Function(int, BlockShape, Offset) onDragStart;
  const _TrayRow({required this.theme, required this.gameState, required this.onDragStart});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: GameConstants.blockPieceTrayHeight,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(3, (i) => _TrayPiece(
          index: i,
          shape: gameState.trayPieces[i],
          theme: theme,
          onDragStart: onDragStart,
          disabled: gameState.isAnimating || gameState.isGameOver,
        )),
      ),
    );
  }
}

class _TrayPiece extends StatefulWidget {
  final int index;
  final BlockShape? shape;
  final GameThemeData theme;
  final void Function(int, BlockShape, Offset) onDragStart;
  final bool disabled;
  const _TrayPiece({required this.index, required this.shape, required this.theme,
    required this.onDragStart, required this.disabled});
  @override State<_TrayPiece> createState() => _TrayPieceState();
}

class _TrayPieceState extends State<_TrayPiece> with SingleTickerProviderStateMixin {
  late AnimationController _bounceCtrl;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _bounceCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
  }

  @override void dispose() { _bounceCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (widget.shape == null) return const SizedBox(width: 100, height: 100);
    final shape  = widget.shape!;
    final colors = widget.theme.colors;
    const mini   = 22.0;

    return GestureDetector(
      // onPanStart fires immediately on touch — no long press needed
      onPanStart: widget.disabled ? null : (details) {
        setState(() => _isDragging = true);
        widget.onDragStart(widget.index, shape, details.globalPosition);
      },
      onPanEnd: (_) => setState(() => _isDragging = false),
      onPanCancel: () => setState(() => _isDragging = false),
      child: AnimatedBuilder(
        animation: _bounceCtrl,
        builder: (_, __) {
          final bounce = sin(_bounceCtrl.value * pi) * 3;
          return Transform.translate(
            offset: Offset(0, _isDragging ? 0 : bounce),
            child: Opacity(
              opacity: _isDragging ? 0.3 : 1.0,
              child: Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  color: colors.panelBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: colors.panelBorder.withOpacity(0.5), width: 1),
                  boxShadow: [BoxShadow(color: colors.glowColor.withOpacity(0.1), blurRadius: 8)],
                ),
                child: Center(
                  child: CustomPaint(
                    size: Size(shape.width * mini, shape.height * mini),
                    painter: _ShapePainter(shape: shape, colors: colors, cellSize: mini),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ShapePainter extends CustomPainter {
  final BlockShape shape;
  final GameThemeColors colors;
  final double cellSize;
  const _ShapePainter({required this.shape, required this.colors, required this.cellSize});

  @override
  void paint(Canvas canvas, Size size) {
    final idx   = shape.colorIndex.clamp(0, colors.blockColors.length - 1);
    final color = colors.blockColors[idx];
    final paint = Paint()..color = color;
    final glow  = Paint()..color = color.withOpacity(0.3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    for (final cell in shape.cells) {
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cell[1]*cellSize+1, cell[0]*cellSize+1, cellSize-2, cellSize-2),
        const Radius.circular(4),
      );
      canvas.drawRRect(rect, glow);
      canvas.drawRRect(rect, paint);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(cell[1]*cellSize+3, cell[0]*cellSize+3, cellSize*0.4, cellSize*0.25),
          const Radius.circular(2),
        ),
        Paint()..color = Colors.white.withOpacity(0.25),
      );
    }
  }
  @override bool shouldRepaint(_ShapePainter o) => false;
}

// ── Score Panel ────────────────────────────────────────────────────────────

class _ScorePanel extends StatelessWidget {
  final GameThemeData theme;
  final GameState gameState;
  const _ScorePanel({required this.theme, required this.gameState});

  @override
  Widget build(BuildContext context) {
    final c = theme.colors;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: c.panelBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: c.panelBorder.withOpacity(0.5), width: 1),
        boxShadow: [BoxShadow(color: c.glowColor.withOpacity(0.12), blurRadius: 16)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _StatBadge(label: 'SCORE', value: gameState.score.toString(), colors: c),
          if (gameState.combo > 1)
            _StatBadge(label: 'COMBO', value: '×${gameState.combo}', colors: c, isCombo: true),
          _StatBadge(label: 'BEST', value: gameState.highScore.toString(), colors: c),
        ],
      ),
    );
  }
}

class _StatBadge extends StatelessWidget {
  final String label, value;
  final GameThemeColors colors;
  final bool isCombo;
  const _StatBadge({required this.label, required this.value, required this.colors, this.isCombo = false});

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(label, style: TextStyle(
        color: colors.textPrimary.withOpacity(0.5), fontSize: 10,
        letterSpacing: 1.5, fontWeight: FontWeight.w600)),
      const SizedBox(height: 2),
      Text(value, style: TextStyle(
        color: isCombo ? colors.textAccent : colors.textPrimary,
        fontSize: isCombo ? 22 : 20, fontWeight: FontWeight.bold,
        shadows: isCombo ? [Shadow(color: colors.glowColor, blurRadius: 8)] : null)),
    ],
  );
}

// ── Game Over Panel ────────────────────────────────────────────────────────

class _GameOverPanel extends StatelessWidget {
  final GameThemeData theme;
  final int score, highScore;
  final VoidCallback onRestart;
  const _GameOverPanel({required this.theme, required this.score,
    required this.highScore, required this.onRestart});

  @override
  Widget build(BuildContext context) {
    final c = theme.colors;
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.80),
        child: Center(
          child: Container(
            margin: const EdgeInsets.all(32),
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: c.panelBg,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: c.panelBorder, width: 1.5),
              boxShadow: [BoxShadow(color: c.glowColor.withOpacity(0.25),
                  blurRadius: 30, spreadRadius: 5)],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('GAME OVER', style: TextStyle(
                  color: c.textPrimary, fontSize: 28, fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                  shadows: [Shadow(color: c.glowColor, blurRadius: 12)])),
                const SizedBox(height: 20),
                Text('Score: $score', style: TextStyle(
                  color: c.textAccent, fontSize: 20, fontWeight: FontWeight.w600)),
                Text('Best: $highScore', style: TextStyle(
                  color: c.textPrimary.withOpacity(0.6), fontSize: 14)),
                const SizedBox(height: 28),
                _PremiumButton(label: 'PLAY AGAIN', colors: c, onTap: onRestart),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Premium Button ─────────────────────────────────────────────────────────

class _PremiumButton extends StatefulWidget {
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;
  const _PremiumButton({required this.label, required this.colors, required this.onTap});
  @override State<_PremiumButton> createState() => _PremiumButtonState();
}

class _PremiumButtonState extends State<_PremiumButton> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween(begin: 1.0, end: 0.94).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [c.buttonPrimary, c.buttonSecondary],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: c.panelBorder, width: 1),
              boxShadow: [BoxShadow(color: c.glowColor.withOpacity(0.4),
                  blurRadius: 16, offset: const Offset(0, 4))],
            ),
            child: Text(widget.label, style: TextStyle(
              color: c.textPrimary, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 2)),
          ),
        ),
      ),
    );
  }
}
