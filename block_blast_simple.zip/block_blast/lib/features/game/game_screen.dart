import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'components/forest_background.dart';
import 'components/game_grid.dart';
import '../../core/theme/game_theme.dart';
import '../../core/services/sound_manager.dart';

class GameScreen extends ConsumerStatefulWidget {
  const GameScreen({super.key});

  @override
  ConsumerState<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends ConsumerState<GameScreen> {
  GameThemeData _theme = forestTheme;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  Widget _buildBackground({required Widget child}) {
    switch (_theme.type) {
      case GameThemeType.forest:
        return ForestBackground(child: child);
      default:
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [_theme.colors.background1, _theme.colors.background2],
            ),
          ),
          child: child,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final size    = MediaQuery.of(context).size;
    final safeTop = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: Colors.black,
      body: _buildBackground(
        child: SafeArea(
          child: SizedBox(
            height: size.height - safeTop,
            child: Column(
              children: [
                _TopHUD(
                  theme: _theme,
                  onThemeChange: (t) => setState(() => _theme = t),
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: GameGrid(theme: _theme),
                ),
                const Spacer(),
                _BottomBar(theme: _theme),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Top HUD ───────────────────────────────────────────────────────────────

class _TopHUD extends StatelessWidget {
  final GameThemeData theme;
  final ValueChanged<GameThemeData> onThemeChange;
  const _TopHUD({required this.theme, required this.onThemeChange});

  @override
  Widget build(BuildContext context) {
    final c = theme.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: c.panelBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: c.panelBorder.withOpacity(0.4)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: c.glowColor,
                    boxShadow: [BoxShadow(color: c.glowColor, blurRadius: 4)],
                  ),
                ),
                const SizedBox(width: 6),
                Text(theme.name, style: TextStyle(
                  color: c.textPrimary, fontSize: 12, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => _showSettings(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: c.panelBg,
                shape: BoxShape.circle,
                border: Border.all(color: c.panelBorder.withOpacity(0.4)),
              ),
              child: Icon(Icons.settings_outlined, color: c.textPrimary, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  void _showSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _SettingsSheet(
        theme: theme,
        onThemeChange: onThemeChange,
      ),
    );
  }
}

// ── Bottom Bar ─────────────────────────────────────────────────────────────

class _BottomBar extends StatelessWidget {
  final GameThemeData theme;
  const _BottomBar({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('BLOCK BLAST', style: TextStyle(
            color: theme.colors.textPrimary.withOpacity(0.2),
            fontSize: 11, letterSpacing: 3, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

// ── Settings Sheet ─────────────────────────────────────────────────────────

class _SettingsSheet extends ConsumerWidget {
  final GameThemeData theme;
  final ValueChanged<GameThemeData> onThemeChange;
  const _SettingsSheet({required this.theme, required this.onThemeChange});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c     = theme.colors;
    final sound = ref.read(soundManagerProvider);

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: c.panelBg,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: c.panelBorder.withOpacity(0.5)),
        boxShadow: [BoxShadow(color: c.glowColor.withOpacity(0.15), blurRadius: 24)],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Settings', style: TextStyle(
            color: c.textPrimary, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          _SoundRow(label: 'Music',         icon: Icons.music_note_outlined,
              value: sound.musicEnabled, onChanged: (_) => sound.toggleMusic()),
          const SizedBox(height: 12),
          _SoundRow(label: 'Sound Effects', icon: Icons.volume_up_outlined,
              value: sound.sfxEnabled,   onChanged: (_) => sound.toggleSfx()),
          const SizedBox(height: 24),
          Text('Theme', style: TextStyle(
            color: c.textPrimary.withOpacity(0.5), fontSize: 12,
            letterSpacing: 1.2, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: ThemeRegistry.themes.values.map((t) {
              final isActive = t.type == theme.type;
              return GestureDetector(
                onTap: () {
                  onThemeChange(t);
                  Navigator.pop(context);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: isActive ? c.buttonPrimary.withOpacity(0.3) : Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isActive ? c.panelBorder : c.panelBorder.withOpacity(0.3)),
                  ),
                  child: Text(t.name, style: TextStyle(
                    color: isActive ? c.textAccent : c.textPrimary.withOpacity(0.5),
                    fontSize: 12,
                    fontWeight: isActive ? FontWeight.w600 : FontWeight.normal)),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _SoundRow extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SoundRow({required this.label, required this.icon,
      required this.value, required this.onChanged});
  @override State<_SoundRow> createState() => _SoundRowState();
}

class _SoundRowState extends State<_SoundRow> {
  late bool _v;
  @override void initState() { super.initState(); _v = widget.value; }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(widget.icon, color: Colors.white54, size: 20),
        const SizedBox(width: 12),
        Expanded(child: Text(widget.label,
            style: const TextStyle(color: Colors.white, fontSize: 15))),
        Switch.adaptive(
          value: _v,
          onChanged: (v) { setState(() => _v = v); widget.onChanged(v); },
          activeColor: const Color(0xFF4CAF50),
        ),
      ],
    );
  }
}
