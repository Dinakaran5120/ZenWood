import 'dart:math';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:equatable/equatable.dart';
import '../../../core/constants/game_constants.dart';
import '../../../core/services/sound_manager.dart';

// ─────────────────────────────────────────────
//  Game State Model
// ─────────────────────────────────────────────

class CellState extends Equatable {
  final bool filled;
  final int colorIndex; // index into theme blockColors
  final bool clearing;  // true during clear animation

  const CellState({
    this.filled = false,
    this.colorIndex = 0,
    this.clearing = false,
  });

  CellState copyWith({bool? filled, int? colorIndex, bool? clearing}) =>
      CellState(
        filled: filled ?? this.filled,
        colorIndex: colorIndex ?? this.colorIndex,
        clearing: clearing ?? this.clearing,
      );

  @override
  List<Object?> get props => [filled, colorIndex, clearing];
}

class GameState extends Equatable {
  final List<List<CellState>> grid;       // [row][col]
  final List<BlockShape?> trayPieces;     // 3 pieces in tray
  final int score;
  final int highScore;
  final int combo;
  final bool isGameOver;
  final bool isAnimating;
  final Set<int> clearingRows;
  final Set<int> clearingCols;

  const GameState({
    required this.grid,
    required this.trayPieces,
    this.score = 0,
    this.highScore = 0,
    this.combo = 0,
    this.isGameOver = false,
    this.isAnimating = false,
    this.clearingRows = const {},
    this.clearingCols = const {},
  });

  static GameState initial() {
    final grid = List.generate(
      GameConstants.gridSize,
      (_) => List.generate(GameConstants.gridSize, (_) => const CellState()),
    );
    return GameState(
      grid: grid,
      trayPieces: _generateTray(),
      highScore: 0,
    );
  }

  static List<BlockShape?> _generateTray() {
    final rng = Random();
    // weighted: avoid 3x3 early
    final pool = allShapes.where((s) => s.id != 'sq3x3').toList();
    return List.generate(3, (_) => pool[rng.nextInt(pool.length)]);
  }

  GameState copyWith({
    List<List<CellState>>? grid,
    List<BlockShape?>? trayPieces,
    int? score,
    int? highScore,
    int? combo,
    bool? isGameOver,
    bool? isAnimating,
    Set<int>? clearingRows,
    Set<int>? clearingCols,
  }) =>
      GameState(
        grid: grid ?? this.grid,
        trayPieces: trayPieces ?? this.trayPieces,
        score: score ?? this.score,
        highScore: highScore ?? this.highScore,
        combo: combo ?? this.combo,
        isGameOver: isGameOver ?? this.isGameOver,
        isAnimating: isAnimating ?? this.isAnimating,
        clearingRows: clearingRows ?? this.clearingRows,
        clearingCols: clearingCols ?? this.clearingCols,
      );

  @override
  List<Object?> get props =>
      [grid, trayPieces, score, highScore, combo, isGameOver, isAnimating,
       clearingRows, clearingCols];
}

// ─────────────────────────────────────────────
//  Game Notifier
// ─────────────────────────────────────────────

class GameNotifier extends StateNotifier<GameState> {
  final SoundManager _sound;

  GameNotifier(this._sound) : super(GameState.initial());

  void resetGame() {
    state = GameState.initial().copyWith(highScore: state.highScore);
  }

  // ── Can a shape be placed at (row, col)? ──
  bool canPlace(BlockShape shape, int row, int col) {
    for (final cell in shape.cells) {
      final r = row + cell[0];
      final c = col + cell[1];
      if (r < 0 || r >= GameConstants.gridSize) return false;
      if (c < 0 || c >= GameConstants.gridSize) return false;
      if (state.grid[r][c].filled) return false;
    }
    return true;
  }

  // ── Place a tray piece at grid position ───
  Future<void> placeBlock(int trayIndex, int row, int col) async {
    final piece = state.trayPieces[trayIndex];
    if (piece == null) return;
    if (!canPlace(piece, row, col)) return;
    if (state.isAnimating) return;

    _sound.placeBlock();

    // Place cells on grid
    final newGrid = _copyGrid(state.grid);
    for (final cell in piece.cells) {
      newGrid[row + cell[0]][col + cell[1]] = CellState(
        filled: true,
        colorIndex: piece.colorIndex,
      );
    }

    // Remove from tray
    final newTray = List<BlockShape?>.from(state.trayPieces);
    newTray[trayIndex] = null;

    // Score placed cells
    final placedScore = piece.cells.length * GameConstants.pointsPerCell;

    state = state.copyWith(
      grid: newGrid,
      trayPieces: newTray,
      score: state.score + placedScore,
      isAnimating: true,
    );

    // Check & clear lines
    await _checkAndClearLines(newGrid, newTray);
  }

  Future<void> _checkAndClearLines(
      List<List<CellState>> grid, List<BlockShape?> tray) async {
    final clearRows = <int>{};
    final clearCols = <int>{};
    final G = GameConstants.gridSize;

    for (int r = 0; r < G; r++) {
      if (grid[r].every((c) => c.filled)) clearRows.add(r);
    }
    for (int c = 0; c < G; c++) {
      if (List.generate(G, (r) => grid[r][c]).every((cs) => cs.filled)) {
        clearCols.add(c);
      }
    }

    if (clearRows.isEmpty && clearCols.isEmpty) {
      await _finalizeTurn(grid, tray, 0);
      return;
    }

    // Mark clearing
    final animGrid = _copyGrid(grid);
    for (final r in clearRows) {
      for (int c = 0; c < G; c++) animGrid[r][c] = animGrid[r][c].copyWith(clearing: true);
    }
    for (final c in clearCols) {
      for (int r = 0; r < G; r++) animGrid[r][c] = animGrid[r][c].copyWith(clearing: true);
    }

    state = state.copyWith(
      grid: animGrid,
      clearingRows: clearRows,
      clearingCols: clearCols,
    );

    _sound.lineClear();
    await Future.delayed(
        const Duration(milliseconds: GameConstants.lineClearDurationMs));

    // Remove cleared cells
    final clearedGrid = _copyGrid(animGrid);
    for (final r in clearRows) {
      for (int c = 0; c < G; c++) clearedGrid[r][c] = const CellState();
    }
    for (final c in clearCols) {
      for (int r = 0; r < G; r++) clearedGrid[r][c] = const CellState();
    }

    final linesCleared = clearRows.length + clearCols.length;
    final lineScore = linesCleared * GameConstants.pointsPerLine;
    final newCombo = state.combo + 1;
    final comboBonus = (newCombo > 1)
        ? (newCombo - 1) * GameConstants.comboMultiplierStep
        : 0;

    if (newCombo > 1) _sound.combo();

    await _finalizeTurn(clearedGrid, tray, lineScore + comboBonus, combo: newCombo);
  }

  Future<void> _finalizeTurn(
    List<List<CellState>> grid,
    List<BlockShape?> tray,
    int bonusScore, {
    int combo = 0,
  }) async {
    // Refill tray if all used
    final newTray = tray.every((p) => p == null)
        ? GameState._generateTray()
        : List<BlockShape?>.from(tray);

    final newScore = state.score + bonusScore;
    final newHigh = max(newScore, state.highScore);

    state = state.copyWith(
      grid: grid,
      trayPieces: newTray,
      score: newScore,
      highScore: newHigh,
      combo: combo,
      clearingRows: {},
      clearingCols: {},
      isAnimating: false,
    );

    if (_isGameOver(grid, newTray)) {
      _sound.gameOver();
      state = state.copyWith(isGameOver: true);
    }
  }

  bool _isGameOver(List<List<CellState>> grid, List<BlockShape?> tray) {
    final G = GameConstants.gridSize;
    for (final piece in tray) {
      if (piece == null) continue;
      for (int r = 0; r < G; r++) {
        for (int c = 0; c < G; c++) {
          if (canPlaceOnGrid(piece, r, c, grid)) return false;
        }
      }
    }
    return true;
  }

  bool canPlaceOnGrid(
      BlockShape shape, int row, int col, List<List<CellState>> grid) {
    final G = GameConstants.gridSize;
    for (final cell in shape.cells) {
      final r = row + cell[0];
      final c = col + cell[1];
      if (r < 0 || r >= G || c < 0 || c >= G) return false;
      if (grid[r][c].filled) return false;
    }
    return true;
  }

  List<List<CellState>> _copyGrid(List<List<CellState>> src) =>
      src.map((row) => List<CellState>.from(row)).toList();
}

final gameProvider = StateNotifierProvider<GameNotifier, GameState>((ref) {
  final sound = ref.read(soundManagerProvider);
  return GameNotifier(sound);
});
