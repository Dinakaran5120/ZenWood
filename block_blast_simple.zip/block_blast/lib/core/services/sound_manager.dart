import 'package:flutter_riverpod/flutter_riverpod.dart';

// SoundManager - simplified version without flame_audio
// flame_audio will be added back when we add real sound files

class SoundManager {
  bool _sfxEnabled   = true;
  bool _musicEnabled = true;

  void placeBlock() {} // sounds added in next step
  void lineClear()  {}
  void combo()      {}
  void gameOver()   {}
  void tap()        {}

  Future<void> preload() async {}
  Future<void> playMusic(String file) async {}
  Future<void> stopMusic() async {}

  void toggleSfx()   => _sfxEnabled   = !_sfxEnabled;
  void toggleMusic() => _musicEnabled = !_musicEnabled;

  bool get sfxEnabled   => _sfxEnabled;
  bool get musicEnabled => _musicEnabled;
}

final soundManagerProvider = Provider<SoundManager>((_) => SoundManager());
