import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class PerformanceOptimizer with WidgetsBindingObserver {
  Timer? _perfTimer;

  void initialize() {
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {}

  @override
  void didHaveMemoryPressure() {
    imageCache.clear();
    imageCache.clearLiveImages();
  }

  void dispose() {
    _perfTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
  }
}

void configureImageCache() {
  PaintingBinding.instance.imageCache.maximumSizeBytes = 50 * 1024 * 1024;
  PaintingBinding.instance.imageCache.maximumSize = 100;
}

final performanceProvider = Provider<PerformanceOptimizer>((ref) {
  final o = PerformanceOptimizer()..initialize();
  ref.onDispose(o.dispose);
  return o;
});
