# Block Blast — Flutter + Flame + Firebase

## Firebase Setup

### 1. Create project at console.firebase.google.com
Enable: Authentication (Google + Email + Anonymous), Cloud Firestore, Cloud Storage, Analytics

### 2. FlutterFire CLI
```bash
dart pub global activate flutterfire_cli
flutterfire configure --project=YOUR_PROJECT_ID
```
Generates lib/firebase_options.dart automatically.

### 3. SHA-1 for Google Sign-In
```bash
cd android && ./gradlew signingReport
# Paste SHA1 into Firebase Console → Project Settings → Android app
```

### 4. Deploy rules + indexes
```bash
firebase deploy --only firestore
```

## Firestore Schema
- /users/{uid} — profile, score, location, coins, streak, cloudSaveData
- /users/{uid}/reward_history — daily claim log
- /users/{uid}/save_history — last 10 cloud saves
- /leaderboard/{uid} — global + country rankings

## Auth Flow
App → Firebase init → authStateChanges →
  null: LoginScreen (Google / Email / Anonymous) →
  new user: create profile + fetch location + UsernameSetupScreen →
  existing: update lastSeen → GameScreen

## Feature Status
- Firebase Auth (Google, Email, Anonymous): DONE
- User profile (Firestore): DONE
- Score storage: DONE
- Location (GPS + country): DONE
- Global leaderboard: DONE
- Country leaderboard: DONE
- Daily reward streak: DONE
- Cloud save + history: DONE
