import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// ─────────────────────────────────────────────
//  PerformanceOptimizer
//  Monitors frame rate, memory pressure,
//  pauses animations on app background
// ─────────────────────────────────────────────

class PerformanceOptimizer with WidgetsBindingObserver {
  bool _isPaused = false;
  Timer? _perfTimer;

  void initialize() {
    WidgetsBinding.instance.addObserver(this);
    _startMonitoring();
  }

  // ── App lifecycle ─────────────────────────
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        _isPaused = true;
        _onPause();
      case AppLifecycleState.resumed:
        _isPaused = false;
        _onResume();
      default:
        break;
    }
  }

  void _onPause() {
    // All AnimationController.repeat() controllers stop automatically
    // because they are vsync-bound to widgets
    _perfTimer?.cancel();
  }

  void _onResume() {
    _startMonitoring();
  }

  // ── Frame monitoring ──────────────────────
  void _startMonitoring() {
    _perfTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      final timings = SchedulerBinding.instance.currentFrameTimeStamp;
      // Log frame timings in debug — detect jank
      if (!_isPaused) _checkFrameBudget(timings);
    });
  }

  void _checkFrameBudget(Duration timestamp) {
    // 16ms = 60fps, 33ms = 30fps
    // In a real app, use SchedulerBinding.instance.currentFrameTimeStamp delta
    // This is a placeholder for actual frame timing logic
    debugPrint('[Perf] Frame check at ${timestamp.inMilliseconds}ms');
  }

  // ── Memory pressure ───────────────────────
  @override
  void didHaveMemoryPressure() {
    // Clear image caches
    imageCache.clear();
    imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();
  }

  bool get isPaused => _isPaused;

  void dispose() {
    _perfTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
  }
}

// ─────────────────────────────────────────────
//  Object Pool — reuse particle/block objects
// ─────────────────────────────────────────────

class ObjectPool<T> {
  final T Function() _factory;
  final void Function(T) _reset;
  final int _maxSize;
  final List<T> _available = [];

  ObjectPool({
    required T Function() factory,
    required void Function(T) reset,
    int maxSize = 50,
  })  : _factory = factory,
        _reset = reset,
        _maxSize = maxSize;

  T acquire() {
    if (_available.isNotEmpty) {
      return _available.removeLast();
    }
    return _factory();
  }

  void release(T obj) {
    if (_available.length >= _maxSize) return;
    _reset(obj);
    _available.add(obj);
  }

  void clear() => _available.clear();
  int get available => _available.length;
}

// ─────────────────────────────────────────────
//  RepaintBoundary helper
//  Wraps expensive paint subtrees
// ─────────────────────────────────────────────

class IsolatedPaintBoundary extends StatelessWidget {
  final Widget child;
  const IsolatedPaintBoundary({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(child: child);
  }
}

// ─────────────────────────────────────────────
//  Image cache config
// ─────────────────────────────────────────────

void configureImageCache() {
  // Limit cache to 100MB and 200 images
  PaintingBinding.instance.imageCache.maximumSizeBytes = 100 * 1024 * 1024;
  PaintingBinding.instance.imageCache.maximumSize = 200;
}

// ─────────────────────────────────────────────
//  Provider
// ─────────────────────────────────────────────

final performanceProvider = Provider<PerformanceOptimizer>((ref) {
  final optimizer = PerformanceOptimizer();
  optimizer.initialize();
  ref.onDispose(optimizer.dispose);
  return optimizer;
});
