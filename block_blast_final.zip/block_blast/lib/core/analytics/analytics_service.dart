import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../admob/admob_service.dart';

// ─────────────────────────────────────────────
//  AnalyticsService — Firebase Analytics + Crashlytics
// ─────────────────────────────────────────────

class AnalyticsService {
  final FirebaseAnalytics _analytics = FirebaseAnalytics.instance;
  final FirebaseCrashlytics _crashlytics = FirebaseCrashlytics.instance;

  // ── Initialize ────────────────────────────
  Future<void> initialize() async {
    // Disable Crashlytics in debug
    await _crashlytics.setCrashlyticsCollectionEnabled(!kDebugMode);
    // Catch all uncaught Flutter errors
    FlutterError.onError = _crashlytics.recordFlutterFatalError;
    // Catch async errors
    PlatformDispatcher.instance.onError = (error, stack) {
      _crashlytics.recordError(error, stack, fatal: true);
      return true;
    };
  }

  // ── Set user context ──────────────────────
  Future<void> setUser({
    required String uid,
    required String username,
    String? country,
  }) async {
    await _analytics.setUserId(id: uid);
    await _analytics.setUserProperty(name: 'username', value: username);
    if (country != null) {
      await _analytics.setUserProperty(name: 'country', value: country);
    }
    await _crashlytics.setUserIdentifier(uid);
    await _crashlytics.setCustomKey('username', username);
  }

  // ── Game events ───────────────────────────
  Future<void> logGameStart({required String theme}) async {
    await _analytics.logEvent(
      name: 'game_start',
      parameters: {'theme': theme},
    );
  }

  Future<void> logGameOver({
    required int score,
    required int linesCleared,
    required int gamesPlayed,
  }) async {
    await _analytics.logEvent(
      name: 'game_over',
      parameters: {
        'score': score,
        'lines_cleared': linesCleared,
        'games_played': gamesPlayed,
      },
    );
    // Standard ecommerce-style event for score milestones
    if (score >= 1000) {
      await _analytics.logEvent(
        name: 'score_milestone',
        parameters: {'milestone': (score ~/ 1000) * 1000},
      );
    }
  }

  Future<void> logNewHighScore(int score) async {
    await _analytics.logEvent(
      name: 'new_high_score',
      parameters: {'score': score},
    );
  }

  Future<void> logLineClear({required int lines, required int combo}) async {
    await _analytics.logEvent(
      name: 'line_clear',
      parameters: {'lines': lines, 'combo': combo},
    );
  }

  // ── Ad events ─────────────────────────────
  Future<void> logAdImpression(AdType type) async {
    await _analytics.logEvent(
      name: 'ad_impression',
      parameters: {'ad_type': type.name},
    );
  }

  Future<void> logAdReward(AdType type, int coins) async {
    await _analytics.logEvent(
      name: 'ad_reward_earned',
      parameters: {'ad_type': type.name, 'coins': coins},
    );
  }

  // ── Store events ──────────────────────────
  Future<void> logPurchase({
    required String itemId,
    required String itemName,
    required int coinCost,
  }) async {
    await _analytics.logEvent(
      name: 'store_purchase',
      parameters: {
        'item_id': itemId,
        'item_name': itemName,
        'coin_cost': coinCost,
      },
    );
  }

  Future<void> logIapPurchase({
    required String productId,
    required double price,
    required String currency,
  }) async {
    await _analytics.logPurchase(
      currency: currency,
      value: price,
      items: [AnalyticsEventItem(itemId: productId, itemName: productId)],
    );
  }

  // ── Spin wheel events ─────────────────────
  Future<void> logSpinWheel({required String rewardType, required int value}) async {
    await _analytics.logEvent(
      name: 'spin_wheel',
      parameters: {'reward_type': rewardType, 'value': value},
    );
  }

  // ── Daily reward events ───────────────────
  Future<void> logDailyReward({required int streak, required int coins}) async {
    await _analytics.logEvent(
      name: 'daily_reward_claimed',
      parameters: {'streak': streak, 'coins': coins},
    );
  }

  // ── Theme events ──────────────────────────
  Future<void> logThemeChange(String theme) async {
    await _analytics.logEvent(
      name: 'theme_changed',
      parameters: {'theme': theme},
    );
  }

  // ── Session events ────────────────────────
  Future<void> logScreenView(String screenName) async {
    await _analytics.logScreenView(screenName: screenName);
  }

  // ── Error recording ───────────────────────
  Future<void> recordError(
    dynamic error,
    StackTrace? stack, {
    bool fatal = false,
    String? context,
  }) async {
    await _crashlytics.recordError(
      error,
      stack,
      fatal: fatal,
      information: context != null ? [context] : [],
    );
  }

  Future<void> log(String message) async {
    await _crashlytics.log(message);
  }
}

final analyticsServiceProvider = Provider<AnalyticsService>((ref) {
  return AnalyticsService();
});
