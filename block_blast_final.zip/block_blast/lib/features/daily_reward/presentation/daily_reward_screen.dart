import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/daily_reward_service.dart';
import '../../../core/models/user_model.dart';
import '../../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  DailyRewardScreen
// ─────────────────────────────────────────────

class DailyRewardScreen extends ConsumerStatefulWidget {
  final GameThemeData theme;
  const DailyRewardScreen({super.key, required this.theme});

  @override
  ConsumerState<DailyRewardScreen> createState() => _DailyRewardScreenState();
}

class _DailyRewardScreenState extends ConsumerState<DailyRewardScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _celebCtrl;
  bool _showCelebration = false;
  DailyRewardResult? _claimedResult;

  @override
  void initState() {
    super.initState();
    _celebCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
  }

  @override
  void dispose() {
    _celebCtrl.dispose();
    super.dispose();
  }

  Future<void> _claim() async {
    final result =
        await ref.read(dailyRewardProvider.notifier).claimReward();
    if (result != null && mounted) {
      setState(() {
        _claimedResult = result;
        _showCelebration = true;
      });
      _celebCtrl.forward(from: 0);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dr = ref.watch(dailyRewardProvider);
    final colors = widget.theme.colors;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          Column(
            children: [
              _Header(colors: colors),
              const SizedBox(height: 8),

              // Streak info
              _StreakBadge(streak: dr.currentStreak, colors: colors),

              const SizedBox(height: 24),

              // 7-day calendar
              _SevenDayCalendar(
                currentStreak: dr.currentStreak,
                colors: colors,
              ),

              const SizedBox(height: 32),

              // Claim button / countdown
              dr.canClaim
                  ? _ClaimButton(
                      colors: colors,
                      isLoading: dr.isLoading,
                      onClaim: _claim,
                    )
                  : _Countdown(
                      timeUntilNext: dr.timeUntilNext ?? Duration.zero,
                      colors: colors,
                    ),
            ],
          ),

          // Celebration overlay
          if (_showCelebration && _claimedResult != null)
            _CelebrationOverlay(
              result: _claimedResult!,
              colors: colors,
              ctrl: _celebCtrl,
              onDone: () => setState(() => _showCelebration = false),
            ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final GameThemeColors colors;
  const _Header({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child:
                Icon(Icons.arrow_back_ios, color: colors.textPrimary, size: 20),
          ),
          const SizedBox(width: 12),
          Text(
            'DAILY REWARD',
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }
}

class _StreakBadge extends StatelessWidget {
  final int streak;
  final GameThemeColors colors;
  const _StreakBadge({required this.streak, required this.colors});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: colors.panelBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.panelBorder.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(
              color: colors.glowColor.withOpacity(0.1), blurRadius: 12)
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🔥', style: TextStyle(fontSize: 28)),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$streak day streak!',
                style: TextStyle(
                  color: colors.textAccent,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  shadows: [Shadow(color: colors.glowColor, blurRadius: 8)],
                ),
              ),
              Text(
                streak >= 7
                    ? 'Max streak — keep it up!'
                    : '${7 - streak} days to weekly bonus',
                style: TextStyle(
                  color: colors.textPrimary.withOpacity(0.5),
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SevenDayCalendar extends StatelessWidget {
  final int currentStreak;
  final GameThemeColors colors;

  const _SevenDayCalendar({
    required this.currentStreak,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Text(
            'Login rewards',
            style: TextStyle(
              color: colors.textPrimary.withOpacity(0.5),
              fontSize: 12,
              letterSpacing: 1.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: dailyRewardSchedule.map((day) {
              final claimed = currentStreak >= day.day;
              final isCurrent = currentStreak + 1 == day.day;
              return Expanded(
                child: _DayCard(
                  day: day,
                  claimed: claimed,
                  isCurrent: isCurrent,
                  colors: colors,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _DayCard extends StatelessWidget {
  final DailyRewardDay day;
  final bool claimed, isCurrent;
  final GameThemeColors colors;

  const _DayCard({
    required this.day,
    required this.claimed,
    required this.isCurrent,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
      decoration: BoxDecoration(
        color: claimed
            ? colors.buttonPrimary.withOpacity(0.3)
            : isCurrent
                ? colors.panelBorder.withOpacity(0.3)
                : colors.panelBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isCurrent
              ? colors.glowColor
              : claimed
                  ? colors.panelBorder.withOpacity(0.5)
                  : colors.panelBorder.withOpacity(0.15),
          width: isCurrent ? 1.5 : 0.5,
        ),
        boxShadow: isCurrent
            ? [
                BoxShadow(
                    color: colors.glowColor.withOpacity(0.3), blurRadius: 8)
              ]
            : null,
      ),
      child: Column(
        children: [
          Text(
            'Day',
            style: TextStyle(
              color: colors.textPrimary.withOpacity(0.3),
              fontSize: 8,
            ),
          ),
          Text(
            '${day.day}',
            style: TextStyle(
              color: claimed || isCurrent
                  ? colors.textPrimary
                  : colors.textPrimary.withOpacity(0.4),
              fontSize: 13,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            claimed ? '✓' : day.isSpecial ? '🎁' : '🪙',
            style: const TextStyle(fontSize: 14),
          ),
          Text(
            '${day.coins}',
            style: TextStyle(
              color: day.isSpecial
                  ? colors.textAccent
                  : colors.textPrimary.withOpacity(0.7),
              fontSize: 10,
              fontWeight:
                  day.isSpecial ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}

class _ClaimButton extends StatelessWidget {
  final GameThemeColors colors;
  final bool isLoading;
  final VoidCallback onClaim;

  const _ClaimButton({
    required this.colors,
    required this.isLoading,
    required this.onClaim,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: GestureDetector(
        onTap: isLoading ? null : onClaim,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 18),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [colors.buttonPrimary, colors.buttonSecondary],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: colors.panelBorder, width: 1),
            boxShadow: [
              BoxShadow(
                color: colors.glowColor.withOpacity(0.4),
                blurRadius: 20,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: isLoading
              ? Center(
                  child: SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: colors.textPrimary,
                      strokeWidth: 2,
                    ),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('🎁', style: TextStyle(fontSize: 22)),
                    const SizedBox(width: 10),
                    Text(
                      'CLAIM REWARD',
                      style: TextStyle(
                        color: colors.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class _Countdown extends StatefulWidget {
  final Duration timeUntilNext;
  final GameThemeColors colors;

  const _Countdown({required this.timeUntilNext, required this.colors});

  @override
  State<_Countdown> createState() => _CountdownState();
}

class _CountdownState extends State<_Countdown> {
  late Duration _remaining;

  @override
  void initState() {
    super.initState();
    _remaining = widget.timeUntilNext;
    _tick();
  }

  void _tick() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      setState(() {
        _remaining = _remaining.inSeconds > 0
            ? _remaining - const Duration(seconds: 1)
            : Duration.zero;
      });
      if (_remaining.inSeconds > 0) _tick();
    });
  }

  @override
  Widget build(BuildContext context) {
    final h = _remaining.inHours.toString().padLeft(2, '0');
    final m = (_remaining.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_remaining.inSeconds % 60).toString().padLeft(2, '0');
    final colors = widget.colors;

    return Column(
      children: [
        Text(
          'Next reward in',
          style: TextStyle(
            color: colors.textPrimary.withOpacity(0.5),
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          '$h:$m:$s',
          style: TextStyle(
            color: colors.textPrimary,
            fontSize: 36,
            fontWeight: FontWeight.bold,
            fontFamily: 'monospace',
            shadows: [Shadow(color: colors.glowColor, blurRadius: 12)],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Come back tomorrow!',
          style: TextStyle(
            color: colors.textPrimary.withOpacity(0.3),
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────
//  Celebration overlay
// ─────────────────────────────────────────────

class _CelebrationOverlay extends StatelessWidget {
  final DailyRewardResult result;
  final GameThemeColors colors;
  final AnimationController ctrl;
  final VoidCallback onDone;

  const _CelebrationOverlay({
    required this.result,
    required this.colors,
    required this.ctrl,
    required this.onDone,
  });

  @override
  Widget build(BuildContext context) {
    final scale = CurvedAnimation(parent: ctrl, curve: Curves.elasticOut);
    final fade = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
          parent: ctrl,
          curve: const Interval(0.0, 0.3, curve: Curves.easeIn)),
    );

    return Positioned.fill(
      child: GestureDetector(
        onTap: onDone,
        child: AnimatedBuilder(
          animation: ctrl,
          builder: (ctx, _) => Container(
            color: Colors.black.withOpacity(0.7 * fade.value),
            child: Center(
              child: Transform.scale(
                scale: scale.value,
                child: Container(
                  margin: const EdgeInsets.all(40),
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    color: colors.panelBg,
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: colors.panelBorder, width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: colors.glowColor.withOpacity(0.4),
                        blurRadius: 40,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('🎉', style: TextStyle(fontSize: 52)),
                      const SizedBox(height: 12),
                      Text(
                        result.message,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: colors.textPrimary,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text('🪙', style: TextStyle(fontSize: 28)),
                          const SizedBox(width: 8),
                          Text(
                            '+${result.coinsEarned}',
                            style: TextStyle(
                              color: colors.textAccent,
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              shadows: [
                                Shadow(
                                    color: colors.glowColor, blurRadius: 12)
                              ],
                            ),
                          ),
                        ],
                      ),
                      if (result.bonusItem != null) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: colors.buttonPrimary.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: colors.panelBorder.withOpacity(0.5)),
                          ),
                          child: Text(
                            '🎁 ${result.bonusItem} unlocked!',
                            style: TextStyle(
                              color: colors.textAccent,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 24),
                      Text(
                        'Tap anywhere to continue',
                        style: TextStyle(
                          color: colors.textPrimary.withOpacity(0.3),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
