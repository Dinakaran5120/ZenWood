import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../data/auth_repository.dart';
import '../data/user_repository.dart';
import '../../../core/models/user_model.dart';
import '../../../core/services/location_service.dart';

// ─────────────────────────────────────────────
//  AuthState
// ─────────────────────────────────────────────

enum AuthStatus { initial, loading, authenticated, unauthenticated, error }

class AuthState {
  final AuthStatus status;
  final UserModel? user;
  final String? errorMessage;
  final bool needsUsername; // true for new anonymous users

  const AuthState({
    this.status = AuthStatus.initial,
    this.user,
    this.errorMessage,
    this.needsUsername = false,
  });

  AuthState copyWith({
    AuthStatus? status,
    UserModel? user,
    String? errorMessage,
    bool? needsUsername,
  }) =>
      AuthState(
        status: status ?? this.status,
        user: user ?? this.user,
        errorMessage: errorMessage ?? this.errorMessage,
        needsUsername: needsUsername ?? this.needsUsername,
      );

  bool get isAuthenticated => status == AuthStatus.authenticated;
  bool get isLoading => status == AuthStatus.loading;
}

// ─────────────────────────────────────────────
//  AuthNotifier
// ─────────────────────────────────────────────

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _authRepo;
  final UserRepository _userRepo;
  final LocationService _locationService;

  AuthNotifier(this._authRepo, this._userRepo, this._locationService)
      : super(const AuthState()) {
    _init();
  }

  void _init() {
    _authRepo.authStateChanges.listen((user) async {
      if (user == null) {
        state = const AuthState(status: AuthStatus.unauthenticated);
      } else {
        await _onUserSignedIn(user);
      }
    });
  }

  Future<void> _onUserSignedIn(User firebaseUser) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      var profile = await _userRepo.getUserProfile(firebaseUser.uid);

      if (profile == null) {
        // New user — create profile
        final username = firebaseUser.isAnonymous
            ? 'Player${firebaseUser.uid.substring(0, 4).toUpperCase()}'
            : (firebaseUser.displayName ?? 'Player');

        await _userRepo.createUserProfile(
          uid: firebaseUser.uid,
          email: firebaseUser.email ?? '',
          username: username,
          photoUrl: firebaseUser.photoURL,
        );
        profile = await _userRepo.getUserProfile(firebaseUser.uid);

        // Fetch location in background
        _fetchAndSaveLocation(firebaseUser.uid);
      } else {
        // Existing — update lastSeen
        await _userRepo.touchLastSeen(firebaseUser.uid);
      }

      state = AuthState(
        status: AuthStatus.authenticated,
        user: profile,
        needsUsername: firebaseUser.isAnonymous,
      );
    } catch (e) {
      state = state.copyWith(
        status: AuthStatus.error,
        errorMessage: e.toString(),
      );
    }
  }

  // ── Sign in methods ───────────────────────

  Future<void> signInWithGoogle() async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      await _authRepo.signInWithGoogle();
      // _onUserSignedIn is called via stream
    } on AuthException catch (e) {
      state = state.copyWith(
        status: AuthStatus.unauthenticated,
        errorMessage: e.message,
      );
    }
  }

  Future<void> signInAnonymously() async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      await _authRepo.signInAnonymously();
    } on AuthException catch (e) {
      state = state.copyWith(
        status: AuthStatus.unauthenticated,
        errorMessage: e.message,
      );
    }
  }

  Future<void> signInWithEmail({
    required String email,
    required String password,
  }) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      await _authRepo.signInWithEmail(email: email, password: password);
    } on AuthException catch (e) {
      state = state.copyWith(
        status: AuthStatus.unauthenticated,
        errorMessage: e.message,
      );
    }
  }

  Future<void> createAccount({
    required String email,
    required String password,
    required String username,
  }) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      final cred = await _authRepo.createUserWithEmail(
        email: email,
        password: password,
      );
      // Pre-set username before _onUserSignedIn fires
      if (cred.user != null) {
        await _userRepo.createUserProfile(
          uid: cred.user!.uid,
          email: email,
          username: username,
        );
      }
    } on AuthException catch (e) {
      state = state.copyWith(
        status: AuthStatus.unauthenticated,
        errorMessage: e.message,
      );
    }
  }

  // ── Update username ───────────────────────

  Future<bool> setUsername(String username) async {
    final uid = _authRepo.currentUid;
    if (uid == null) return false;
    try {
      await _userRepo.updateUsername(uid, username);
      state = state.copyWith(
        needsUsername: false,
        user: state.user?.copyWith(username: username),
      );
      return true;
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
      return false;
    }
  }

  // ── Location ──────────────────────────────

  Future<void> _fetchAndSaveLocation(String uid) async {
    final result = await _locationService.getLocation();
    if (result == null) return;
    await _userRepo.updateLocation(
      uid: uid,
      latitude: result.latitude,
      longitude: result.longitude,
      country: result.country,
      countryName: result.countryName,
    );
    // Refresh local state
    final updated = await _userRepo.getUserProfile(uid);
    if (updated != null && mounted) {
      state = state.copyWith(user: updated);
    }
  }

  Future<void> refreshLocation() async {
    final uid = _authRepo.currentUid;
    if (uid == null) return;
    await _fetchAndSaveLocation(uid);
  }

  // ── Sign out ──────────────────────────────

  Future<void> signOut() async {
    await _authRepo.signOut();
    state = const AuthState(status: AuthStatus.unauthenticated);
  }

  // ── Link anonymous to Google ──────────────

  Future<void> linkWithGoogle() async {
    try {
      await _authRepo.linkAnonymousWithGoogle();
      state = state.copyWith(needsUsername: false);
    } on AuthException catch (e) {
      state = state.copyWith(errorMessage: e.message);
    }
  }

  void clearError() => state = state.copyWith(errorMessage: null);
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final authNotifierProvider =
    StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(
    ref.read(authRepositoryProvider),
    ref.read(userRepositoryProvider),
    ref.read(locationServiceProvider),
  );
});
