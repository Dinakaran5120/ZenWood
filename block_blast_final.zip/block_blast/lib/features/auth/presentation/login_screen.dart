import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/auth_notifier.dart';
import '../../game/components/forest_background.dart';
import '../../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  LoginScreen
//  Forest-themed premium login UI
// ─────────────────────────────────────────────

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entryCtrl;
  late Animation<double> _fadeIn;
  late Animation<Offset> _slideUp;

  bool _showEmailForm = false;
  bool _isRegister = false;

  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  final _colors = forestTheme.colors;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    _fadeIn = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeIn);
    _slideUp = Tween(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _usernameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);

    // Listen for errors
    ref.listen<AuthState>(authNotifierProvider, (_, next) {
      if (next.errorMessage != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.errorMessage!),
            backgroundColor: Colors.red.shade800,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
        );
        ref.read(authNotifierProvider.notifier).clearError();
      }
    });

    return Scaffold(
      backgroundColor: Colors.black,
      body: ForestBackground(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeIn,
            child: SlideTransition(
              position: _slideUp,
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(28),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ── Logo / Title ──────
                      _LogoSection(colors: _colors),

                      const SizedBox(height: 48),

                      // ── Auth card ─────────
                      _AuthCard(
                        colors: _colors,
                        child: authState.isLoading
                            ? _LoadingIndicator(colors: _colors)
                            : _showEmailForm
                                ? _EmailForm(
                                    isRegister: _isRegister,
                                    colors: _colors,
                                    emailCtrl: _emailCtrl,
                                    passCtrl: _passCtrl,
                                    usernameCtrl: _usernameCtrl,
                                    formKey: _formKey,
                                    onSubmit: _handleEmailSubmit,
                                    onBack: () => setState(
                                        () => _showEmailForm = false),
                                    onToggle: () => setState(
                                        () => _isRegister = !_isRegister),
                                  )
                                : _SignInButtons(
                                    colors: _colors,
                                    onGoogle: () => ref
                                        .read(authNotifierProvider.notifier)
                                        .signInWithGoogle(),
                                    onEmail: () => setState(
                                        () => _showEmailForm = true),
                                    onGuest: () => ref
                                        .read(authNotifierProvider.notifier)
                                        .signInAnonymously(),
                                  ),
                      ),

                      const SizedBox(height: 24),

                      Text(
                        'By continuing you agree to our Terms & Privacy Policy',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _colors.textPrimary.withOpacity(0.3),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _handleEmailSubmit() async {
    if (!_formKey.currentState!.validate()) return;
    final notifier = ref.read(authNotifierProvider.notifier);
    if (_isRegister) {
      await notifier.createAccount(
        email: _emailCtrl.text.trim(),
        password: _passCtrl.text,
        username: _usernameCtrl.text.trim(),
      );
    } else {
      await notifier.signInWithEmail(
        email: _emailCtrl.text.trim(),
        password: _passCtrl.text,
      );
    }
  }
}

// ─────────────────────────────────────────────
//  Logo section
// ─────────────────────────────────────────────

class _LogoSection extends StatelessWidget {
  final GameThemeColors colors;
  const _LogoSection({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: colors.panelBg,
            border: Border.all(color: colors.panelBorder, width: 2),
            boxShadow: [
              BoxShadow(
                color: colors.glowColor.withOpacity(0.4),
                blurRadius: 30,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Icon(
            Icons.grid_view_rounded,
            color: colors.textAccent,
            size: 44,
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'BLOCK BLAST',
          style: TextStyle(
            color: colors.textPrimary,
            fontSize: 32,
            fontWeight: FontWeight.bold,
            letterSpacing: 4,
            shadows: [
              Shadow(color: colors.glowColor, blurRadius: 16),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Enchanted Forest Edition',
          style: TextStyle(
            color: colors.textAccent.withOpacity(0.7),
            fontSize: 13,
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────
//  Auth card container
// ─────────────────────────────────────────────

class _AuthCard extends StatelessWidget {
  final GameThemeColors colors;
  final Widget child;
  const _AuthCard({required this.colors, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: colors.panelBg,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: colors.panelBorder.withOpacity(0.5),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: colors.glowColor.withOpacity(0.1),
            blurRadius: 24,
            spreadRadius: 2,
          ),
        ],
      ),
      child: child,
    );
  }
}

// ─────────────────────────────────────────────
//  Sign-in buttons
// ─────────────────────────────────────────────

class _SignInButtons extends StatelessWidget {
  final GameThemeColors colors;
  final VoidCallback onGoogle, onEmail, onGuest;
  const _SignInButtons({
    required this.colors,
    required this.onGoogle,
    required this.onEmail,
    required this.onGuest,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'Sign in to save your progress',
          style: TextStyle(
            color: colors.textPrimary.withOpacity(0.6),
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 24),
        _AuthButton(
          label: 'Continue with Google',
          icon: Icons.g_mobiledata_rounded,
          colors: colors,
          onTap: onGoogle,
          isPrimary: true,
        ),
        const SizedBox(height: 12),
        _AuthButton(
          label: 'Continue with Email',
          icon: Icons.email_outlined,
          colors: colors,
          onTap: onEmail,
        ),
        const SizedBox(height: 20),
        Row(children: [
          Expanded(
              child: Divider(color: colors.panelBorder.withOpacity(0.3))),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(
              'or',
              style: TextStyle(
                  color: colors.textPrimary.withOpacity(0.3), fontSize: 12),
            ),
          ),
          Expanded(
              child: Divider(color: colors.panelBorder.withOpacity(0.3))),
        ]),
        const SizedBox(height: 16),
        TextButton(
          onPressed: onGuest,
          child: Text(
            'Play as Guest',
            style: TextStyle(
              color: colors.textPrimary.withOpacity(0.5),
              fontSize: 13,
              decoration: TextDecoration.underline,
              decorationColor: colors.textPrimary.withOpacity(0.3),
            ),
          ),
        ),
      ],
    );
  }
}

class _AuthButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final GameThemeColors colors;
  final VoidCallback onTap;
  final bool isPrimary;

  const _AuthButton({
    required this.label,
    required this.icon,
    required this.colors,
    required this.onTap,
    this.isPrimary = false,
  });

  @override
  State<_AuthButton> createState() => _AuthButtonState();
}

class _AuthButtonState extends State<_AuthButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scale = Tween(begin: 1.0, end: 0.96).animate(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (ctx, _) => Transform.scale(
          scale: _scale.value,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: widget.isPrimary
                  ? c.buttonPrimary
                  : c.panelBorder.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: widget.isPrimary
                    ? c.panelBorder
                    : c.panelBorder.withOpacity(0.3),
                width: 1,
              ),
              boxShadow: widget.isPrimary
                  ? [
                      BoxShadow(
                        color: c.glowColor.withOpacity(0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 3),
                      )
                    ]
                  : null,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(widget.icon, color: c.textPrimary, size: 22),
                const SizedBox(width: 10),
                Text(
                  widget.label,
                  style: TextStyle(
                    color: c.textPrimary,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Email form
// ─────────────────────────────────────────────

class _EmailForm extends StatelessWidget {
  final bool isRegister;
  final GameThemeColors colors;
  final TextEditingController emailCtrl, passCtrl, usernameCtrl;
  final GlobalKey<FormState> formKey;
  final VoidCallback onSubmit, onBack, onToggle;

  const _EmailForm({
    required this.isRegister,
    required this.colors,
    required this.emailCtrl,
    required this.passCtrl,
    required this.usernameCtrl,
    required this.formKey,
    required this.onSubmit,
    required this.onBack,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: onBack,
                child: Icon(Icons.arrow_back_ios,
                    color: colors.textPrimary, size: 20),
              ),
              const SizedBox(width: 8),
              Text(
                isRegister ? 'Create Account' : 'Sign In',
                style: TextStyle(
                  color: colors.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          if (isRegister) ...[
            _ThemedField(
              ctrl: usernameCtrl,
              label: 'Username',
              icon: Icons.person_outline,
              colors: colors,
              validator: (v) => (v == null || v.length < 3)
                  ? 'Min 3 characters'
                  : null,
            ),
            const SizedBox(height: 12),
          ],

          _ThemedField(
            ctrl: emailCtrl,
            label: 'Email',
            icon: Icons.email_outlined,
            colors: colors,
            keyboardType: TextInputType.emailAddress,
            validator: (v) =>
                (v == null || !v.contains('@')) ? 'Enter valid email' : null,
          ),
          const SizedBox(height: 12),
          _ThemedField(
            ctrl: passCtrl,
            label: 'Password',
            icon: Icons.lock_outline,
            colors: colors,
            obscure: true,
            validator: (v) =>
                (v == null || v.length < 6) ? 'Min 6 characters' : null,
          ),
          const SizedBox(height: 20),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onSubmit,
              style: ElevatedButton.styleFrom(
                backgroundColor: colors.buttonPrimary,
                foregroundColor: colors.textPrimary,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
              child: Text(
                isRegister ? 'Create Account' : 'Sign In',
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: TextButton(
              onPressed: onToggle,
              child: Text(
                isRegister
                    ? 'Already have an account? Sign in'
                    : "Don't have an account? Register",
                style: TextStyle(
                  color: colors.textAccent,
                  fontSize: 13,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ThemedField extends StatelessWidget {
  final TextEditingController ctrl;
  final String label;
  final IconData icon;
  final GameThemeColors colors;
  final bool obscure;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;

  const _ThemedField({
    required this.ctrl,
    required this.label,
    required this.icon,
    required this.colors,
    this.obscure = false,
    this.keyboardType,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: ctrl,
      obscureText: obscure,
      keyboardType: keyboardType,
      validator: validator,
      style: TextStyle(color: colors.textPrimary, fontSize: 15),
      decoration: InputDecoration(
        labelText: label,
        labelStyle:
            TextStyle(color: colors.textPrimary.withOpacity(0.5), fontSize: 13),
        prefixIcon: Icon(icon, color: colors.textPrimary.withOpacity(0.5), size: 20),
        filled: true,
        fillColor: colors.panelBorder.withOpacity(0.1),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colors.panelBorder.withOpacity(0.3)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colors.panelBorder.withOpacity(0.3)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colors.glowColor, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Loading indicator
// ─────────────────────────────────────────────

class _LoadingIndicator extends StatelessWidget {
  final GameThemeColors colors;
  const _LoadingIndicator({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 32),
      child: Center(
        child: Column(
          children: [
            SizedBox(
              width: 36,
              height: 36,
              child: CircularProgressIndicator(
                color: colors.glowColor,
                strokeWidth: 2.5,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              'Connecting...',
              style: TextStyle(
                color: colors.textPrimary.withOpacity(0.5),
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Username Setup Screen (for anonymous users)
// ─────────────────────────────────────────────

class UsernameSetupScreen extends ConsumerStatefulWidget {
  const UsernameSetupScreen({super.key});

  @override
  ConsumerState<UsernameSetupScreen> createState() =>
      _UsernameSetupScreenState();
}

class _UsernameSetupScreenState extends ConsumerState<UsernameSetupScreen> {
  final _ctrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _loading = false;
  final _colors = forestTheme.colors;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final ok = await ref
        .read(authNotifierProvider.notifier)
        .setUsername(_ctrl.text.trim());
    if (!ok && mounted) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: ForestBackground(
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: _colors.panelBg,
                  borderRadius: BorderRadius.circular(24),
                  border:
                      Border.all(color: _colors.panelBorder.withOpacity(0.5)),
                  boxShadow: [
                    BoxShadow(
                      color: _colors.glowColor.withOpacity(0.15),
                      blurRadius: 30,
                    ),
                  ],
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.person_outline,
                          color: _colors.textAccent, size: 48),
                      const SizedBox(height: 16),
                      Text(
                        'Choose your name',
                        style: TextStyle(
                          color: _colors.textPrimary,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'This will appear on the leaderboard',
                        style: TextStyle(
                          color: _colors.textPrimary.withOpacity(0.5),
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 24),
                      _ThemedField(
                        ctrl: _ctrl,
                        label: 'Username',
                        icon: Icons.person_outline,
                        colors: _colors,
                        validator: (v) {
                          if (v == null || v.trim().length < 3) {
                            return 'Min 3 characters';
                          }
                          if (v.trim().length > 16) {
                            return 'Max 16 characters';
                          }
                          if (!RegExp(r'^[a-zA-Z0-9_]+$').hasMatch(v.trim())) {
                            return 'Letters, numbers, underscores only';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _loading ? null : _submit,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _colors.buttonPrimary,
                            foregroundColor: _colors.textPrimary,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14)),
                          ),
                          child: _loading
                              ? SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                    color: _colors.textPrimary,
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Text(
                                  'Start Playing',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
