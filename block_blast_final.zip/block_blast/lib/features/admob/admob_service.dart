import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../analytics/analytics_service.dart';

// ─────────────────────────────────────────────
//  AdMob Service — Production ready
//  All ad unit IDs use test IDs in debug mode
//  Replace _prod* constants with real IDs
// ─────────────────────────────────────────────

class AdIds {
  // ── Test IDs (auto-used in debug) ─────────
  static const _testBanner     = 'ca-app-pub-3940256099942544/6300978111';
  static const _testInterstitial= 'ca-app-pub-3940256099942544/1033173712';
  static const _testRewarded   = 'ca-app-pub-3940256099942544/5224354917';

  // ── Production IDs (replace these) ────────
  static const _prodBanner      = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
  static const _prodInterstitial= 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
  static const _prodRewarded    = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';

  static String get banner =>
      kDebugMode ? _testBanner : _prodBanner;
  static String get interstitial =>
      kDebugMode ? _testInterstitial : _prodInterstitial;
  static String get rewarded =>
      kDebugMode ? _testRewarded : _prodRewarded;
}

enum AdType { banner, interstitial, rewarded, dailyReward, continueAfterFail }

class AdResult {
  final bool earned;
  final int coinsEarned;
  final String? message;
  const AdResult({this.earned = false, this.coinsEarned = 0, this.message});
}

class AdMobService {
  final AnalyticsService _analytics;

  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  RewardedAd? _dailyRewardAd;
  RewardedAd? _continueAd;
  BannerAd? _bannerAd;

  bool _interstitialLoading = false;
  bool _rewardedLoading = false;
  bool _dailyRewardLoading = false;
  bool _continueLoading = false;
  bool _bannerLoaded = false;

  // Completer for awaiting rewarded result
  Completer<AdResult>? _rewardCompleter;

  AdMobService(this._analytics);

  // ── Initialize ────────────────────────────
  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    // Request configuration
    final config = RequestConfiguration(
      testDeviceIds: kDebugMode ? ['YOUR_TEST_DEVICE_ID'] : [],
    );
    MobileAds.instance.updateRequestConfiguration(config);
    // Pre-load all ad types
    await Future.wait([
      _loadInterstitial(),
      _loadRewarded(),
      _loadDailyReward(),
      _loadContinueAd(),
      _loadBanner(),
    ]);
  }

  // ─────────────────────────────────────────
  //  BANNER AD
  // ─────────────────────────────────────────

  Future<void> _loadBanner() async {
    _bannerAd?.dispose();
    _bannerAd = BannerAd(
      adUnitId: AdIds.banner,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => _bannerLoaded = true,
        onAdFailedToLoad: (_, error) {
          _bannerLoaded = false;
          // Retry after 30s
          Future.delayed(const Duration(seconds: 30), _loadBanner);
        },
      ),
    );
    await _bannerAd!.load();
  }

  BannerAd? get bannerAd => _bannerLoaded ? _bannerAd : null;

  // ─────────────────────────────────────────
  //  INTERSTITIAL AD
  // ─────────────────────────────────────────

  Future<void> _loadInterstitial() async {
    if (_interstitialLoading) return;
    _interstitialLoading = true;
    await InterstitialAd.load(
      adUnitId: AdIds.interstitial,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _interstitialLoading = false;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (_) {
              _interstitialAd = null;
              _loadInterstitial(); // pre-load next
            },
            onAdFailedToShowFullScreenContent: (_, error) {
              _interstitialAd = null;
              _loadInterstitial();
            },
          );
        },
        onAdFailedToLoad: (error) {
          _interstitialLoading = false;
          Future.delayed(const Duration(seconds: 60), _loadInterstitial);
        },
      ),
    );
  }

  /// Show interstitial (e.g. between games). Returns false if not ready.
  Future<bool> showInterstitial() async {
    if (_interstitialAd == null) {
      await _loadInterstitial();
      return false;
    }
    await _analytics.logAdImpression(AdType.interstitial);
    await _interstitialAd!.show();
    return true;
  }

  // ─────────────────────────────────────────
  //  REWARDED AD — generic coins reward
  // ─────────────────────────────────────────

  Future<void> _loadRewarded() async {
    if (_rewardedLoading) return;
    _rewardedLoading = true;
    await RewardedAd.load(
      adUnitId: AdIds.rewarded,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _rewardedLoading = false;
          _setupRewardedCallbacks(ad, AdType.rewarded);
        },
        onAdFailedToLoad: (error) {
          _rewardedLoading = false;
          Future.delayed(const Duration(seconds: 60), _loadRewarded);
        },
      ),
    );
  }

  void _setupRewardedCallbacks(RewardedAd ad, AdType type) {
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (_) {
        // If completer wasn't completed (user skipped), complete with no reward
        if (_rewardCompleter != null && !_rewardCompleter!.isCompleted) {
          _rewardCompleter!.complete(
              const AdResult(earned: false, message: 'Ad skipped'));
        }
        _rewardCompleter = null;
        // Reload
        if (type == AdType.rewarded) _loadRewarded();
        if (type == AdType.dailyReward) _loadDailyReward();
        if (type == AdType.continueAfterFail) _loadContinueAd();
      },
      onAdFailedToShowFullScreenContent: (_, error) {
        _rewardCompleter?.complete(
            const AdResult(earned: false, message: 'Ad failed to show'));
        _rewardCompleter = null;
      },
    );
  }

  /// Show rewarded ad and wait for result
  Future<AdResult> showRewardedAd({int coinsOnSuccess = 100}) async {
    if (_rewardedAd == null) {
      await _loadRewarded();
      return const AdResult(earned: false, message: 'Ad not ready yet');
    }
    _rewardCompleter = Completer<AdResult>();
    await _analytics.logAdImpression(AdType.rewarded);
    await _rewardedAd!.show(
      onUserEarnedReward: (_, reward) {
        _rewardCompleter?.complete(AdResult(
          earned: true,
          coinsEarned: coinsOnSuccess,
          message: '+$coinsOnSuccess coins!',
        ));
        _rewardedAd = null;
      },
    );
    return _rewardCompleter!.future;
  }

  // ─────────────────────────────────────────
  //  DAILY REWARD AD
  // ─────────────────────────────────────────

  Future<void> _loadDailyReward() async {
    if (_dailyRewardLoading) return;
    _dailyRewardLoading = true;
    await RewardedAd.load(
      adUnitId: AdIds.rewarded, // uses same unit — separate tracking
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _dailyRewardAd = ad;
          _dailyRewardLoading = false;
          _setupRewardedCallbacks(ad, AdType.dailyReward);
        },
        onAdFailedToLoad: (_) {
          _dailyRewardLoading = false;
          Future.delayed(const Duration(seconds: 60), _loadDailyReward);
        },
      ),
    );
  }

  /// Watch ad to double daily reward coins
  Future<AdResult> showDailyRewardAd({required int baseCoins}) async {
    if (_dailyRewardAd == null) {
      return const AdResult(earned: false, message: 'Ad not ready');
    }
    _rewardCompleter = Completer<AdResult>();
    await _analytics.logAdImpression(AdType.dailyReward);
    await _dailyRewardAd!.show(
      onUserEarnedReward: (_, __) {
        final bonus = baseCoins; // doubles the reward
        _rewardCompleter?.complete(AdResult(
          earned: true,
          coinsEarned: bonus,
          message: 'Daily reward doubled! +$bonus bonus coins!',
        ));
        _dailyRewardAd = null;
      },
    );
    return _rewardCompleter!.future;
  }

  // ─────────────────────────────────────────
  //  CONTINUE-AFTER-FAIL AD
  // ─────────────────────────────────────────

  Future<void> _loadContinueAd() async {
    if (_continueLoading) return;
    _continueLoading = true;
    await RewardedAd.load(
      adUnitId: AdIds.rewarded,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _continueAd = ad;
          _continueLoading = false;
          _setupRewardedCallbacks(ad, AdType.continueAfterFail);
        },
        onAdFailedToLoad: (_) {
          _continueLoading = false;
          Future.delayed(const Duration(seconds: 60), _loadContinueAd);
        },
      ),
    );
  }

  /// Watch ad to continue after game over
  Future<AdResult> showContinueAfterFailAd() async {
    if (_continueAd == null) {
      return const AdResult(earned: false, message: 'Ad not ready');
    }
    _rewardCompleter = Completer<AdResult>();
    await _analytics.logAdImpression(AdType.continueAfterFail);
    await _continueAd!.show(
      onUserEarnedReward: (_, __) {
        _rewardCompleter?.complete(const AdResult(
          earned: true,
          message: 'Keep going!',
        ));
        _continueAd = null;
      },
    );
    return _rewardCompleter!.future;
  }

  bool get canContinueAfterFail => _continueAd != null;
  bool get canShowRewarded => _rewardedAd != null;
  bool get canShowInterstitial => _interstitialAd != null;

  void dispose() {
    _bannerAd?.dispose();
    _interstitialAd?.dispose();
    _rewardedAd?.dispose();
    _dailyRewardAd?.dispose();
    _continueAd?.dispose();
  }
}

// ─────────────────────────────────────────────
//  Banner Ad Widget
// ─────────────────────────────────────────────

import 'package:flutter/material.dart';

class BannerAdWidget extends ConsumerWidget {
  const BannerAdWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final adService = ref.read(adMobServiceProvider);
    final banner = adService.bannerAd;
    if (banner == null) return const SizedBox.shrink();
    return Container(
      width: banner.size.width.toDouble(),
      height: banner.size.height.toDouble(),
      alignment: Alignment.center,
      child: AdWidget(ad: banner),
    );
  }
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final adMobServiceProvider = Provider<AdMobService>((ref) {
  final analytics = ref.read(analyticsServiceProvider);
  return AdMobService(analytics);
});
