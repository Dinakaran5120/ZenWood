import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'store_models.dart';
import 'store_repository.dart';
import '../auth/domain/auth_notifier.dart';
import '../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  StoreScreen — Premium animated in-game store
// ─────────────────────────────────────────────

class StoreScreen extends ConsumerStatefulWidget {
  final GameThemeData theme;
  const StoreScreen({super.key, required this.theme});

  @override
  ConsumerState<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends ConsumerState<StoreScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entryCtrl;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..forward();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = ref.watch(storeProvider);
    final auth = ref.watch(authNotifierProvider);
    final colors = widget.theme.colors;
    final coins = auth.user?.coins ?? 0;

    // Show purchase feedback
    ref.listen<StoreState>(storeProvider, (_, next) {
      if (next.message != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.message!),
            backgroundColor: colors.buttonPrimary,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            duration: const Duration(seconds: 2),
          ),
        );
        ref.read(storeProvider.notifier).clearMessage();
      }
    });

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: FadeTransition(
        opacity: _entryCtrl,
        child: Column(
          children: [
            // ── Header + coins ────────────
            _StoreHeader(colors: colors, coins: coins),

            // ── Avatar preview ────────────
            _AvatarPreview(
              inventory: store.inventory,
              colors: colors,
            ),

            // ── Category tabs ─────────────
            _CategoryTabs(
              selected: store.selectedCategory,
              colors: colors,
              onSelect: (cat) =>
                  ref.read(storeProvider.notifier).selectCategory(cat),
            ),

            const SizedBox(height: 8),

            // ── Items grid ────────────────
            Expanded(
              child: store.isLoading
                  ? Center(
                      child: CircularProgressIndicator(color: colors.glowColor))
                  : _ItemsGrid(
                      items: store.filteredItems,
                      inventory: store.inventory,
                      coins: coins,
                      colors: colors,
                      onBuy: (item) async {
                        final result = await ref
                            .read(storeProvider.notifier)
                            .purchase(item, coins);
                        if (!result.isSuccess &&
                            result.status ==
                                PurchaseStatus.insufficientCoins) {
                          _showInsufficientCoins(context, colors, result);
                        }
                      },
                      onEquip: (item) =>
                          ref.read(storeProvider.notifier).equip(item),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _showInsufficientCoins(
      BuildContext context, GameThemeColors colors, PurchaseResult result) {
    showDialog(
      context: context,
      builder: (_) => _InsufficientCoinsDialog(
        colors: colors,
        coinsNeeded: result.coinsNeeded ?? 0,
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Store Header
// ─────────────────────────────────────────────

class _StoreHeader extends StatelessWidget {
  final GameThemeColors colors;
  final int coins;
  const _StoreHeader({required this.colors, required this.coins});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Icon(Icons.arrow_back_ios, color: colors.textPrimary, size: 20),
          ),
          const SizedBox(width: 12),
          Text(
            'STORE',
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 22,
              fontWeight: FontWeight.bold,
              letterSpacing: 3,
            ),
          ),
          const Spacer(),
          // Coin balance
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: colors.panelBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: colors.panelBorder.withOpacity(0.5)),
              boxShadow: [
                BoxShadow(color: colors.glowColor.withOpacity(0.15), blurRadius: 8)
              ],
            ),
            child: Row(
              children: [
                const Text('🪙', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 6),
                Text(
                  _fmt(coins),
                  style: TextStyle(
                    color: colors.textAccent,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _fmt(int n) {
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}

// ─────────────────────────────────────────────
//  Avatar Preview
// ─────────────────────────────────────────────

class _AvatarPreview extends StatefulWidget {
  final Inventory inventory;
  final GameThemeColors colors;
  const _AvatarPreview({required this.inventory, required this.colors});

  @override
  State<_AvatarPreview> createState() => _AvatarPreviewState();
}

class _AvatarPreviewState extends State<_AvatarPreview>
    with SingleTickerProviderStateMixin {
  late AnimationController _floatCtrl;

  @override
  void initState() {
    super.initState();
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _floatCtrl.dispose();
    super.dispose();
  }

  String _findEmoji(String? id) {
    if (id == null) return '';
    return storeCatalog.firstWhere((i) => i.id == id,
        orElse: () => storeCatalog.first).emoji;
  }

  @override
  Widget build(BuildContext context) {
    final inv = widget.inventory;
    final c = widget.colors;

    return AnimatedBuilder(
      animation: _floatCtrl,
      builder: (ctx, _) => Transform.translate(
        offset: Offset(0, -4 + _floatCtrl.value * 8),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: c.panelBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: c.panelBorder.withOpacity(0.4)),
            boxShadow: [
              BoxShadow(color: c.glowColor.withOpacity(0.15), blurRadius: 20)
            ],
          ),
          child: Column(
            children: [
              // Accessories row (above head)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (inv.equippedHalo != null)
                    Text(_findEmoji(inv.equippedHalo),
                        style: const TextStyle(fontSize: 20)),
                  if (inv.equippedHat != null)
                    Text(_findEmoji(inv.equippedHat),
                        style: const TextStyle(fontSize: 24)),
                  if (inv.equippedHorn != null)
                    Text(_findEmoji(inv.equippedHorn),
                        style: const TextStyle(fontSize: 20)),
                ],
              ),
              // Avatar body
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (inv.equippedWing != null)
                    Text(_findEmoji(inv.equippedWing),
                        style: const TextStyle(fontSize: 28)),
                  // Central avatar
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: c.buttonPrimary.withOpacity(0.3),
                          border: Border.all(color: c.panelBorder, width: 2),
                          boxShadow: [
                            BoxShadow(color: c.glowColor.withOpacity(0.3),
                                blurRadius: 16)
                          ],
                        ),
                        child: const Center(
                          child: Text('😊', style: TextStyle(fontSize: 40)),
                        ),
                      ),
                      if (inv.equippedGlasses != null)
                        Positioned(
                          top: 20,
                          child: Text(_findEmoji(inv.equippedGlasses),
                              style: const TextStyle(fontSize: 18)),
                        ),
                    ],
                  ),
                  if (inv.equippedWing != null)
                    Text(_findEmoji(inv.equippedWing),
                        style: const TextStyle(
                            fontSize: 28)),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                inv.bombs > 0 ? '💣 ×${inv.bombs} bombs ready' : 'Equip accessories above',
                style: TextStyle(
                    color: c.textPrimary.withOpacity(0.4), fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Category Tabs
// ─────────────────────────────────────────────

class _CategoryTabs extends StatelessWidget {
  final ItemCategory selected;
  final GameThemeColors colors;
  final ValueChanged<ItemCategory> onSelect;

  const _CategoryTabs({
    required this.selected,
    required this.colors,
    required this.onSelect,
  });

  static const _cats = [
    (ItemCategory.hat, '🎩', 'Hats'),
    (ItemCategory.wing, '🪽', 'Wings'),
    (ItemCategory.glasses, '👓', 'Glasses'),
    (ItemCategory.horn, '😈', 'Horns'),
    (ItemCategory.halo, '😇', 'Halos'),
    (ItemCategory.powerup, '💣', 'Bombs'),
    (ItemCategory.theme, '🎨', 'Themes'),
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 52,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _cats.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final (cat, emoji, label) = _cats[i];
          final isActive = cat == selected;
          return GestureDetector(
            onTap: () => onSelect(cat),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: isActive ? colors.buttonPrimary : colors.panelBg,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: isActive
                      ? colors.panelBorder
                      : colors.panelBorder.withOpacity(0.2),
                ),
                boxShadow: isActive
                    ? [BoxShadow(
                        color: colors.glowColor.withOpacity(0.3), blurRadius: 8)]
                    : null,
              ),
              child: Row(
                children: [
                  Text(emoji, style: const TextStyle(fontSize: 14)),
                  const SizedBox(width: 4),
                  Text(
                    label,
                    style: TextStyle(
                      color: isActive
                          ? colors.textPrimary
                          : colors.textPrimary.withOpacity(0.5),
                      fontSize: 12,
                      fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Items Grid
// ─────────────────────────────────────────────

class _ItemsGrid extends StatelessWidget {
  final List<StoreItem> items;
  final Inventory inventory;
  final int coins;
  final GameThemeColors colors;
  final void Function(StoreItem) onBuy;
  final void Function(StoreItem) onEquip;

  const _ItemsGrid({
    required this.items,
    required this.inventory,
    required this.coins,
    required this.colors,
    required this.onBuy,
    required this.onEquip,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.85,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: items.length,
      itemBuilder: (_, i) {
        final item = items[i];
        final owned = inventory.owns(item.id);
        final canAfford = coins >= item.coinPrice;
        final equipped = _isEquipped(item);

        return _ItemCard(
          item: item,
          owned: owned,
          equipped: equipped,
          canAfford: canAfford,
          colors: colors,
          onTap: owned ? () => onEquip(item) : () => onBuy(item),
        );
      },
    );
  }

  bool _isEquipped(StoreItem item) => switch (item.category) {
        ItemCategory.hat => inventory.equippedHat == item.id,
        ItemCategory.wing => inventory.equippedWing == item.id,
        ItemCategory.glasses => inventory.equippedGlasses == item.id,
        ItemCategory.horn => inventory.equippedHorn == item.id,
        ItemCategory.halo => inventory.equippedHalo == item.id,
        _ => false,
      };
}

class _ItemCard extends StatefulWidget {
  final StoreItem item;
  final bool owned, equipped, canAfford;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _ItemCard({
    required this.item,
    required this.owned,
    required this.equipped,
    required this.canAfford,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_ItemCard> createState() => _ItemCardState();
}

class _ItemCardState extends State<_ItemCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressCtrl;

  @override
  void initState() {
    super.initState();
    _pressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
  }

  @override
  void dispose() {
    _pressCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    final rarity = widget.item.rarity;
    final rarityColor1 = Color(rarity.colors[0]);
    final rarityColor2 = Color(rarity.colors[1]);

    return GestureDetector(
      onTapDown: (_) => _pressCtrl.forward(),
      onTapUp: (_) {
        _pressCtrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _pressCtrl.reverse(),
      child: AnimatedBuilder(
        animation: _pressCtrl,
        builder: (_, __) => Transform.scale(
          scale: 1.0 - _pressCtrl.value * 0.04,
          child: Container(
            decoration: BoxDecoration(
              color: c.panelBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: widget.equipped
                    ? c.glowColor
                    : rarityColor1.withOpacity(0.4),
                width: widget.equipped ? 2 : 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: (widget.equipped ? c.glowColor : rarityColor1)
                      .withOpacity(0.15),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Column(
              children: [
                // Rarity gradient header
                Container(
                  height: 4,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(16)),
                    gradient: LinearGradient(
                      colors: [rarityColor1, rarityColor2],
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Emoji
                        Text(widget.item.emoji,
                            style: const TextStyle(fontSize: 40)),

                        // Name + rarity
                        Column(
                          children: [
                            Text(
                              widget.item.name,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: c.textPrimary,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                    colors: [rarityColor1, rarityColor2]),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                rarity.label,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ],
                        ),

                        // Action button
                        _ActionButton(
                          owned: widget.owned,
                          equipped: widget.equipped,
                          canAfford: widget.canAfford,
                          price: widget.item.coinPrice,
                          colors: c,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final bool owned, equipped, canAfford;
  final int price;
  final GameThemeColors colors;

  const _ActionButton({
    required this.owned,
    required this.equipped,
    required this.canAfford,
    required this.price,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    if (owned) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: equipped
              ? colors.glowColor.withOpacity(0.3)
              : colors.panelBorder.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
          border: equipped
              ? Border.all(color: colors.glowColor, width: 1)
              : null,
        ),
        child: Text(
          equipped ? 'EQUIPPED ✓' : 'EQUIP',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: equipped ? colors.textAccent : colors.textPrimary.withOpacity(0.6),
            fontSize: 11,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: canAfford
            ? colors.buttonPrimary
            : colors.panelBorder.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            canAfford ? '🪙' : '🔒',
            style: const TextStyle(fontSize: 12),
          ),
          const SizedBox(width: 4),
          Text(
            _fmt(price),
            style: TextStyle(
              color: canAfford
                  ? colors.textPrimary
                  : colors.textPrimary.withOpacity(0.3),
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  String _fmt(int n) =>
      n >= 1000 ? '${(n / 1000).toStringAsFixed(1)}K' : n.toString();
}

// ─────────────────────────────────────────────
//  Insufficient Coins Dialog
// ─────────────────────────────────────────────

class _InsufficientCoinsDialog extends StatelessWidget {
  final GameThemeColors colors;
  final int coinsNeeded;

  const _InsufficientCoinsDialog({
    required this.colors,
    required this.coinsNeeded,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: colors.panelBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🪙', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 12),
            Text(
              'Not enough coins',
              style: TextStyle(
                color: colors.textPrimary,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'You need $coinsNeeded more coins.\nWatch an ad to earn coins!',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colors.textPrimary.withOpacity(0.5),
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Later',
                        style:
                            TextStyle(color: colors.textPrimary.withOpacity(0.5))),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: colors.buttonPrimary,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text('Watch Ad 📺',
                        style: TextStyle(color: colors.textPrimary)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
