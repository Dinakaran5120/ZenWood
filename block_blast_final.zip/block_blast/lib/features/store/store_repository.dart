import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'store_models.dart';
import '../auth/data/auth_repository.dart';
import '../auth/data/user_repository.dart';
import '../auth/domain/auth_notifier.dart';
import '../../core/analytics/analytics_service.dart';

// ─────────────────────────────────────────────
//  StoreRepository — purchase + inventory sync
// ─────────────────────────────────────────────

class StoreRepository {
  final FirebaseFirestore _db;
  final AuthRepository _authRepo;
  final UserRepository _userRepo;
  final AnalyticsService _analytics;

  StoreRepository({
    required this._authRepo,
    required this._userRepo,
    required this._analytics,
    FirebaseFirestore? db,
  }) : _db = db ?? FirebaseFirestore.instance;

  DocumentReference<Map<String, dynamic>> _userDoc(String uid) =>
      _db.collection('users').doc(uid);

  // ── Load inventory ────────────────────────
  Future<Inventory> loadInventory(String uid) async {
    final snap = await _userDoc(uid).get();
    final data = snap.data()?['inventory'] as Map<String, dynamic>?;
    return data != null ? Inventory.fromMap(data) : Inventory.empty;
  }

  Stream<Inventory> watchInventory(String uid) {
    return _userDoc(uid).snapshots().map((snap) {
      final data = snap.data()?['inventory'] as Map<String, dynamic>?;
      return data != null ? Inventory.fromMap(data) : Inventory.empty;
    });
  }

  // ── Purchase item with coins ──────────────
  Future<PurchaseResult> purchaseItem({
    required String uid,
    required StoreItem item,
    required int currentCoins,
  }) async {
    if (currentCoins < item.coinPrice) {
      return PurchaseResult.insufficient(item.coinPrice - currentCoins);
    }

    try {
      // Load current inventory
      final inventory = await loadInventory(uid);
      if (inventory.owns(item.id) && item.category != ItemCategory.powerup) {
        return PurchaseResult.alreadyOwned();
      }

      await _db.runTransaction((tx) async {
        final ref = _userDoc(uid);
        final snap = await tx.get(ref);
        final coins = (snap.data()?['coins'] as num?)?.toInt() ?? 0;

        if (coins < item.coinPrice) {
          throw Exception('Insufficient coins');
        }

        // Build updated inventory
        final currentInv = Inventory.fromMap(
            snap.data()?['inventory'] as Map<String, dynamic>? ?? {});

        final newOwned = {...currentInv.ownedItems, item.id};
        int newBombs = currentInv.bombs;
        Set<String> newThemes = {...currentInv.unlockedThemes};

        if (item.category == ItemCategory.powerup) {
          newBombs += (item.metadata['count'] as int? ?? 1);
        }
        if (item.category == ItemCategory.theme) {
          newThemes.add(item.metadata['themeId'] as String);
        }

        final updatedInv = currentInv.copyWith(
          ownedItems: newOwned,
          bombs: newBombs,
          unlockedThemes: newThemes,
        );

        tx.update(ref, {
          'coins': FieldValue.increment(-item.coinPrice),
          'inventory': updatedInv.toMap(),
        });
      });

      await _analytics.logPurchase(
        itemId: item.id,
        itemName: item.name,
        coinCost: item.coinPrice,
      );

      return PurchaseResult.success(item);
    } catch (e) {
      return PurchaseResult.error(e.toString());
    }
  }

  // ── Equip accessory ───────────────────────
  Future<void> equipItem({
    required String uid,
    required StoreItem item,
    required Inventory current,
  }) async {
    if (!current.owns(item.id)) return;

    Inventory updated;
    switch (item.category) {
      case ItemCategory.hat:
        updated = current.equippedHat == item.id
            ? current.copyWith(clearHat: true)
            : current.copyWith(equippedHat: item.id);
      case ItemCategory.wing:
        updated = current.equippedWing == item.id
            ? current.copyWith(clearWing: true)
            : current.copyWith(equippedWing: item.id);
      case ItemCategory.glasses:
        updated = current.equippedGlasses == item.id
            ? current.copyWith(clearGlasses: true)
            : current.copyWith(equippedGlasses: item.id);
      case ItemCategory.horn:
        updated = current.equippedHorn == item.id
            ? current.copyWith(clearHorn: true)
            : current.copyWith(equippedHorn: item.id);
      case ItemCategory.halo:
        updated = current.equippedHalo == item.id
            ? current.copyWith(clearHalo: true)
            : current.copyWith(equippedHalo: item.id);
      default:
        return;
    }

    await _userDoc(uid).update({'inventory': updated.toMap()});
  }

  // ── Use a bomb ────────────────────────────
  Future<bool> useBomb(String uid, int currentBombs) async {
    if (currentBombs <= 0) return false;
    await _userDoc(uid).update({
      'inventory.bombs': FieldValue.increment(-1),
    });
    return true;
  }

  // ── Add coins (from ads, spin, rewards) ───
  Future<void> addCoins(String uid, int amount) async {
    await _userDoc(uid).update({'coins': FieldValue.increment(amount)});
  }
}

// ─────────────────────────────────────────────
//  Purchase Result
// ─────────────────────────────────────────────

enum PurchaseStatus { success, insufficientCoins, alreadyOwned, error }

class PurchaseResult {
  final PurchaseStatus status;
  final StoreItem? item;
  final int? coinsNeeded;
  final String? errorMessage;

  const PurchaseResult._({
    required this.status,
    this.item,
    this.coinsNeeded,
    this.errorMessage,
  });

  factory PurchaseResult.success(StoreItem item) =>
      PurchaseResult._(status: PurchaseStatus.success, item: item);
  factory PurchaseResult.insufficient(int needed) =>
      PurchaseResult._(status: PurchaseStatus.insufficientCoins, coinsNeeded: needed);
  factory PurchaseResult.alreadyOwned() =>
      PurchaseResult._(status: PurchaseStatus.alreadyOwned);
  factory PurchaseResult.error(String msg) =>
      PurchaseResult._(status: PurchaseStatus.error, errorMessage: msg);

  bool get isSuccess => status == PurchaseStatus.success;
  String get message => switch (status) {
        PurchaseStatus.success => '${item?.name} purchased!',
        PurchaseStatus.insufficientCoins =>
          'Need ${coinsNeeded ?? 0} more coins',
        PurchaseStatus.alreadyOwned => 'Already owned',
        PurchaseStatus.error => errorMessage ?? 'Purchase failed',
      };
}

// ─────────────────────────────────────────────
//  Store State + Notifier
// ─────────────────────────────────────────────

class StoreState {
  final Inventory inventory;
  final bool isLoading;
  final String? message;
  final ItemCategory selectedCategory;

  const StoreState({
    this.inventory = const Inventory(),
    this.isLoading = false,
    this.message,
    this.selectedCategory = ItemCategory.hat,
  });

  StoreState copyWith({
    Inventory? inventory,
    bool? isLoading,
    String? message,
    ItemCategory? selectedCategory,
  }) =>
      StoreState(
        inventory: inventory ?? this.inventory,
        isLoading: isLoading ?? this.isLoading,
        message: message,
        selectedCategory: selectedCategory ?? this.selectedCategory,
      );

  List<StoreItem> get filteredItems =>
      storeCatalog.where((i) => i.category == selectedCategory).toList();
}

class StoreNotifier extends StateNotifier<StoreState> {
  final StoreRepository _repo;
  final String? _uid;

  StoreNotifier(this._repo, this._uid) : super(const StoreState()) {
    if (_uid != null) _watchInventory();
  }

  void _watchInventory() {
    _repo.watchInventory(_uid!).listen((inv) {
      state = state.copyWith(inventory: inv);
    });
  }

  void selectCategory(ItemCategory cat) =>
      state = state.copyWith(selectedCategory: cat, message: null);

  Future<PurchaseResult> purchase(StoreItem item, int coins) async {
    state = state.copyWith(isLoading: true, message: null);
    final result = await _repo.purchaseItem(
      uid: _uid!,
      item: item,
      currentCoins: coins,
    );
    state = state.copyWith(isLoading: false, message: result.message);
    return result;
  }

  Future<void> equip(StoreItem item) async {
    if (_uid == null) return;
    await _repo.equipItem(uid: _uid!, item: item, current: state.inventory);
  }

  void clearMessage() => state = state.copyWith(message: null);
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final storeRepositoryProvider = Provider<StoreRepository>((ref) => StoreRepository(
  authRepo: ref.read(authRepositoryProvider),
  userRepo: ref.read(userRepositoryProvider),
  analytics: ref.read(analyticsServiceProvider),
));

final storeProvider = StateNotifierProvider<StoreNotifier, StoreState>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  return StoreNotifier(ref.read(storeRepositoryProvider), uid);
});

final inventoryProvider = StreamProvider.autoDispose<Inventory>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  if (uid == null) return Stream.value(Inventory.empty);
  return ref.read(storeRepositoryProvider).watchInventory(uid);
});
