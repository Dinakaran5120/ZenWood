import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../auth/data/auth_repository.dart';
import '../auth/domain/auth_notifier.dart';
import '../../core/analytics/analytics_service.dart';
import '../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  Spin Wheel — Prize definitions
// ─────────────────────────────────────────────

enum SpinPrizeType { coins, bomb, theme, jackpot }

class SpinPrize {
  final String label;
  final String emoji;
  final SpinPrizeType type;
  final int value;           // coins amount or bomb count
  final String? themeId;
  final Color color;
  final double weight;       // relative probability

  const SpinPrize({
    required this.label,
    required this.emoji,
    required this.type,
    required this.value,
    this.themeId,
    required this.color,
    required this.weight,
  });
}

const List<SpinPrize> wheelPrizes = [
  SpinPrize(label: '50 Coins', emoji: '🪙', type: SpinPrizeType.coins,
      value: 50, color: Color(0xFFFFCA28), weight: 30),
  SpinPrize(label: '100 Coins', emoji: '💰', type: SpinPrizeType.coins,
      value: 100, color: Color(0xFFFFB300), weight: 25),
  SpinPrize(label: '1 Bomb', emoji: '💣', type: SpinPrizeType.bomb,
      value: 1, color: Color(0xFF757575), weight: 15),
  SpinPrize(label: '250 Coins', emoji: '💎', type: SpinPrizeType.coins,
      value: 250, color: Color(0xFF26C6DA), weight: 12),
  SpinPrize(label: '3 Bombs', emoji: '💥', type: SpinPrizeType.bomb,
      value: 3, color: Color(0xFFEF5350), weight: 8),
  SpinPrize(label: '500 Coins', emoji: '🏆', type: SpinPrizeType.coins,
      value: 500, color: Color(0xFFAB47BC), weight: 5),
  SpinPrize(label: 'Beach Theme', emoji: '🏖️', type: SpinPrizeType.theme,
      value: 0, themeId: 'beach', color: Color(0xFF29B6F6), weight: 3),
  SpinPrize(label: '1000 Coins!', emoji: '🎰', type: SpinPrizeType.jackpot,
      value: 1000, color: Color(0xFFFF7043), weight: 2),
];

// ─────────────────────────────────────────────
//  SpinWheelService — Firebase tracking
// ─────────────────────────────────────────────

class SpinWheelService {
  final FirebaseFirestore _db;
  final AuthRepository _authRepo;
  final AnalyticsService _analytics;

  SpinWheelService({
    required this._db,
    required this._authRepo,
    required this._analytics,
  });

  Future<bool> canSpin(String uid) async {
    final snap = await _db.collection('users').doc(uid).get();
    final lastSpinTs = snap.data()?['lastSpinAt'] as Timestamp?;
    if (lastSpinTs == null) return true;
    final diff = DateTime.now().difference(lastSpinTs.toDate());
    return diff.inHours >= 24;
  }

  Future<Duration> timeUntilNextSpin(String uid) async {
    final snap = await _db.collection('users').doc(uid).get();
    final lastSpinTs = snap.data()?['lastSpinAt'] as Timestamp?;
    if (lastSpinTs == null) return Duration.zero;
    final next = lastSpinTs.toDate().add(const Duration(hours: 24));
    final diff = next.difference(DateTime.now());
    return diff.isNegative ? Duration.zero : diff;
  }

  SpinPrize selectPrize() {
    final totalWeight = wheelPrizes.fold(0.0, (s, p) => s + p.weight);
    final roll = Random().nextDouble() * totalWeight;
    double cumulative = 0;
    for (final prize in wheelPrizes) {
      cumulative += prize.weight;
      if (roll <= cumulative) return prize;
    }
    return wheelPrizes.first;
  }

  Future<SpinPrize> executeSpin(String uid) async {
    final prize = selectPrize();
    final ref = _db.collection('users').doc(uid);

    await _db.runTransaction((tx) async {
      final updates = <String, dynamic>{
        'lastSpinAt': FieldValue.serverTimestamp(),
        'spinCount': FieldValue.increment(1),
      };

      if (prize.type == SpinPrizeType.coins ||
          prize.type == SpinPrizeType.jackpot) {
        updates['coins'] = FieldValue.increment(prize.value);
      } else if (prize.type == SpinPrizeType.bomb) {
        updates['inventory.bombs'] = FieldValue.increment(prize.value);
      } else if (prize.type == SpinPrizeType.theme && prize.themeId != null) {
        final snap = await tx.get(ref);
        final inv = snap.data()?['inventory'] as Map<String, dynamic>? ?? {};
        final themes = List<String>.from(inv['unlockedThemes'] ?? ['forest']);
        if (!themes.contains(prize.themeId!)) themes.add(prize.themeId!);
        updates['inventory.unlockedThemes'] = themes;
      }

      tx.update(ref, updates);

      // Log to spin_history
      final histRef = ref.collection('spin_history').doc();
      tx.set(histRef, {
        'prize': prize.label,
        'type': prize.type.name,
        'value': prize.value,
        'spunAt': FieldValue.serverTimestamp(),
      });
    });

    await _analytics.logSpinWheel(
        rewardType: prize.type.name, value: prize.value);
    return prize;
  }
}

// ─────────────────────────────────────────────
//  SpinWheelState + Notifier
// ─────────────────────────────────────────────

enum SpinStatus { idle, spinning, result, cooldown }

class SpinWheelState {
  final SpinStatus status;
  final SpinPrize? lastPrize;
  final bool canSpin;
  final Duration? timeUntilNext;
  final double targetAngle;

  const SpinWheelState({
    this.status = SpinStatus.idle,
    this.lastPrize,
    this.canSpin = true,
    this.timeUntilNext,
    this.targetAngle = 0,
  });

  SpinWheelState copyWith({
    SpinStatus? status,
    SpinPrize? lastPrize,
    bool? canSpin,
    Duration? timeUntilNext,
    double? targetAngle,
  }) =>
      SpinWheelState(
        status: status ?? this.status,
        lastPrize: lastPrize ?? this.lastPrize,
        canSpin: canSpin ?? this.canSpin,
        timeUntilNext: timeUntilNext ?? this.timeUntilNext,
        targetAngle: targetAngle ?? this.targetAngle,
      );
}

class SpinWheelNotifier extends StateNotifier<SpinWheelState> {
  final SpinWheelService _service;
  final String? _uid;

  SpinWheelNotifier(this._service, this._uid) : super(const SpinWheelState()) {
    _checkCanSpin();
  }

  Future<void> _checkCanSpin() async {
    if (_uid == null) return;
    final can = await _service.canSpin(_uid!);
    Duration? until;
    if (!can) until = await _service.timeUntilNextSpin(_uid!);
    state = state.copyWith(
      canSpin: can,
      status: can ? SpinStatus.idle : SpinStatus.cooldown,
      timeUntilNext: until,
    );
  }

  Future<SpinPrize?> spin() async {
    if (!state.canSpin || _uid == null) return null;
    if (state.status == SpinStatus.spinning) return null;

    // Pre-select prize for deterministic landing
    final prize = _service.selectPrize();

    // Calculate target angle for this prize
    final prizeIndex = wheelPrizes.indexOf(prize);
    final sliceAngle = (pi * 2) / wheelPrizes.length;
    // Spin at least 5 full rotations + land on prize
    final spins = 5 + Random().nextInt(3);
    final targetAngle = spins * pi * 2 +
        (wheelPrizes.length - prizeIndex) * sliceAngle -
        sliceAngle / 2;

    state = state.copyWith(
      status: SpinStatus.spinning,
      targetAngle: targetAngle,
    );

    // Persist to Firebase (happens during animation)
    await _service.executeSpin(_uid!);

    return prize;
  }

  void onSpinComplete(SpinPrize prize) {
    state = state.copyWith(
      status: SpinStatus.result,
      lastPrize: prize,
      canSpin: false,
    );
  }

  void dismissResult() {
    state = state.copyWith(status: SpinStatus.cooldown, lastPrize: null);
    _checkCanSpin();
  }
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final spinWheelServiceProvider = Provider<SpinWheelService>((ref) =>
    SpinWheelService(
      db: FirebaseFirestore.instance,
      authRepo: ref.read(authRepositoryProvider),
      analytics: ref.read(analyticsServiceProvider),
    ));

final spinWheelProvider =
    StateNotifierProvider<SpinWheelNotifier, SpinWheelState>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  return SpinWheelNotifier(ref.read(spinWheelServiceProvider), uid);
});

// ─────────────────────────────────────────────
//  Spin Wheel Screen
// ─────────────────────────────────────────────

class SpinWheelScreen extends ConsumerStatefulWidget {
  final GameThemeData theme;
  const SpinWheelScreen({super.key, required this.theme});

  @override
  ConsumerState<SpinWheelScreen> createState() => _SpinWheelScreenState();
}

class _SpinWheelScreenState extends ConsumerState<SpinWheelScreen>
    with TickerProviderStateMixin {
  late AnimationController _spinCtrl;
  late AnimationController _resultCtrl;
  late AnimationController _glowCtrl;
  late Animation<double> _spinAnim;
  late Animation<double> _resultScale;

  SpinPrize? _pendingPrize;
  double _currentAngle = 0;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4000),
    );
    _resultCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _resultScale = CurvedAnimation(
        parent: _resultCtrl, curve: Curves.elasticOut);
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    _resultCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _triggerSpin() async {
    final notifier = ref.read(spinWheelProvider.notifier);
    final prize = await notifier.spin();
    if (prize == null) return;

    _pendingPrize = prize;
    final state = ref.read(spinWheelProvider);

    // Animate from current angle to target
    _spinAnim = Tween<double>(
      begin: _currentAngle,
      end: _currentAngle + state.targetAngle,
    ).animate(CurvedAnimation(
      parent: _spinCtrl,
      curve: const _SpinCurve(), // custom deceleration
    ));

    _spinCtrl.reset();
    _spinCtrl.forward().then((_) {
      _currentAngle = _spinAnim.value % (pi * 2);
      if (_pendingPrize != null) {
        notifier.onSpinComplete(_pendingPrize!);
        _resultCtrl.forward(from: 0);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final wheelState = ref.watch(spinWheelProvider);
    final colors = widget.theme.colors;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        children: [
          _WheelHeader(colors: colors),
          const Spacer(),

          // Glow ring + wheel
          AnimatedBuilder(
            animation: Listenable.merge([_spinCtrl, _glowCtrl]),
            builder: (ctx, _) {
              final angle = _spinCtrl.isAnimating
                  ? _spinAnim.value
                  : _currentAngle;
              return Stack(
                alignment: Alignment.center,
                children: [
                  // Outer glow ring
                  Container(
                    width: 280 + _glowCtrl.value * 10,
                    height: 280 + _glowCtrl.value * 10,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: colors.glowColor.withOpacity(
                              0.2 + _glowCtrl.value * 0.15),
                          blurRadius: 30 + _glowCtrl.value * 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                  ),
                  // Wheel
                  Transform.rotate(
                    angle: angle,
                    child: CustomPaint(
                      size: const Size(270, 270),
                      painter: _WheelPainter(prizes: wheelPrizes),
                    ),
                  ),
                  // Center hub
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: colors.panelBg,
                      border: Border.all(color: colors.panelBorder, width: 3),
                      boxShadow: [
                        BoxShadow(
                            color: colors.glowColor.withOpacity(0.4),
                            blurRadius: 10)
                      ],
                    ),
                    child: const Icon(Icons.star, color: Colors.amber, size: 20),
                  ),
                  // Pointer
                  Positioned(
                    top: 0,
                    child: CustomPaint(
                      size: const Size(24, 30),
                      painter: _PointerPainter(color: colors.glowColor),
                    ),
                  ),
                ],
              );
            },
          ),

          const Spacer(),

          // Spin button / cooldown
          Padding(
            padding: const EdgeInsets.fromLTRB(40, 0, 40, 32),
            child: wheelState.status == SpinStatus.cooldown
                ? _CooldownTimer(
                    duration: wheelState.timeUntilNext ?? Duration.zero,
                    colors: colors,
                  )
                : _SpinButton(
                    colors: colors,
                    enabled: wheelState.canSpin &&
                        wheelState.status != SpinStatus.spinning,
                    onSpin: _triggerSpin,
                  ),
          ),

          // Result popup
          if (wheelState.status == SpinStatus.result &&
              wheelState.lastPrize != null)
            _PrizePopup(
              prize: wheelState.lastPrize!,
              colors: colors,
              scale: _resultScale,
              onDismiss: () {
                ref.read(spinWheelProvider.notifier).dismissResult();
                _resultCtrl.reset();
              },
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Wheel Painter
// ─────────────────────────────────────────────

class _WheelPainter extends CustomPainter {
  final List<SpinPrize> prizes;
  const _WheelPainter({required this.prizes});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    final sliceAngle = (pi * 2) / prizes.length;
    final textPainter = TextPainter(textDirection: TextDirection.ltr);

    for (int i = 0; i < prizes.length; i++) {
      final start = i * sliceAngle - pi / 2;
      final prize = prizes[i];

      // Slice fill
      final paint = Paint()
        ..color = prize.color
        ..style = PaintingStyle.fill;
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: radius),
          start, sliceAngle, true, paint);

      // Slice border
      final borderPaint = Paint()
        ..color = Colors.black.withOpacity(0.15)
        ..strokeWidth = 1.5
        ..style = PaintingStyle.stroke;
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: radius),
          start, sliceAngle, true, borderPaint);

      // Emoji + label
      canvas.save();
      canvas.translate(center.dx, center.dy);
      canvas.rotate(start + sliceAngle / 2);

      // Emoji
      textPainter.text = TextSpan(
        text: prize.emoji,
        style: const TextStyle(fontSize: 18),
      );
      textPainter.layout();
      textPainter.paint(
          canvas,
          Offset(radius * 0.55 - textPainter.width / 2,
              -textPainter.height / 2));

      // Label
      textPainter.text = TextSpan(
        text: prize.label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 9,
          fontWeight: FontWeight.bold,
          shadows: [Shadow(color: Colors.black, blurRadius: 3)],
        ),
      );
      textPainter.layout(maxWidth: radius * 0.4);
      textPainter.paint(
          canvas,
          Offset(radius * 0.62, -textPainter.height / 2));

      canvas.restore();
    }

    // Outer ring
    final ringPaint = Paint()
      ..color = Colors.white.withOpacity(0.3)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;
    canvas.drawCircle(center, radius - 1, ringPaint);
  }

  @override
  bool shouldRepaint(_WheelPainter old) => false;
}

// ─────────────────────────────────────────────
//  Pointer Painter
// ─────────────────────────────────────────────

class _PointerPainter extends CustomPainter {
  final Color color;
  const _PointerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    final path = Path()
      ..moveTo(size.width / 2, size.height)
      ..lineTo(0, 0)
      ..lineTo(size.width, 0)
      ..close();
    canvas.drawPath(path, paint);
    canvas.drawPath(
        path,
        Paint()
          ..color = Colors.white.withOpacity(0.4)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1);
  }

  @override
  bool shouldRepaint(_) => false;
}

// ─────────────────────────────────────────────
//  Custom spin easing — fast then slow
// ─────────────────────────────────────────────

class _SpinCurve extends Curve {
  const _SpinCurve();

  @override
  double transformInternal(double t) {
    // Accelerate to 0.3 then decelerate
    if (t < 0.3) return Curves.easeIn.transform(t / 0.3) * 0.3;
    return 0.3 + Curves.decelerate.transform((t - 0.3) / 0.7) * 0.7;
  }
}

// ─────────────────────────────────────────────
//  Spin Button
// ─────────────────────────────────────────────

class _SpinButton extends StatefulWidget {
  final GameThemeColors colors;
  final bool enabled;
  final VoidCallback onSpin;

  const _SpinButton({
    required this.colors,
    required this.enabled,
    required this.onSpin,
  });

  @override
  State<_SpinButton> createState() => _SpinButtonState();
}

class _SpinButtonState extends State<_SpinButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) => GestureDetector(
        onTap: widget.enabled ? widget.onSpin : null,
        child: Transform.scale(
          scale: widget.enabled ? 1.0 + _pulse.value * 0.03 : 1.0,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 18),
            decoration: BoxDecoration(
              gradient: widget.enabled
                  ? LinearGradient(
                      colors: [c.buttonPrimary, c.buttonSecondary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : null,
              color: widget.enabled ? null : c.panelBorder.withOpacity(0.2),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: widget.enabled ? c.panelBorder : c.panelBorder.withOpacity(0.2),
              ),
              boxShadow: widget.enabled
                  ? [
                      BoxShadow(
                        color: c.glowColor.withOpacity(
                            0.3 + _pulse.value * 0.2),
                        blurRadius: 20 + _pulse.value * 10,
                        offset: const Offset(0, 4),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  widget.enabled ? '🎰' : '⏳',
                  style: const TextStyle(fontSize: 24),
                ),
                const SizedBox(width: 12),
                Text(
                  widget.enabled ? 'SPIN NOW — FREE!' : 'SPINNING...',
                  style: TextStyle(
                    color: widget.enabled
                        ? c.textPrimary
                        : c.textPrimary.withOpacity(0.4),
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Cooldown Timer
// ─────────────────────────────────────────────

class _CooldownTimer extends StatefulWidget {
  final Duration duration;
  final GameThemeColors colors;
  const _CooldownTimer({required this.duration, required this.colors});

  @override
  State<_CooldownTimer> createState() => _CooldownTimerState();
}

class _CooldownTimerState extends State<_CooldownTimer> {
  late Duration _remaining;

  @override
  void initState() {
    super.initState();
    _remaining = widget.duration;
    _tick();
  }

  void _tick() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      setState(() {
        _remaining = _remaining.inSeconds > 0
            ? _remaining - const Duration(seconds: 1)
            : Duration.zero;
      });
      if (_remaining.inSeconds > 0) _tick();
    });
  }

  @override
  Widget build(BuildContext context) {
    final h = _remaining.inHours.toString().padLeft(2, '0');
    final m = (_remaining.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_remaining.inSeconds % 60).toString().padLeft(2, '0');
    final c = widget.colors;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: BoxDecoration(
        color: c.panelBg,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: c.panelBorder.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text('Next free spin in',
              style: TextStyle(
                  color: c.textPrimary.withOpacity(0.5), fontSize: 13)),
          const SizedBox(height: 6),
          Text(
            '$h:$m:$s',
            style: TextStyle(
              color: c.textPrimary,
              fontSize: 32,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
              shadows: [Shadow(color: c.glowColor, blurRadius: 8)],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Prize Popup overlay
// ─────────────────────────────────────────────

class _PrizePopup extends StatelessWidget {
  final SpinPrize prize;
  final GameThemeColors colors;
  final Animation<double> scale;
  final VoidCallback onDismiss;

  const _PrizePopup({
    required this.prize,
    required this.colors,
    required this.scale,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: GestureDetector(
        onTap: onDismiss,
        child: Container(
          color: Colors.black.withOpacity(0.7),
          child: Center(
            child: ScaleTransition(
              scale: scale,
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 40),
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: colors.panelBg,
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(
                    color: prize.color,
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: prize.color.withOpacity(0.5),
                      blurRadius: 40,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(prize.emoji,
                        style: const TextStyle(fontSize: 64)),
                    const SizedBox(height: 12),
                    Text(
                      'YOU WON!',
                      style: TextStyle(
                        color: colors.textPrimary.withOpacity(0.5),
                        fontSize: 13,
                        letterSpacing: 3,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      prize.label,
                      style: TextStyle(
                        color: colors.textPrimary,
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        shadows: [Shadow(color: prize.color, blurRadius: 12)],
                      ),
                    ),
                    const SizedBox(height: 24),
                    GestureDetector(
                      onTap: onDismiss,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 32, vertical: 12),
                        decoration: BoxDecoration(
                          color: prize.color,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Text(
                          'AWESOME!',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _WheelHeader extends StatelessWidget {
  final GameThemeColors colors;
  const _WheelHeader({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child:
                Icon(Icons.arrow_back_ios, color: colors.textPrimary, size: 20),
          ),
          const SizedBox(width: 12),
          Text(
            'LUCKY SPIN',
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 22,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const Spacer(),
          const Text('🎰', style: TextStyle(fontSize: 24)),
        ],
      ),
    );
  }
}
