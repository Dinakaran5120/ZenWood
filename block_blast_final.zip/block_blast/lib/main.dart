import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'firebase_options.dart';
import 'core/analytics/analytics_service.dart';
import 'core/performance/performance_optimizer.dart';
import 'features/admob/admob_service.dart';
import 'features/auth/domain/auth_notifier.dart';
import 'features/auth/presentation/login_screen.dart';
import 'features/game/game_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  configureImageCache();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(true);
  FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
  PlatformDispatcher.instance.onError = (error, stack) {
    FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    return true;
  };
  runApp(const ProviderScope(child: BlockBlastApp()));
}

class BlockBlastApp extends ConsumerStatefulWidget {
  const BlockBlastApp({super.key});
  @override
  ConsumerState<BlockBlastApp> createState() => _BlockBlastAppState();
}

class _BlockBlastAppState extends ConsumerState<BlockBlastApp> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await ref.read(analyticsServiceProvider).initialize();
    await ref.read(adMobServiceProvider).initialize();
    ref.read(performanceProvider);
    if (mounted) setState(() => _ready = true);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Block Blast',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF4CAF50),
          secondary: Color(0xFF7FD96B),
        ),
      ),
      home: _ready ? const AppShell() : const _SplashScreen(),
    );
  }
}

class AppShell extends ConsumerWidget {
  const AppShell({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authNotifierProvider);
    return switch (auth.status) {
      AuthStatus.initial || AuthStatus.loading => const _SplashScreen(),
      AuthStatus.unauthenticated || AuthStatus.error => const LoginScreen(),
      AuthStatus.authenticated => auth.needsUsername
          ? const UsernameSetupScreen()
          : const GameScreen(),
    };
  }
}

class _SplashScreen extends StatefulWidget {
  const _SplashScreen();
  @override
  State<_SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<_SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this, duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050E05),
      body: Center(
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Transform.scale(
                scale: 0.92 + _ctrl.value * 0.08,
                child: Container(
                  width: 100, height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF0D1F0D),
                    boxShadow: [BoxShadow(
                      color: const Color(0xFF4CAF50).withOpacity(0.25 + _ctrl.value * 0.25),
                      blurRadius: 40, spreadRadius: 8,
                    )],
                  ),
                  child: const Icon(Icons.grid_view_rounded, color: Color(0xFF7FD96B), size: 50),
                ),
              ),
              const SizedBox(height: 28),
              const Text('BLOCK BLAST', style: TextStyle(
                color: Color(0xFFE8F5E0), fontSize: 28,
                fontWeight: FontWeight.bold, letterSpacing: 5,
              )),
              const SizedBox(height: 40),
              SizedBox(width: 24, height: 24, child: CircularProgressIndicator(
                color: const Color(0xFF4CAF50).withOpacity(0.6), strokeWidth: 2,
              )),
            ],
          ),
        ),
      ),
    );
  }
}
